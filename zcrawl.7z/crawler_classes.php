<?php
require_once('browser_classes.php');
require_once('pageParser_classes.php');
require_once('crawlerTool_classes.php');

class Crawler
{
    private $hideAndSeek = false;
    private $mimicBrowser = false;
    private $maxErrorsPerBrowser = 10;

    private $browsers = array();
    private $errorLog = '';
    private $mailsSent = array();

    /** delay between requests options **/
    private $min_delay = 0;
    private $max_delay = 0;

    public function __construct($config = array())
    {
        foreach($config as $key => $value){
            $this->$key = $value;
        }
        $this->setUpBrowsers();
    }

    /**
     * Perform GET or POST request
     *
     * @param $url
     * @param bool $postData
     * @param string $refer
     * @param int $try
     * @return mixed|string
     */
    public function request($url, $postData = false, $refer = '', $try = 0)
    {
        sleep(rand($this->min_delay, $this->max_delay));
        /** @var $browser Browser */
        $browser = $this->getNextBrowser();
        try {
            $html = $browser->request($url, $postData, $refer, $try);
        } catch (CurlUnexpectedErrorException $e) {
            $this->prepareMailDevNotify($url, $browser, $e->getMessage());
            if($this->needToRetryRequest($browser)){
                $html = $this->request($url, $postData, $refer, $try);
            } else {
                return '';
            }
        } catch (OutOfBrowsersException $e) {
            $this->mailDevNotify('outOfBrowsers', $url);
            return '';
        }
        return $html;
    }

    /**
     * Enable delay between requests
     *
     * @param integer $min_delay
     * @param integer $max_delay
     */
    public function enable_delay_between_requests($min_delay, $max_delay)
    {
        $this->min_delay = intval($min_delay);
        $this->max_delay = intval($max_delay);
    }

    /**
     * Enable or disable cookies
     *
     * @param boolean $boolean
     */
    public function use_cookies($boolean)
    {
        foreach ($this->browsers as $browser) {
            /** @var $browser Browser */
            $browser->setEnableCookies($boolean);
        }
    }

    /**
     * Clean cookies
     */
    public function clean_cookies()
    {
        foreach ($this->browsers as $browser) {
            /** @var $browser Browser */
            $browser->cleanCookies();
        }
    }

    /**
     * Checks if it is usefull to send the request again.
     *
     * @param $browser Browser
     * @return bool
     */
    private function needToRetryRequest($browser){
        if (!empty($this->hideAndSeek)){
            if($browser->getAmountOfEncounteredErrors() > $this->maxErrorsPerBrowser){
                $this->deleteCurrentBrowser();
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Set up a list of Browsers we can use to send requests to the website.
     */
    private function setUpBrowsers()
    {
        if (empty($this->hideAndSeek)) {
            $this->createBrowsers(1);
        } else {
            $this->createBrowsers(5);
        }
    }

    /**
     * Create a given amount of browsers.
     *
     * @param $numberOfBrowsers
     */
    private function createBrowsers($numberOfBrowsers)
    {
        for ($i = 0; $i < $numberOfBrowsers; $i++) {
            $config = $this->getConfigForBrowser($i);
            $this->browsers[] = $this->createBrowser($config);
        }
    }

    /**
     * Create a Browser object with given configuration.
     *
     * @param $config
     * @return browser
     */
    private function createBrowser($config)
    {
        $browser = new browser($config);
        return $browser;
    }

    /**
     * Delete current browser.
     * Considering we pushed the current browser to the top of the stack, we can just pop it.
     */
    private function deleteCurrentBrowser(){
        array_pop($this->browsers);
    }

    /**
     * Get the next browser in the list.
     * We grab the first browser in the list,
     * and move it to the back of the list to
     * make sure the browsers rotate nicely.
     *
     * @return mixed
     * @throws OutOfBrowsersException
     */
    private function getNextBrowser()
    {
        if(empty($this->browsers)){
            echo 'geen browsers meer <br>';
            throw new OutOfBrowsersException('No more browsers');
        }
        $browser = array_shift($this->browsers);
        array_push($this->browsers, $browser);
        return $browser;
    }

    /**
     * Generate a config file for a browser.
     *
     * @param $browserNumber
     * @return array
     */
    private function getConfigForBrowser($browserNumber)
    {

        $configForBrowser = array(
            'cookie_name' => 'cookie_' . $browserNumber . '.txt',
        );
        if (!empty($this->hideAndSeek)) {
            $configForBrowser['header_accept'] = $this->getHttpAccept();
            $configForBrowser['header_ua'] = $this->getHttpUserAgent();
            $configForBrowser['header_accept_lang'] = $this->getHttpAcceptLanguage();
            $configForBrowser['proxy_address'] = $this->getProxyForBrowser();
            $configForBrowser['proxy_type'] = 'http';
            $configForBrowser['proxy_pwd'] = '';
            $configForBrowser['maxEncounteredErrorsBeforeShutdown'] = $this->maxErrorsPerBrowser;
        }
        if(!empty($this->mimicBrowser)){
            $configForBrowser['mimic_browser'] = true;
        }
        return $configForBrowser;
    }

    /**
     * Generate a random HTTP_ACCEPT header
     *
     * @return mixed
     */
    private function getHttpAccept()
    {
        $httpAcceptList = array(
            'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'text/html, application/xhtml+xml, */*',
            'text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/webp, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1',
        );
        $randomIndex = array_rand($httpAcceptList);
        return $httpAcceptList[$randomIndex];
    }

    /**
     * Generate a random HTTP_USER_AGENT
     *
     * @return mixed
     */
    private function getHttpUserAgent()
    {
        $httpUserAgentList = array(
            'Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.116 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/536.30.1 (KHTML, like Gecko) Version/6.0.5 Safari/536.30.1',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1944.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 5.1; rv:31.0) Gecko/20100101 Firefox/31.0',
            'Mozilla/5.0 (Windows NT 6.0; rv:25.0) Gecko/20100101 Firefox/25.0',
            'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.0; Trident/5.0',
            'Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko',
            'Mozilla/5.0 (iPad; CPU OS 4_3_5 like Mac OS X; en-us) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8L1 Safari/6533.18.5',
            'Mozilla/5.0 (iPad; CPU OS 7_0 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 7_0 like Mac OS X; en-us) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11A465 Safari/9537.53',
            'Mozilla/5.0 (Linux; Android 4.3; Nexus 10 Build/JSS15Q) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.72 Safari/537.36',
            'Mozilla/5.0 (Linux; Android 4.3; Nexus 7 Build/JSS15Q) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/29.0.1547.72 Safari/537.36',
            'Mozilla/5.0 (iPad; CPU OS 7_0_6 like Mac OS X) AppleWebKit/537.51.1 (KHTML, like Gecko) Version/7.0 Mobile/11B651 Safari/9537.53',
            'Mozilla/5.0 (compatible; MSIE 10.6; Windows NT 6.1; Trident/5.0; InfoPath.2; SLCC1; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET CLR 2.0.50727) 3gpp-gba UNTRUSTED/1.0',
            'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0)',
            'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0; GTB7.4; InfoPath.2; SV1; .NET CLR 3.3.69573; WOW64; en-US)',
            'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; WOW64; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET CLR 1.0.3705; .NET CLR 1.1.4322)',
            'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0; .NET CLR 2.7.58687; SLCC2; Media Center PC 5.0; Zune 3.4; Tablet PC 3.6; InfoPath.3)',
        );
        $randomIndex = array_rand($httpUserAgentList);
        return $httpUserAgentList[$randomIndex];
    }

    /**
     * generate a random HTTP_ACCEPT_LANGUAGE
     *
     * @return mixed
     */
    private function getHttpAcceptLanguage()
    {
        $httpAcceptLanguageList = array(
            'en-US,en;q=0.5',
            'en-US,en;q=0.8,nl;q=0.6,fr;q=0.4',
            'en-us',
            'nl-be',
            'nl-BE',
            'nl-BE,nl;q=0.9,en;q=0.8',
        );
        $randomIndex = array_rand($httpAcceptLanguageList);
        return $httpAcceptLanguageList[$randomIndex];
    }

    /**
     * Get a proxy for a Browser. Grab the first
     * proxy in the list and push it to the back
     * of the list to make sure it rotates nicely.
     *
     * @return mixed
     */
    private function getProxyForBrowser()
    {
        static $proxies = array();
        if (empty($proxies)) {
            $proxies = $this->get_proxy_list();
        }
        $proxy = array_shift($proxies);
        array_push($proxies, $proxy);
        return $proxy;
    }

    /**
     * Get the list of proxies.
     *
     * @return array|bool
     */
    private function get_proxy_list()
    {
        $proxies = array();
        if (!is_readable('../../proxies.txt')) {
            echo "Could not find proxies.txt<br>\r\n";
            return false;
        }

        foreach (file('../../proxies.txt') as $proxy) {
            $proxy = trim($proxy);
            if (empty($proxy)) {
                continue;
            }
            $proxies[] = $proxy;
        }
        if (empty($proxies)) {
            return false;
        }

        return $proxies;
    }

    /**
     * Send a mail to Dev-Notify.
     *
     * @param $type
     * @param $url
     * @param $error
     * @return bool
     */
    private function mailDevNotify($type, $url, $error = ''){
        if(array_key_exists($type, $this->mailsSent) && $this->mailsSent[$type] > 0){
            return false;
        }
        $body = '';
        switch($type){
            case 'outOfBrowsers':
                $body .= 'Ran out of browsers when trying to reach: ' . $url . PHP_EOL;
                $body .= 'This implies that there is either something wrong with the website, or our IP is blocked.' . PHP_EOL;
                if(empty($this->hideAndSeek)){
                    $body .= 'The crawler is not running Hide & Seek, perhaps, if the problem persists, this crawler should run Hide & Seek in the future.' . PHP_EOL;
                } else {
                    $body .= 'The crawler is running Hide & Seek. It is possible that all our IPs are blocked.' . PHP_EOL;
                }
                break;
            default:
                return false;
                break;
        }
        if(!empty($this->errorLog)){
            $body .= PHP_EOL . 'Errors occured during this crawl: ';
            $body .= $this->errorLog;
        }
        $this->mailsSent[$type] = 1;
        $title = '[Crawler_classes] Zimmo Crawler problem.';
        $address = 'dev-notify@spiritus.be';
        $headers = 'From: spider4@spiritus.com' . PHP_EOL;
        mail($address, $title, $body, $headers);
    }

    /**
     * @param $url
     * @param $browser Browser
     * @param $errorMessage
     */
    private function prepareMailDevNotify($url, $browser, $errorMessage){
        $proxy = $browser->getProxyAddress();
        $errorMessage =  PHP_EOL . '-----------------------' . PHP_EOL;
        $errorMessage .= 'Error occurred going to: '. $url . PHP_EOL;
        $errorMessage .= 'Using Browser: '. $browser->getHeaderUa() . PHP_EOL;
        $errorMessage .= 'Using Proxy: '. (!empty($proxy) ? $browser->getProxyAddress() : 'None') . PHP_EOL;
        $errorMessage .= 'Encountered '. $browser->getAmountOfEncounteredErrors() .' errors' . PHP_EOL;
        $errorMessage .= 'Last Error: '. $errorMessage . PHP_EOL;
        $this->errorLog .= $errorMessage;
    }

    /**
     * NOT USED! Set script dir
     * Some indexfiles still have this. To make sure they don't crash I copied this function.
     *
     * @param string $dir
     */
    public function set_script_dir($dir)
    {

    }

    /**
     * Enable or disable Expect: header
     *
     * @param $boolean
     */
    public function set_except_header($boolean)
    {
        foreach ($this->browsers as $browser) {
            /** @var $browser Browser */
            $browser->setExceptHeader($boolean);
        }
    }

    /**
     * Set user agent
     *
     * @param $string
     */
    public function set_useragent($string)
    {
        foreach ($this->browsers as $browser) {
            /** @var $browser Browser */
            $browser->setUseragent($string);
        }
    }

    /**
     * Set Accept-Language: header value
     *
     * @param $string
     */
    public function set_accept_lang($string)
    {
        foreach ($this->browsers as $browser) {
            /** @var $browser Browser */
            $browser->setAcceptLang($string);
        }
    }

    /**
     * Enable or disable X-Requested-With: XMLHttpRequest header
     *
     * @param $boolean
     */
    public function set_xmlhttpreq($boolean)
    {
        foreach ($this->browsers as $browser) {
            /** @var $browser Browser */
            $browser->setXmlHttpReq($boolean);
        }
    }

    /**
     * Enable or disable gzip header in curl
     *
     * @param $boolean
     */
    public function use_gzip($boolean)
    {
        foreach ($this->browsers as $browser) {
            /** @var $browser Browser */
            $browser->setUseGzip($boolean);
        }
    }

    /**
     * Set whether a browser should mimic a real browser or not. (Download images and CSS/JS files)
     *
     * @param $boolean
     */
    public function setMimicBrowser($boolean)
    {
        foreach ($this->browsers as $browser) {
            /** @var $browser Browser */
            $browser->setMimicBrowser($boolean);
        }
    }
}

/* ============================= CONFIG ============================= */
set_time_limit(14400);//4hours limit, you can set 0 in crawler, if need more run time
error_reporting(E_ALL);
libxml_use_internal_errors(true);
date_default_timezone_set("Europe/Brussels");

$crawlerConfig = array();
if(isset($_GET['proxy'])){
    $crawlerConfig['hideAndSeek'] = $_GET['proxy'];
}
if(isset($_GET['mimicBrowser'])){
    $crawlerConfig['mimicBrowser'] = $_GET['mimicBrowser'];
}
if(isset($_GET['proxy']) && isset($_GET['maxErrorsPerBrowser'])){
    $crawlerConfig['maxErrorsPerBrowser'] = $_GET['maxErrorsPerBrowser'];
}

$crawler = new Crawler($crawlerConfig);

/* ============================= END CONFIG ========================== */