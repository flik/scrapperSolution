<?php

$urls = array( 'http://220.247.236.35/JobatarAPI/api/Interview/4C5321354FFE/IntroductionVideo',
	      'http://220.247.236.35/JobatarAPI/api/Interview/4C5321354FFE/ThankingVideo',
	      'http://220.247.236.35/JobatarAPI/api/Interview/4C5321354FFE/CorporateVideo',
	      'http://220.247.236.35/JobatarAPI/api/Interview/4C5321354FFE/TipsVideo',
	      'http://220.247.236.35/JobatarAPI/api/Interview/4C5321354FFE/Artwork',
	      'http://220.247.236.35/JobatarAPI/api/Interview/4C5321354FFE/Instructions',
	      'http://220.247.236.35/JobatarAPI/api/Interview/4C5321354FFE/NextQuestion',
	      'http://220.247.236.35/JobatarAPI/api/Interview/4C5321354FFE/UploadAnswer' 
    
);
foreach($urls as $uri){
    $cont = file_get_contents($uri);
    $contents = utf8_encode($cont); 
    $ar = json_decode($contents, true); // returns array("foo" => "bar")
    debugx($uri);
    debug($ar);
    if(isset($ar['Url']))
	echo "<a href='".$ar['Url']."' target='_blank'>".$ar['Url']." </a><br>";
    
}



 //function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

///0514437586 President Line...

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}
