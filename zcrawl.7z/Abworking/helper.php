<?php

error_reporting(E_ALL);
ini_set('display_errors', '1'); 
 
//Blocked website
// http://www.nadimmo.be/ 
 
//Cookies Adjustment
$crawler->enable_delay_between_requests(5,10); 
if (isset($_GET['proxy']))	{ $crawler -> set_proxy($_GET['proxy']); }
$crawler->use_cookies(true);
$crawler->clean_cookies();
$crawler->use_gzip(false);

$start_links[STATUS_TAKEOVER] = array(
'http://www.immo-wereld.be/listing.php?klasse=handelspanden'                     => TYPE_COMMERCIAL,
);

$start_links[STATUS_FORRENT] = array(
'http://www.immo-wereld.be/listing.php?klasse=handelspanden'                     => TYPE_COMMERCIAL,
);
$startPages[STATUS_FORSALE] = array
(
    TYPE_HOUSE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/woningen-villas/"
    ),
    TYPE_APARTMENT        =>  array
    (
        "http://www.immo-isca.be/nl/Type/appartement/"
    ),
    TYPE_NONE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/opbrengstpanden/"
    ),
    TYPE_COMMERCIAL        =>  array
    (
        "http://www.immo-isca.be/nl/Type/handel-kantoor/"
    ),
    TYPE_GARAGE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/garages/"
    ),
    TYPE_PLOT        =>  array
    (
        "http://www.immo-isca.be/nl/Type/garages/"
    ),
);

$startPages[STATUS_FORRENT] = array();

//Saving Office
$propertyCount = 0; 
$properties = array();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "AConcept BVBA";
$office[TAG_OFFICE_URL] = "http://www.concept-bvba.be/";
$office[TAG_STREET] = "Mariakerksesteenweg";
$office[TAG_NUMBER] = "207";
$office[TAG_ZIP] = "9031";
$office[TAG_CITY] = "Gent (Drongen)";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "09 362 37 54";
$office[TAG_FAX] = "0475 50 55 65";
$office[TAG_EMAIL] = "info@concept-bvba.be";

CrawlerTool::saveOffice($office);

//Debuging Page detail
debugx($status.'->'.$type.'->'.'Page: -> '.$page);
	
	///Ajax to HTML
	$html = $crawler->request("http://www.immogie.be/wp-admin/admin-ajax.php", "action=wpp_property_overview_pagination&wpp_ajax_query%5Bshow_children%5D=true&wpp_ajax_query%5Bchild_properties_title%5D=Floor+plans+at+location%3A&wpp_ajax_query%5Bfancybox_preview%5D=true&wpp_ajax_query%5Bbottom_pagination_flag%5D=false&wpp_ajax_query%5Bthumbnail_size%5D=tiny_thumb&wpp_ajax_query%5Bsort_by_text%5D=Sort+By%3A&wpp_ajax_query%5Bsort_by%5D=menu_order&wpp_ajax_query%5Bsort_order%5D=ASC&wpp_ajax_query%5Btemplate%5D=false&wpp_ajax_query%5Bajax_call%5D=true&wpp_ajax_query%5Bdisable_wrapper%5D=false&wpp_ajax_query%5Bsorter_type%5D=buttons&wpp_ajax_query%5Bpagination%5D=on&wpp_ajax_query%5Bhide_count%5D=false&wpp_ajax_query%5Bper_page%5D=5&wpp_ajax_query%5Bstarting_row%5D=0&wpp_ajax_query%5Bunique_hash%5D=25243&wpp_ajax_query%5Bdetail_button%5D=false&wpp_ajax_query%5Bstats%5D=&wpp_ajax_query%5Bclass%5D=wpp_property_overview_shortcode&wpp_ajax_query%5Bin_new_window%5D=false&wpp_ajax_query%5Bquery%5D%5Bproperty_type%5D=Rental&wpp_ajax_query%5Bquery%5D%5Bsort_by%5D=menu_order&wpp_ajax_query%5Bquery%5D%5Bsort_order%5D=ASC&wpp_ajax_query%5Bquery%5D%5Bpagi%5D=0--5&wpp_ajax_query%5Bquery%5D%5Brequested_page%5D=2&wpp_ajax_query%5Bcurrent_page%5D=1&wpp_ajax_query%5Bsortable_attrs%5D%5Bmenu_order%5D=Default&wpp_ajax_query%5Bsortable_attrs%5D%5Bpost_title%5D=Title&wpp_ajax_query%5Bproperties%5D%5Btotal%5D=7&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=74&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=86&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=109&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=113&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=116&wpp_ajax_query%5Bpages%5D=2&wpp_ajax_query%5Bdefault_query%5D%5Bproperty_type%5D=Rental&wpp_ajax_query%5Bdefault_query%5D%5Bsort_by%5D=menu_order&wpp_ajax_query%5Bdefault_query%5D%5Bsort_order%5D=ASC&wpp_ajax_query%5Bdefault_query%5D%5Bpagi%5D=0--5&wpp_ajax_query%5Bdefault_query%5D%5Brequested_page%5D=2&wpp_ajax_query%5Brequested_page%5D=2");
	$ojb = json_decode($html);
	if(!empty($ojb))
	{
	    $html = $ojb->display;
	}
	
	////////////////////////////// Get Pictures by Script ///////////////////////////////////////////////
	   //if(preg_match("/Array\(([^"]*)\)/", $html, $match)){
   preg_match_all('#Array\((.*?)\)#s', $html, $result);
    
    $pics = array();
    
    foreach($result[1] as $res){
        $pics[] = str_replace("'","",$res);
    }
    unset($pics[0]);
    foreach($pics as $pic){
       $p = explode(', ',$pic);
       $picx = 'http://www.av-vastgoed.be/images/panden/'.$p[1];
       $picUrls[] = array(TAG_PICTURE_URL =>  $picx);
    }
    $property[TAG_PICTURES] = $picUrls;
   
	CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL])
//////////////////////////////////////////////////////////////////////////////////////////////////////////

// Address Zip condition
//when you see 'straat' or laan' in 'ligging, can you take by default zip 8300?
//crawl Kapellen always under zip 2950, Halle always under 2980, Deurne always 2100

	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	//Get Attribute

	$property[TAG_UNIQUE_URL_NL] = 'http://www.realtycare.be/'. $parser->getAttr($node, "href");
 
	///Separate text with comma like explode with regex
	preg_match("/Immo\s(.*),/", $text, $match);
 
	$property[TAG_ZIP] = $parser->extract_xpath("b[contains(text(), 'postcode:')]/following-sibling::text()[1]");
     
        $res = explode(' ', $adr);
	$property[TAG_CITY] = trim($res[count($res)-1]);
	
	//Parsing Address
	CrawlerTool::parseAddress( trim($adr), $property );
	
	$property[TAG_CITY] = trim($res[count($res)-1]);
	
	///Zip Fixation with city name  (because these cities are double in belgium with different zips, and then the parser does not know which one to choose)
	if(strtolower($property[TAG_CITY])=='kapellen')
		$property[TAG_ZIP] = "2950";
	
	if(strtolower($property[TAG_CITY])=='halle')
		$property[TAG_ZIP] = "2980";
	
	if(strtolower($property[TAG_CITY])=='deurne')
		$property[TAG_ZIP] = "2100";
		
	if(strtolower($property[TAG_CITY])=='tielt')
		$property[TAG_ZIP] = "8700";	
	
	//Getting Nodes with text
	$nodes = $parser->getNodes("a[. = 'Meer info']");
	 
	/// Geting html with paras
	$para = $parser->getHTML($parser->getNode("section[@class = 'entry']/p"));
	
	$para = str_replace('<br />','<br>',$para);
	$par = explode('<br>', $para);
	
	$imgHtml = $parser->getHTML( $node ); 
	$parserx = new PageParser( $imgHtml ); 

	///Getting link with node html
	$link = $parser->extract_xpath("div[@class = 'title']/h2/a/@href", RETURN_TYPE_TEXT, null, $node); 
	
	$price = $parser->extract_xpath("parent::div[1]/preceding-sibling::div[1]/h2", RETURN_TYPE_NUMBER, null, $node);
	
	// In case of special characters 	
	$parser = new PageParser($html,true);
	
	//instead
	$parser = new PageParser($html);
	// strip_tags for text
	
	// Get all text with Regex techniche (.*s)!s
	preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
	$res[1] = str_replace(chr(11),'',$res[1]);
	$property[TAG_TEXT_DESC_FR] = (strip_tags($res[1]));

	
	///Set  Street Detail another way
	$property[TAG_STREET]=(preg_match('/(.*?)\d/s',$adres,$res)) ? trim(strip_tags(($res[1]))) : '';
	preg_match('!\d+[A-Za-z]\d+|\d+\-\d+|\d+[A-Za-z]|\d+\s+\/\d+[A-Za-z]|\d+|$!',$adres,$res2);
	$property[TAG_NUMBER]=trim($res2[0]);

	
	
	// Seprate the Street
	$street=preg_replace('@,.+\Z@','',$adress);
	
	if(empty($property[TAG_NUMBER])) $property[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);

	/***********************************************************************/
	$address = $parser->extract_xpath("table[@class = 'infolijst']/tr/td[2]", RETURN_TYPE_TEXT); 
	CrawlerTool::parseAddress(preg_replace("/,|\//", "", $address), $property);
	//debugx($address);
	
	$addr = explode(' ',$address);
	$zip = trim($addr[count($addr)-2]);
	
	if(!empty($zip))
	    $property[TAG_ZIP] = $zip;
	
	//$property[TAG_STREET] = trim($addr[0]);
	$bx = explode(' ',$property[TAG_BOX_NUMBER]);
	
	if(isset($bx[2]))
	$property[TAG_BOX_NUMBER] = $bx[0];
	else
	unset($property[TAG_BOX_NUMBER]);
	
	$property[TAG_CITY] = trim($addr[count($addr)-1]);
	/***********************************************************/
	//Complex address 
	$street= $parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[1]");
	
	$property[TAG_CITY] = str_replace('REF','',str_replace('RES','',(preg_replace("/\(.*\)|\d/", "", $street ))));
	
	//Getting Just number
	$parser->regex("/(\d+)$/", $property[TAG_UNIQUE_URL_NL]);
	$parser->regex("/estate.id=(\d+)/", $property[TAG_UNIQUE_URL_NL] ); 
	
	$property[TAG_PRICE] = $parser->extract_regex("/(Prijsklasse.*)/", RETURN_TYPE_NUMBER);
	
	 
	 /// Never Crawl
	if(!empty(strpos($html,"Loué")))
		return;
	 
	$stpos = strpos($html, "in optie");
	if(!empty($stpos))
		return;

	$stpos = strpos($html, "met optie");
	if(!empty( $stpos ))
		return;
	
	$stpos = strpos($html, "optie");
	if(!empty( $stpos ))
		return;
	
	$stpos = strpos($html, "verkocht");
	if(!empty( $stpos ))
		return;
	 
	 ///Encoding Problem...
	$parser = new PageParser($html, true); 
	$property[TAG_TEXT_DESC_FR] = utf8_decode($parser->extract_xpath("table[@border = '1' and not(@cellpadding)]")); 
	$property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode($parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL)); 

	///Getting Unique ID
	CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL])
	
	CrawlerTool::toNumber(); 
	CrawlerTool::encode($property[TAG_STREET]);

	if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
	
	$hiddenFields = $parser->getNodes("input[@type = 'hidden']");

	$postData = "";
	foreach($hiddenFields as $field) {
	    $name = $parser->getAttr($field, "name");
	    $value = $parser->getAttr($field, "value");
	    if($name !== "__EVENTTARGET") {
		$postData .= "&" . $name . "=" . urlencode($value);
	    }
	}
	
	$pageList = array();

 	$property[TAG_TEXT_TITLE_NL]=$parser->extract_xpath("div[@class = 'bloc_content_title']/span[2]");
	
	if(empty($property[TAG_PRICE])) $property[TAG_PRICE] = $parser->extract_xpath("div[@class = 'bloc_content_title']/span[1]",RETURN_TYPE_NUMBER);
	$property[TAG_PRICE]=$parser->extract_xpath("div[@class = 'bloc_content_title']/span[1]",RETURN_TYPE_NUMBER);
	
	$property[TAG_TEXT_DESC_NL]= strip_tags($parser->extract_xpath("div[@class = 'description ']"));
	$property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);

	
	
	// Verkocht
	// Gewijzigd

	// website says type: meublé means that it is an apartment with furniture
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL], 999);
	
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(str_replace('meublé','apartment',$property[TAG_TEXT_DESC_NL]));
	
	$propertyStatus = CrawlerTool::getPropertyStatus($text);
	if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
	{
	    $property[TAG_STATUS] = $propertyStatus;
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////////////Clear Cookies
	$crawler->clean_cookies();
	 
	 
	 $property[TAG_PICTURES] =  $parser->extract_xpath("div[@class = 'camera_imgs']/@data-thumb", RETURN_TYPE_ARRAY, function($pics)
	{
	    $picUrls = array();
	    foreach($pics as $pic) {
	    $pic_src = explode("?",$pic);
	    $pic_url = "http://www.vastgoedlapeire.be".$pic_src[0];
		$picUrls[] = array(TAG_PICTURE_URL => $pic_url);
    
	    }
    
	    return $picUrls;
	});
	 
	////Pictures fixing
	////////////////////////////////////////////////////////////////////////////////////////////////////////////Clear Cookies
	
	//////////////////////////// ONE
	$property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox']", RETURN_TYPE_ARRAY, function($pics)
	{
		$picUrls = array();
		foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.uniximmo.com" . $pic);

		return $picUrls;
	});
 	
	$street = $parser->extract_xpath("div[@class= 'detail-part1']/table/tr[2]");
	
	//////////////////////////// TWO
	$pics = $parser->getNodes("ul[@class = 'bxSlider']/li/img");
	 
	foreach($pics as $picx){
	    
	    $pic = $parser->getAttr($picx, "src");        
	    $picUrls[] = array(TAG_PICTURE_URL => $pic);
	}
	
	$property[TAG_PICTURES] = $picUrls;

	//////////////////////////// THREE
	$property[TAG_PICTURES] =  $parser->extract_xpath("div[@id = 'wowslider-images']/a/img/@src", RETURN_TYPE_ARRAY, function($pics)
	{
	    $picUrls = array();
	    foreach($pics as $pic) {
    
		$picUrls[] = array(TAG_PICTURE_URL => $pic);
    
	    }
    
	    return $picUrls;
	});

	////Files 
	////////////////////////////////////////////////////////////////////////////////////////////////////////////Clear Cookies
	$files = array();
	$nodes = $parser->getNodes("a[contains(@href, 'GetFile.ashx?path=Documents')]");
	foreach($nodes as $node)
	{
		$fileUrl = "http://www.teamproperty.be/" . $parser->regex("/path=(.*)&/", $parser->getAttr($node, "href"));
		$fileTitle = $parser->getText($node);
		$files[] = array(TAG_FILE_URL => $fileUrl, TAG_FILE_TITLE_NL => $fileTitle);
	}
	if(!empty($files)) $property[TAG_FILES] = $files;
 
	$property[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
	     {
		     $fileUrls = array();
		     foreach($files as $file)
		     {
			     if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => "http://www.hetlandgoed.be/".str_replace('../','',$file));
		     }
		     return $fileUrls;
	});

    
    // get all the labels and there values 
    $Labels=$parser->extract_regex('@<td class="kenmerklabel">([^<>]+)</td>@',RETURN_TYPE_ARRAY);
    $Values=$parser->extract_regex('@<div class="field-item even">([^<>]+)</div>@',RETURN_TYPE_ARRAY);
    unset($Labels[count($Labels)-1]);
    
    *****************************************************************************************************
    $nodes = $parser->getNodes("table[@cellpadding=1][@border=0][@style='width: 100%;']/tr");
    foreach($nodes as $node)
    {
    $key = $parser->extract_xpath("td[1]",  RETURN_TYPE_TEXT, null, $node); 
    $val = $parser->extract_xpath("td[2]", RETURN_TYPE_TEXT, null, $node); 
    $k = setAtributesX($key);
    if(!empty($k))
        $property[$k] = GetExactAttrib($key,$val);
    else
        $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $key, TAG_VARIABLE_VALUE => $val);
    }

    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
    *****************************************************************************************************
    
    $nodes = $parser->getNodes("table[@cellpadding=1][@border=0][@style='width: 100%;']/tr/td[2]");
    //debug($nodes);
    foreach($nodes as $node)
    {
	$v = utf8_decode(trim($parser->getText($node)));
	//debugx($v);
	if(empty($v))
	 $vals[] = '-';
	 else
	 $vals[] = $v;
	
    }
   // debug( $vals);
    foreach($vals as $k=>$x){
	
	 
	if($x=="Ja" || $x=="Nee")
	$vars[str_replace(' ','_',$keys[$k])] = ($x=="Ja"?1:0);
	else
	$vars[str_replace(' ','_',$keys[$k])] = $x;
    }
     
     $nodes = $parser->extract_regex("/objectid=(\d+)/", RETURN_TYPE_ARRAY);
     
	$keys = $vals = $vars = array();
    
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////Setting attributes

 	$unmatched_variables = array();
	$attributes = $parser->getNodes("table[@class = 'full-width table details']/tr");
	foreach($attributes as $attr){
		
		$AttribDetail = explode(' ',trim($attr->nodeValue)); 
		 
		$attribute = setAtributesX(str_replace(' ','_', trim($AttribDetail[0]) ));
		if(!empty($attribute))
		    $property[$attribute] = ($AttribDetail[1] === "Ja" ? 1 : 0);
		else
		    $unmatched_variables[str_replace(' ','_', trim($AttribDetail[0])) ] = str_replace(' ','_', trim($AttribDetail[1])) ; 
		
	}
	  
	 
    if($property[TAG_BEDROOMS_TOTAL]<1)
	unset($property[TAG_BEDROOMS_TOTAL]);
	
    if($property[TAG_BATHROOMS_TOTAL]<1)
	unset($property[TAG_BATHROOMS_TOTAL]);

    if($property[TAG_GARAGES_TOTAL]<1)
	unset($property[TAG_GARAGES_TOTAL]);
	
	// In case of li 
	$parser->setQueryTemplate("li[contains(text(),'" .XPATH_QUERY_TEMPLATE . "')]");
	
	// In some case
	$parser->setQueryTemplate("b[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::text()[1]");
	
	// START using XPath query template
	$parser->setQueryTemplate("table[@cellpadding=1][@border=0][@style='width: 100%;']//td[contains(text(),'" .XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]"); 

	// In case of Lable in TD
	 $parser->setQueryTemplate("td[label[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]]/following-sibling::td[1]");

	//In case of TD and get next td val
	$parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    //kwh/m² = TAG_EPC_VALUE 
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC score", RETURN_TYPE_EPC);
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC Index:", RETURN_TYPE_EPC);
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("kwh/m", RETURN_TYPE_EPC);
    
    $property[TAG_KI] = $parser->extract_xpath("kadastraal inkomen", RETURN_TYPE_NUMBER);
    $property[TAG_KI_INDEX] = $parser->extract_xpath("kad.ink.", RETURN_TYPE_NUMBER);
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("bouwjaar", RETURN_TYPE_YEAR);
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("Renovatie jaar", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Bewoonbare opp.:", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Oppervlakte terrein:", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Aantal slaapkamers:", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toiletten aantal", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("garage aantal", RETURN_TYPE_NUMBER);
    $property[TAG_PARKINGS_TOTAL] = $parser->extract_xpath("parking buiten aantal", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FLOORS] = $parser->extract_xpath("verdiepingen aantal", RETURN_TYPE_NUMBER);
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Beschikbaar vanaf", RETURN_TYPE_UNIX_TIMESTAMP); 
    $property[TAG_COMMON_COSTS] = $parser->extract_xpath("lasten", RETURN_TYPE_NUMBER); 
    $property[TAG_GAS_CONNECTION] = ($parser->extract_xpath("gas") === "Ja" ? 1 : 0); 
    $property[TAG_CONNECTION_TO_WATER] = ($parser->extract_xpath("water") === "Ja" ? 1 : 0); 
    $property[TAG_TELEPHONE_CONNECTION] = ($parser->extract_xpath("telefoon") === "Ja" ? 1 : 0); 
    $property[TAG_LIFT] = ($parser->extract_xpath("lift") === "Ja" ? 1 : 0); 
    $property[TAG_FURNISHED] = ($parser->extract_xpath("Gemeubeld") === "Ja" ? 1 : 0); 
    $property[TAG_GARDEN_AVAILABLE] = ($parser->extract_xpath("Tuin") === "Ja" ? 1 : 0); 
    $property[TAG_OPEN_FIRE] = ($parser->extract_xpath("open haard aantal") ? 1 : 0); 
    $property[TAG_ALARM] = ($parser->extract_xpath("alarm") ? 1 : 0); 
    $property[TAG_PARLOPHONE] = ($parser->extract_xpath("parlofoon") ? 1 : 0); 
    $property[TAG_VIDEOPHONE] = ($parser->extract_xpath("videofoon") === "Ja" ? 1 : 0); 
	
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels:", RETURN_TYPE_NUMBER); 
	
    $property[TAG_LOT_WIDTH] 		= $parser->extract_xpath("Perceelbreedte:", RETURN_TYPE_NUMBER); 
    $property[TAG_LOT_DEPTH] 		= $parser->extract_xpath("Perceeldiepte:", RETURN_TYPE_NUMBER); 
    $property[TAG_CONSTRUCTION_TYPE] 	= $parser->extract_xpath("Type constructie:", RETURN_TYPE_TEXT);
    $property[TAG_FRONTAGE_WIDTH] 	= $parser->extract_xpath("Gevelbreedte:", RETURN_TYPE_NUMBER); 
    $property[TAG_HEATING_NL]		= $parser->extract_xpath("Winkel:", RETURN_TYPE_NUMBER); 
    $property[TAG_SHOWERS_TOTAL]        = $parser->extract_xpath("salle de douches nombre", RETURN_TYPE_NUMBER); 
    $property[TAG_FREE_FROM]            =  $parser->extract_xpath("beschikbaar vanaf", RETURN_TYPE_TEXT); 
    $property[TAG_KITCHEN_TYPE_FR]      = $parser->extract_xpath("keuken type", RETURN_TYPE_TEXT);  

    $property[TAG_SUBDIVISION_PERMIT]   = $parser->extract_xpath("Ligging:", RETURN_TYPE_NUMBER);
    $property[TAG_PRIORITY_PURCHASE]   = $parser->extract_xpath("keuken type", RETURN_TYPE_NUMBER);
    $property[TAG_HAS_PROCEEDING]   = $parser->extract_xpath("keuken type", RETURN_TYPE_NUMBER);

    ========
    $parser->extract_xpath("div[contains(@class, 'eight columns')]", RETURN_TYPE_TEXT_ALL);
    $keys = $vals = $vars = array();
    
    $nodes = $parser->getNodes("table[@cellpadding=1][@border=0][@style='width: 100%;']/tr/td[1]");
    foreach($nodes as $node)
    {
	//$imgHtml = $parser->getHTML( $node );
	 $key[] = $parser->getText($node); 
	 //debugx($text); 
	///Getting link with node html
	//$link = $parser->extract_xpath("div[@class = 'title']/h2/a/@href", RETURN_TYPE_TEXT, null, $node);
	
    }
    
    $nodes = $parser->getNodes("table[@cellpadding=1][@border=0][@style='width: 100%;']/tr/td[2]");
    foreach($nodes as $node)
    {
	//$imgHtml = $parser->getHTML( $node );
	 $vals[] = $parser->getText($node); 
	
    }
    
    foreach($vals as $k=>$v){
	if($v=="Ja" || $v=="Nee")
	$vars[str_replace(' ','_',$key[$k])] = $v=="Ja"?1:0
	else
	$vars[str_replace(' ','_',$key[$k])] = $v
    }
    
    $unmatched_variables = array(); 
    foreach ($vars as $label => $value)
    { 
	    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
    } 
    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables; 
    
    
    $unmatched_var_arr = array('Beschikbaar vanaf','Grootte terrein','keuken type','Tuin','buurt type','vloerbedekking type','vloerbedekking type','riolering','olietank','dubbele beglazing','schrijnwerkerij type','wasplaats');
	foreach($unmatched_var_arr as $var){
		$tag_unmatched_var = $parser->extract_xpath($var, RETURN_TYPE_TEXT);
		if($tag_unmatched_var){
			if($tag_unmatched_var=="Ja" || $tag_unmatched_var=="Nee")
				$property[TAG_UNMATCHED_VARIABLES][]=array(TAG_VARIABLE_LABEL=>$var,TAG_VARIABLE_VALUE=>$tag_unmatched_var=="Ja"?1:0);
			else
				$property[TAG_UNMATCHED_VARIABLES][]=array(TAG_VARIABLE_LABEL=>$var,TAG_VARIABLE_VALUE=>$tag_unmatched_var);
		}		
	}
    =======
    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Saving Project and Property

if($property['is_project']==1){
	unset($property['is_project']);
	
	$property[TAG_PROJECT_ID] = $property[TAG_UNIQUE_ID] ;
	CrawlerTool::saveProject($property);
    }else
	CrawlerTool::saveProperty($property);
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
///Clear Empity index
function removeEmptyIndex($property){
 foreach($property as $k=>$v){
		if(empty($v))
		unset($property[$k]);
		
			if(is_array($v)){ 
				foreach($v as $kx=>$vx){ 
					if(empty($vx)){ 
						unset($v[$kx]);
						unset($property[$k]);
					}
				}
			}	
	}
	return $property; 
}

function getLanguageText($crawler, &$property)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
    $html = str_replace("±", "", $html);
    $parser = new PageParser($html, true);

    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);

}

//Function for Handle Attributes 
function setAtributesX($key='',$lan='nl'){ 
    
    $attrib['nl'] = array('Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Badkamer'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'Kadastraal_inkomen'=>TAG_KI, 'Geïndexeerd_kad._inkomen'=>TAG_KI_INDEX,
			'Grondoppervlakte'=>TAG_SURFACE_GROUND, 'Gevelbreedte'=>TAG_FRONTAGE_WIDTH,
			'Verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Badkamer'=>TAG_BATHROOM_SURFACE,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'keuken'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Aantal_slaapkamers'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'Bouwjaar'=>TAG_CONSTRUCTION_YEAR, 'Bewoonb_opp.'=>TAG_SURFACE_GROUND,
			'Parkings'=>TAG_PARKINGS,'Garages'=>TAG_GARAGES_TOTAL, 'Aantal_garages'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'Bewoonbare_oppervlakte'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Tuin'=>TAG_WINTERGARDENS,
			'Gemeubeld'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terras'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE, 'EPC'=>TAG_EPC_VALUE, 'EPC_Certificaat'=>TAG_EPC_CERTIFICATE_NUMBER,
			'Bestemming'=>TAG_MOST_RECENT_DESTINATION, 'Verkavelingvergunning'=>TAG_SUBDIVISION_PERMIT, 'Bouwvergunning'=>TAG_PLANNING_PERMISSION,
			'Voorkooprecht'=>TAG_PRIORITY_PURCHASE
			);
    
    $attrib['fr'] = array( 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Nombre_de_salle_de_bain'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'cuisine'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'année_de_construction_année'=>TAG_CONSTRUCTION_YEAR, 'Taille_terrain_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'surface_nette_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Jardin'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrasse'=>TAG_TERRACES,'Facades'=>TAG_AMOUNT_OF_FACADES,
			'Catégorie'=>TAG_TYPE
			);
    
    $attrib['en'] = array('Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Number_of_bathrooms'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'kitchen'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Number_of_rooms'=>TAG_BEDROOMS_TOTAL,
			'construction_year_year'=>TAG_CONSTRUCTION_YEAR, 'Plot_size_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL, 'Type'=>TAG_TYPE,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'habitable_-_surface_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Garden'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrace'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE
			);
    
    if(!empty($key)){
	
	if( array_key_exists($key, $attrib[$lan]) ){
	    return $attrib[$lan][$key];
	}
	else
	    return '';
    }else
	return '';
	
}
      
function GetExactAttrib($key,$val){
    switch($key){
    case TAG_PRICE:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_BATHROOMS_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_BEDROOMS_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_GARAGES_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_TOILETS_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_CONSTRUCTION_YEAR:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_RENOVATION_YEAR:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_KI:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_EPC_VALUE:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_EPC_CERTIFICATE_NUMBER:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_SURFACE_LIVING_AREA:
       return CrawlerTool::toNumber($val);
       break;
    case TAG_SURFACE_GROUND:
       return CrawlerTool::toNumber($val);
       break;
    case TAG_MOST_RECENT_DESTINATION:
       return trim($val);
       break;
    case TAG_PLANNING_PERMISSION:
       return 1;
       break;
    case TAG_SUBDIVISION_PERMIT:
       return CrawlerTool::toNumber($val); 
    break;
    default:
        return $val;  
    break;
     
    }
}

///Removing Special Characters..
function clean($string) {
   $string = str_replace(' ', '', $string); // Replaces all spaces with hyphens.

   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}
 
	//Iframe url Scanner
	$contact_href = $parser->extract_xpath("iframe[contains(@src, 'contactform')]/@src");

	$nodes = $parser->getNodes("a[. = 'Meer info']");
  
	$pattern = '@<span class="txtvraagprijswaarde">(.+?)</span>@si';
	preg_match($pattern, $html, $price);
	if (isset($price[1])) {
	    $property[TAG_PRICE] = CrawlerTool::toNumber(str_replace('&#8364;', '', ( strip_tags($price[1]))));
	}

	//Get Gext Between td tags
	preg_match_all('#<td>(.*?)</td>#s', $html, $result);
	preg_match("/PHP/", "PHP")       # Match for an unbound literal
	preg_match("/^PHP/", "PHP")      # Match literal at start of string
	preg_match("/PHP$/", "PHP")      # Match literal at end of string
	preg_match("/^PHP$/", "PHP")     # Match for exact string content
	preg_match("/^$/", "")           # Match empty string

	$property[TAG_UNIQUE_URL_FR] = str_replace('nl-be','fr-fr',$property[TAG_UNIQUE_URL_NL]);
	$property[TAG_UNIQUE_URL_EN] = str_replace('nl-be','en-gb',$property[TAG_UNIQUE_URL_NL]);
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_FR]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style"));
	$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@id = 'details_left']/div[1]"))); 
	$property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL)));
	if(empty($property[TAG_TEXT_DESC_NL])){
		
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
		$res[1] = str_replace(chr(11),'',$res[1]);
		$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode(strip_tags($res[1])));
	}
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_EN]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@id = 'details_left']/div[1]"))); 
	$property[TAG_PLAIN_TEXT_ALL_EN] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL))); 
	
	if(empty($property[TAG_TEXT_DESC_NL])){
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
		$res[1] = str_replace(chr(11),'',$res[1]);
		$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode(strip_tags($res[1])));
	}
	
	///Getting Unique ID
	CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL])
	 	
	CrawlerTool::toNumber(); 
	CrawlerTool::encode($property[TAG_STREET]); 
	///Getting link with node html
	$link = $parser->extract_xpath("div[@class = 'title']/h2/a/@href", RETURN_TYPE_TEXT, null, $node); 
	
	$price = $parser->extract_xpath("parent::div[1]/preceding-sibling::div[1]/h2", RETURN_TYPE_NUMBER, null, $node);
	
	CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL])

	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));
      
	//////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Getting 4 Digit number 
	if(empty($property[TAG_CITY])){
		
		$address = $parser->extract_xpath("table[@class = 'infolijst']/tr/td[2]", RETURN_TYPE_TEXT);
		
		$address = $parser->extract_xpath("p[@class = 'extrainfo']", RETURN_TYPE_TEXT); 
		
		$addr = explode(' ',$address);
		$property[TAG_CITY] = trim($addr[count($addr)-1]);
		$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
		
		if(strlen($property[TAG_ZIP]) < 4){
			$address = str_replace($property[TAG_ZIP],'',$address );
			$property[TAG_BOX_NUMBER] = $property[TAG_ZIP];
			$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
		}
		
		$property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
		$property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
		
		$property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
		$property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
		
		if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
		
		if(strlen($property[TAG_BOX_NUMBER]) < 3 || strlen($property[TAG_BOX_NUMBER]) > 3 )
		unset($property[TAG_BOX_NUMBER]);
	}
	//$property[TAG_STREET] = trim($addr[0]);
	//$property[TAG_NUMBER] = $parser->regex("/(\d{2})/", $address );  	

	$propertyStatus = CrawlerTool::getPropertyStatus($text);
	if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
	{
	    $property[TAG_STATUS] = $propertyStatus;
	}
		
	//Return in case of sold or rented
	if($property[TAG_STATUS]==STATUS_SOLD)	 return ;
	if($property[TAG_STATUS]==STATUS_RENTED) return ;
	
	if(strpos($html,"VERHUURD") || strpos($html,"Verhuurd")){
	    $property[TAG_STATUS] = "rented"; return;
	}
	if(strpos($html,"VERKOCHT") || strpos($html,"Verkocht")){
	    $property[TAG_STATUS] = "sold"; return;
	}

	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array and exit debug exit = de
function de($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	  exit;
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array debug all = da
function da($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}

function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
} 

function removeBrackets($str){
	$str = str_replace('–','',$str);
	$str = str_replace('(','',$str);
	$str = str_replace(')','',$str);
	$str = str_replace('-','',$str);
	return $str;
}
	
function regex($exp, $text, Closure $closure = null){
	if(preg_match($exp, $text, $match))
	{
	    if(empty($closure))
	    {
		return trim($match[1]);
	    }
	    else
	    {
		return $closure($match);
	    }
	}
	
	return "";
}
    
	//////Crome is good for Ajax testing
	
function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");

        $str = str_replace(array_keys($invalid), '', $str); //array_values($invalid)

        return $str;
    }	
	

function getAttributes($key, $language='nl'){ //String Function always return string

	$attributeTagsArray	= array('en' => array(	'pric' 			=>  TAG_PRICE,
							'constr'		=> TAG_CONSTRUCTION_YEAR,
							'ground'		=> TAG_SURFACE_GROUND,
							'living' 		=> TAG_SURFACE_LIVING_AREA,
							'bath'			=> TAG_BATHROOMS_TOTAL,
							'warm'			=> TAG_HEATING_EN,
							'heat'			=> TAG_HEATING_EN,
							'sewer'			=> TAG_CONNECTION_TO_SEWER,
							'telep'			=> TAG_TELEPHONE_CONNECTION,
							'intern'		=> TAG_INTERNET_CONNECTION,
							'permission'	=> TAG_PLANNING_PERMISSION,
							'subdivision'	=> TAG_SUBDIVISION_PERMIT,
							'electri'		=> TAG_METER_FOR_ELECTRICITY,
							'hall'			=> TAG_HALLS,
							'dining'		=> TAG_DININGS,
							'kitch'			=> TAG_KITCHENS,
							'laundr'		=> TAG_LAUNDRY_ROOMS,
							'dress'			=> TAG_DRESSING,
							'bed'			=> TAG_BEDROOMS_TOTAL,
							'room'			=> TAG_BEDROOMS_TOTAL,
							'park'			=> TAG_PARKINGS,
							'garage'		=> TAG_GARAGES_TOTAL,
							'type'			=> TAG_TYPE,
							'garden'		=> TAG_GARDEN_AVAILABLE,
							'floor'			=> TAG_AMOUNT_OF_FLOORS,
							'winter'		=> TAG_WINTERGARDENS,
							'furnish'		=> TAG_FURNISHED,
							'water'			=> TAG_CONNECTION_TO_WATER,
							'lift'			=> TAG_LIFT,
							'glaz'			=> TAG_DOUBLE_GLAZING,
							'terrac'		=> TAG_TERRACES,
							'fronts'		=> TAG_AMOUNT_OF_FACADES,
							'category'		=> TAG_TYPE,
							'free'			=> TAG_FREE_FROM_DATE,
							'habit'			=> TAG_SURFACE_LIVING_AREA,
							'plot'			=> TAG_SURFACE_GROUND,
							'shops'			=> TAG_DISTANCE_SHOPS,
							'schools'		=> TAG_DISTANCE_SCHOOL,
							'transport'		=> TAG_DISTANCE_PUBLIC_TRANSPORT,
							'shower'		=> TAG_SHOWERS_TOTAL,
							'stor'			=> TAG_STOREROOMS,
							'gas'			=> TAG_GAS_CONNECTION,
							'alarm'			=> TAG_ALARM,
							'security'		=> TAG_SECURITY_DOOR,
							'parlo'			=> TAG_PARLOPHONE,
							'video'			=> TAG_VIDEOPHONE,
							'elevat'		=> TAG_LIFT,
							'blind'			=> TAG_SUN_BLINDS,
							'renova'		=> TAG_RENOVATION_YEAR,
							'control'		=> TAG_ACCESS_SEMIVALID,
								),
					'nl' => array(	"prij" =>  TAG_PRICE,
							"bouwjaar" => TAG_CONSTRUCTION_YEAR,
							"grondopp" => TAG_SURFACE_GROUND, 
							"bewoonbare" => TAG_SURFACE_LIVING_AREA,
							"slaapkamer"=> TAG_BEDROOMS_TOTAL,
							"badkam"=> TAG_BATHROOMS_TOTAL,
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"verdieping" => TAG_AMOUNT_OF_FLOORS,
							"living" => TAG_SURFACE_LIVING_AREA,
							"renovatie" => TAG_RENOVATION_YEAR,
							"kadaster sectie" => TAG_CADASTRAL_SECTION,
							"beschikbaar" => TAG_FREE_FROM,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"mail" => TAG_EMAIL,
							"winkels" => TAG_DISTANCE_SHOPS,
							"vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"overstromings" => TAG_FLOOD_INFORMATION_NL,
							"garage" => TAG_GARAGES_TOTAL,
							"toilet" => TAG_TOILETS_TOTAL,
							"parking" => TAG_PARKINGS_TOTAL,
							"gevels" => TAG_AMOUNT_OF_FACADES,
							"lasten" => TAG_COMMON_COSTS,
							"gas" => TAG_GAS_CONNECTION,
							"water" => TAG_CONNECTION_TO_WATER,
							"telefoon" => TAG_TELEPHONE,
							"lift" => TAG_LIFT,
							"gemeubeld" => TAG_FURNISHED,
							"tuin" => TAG_GARDEN_AVAILABLE,
							"haard" => TAG_OPEN_FIRE,
							"alarm" => TAG_ALARM,
							"parlofoon" => TAG_PARLOPHONE,
							"videofoon" => TAG_VIDEOPHONE,
							"breedte" => TAG_LOT_WIDTH,
							"diepte" => TAG_LOT_DEPTH,
							"constructie" => TAG_CONSTRUCTION_TYPE,
							"gevelbreedte" => TAG_FRONTAGE_WIDTH,
							"winkel" => TAG_HEATING_NL,
							"douche" => TAG_SHOWERS_TOTAL,
							"keuken" => TAG_KITCHEN_TYPE_NL,
							"ligging" => TAG_SUBDIVISION_PERMIT,
							"stedenbouwkundige" => TAG_PLANNING_PERMISSION,
							"terras" => TAG_TERRACES,
							"terrein" => TAG_SURFACE_GROUND,
							"scholen" => TAG_DISTANCE_SCHOOL,
							"oppervlakte" => TAG_SURFACE_LIVING_AREA,
							"eetkamer" => TAG_DININGS,
							"dressing" => TAG_DRESSINGS,
							"kelder" => TAG_CELLARS,
							"beroep" => TAG_FREE_PROFESSIONS,
							"berging" => TAG_STOREROOMS,
							"wasplaats" => TAG_LAUNDRY_ROOMS,
							"elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"beglazing" => TAG_DOUBLE_GLAZING,
							"verwarming" => TAG_HEATING_NL,
							"riolering" => TAG_CONNECTION_TO_SEWER,
							"olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"waterput" => TAG_WELL,
							"telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
							"toegangscontrole" => TAG_ACCESS_SEMIVALID,
							"computer" => TAG_INTERNET_CONNECTION,
								),
				);
	
	$keys = array_keys($attributeTagsArray[$language]); // Returning Keys
	$key = clearForLowerCase($key); // Converting to lower case
	
	foreach($keys as $k){
	   
		   $check = stripos("X$key","$k");
		   if(!empty($check))
		   return $attributeTagsArray[$language][$k];
	    }
	}
	return '';	 
}

/// Basic checking for 
function clearForLowerCase($str = ''){
    $str = strtolower($str);
    $str = trim(strip_tags($str));
    //$str = preg_replace('![^a-z0-9_\-\. ]!','',$str);
    $str = trim(preg_replace('!nbsp!','',$str));

    return trim(utf8_decode($str));

}
	
	
	
function extractAddress($address){
	$street = "";
	if (strpos($address, ',') !== false) {
		list($number, $street) = explode(',', $address, 2);
	} else {
		preg_match('~^(.*?)((?:unit )?(?:[0-9]+\s?-\s?[0-9]+|[0-9]+))(.*)$~is', $address, $parts);
		
		$number = $parts[2];
		if (trim($parts[1]) != '') {
			$street .= trim($parts[1]);
		}
		if(trim($parts[3]) != '') {
			if($street ==""){
				$street .= trim($parts[3]);
			}
			else{
				$street .= " ".trim($parts[3]);	
			}
		}
	}

	return $number."|||".$street;

}

$property[TAG_STREET] = str_replace('x'.$property[TAG_TEXT_TITLE_NL], '', $property[TAG_STREET]);
	
	//////
	if(stripos('x'.$property[TAG_STREET],'Henri')!==false) { $property[TAG_CITY] = 'Gent'; $property[TAG_ZIP] = 9051; }
	if(stripos('x'.$property[TAG_CITY],'Panne')!==false) { $property[TAG_CITY] = 'De Panne'; }


//Out of Belgium
	if(strtolower($property[TAG_CITY]) == strtolower('Sie') )
	return;







	
?>
