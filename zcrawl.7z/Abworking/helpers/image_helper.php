<?php

/**********************Technique A ****************////*****************************************************************************************************
////////////////////////////// Get Pictures by Script ///////////////////////////////////////////////

   preg_match_all('#Array\((.*?)\)#s', $html, $result);
    
    $pics = array();
    
    foreach($result[1] as $res){
        $pics[] = str_replace("'","",$res);
    }
    unset($pics[0]);
    foreach($pics as $pic){
       $p = explode(', ',$pic);
       $picx = 'http://www.av-vastgoed.be/images/panden/'.$p[1];
       $picUrls[] = array(TAG_PICTURE_URL =>  $picx);
    }
    $property[TAG_PICTURES] = $picUrls;
////////////////////////////////////////////////////////////////////////////////////////////////

/**********************Technique B ****************////*****************************************************************************************************
//////////////////////////// Getting Images from Ul Li /////////////////////////////////////////

	$pics = $parser->getNodes("ul[@class = 'bxSlider']/li/img");
	 
	foreach($pics as $picx){
	    
	    $pic = $parser->getAttr($picx, "src");        
	    $picUrls[] = array(TAG_PICTURE_URL => $pic);
	}
	
	$property[TAG_PICTURES] = $picUrls;

	
    if(empty($project[TAG_PICTURES])){
	
	$pics = $parser->getNodes("img[contains(@src, 'fotos')]");
	 
	foreach($pics as $picx){
	    
	    $pic = $parser->getAttr($picx, "src");        
	    $picUrls[] = array(TAG_PICTURE_URL => 'http://www.lapeirre.be/'.$pic);
	}
	
	$project[TAG_PICTURES] = $picUrls;
    }
////////////////////////////////////////////////////////////////////////////////////////////////

/**********************Technique C ****************////*****************************************************************************************************
//////////////////////////// Wow Slide Images /////////////////////////////////////////////////
	$property[TAG_PICTURES] =  $parser->extract_xpath("div[@id = 'wowslider-images']/a/img/@src", RETURN_TYPE_ARRAY, function($pics)
	{
	    $picUrls = array();
	    foreach($pics as $pic) {
    
		$picUrls[] = array(TAG_PICTURE_URL => $pic);
    
	    }
    
	    return $picUrls;
	});
////////////////////////////////////////////////////////////////////////////////////////////////
/**********************Technique D ****************////*****************************************************************************************************

///////////////////////// Getting images By REL attribute /////////////////////////////////////

$property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox']", RETURN_TYPE_ARRAY, function($pics)
	{
		$picUrls = array();
		foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.uniximmo.com" . $pic);

		return $picUrls;
	});

///////////////////////////////////////////////////////////////////////////////////////////////

/**********************Technique E ****************////*****************************************************************************************************
//////////////////////// Html Source having camera images in it //////////////////////////////

$property[TAG_PICTURES] =  $parser->extract_xpath("div[@class = 'camera_imgs']/@data-thumb", RETURN_TYPE_ARRAY, function($pics)
    {
	$picUrls = array();
	foreach($pics as $pic) {
        $pic_src = explode("?",$pic);
        $pic_url = "http://www.vastgoedlapeire.be".$pic_src[0];
	    $picUrls[] = array(TAG_PICTURE_URL => $pic_url);

	}

	return $picUrls;
    });
    
/////////////////////////////////////////////////////////////////////////////////////////////


?>