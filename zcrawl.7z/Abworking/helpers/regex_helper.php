<?php
/********************** Regex Techniques ********************************////*****************************************************************************************************/
	
	
	//Google related data
	if (preg_match('!GoogleX=([0-9.]+)&GoogleY=([0-9.]+)&!',$html,$res))
	{
		$property[TAG_LATITUDE] = $res[1];
		$property[TAG_LONGITUDE] = $res[2];
	}
	
	
	//Getting Just number
	$parser->regex("/(\d+)$/", $property[TAG_UNIQUE_URL_NL]);
	$parser->regex("/estate.id=(\d+)/", $property[TAG_UNIQUE_URL_NL] ); 
	
	$property[TAG_PRICE] = $parser->extract_regex("/(Prijsklasse.*)/", RETURN_TYPE_NUMBER);


	//Get Gext Between td tags
	preg_match_all('#<td>(.*?)</td>#s', $html, $result);
	
	
$html1=preg_replace('/<td width="5%" align="Center" Class="(.*?)"><B>:<\/B><\/td>/','',$html);
preg_match_all('!<td width="30%" Class=.*?<B>([^<>]+)</B></td>\s+<td align="Left" width="65%".*?">([^<>]+)</td>!',$html1,$res,PREG_SET_ORDER);
foreach ($res as $arr)
{
	$arr[1] = strtolower($arr[1]);
	$arr[1] = trim($arr[1]);
	$arr[1] = preg_replace('!&nbsp;!','',$arr[1]);
	echo $arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
	echo $vars[$arr[1]] = str_replace('&nbsp;','',$arr[2]);
	echo "<br>";
}



/********************** Regex Techniques Getting Attribute by Text ********************************////*****************************************************************************************************/

  $property[TAG_EPC_VALUE] = $parser->extract_regex("/([\d,\d]+)\skwh/i", RETURN_TYPE_EPC);
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_regex("/(\d+)\skwh/i", RETURN_TYPE_EPC);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_regex("/(\d)&nbsp;(ruime slaapkamer|slaapkamers)/", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_regex("/(\d)\ssBadkamer/i", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("li[contains(text(), 'Oppervlakte grond')]", RETURN_TYPE_NUMBER);
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("p[contains(text(), 'Beschikbaar vanaf')]/strong", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM_DATE] = $parser->extract_regex("/vanaf\s(.*?)</", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM] = $parser->extract_regex("/vanaf\s(.*?)\./");
    $property[TAG_LIFT] = CrawlerTool::contains($parser->extract_regex("/(Lift)/i"), "Lift");

    
    
/*1. Syntax of preg_match
While full syntax is
*/

/*
 2. Simple String Checks with preg_match()
Here are some syntax examples that check strings for certain content:
*/
 
preg_match("/PHP/", "PHP");       # Match for an unbound literal
preg_match("/^PHP/", "PHP");     # Match literal at start of string
preg_match("/PHP$/", "PHP");   # Match literal at end of string
preg_match("/^PHP$/", "PHP");     # Match for exact string content
preg_match("/^$/", "")    ;       # Match empty string

preg_match("/PHP/", "PHP");             # / as commonly used delimiter
preg_match("@PHP@", "PHP");             # @ as delimiter
preg_match("!PHP!", "PHP");             # ! as delimiter

preg_match("/http:\/\//", "http://");     # match http:// protocol prefix with / delimiter
preg_match("#http://#",   "http://");      # match http:// protocol prefix with # delimiter

preg_match("/PHP/", "PHP");                # case sensitive string matching
preg_match("/php/i", "PHP");               # case in-sensitive string matching

preg_match("/P.P/",     "PHP");            # match a single character
preg_match("/P.*P/",    "PHP");            # match multipe characters
preg_match("/P[A-Z]P/", "PHP");           # match from character range A-Z
preg_match("/[PH]*/",   "PHP");           # match from character set P and H
preg_match("/P\wP/",    "PHP");          # match one word character
preg_match("/\bPHP\b/", "regex in PHP");   # match the word "PHP", but not "PHP" as larger string

preg_match("/[PH]{3}/",   "PHP");          # match exactly 3 characters from set [PH]
preg_match("/[PH]{3,3}/", "PHP");          # match exactly 3 characters from set [PH]
preg_match("/[PH]{,3}/",  "PHP");          # match at most 3 characters from set [PH]
preg_match("/[PH]{3,}/",  "PHP");          # match at least 3 characters from set [PH]

# Extract everything after the literal "START"
preg_match("/START(.*)/", $string, $results) ; 
 
# Extract the number from a date string
preg_match("/(\d{4})-(\d{2})-(\d{2})/", "2012-10-20", $results);
 
# Nesting of capture groups, extract full name, and both parts...
preg_match("/name is ((\w+), (\w+))/", "name is Doe, John", $results);

// Extract the number from a date string
preg_match("/(?P<year>\d{4})-(?P<month>\d{2})-(?P<day>\d{2})/", "2012-10-20", $results);

//Check for preg_match() Processing Errors!
preg_last_error();

$bedroomsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $bedrooms);

//Get href 
preg_match_all('!<a href="([^"\/]+).html".*?">MEER INFO</a>!',$html,$res);

///http://www.groepindustrimmo.be/showobject.aspx?objectid=2597 
$pattern = "Bouwjaar:<\/u>(.+?)<\/p>";
preg_match ( "/" . $pattern . "/is", $html, $constructy);
if (isset($constructy[1])) {
	$property[TAG_CONSTRUCTION_YEAR] = preg_replace ("/\D/", "", preg_replace("/\(.+\)|\+.+/", " ", strip_tags($constructy[1])));
}

$pattern = "<u>Vrij.*?<\/u>(.+?)<";
preg_match ( "/" . $pattern . "/is", $html, $shortdescr);
if (isset($shortdescr[1])) {
	$property[TAG_FREE_FROM_DATE] = CrawlerTool::toUnixTimestamp(substr (trim (preg_replace("/&nbsp;|\n|\r|\s+|:/s", " ", ( strip_tags ($shortdescr[1])))), 0, 255));
}
$pattern = "Gemeenschappelijke\s+?kosten.+?<\/u>(.+?)&euro;";
preg_match ( "/" . $pattern . "/is", $html, $price);
if (isset($price[1])) {
	$property[TAG_COMMON_COSTS] = CrawlerTool::toNumber( trim(strip_tags ($price[1])));
}

?>