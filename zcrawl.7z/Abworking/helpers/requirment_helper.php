<?php

//To on Error reporting 
error_reporting(E_ALL);
ini_set('display_errors', '1'); 
 
//Cookies Adjustment
$crawler->enable_delay_between_requests(5,10); 
if (isset($_GET['proxy']))	{ $crawler -> set_proxy($_GET['proxy']); }
$crawler->use_cookies(true);
$crawler->clean_cookies();
$crawler->use_gzip(false); 
  
// START writing data to output.xml file
CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "AConcept";
$office[TAG_OFFICE_URL] = "http://www.brabimo.be/";
$office[TAG_STREET] = "Mariakerksesteenweg";
$office[TAG_NUMBER] = "207";
$office[TAG_ZIP] = "9031";
$office[TAG_CITY] = "Gent";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "09 362 37 54";
$office[TAG_FAX] = "0475 50 55 65";
$office[TAG_EMAIL] = "info@brabimo.be";
CrawlerTool::saveOffice($office);


///All Stater constants  


$startPages[STATUS_FORSALE] = array
(
    TYPE_HOUSE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/woningen-villas/"
    ),
    TYPE_APARTMENT        =>  array
    (
        "http://www.immo-isca.be/nl/Type/appartement/"
    ),
    TYPE_NONE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/opbrengstpanden/"
    ),
    TYPE_COMMERCIAL        =>  array
    (
        "http://www.immo-isca.be/nl/Type/handel-kantoor/"
    ),
    TYPE_GARAGE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/garages/"
    ),
    TYPE_PLOT        =>  array
    (
        "http://www.immo-isca.be/nl/Type/garages/"
    ),
);

$start_links[STATUS_FORRENT] = array(
TYPE_NONE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/opbrengstpanden/"
    ),
);

$start_links[STATUS_TAKEOVER] = array(
TYPE_NONE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/opbrengstpanden/"
    ),
);

///Getting Unique ID
	CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]) ;
 

 ////////////////Adding Lat and log
	preg_match_all('#google.maps.LatLng\((.*?)\)#s', $html, $result);
	$latlog = str_replace("'","",$result[1][0]);
	$latlog = explode(',', $latlog);
	
	$property[TAG_LATITUDE] = getLatLong($latlog[0]);
	$property[TAG_LONGITUDE] = getLatLong($latlog[1]); 



//function for print array
function debug($obj)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}    
    
    
       
?>