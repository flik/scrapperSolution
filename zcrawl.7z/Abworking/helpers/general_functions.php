<?php

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}

//// Fixing Special Charachter Issue
function fixSpecialChr($str){
	
	$str =  CrawlerTool::strip(CrawlerTool::fixUTF8(strip_tags($str))); 
	//$str = preg_replace("![^a-z0-9_\à\â\ç\é\è\ê\ë\î\ï\ô\ó\ö\û\ù\ü\ÿ\ñ\æ\œ\’\„\”\“\”€\.\- ]!", "",$str);
	//$str = preg_replace("/^[A-Za-z0-9àâçéèêëîïôóöûùüÿñæœ’„”“”€ .-]*$/i", "",$str);
	//$str = preg_replace("[^\u0000-\u007F]", "",$str); 
	//toUTF8 
	// return utf8_decode(strip_tags($str));
	//return mb_convert_encoding(utf8_decode(strip_tags($str)), 'HTML-ENTITIES', 'UTF-8');
	return $str;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function to get html between two points in htm source
function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function to remove brackets from string
function removeBrackets($str){
	$str = str_replace('–','',$str);
	$str = str_replace('(','',$str);
	$str = str_replace(')','',$str);
	$str = str_replace('-','',$str);
	return $str;
}
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for Regex
function regex($exp, $text, Closure $closure = null){
	if(preg_match($exp, $text, $match))
	{
	    if(empty($closure))
	    {
		return trim($match[1]);
	    }
	    else
	    {
		return $closure($match);
	    }
	}
	
	return "";
}
     
//////Function to return number and text string
function extractAddress($address){
	$street = "";
	if (strpos($address, ',') !== false) {
		list($number, $street) = explode(',', $address, 2);
	} else {
		preg_match('~^(.*?)((?:unit )?(?:[0-9]+\s?-\s?[0-9]+|[0-9]+))(.*)$~is', $address, $parts);
		
		$number = $parts[2];
		if (trim($parts[1]) != '') {
			$street .= trim($parts[1]);
		}
		if(trim($parts[3]) != '') {
			if($street ==""){
				$street .= trim($parts[3]);
			}
			else{
				$street .= " ".trim($parts[3]);	
			}
		}
	}

	return $number."|||".$street;

}

//////Function to convert relative address to absolute address
function rel2abs($rel, $base){
	$path = "";
    /* return if already absolute URL */
    if (parse_url($rel, PHP_URL_SCHEME) != '') return $rel;
    /* queries and anchors */
    if ($rel[0]=='#' || $rel[0]=='?') return $base.$rel;
    
    /* parse base URL and convert to local variables:
    $scheme, $host, $path */
    
    extract(parse_url($base));

    /* remove non-directory element from path */
    $path = preg_replace('#/[^/]*$#', '', $path);

    /* destroy path if relative url points to root */
    if ($rel[0] == '/') $path = '';

    /* dirty absolute URL */
    $abs = "$host$path/$rel";

    /* replace '//' or '/./' or '/foo/../' with '/' */
    $re = array('#(/\.?/)#', '#/(?!\.\.)[^/]+/\.\./#');
    for($n=1; $n>0; $abs=preg_replace($re, '/', $abs, -1, $n)) {}

    /* absolute URL is ready! */
    return $scheme.'://'.$abs;
}

//////Function to remove unwanted characters and - inplace of spaces
function slugify($text) {
	// replace non letter or digits by -
	$text = preg_replace('~[^\\pL\d]+~u', '-', $text);
	// trim
    $text = trim($text, '-');

    // transliterate
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

    // lowercase
    $text = strtolower($text);

    // remove unwanted characters
    $text = preg_replace('~[^-\w]+~', '', $text);

    if (empty($text))
    {
        return 'n-a';
    }

    return $text;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
///Clear Empity index
function removeEmptyIndex($property){
 foreach($property as $k=>$v){
		if(empty($v))
		unset($property[$k]);
		
			if(is_array($v)){ 
				foreach($v as $kx=>$vx){ 
					if(empty($vx)){ 
						unset($v[$kx]);
						unset($property[$k]);
					}
				}
			}	
	}
	return $property; 
}

function getLanguageText($crawler, &$property)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
    $html = str_replace("±", "", $html);
    $parser = new PageParser($html, true);

    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);

}

//Function for Handle Attributes 
function setAtributesX($key='',$lan='nl'){ 
    
    $attrib['nl'] = array('Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Badkamer'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'Kadastraal_inkomen'=>TAG_KI, 'Geïndexeerd_kad._inkomen'=>TAG_KI_INDEX,
			'Grondoppervlakte'=>TAG_SURFACE_GROUND, 'Gevelbreedte'=>TAG_FRONTAGE_WIDTH,
			'Verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Badkamer'=>TAG_BATHROOM_SURFACE,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'keuken'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Aantal_slaapkamers'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'Bouwjaar'=>TAG_CONSTRUCTION_YEAR, 'Bewoonb_opp.'=>TAG_SURFACE_GROUND,
			'Parkings'=>TAG_PARKINGS,'Garages'=>TAG_GARAGES_TOTAL, 'Aantal_garages'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'Bewoonbare_oppervlakte'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Tuin'=>TAG_WINTERGARDENS,
			'Gemeubeld'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terras'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE, 'EPC'=>TAG_EPC_VALUE, 'EPC_Certificaat'=>TAG_EPC_CERTIFICATE_NUMBER,
			'Bestemming'=>TAG_MOST_RECENT_DESTINATION, 'Verkavelingvergunning'=>TAG_SUBDIVISION_PERMIT, 'Bouwvergunning'=>TAG_PLANNING_PERMISSION,
			'Voorkooprecht'=>TAG_PRIORITY_PURCHASE
			);
    
    $attrib['fr'] = array( 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Nombre_de_salle_de_bain'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'cuisine'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'année_de_construction_année'=>TAG_CONSTRUCTION_YEAR, 'Taille_terrain_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'surface_nette_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Jardin'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrasse'=>TAG_TERRACES,'Facades'=>TAG_AMOUNT_OF_FACADES,
			'Catégorie'=>TAG_TYPE
			);
    
    $attrib['en'] = array('Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Number_of_bathrooms'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'kitchen'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Number_of_rooms'=>TAG_BEDROOMS_TOTAL,
			'construction_year_year'=>TAG_CONSTRUCTION_YEAR, 'Plot_size_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL, 'Type'=>TAG_TYPE,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'habitable_-_surface_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Garden'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrace'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE
			);
    
    if(!empty($key)){
	
	if( array_key_exists($key, $attrib[$lan]) ){
	    return $attrib[$lan][$key];
	}
	else
	    return '';
    }else
	return '';
	
}
        

///Removing Special Characters..
function clean($string) {
   $string = str_replace(' ', '', $string); // Replaces all spaces with hyphens.

   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}


function getAttributes($key, $language='nl'){ //String Function always return string

	$attributeTagsArray	= array('en' => array(	'pric' 			=>  TAG_PRICE,
							'constr'		=> TAG_CONSTRUCTION_YEAR,
							'ground'		=> TAG_SURFACE_GROUND,
							'living' 		=> TAG_SURFACE_LIVING_AREA,
							'bath'			=> TAG_BATHROOMS_TOTAL,
							'warm'			=> TAG_HEATING_EN,
							'heat'			=> TAG_HEATING_EN,
							'sewer'			=> TAG_CONNECTION_TO_SEWER,
							'telep'			=> TAG_TELEPHONE_CONNECTION,
							'intern'		=> TAG_INTERNET_CONNECTION,
							'permission'	=> TAG_PLANNING_PERMISSION,
							'subdivision'	=> TAG_SUBDIVISION_PERMIT,
							'electri'		=> TAG_METER_FOR_ELECTRICITY,
							'hall'			=> TAG_HALLS,
							'dining'		=> TAG_DININGS,
							'kitch'			=> TAG_KITCHENS,
							'laundr'		=> TAG_LAUNDRY_ROOMS,
							'dress'			=> TAG_DRESSING,
							'bed'			=> TAG_BEDROOMS_TOTAL,
							'room'			=> TAG_BEDROOMS_TOTAL,
							'park'			=> TAG_PARKINGS,
							'garage'		=> TAG_GARAGES_TOTAL,
							'type'			=> TAG_TYPE,
							'garden'		=> TAG_GARDEN_AVAILABLE,
							'floor'			=> TAG_AMOUNT_OF_FLOORS,
							'winter'		=> TAG_WINTERGARDENS,
							'furnish'		=> TAG_FURNISHED,
							'water'			=> TAG_CONNECTION_TO_WATER,
							'lift'			=> TAG_LIFT,
							'glaz'			=> TAG_DOUBLE_GLAZING,
							'terrac'		=> TAG_TERRACES,
							'fronts'		=> TAG_AMOUNT_OF_FACADES,
							'category'		=> TAG_TYPE,
							'free'			=> TAG_FREE_FROM_DATE,
							'habit'			=> TAG_SURFACE_LIVING_AREA,
							'plot'			=> TAG_SURFACE_GROUND,
							'shops'			=> TAG_DISTANCE_SHOPS,
							'schools'		=> TAG_DISTANCE_SCHOOL,
							'transport'		=> TAG_DISTANCE_PUBLIC_TRANSPORT,
							'shower'		=> TAG_SHOWERS_TOTAL,
							'stor'			=> TAG_STOREROOMS,
							'gas'			=> TAG_GAS_CONNECTION,
							'alarm'			=> TAG_ALARM,
							'security'		=> TAG_SECURITY_DOOR,
							'parlo'			=> TAG_PARLOPHONE,
							'video'			=> TAG_VIDEOPHONE,
							'elevat'		=> TAG_LIFT,
							'blind'			=> TAG_SUN_BLINDS,
							'renova'		=> TAG_RENOVATION_YEAR,
							'control'		=> TAG_ACCESS_SEMIVALID,
								),
					'nl' => array(	"prij" =>  TAG_PRICE,
							"bouwjaar" => TAG_CONSTRUCTION_YEAR,
							"grondopp" => TAG_SURFACE_GROUND, 
							"bewoonbare" => TAG_SURFACE_LIVING_AREA,
							"slaapkamer"=> TAG_BEDROOMS_TOTAL,
							"badkam"=> TAG_BATHROOMS_TOTAL,
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"verdieping" => TAG_AMOUNT_OF_FLOORS,
							"living" => TAG_SURFACE_LIVING_AREA,
							"renovatie" => TAG_RENOVATION_YEAR,
							"kadaster sectie" => TAG_CADASTRAL_SECTION,
							"beschikbaar" => TAG_FREE_FROM,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"mail" => TAG_EMAIL,
							"winkels" => TAG_DISTANCE_SHOPS,
							"vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"overstromings" => TAG_FLOOD_INFORMATION_NL,
							"garage" => TAG_GARAGES_TOTAL,
							"toilet" => TAG_TOILETS_TOTAL,
							"parking" => TAG_PARKINGS_TOTAL,
							"gevels" => TAG_AMOUNT_OF_FACADES,
							"lasten" => TAG_COMMON_COSTS,
							"gas" => TAG_GAS_CONNECTION,
							"water" => TAG_CONNECTION_TO_WATER,
							"telefoon" => TAG_TELEPHONE,
							"lift" => TAG_LIFT,
							"gemeubeld" => TAG_FURNISHED,
							"tuin" => TAG_GARDEN_AVAILABLE,
							"haard" => TAG_OPEN_FIRE,
							"alarm" => TAG_ALARM,
							"parlofoon" => TAG_PARLOPHONE,
							"videofoon" => TAG_VIDEOPHONE,
							"breedte" => TAG_LOT_WIDTH,
							"diepte" => TAG_LOT_DEPTH,
							"constructie" => TAG_CONSTRUCTION_TYPE,
							"gevelbreedte" => TAG_FRONTAGE_WIDTH,
							"winkel" => TAG_HEATING_NL,
							"douche" => TAG_SHOWERS_TOTAL,
							"keuken" => TAG_KITCHEN_TYPE_NL,
							"ligging" => TAG_SUBDIVISION_PERMIT,
							"stedenbouwkundige" => TAG_PLANNING_PERMISSION,
							"terras" => TAG_TERRACES,
							"terrein" => TAG_SURFACE_GROUND,
							"scholen" => TAG_DISTANCE_SCHOOL,
							"oppervlakte" => TAG_SURFACE_LIVING_AREA,
							"eetkamer" => TAG_DININGS,
							"dressing" => TAG_DRESSINGS,
							"kelder" => TAG_CELLARS,
							"beroep" => TAG_FREE_PROFESSIONS,
							"berging" => TAG_STOREROOMS,
							"wasplaats" => TAG_LAUNDRY_ROOMS,
							"elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"beglazing" => TAG_DOUBLE_GLAZING,
							"verwarming" => TAG_HEATING_NL,
							"riolering" => TAG_CONNECTION_TO_SEWER,
							"olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"waterput" => TAG_WELL,
							"telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
							"toegangscontrole" => TAG_ACCESS_SEMIVALID,
							"computer" => TAG_INTERNET_CONNECTION,
								),
                                        'fr' => array(	"prij" =>  TAG_PRICE,
							"Meuble" => TAG_FURNISHED,
							"facades" => TAG_AMOUNT_OF_FACADES,
							"nombre_de_chambres"=> TAG_BEDROOMS_TOTAL,
							"nombre_de_salle_de_bain"=> TAG_BATHROOMS_TOTAL,
							"jardin" => TAG_GARDEN_AVAILABLE,
							"garage" => TAG_GARAGES_TOTAL,
							"terras" => TAG_TERRACES,
							"parking" => TAG_PARKINGS_TOTAL,
							"habita" => TAG_SURFACE_LIVING_AREA,
							"terrain" => TAG_SURFACE_GROUND,
							"disponible" => TAG_FREE_FROM,
							"magasins" => TAG_DISTANCE_SHOPS,
							"transport" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"toilet" => TAG_TOILETS_TOTAL,
							"construction_annee" => TAG_CONSTRUCTION_YEAR,
							"renovation_annee" => TAG_RENOVATION_YEAR,
							"tages" => TAG_AMOUNT_OF_FLOORS,
							"alarm" => TAG_ALARM,
							"gaz" => TAG_GAS_CONNECTION,
							"eau" => TAG_CONNECTION_TO_WATER,
							"parlophone" => TAG_PARLOPHONE,
							"vitrage" => TAG_DOUBLE_GLAZING,
							"network" => TAG_INTERNET_CONNECTION,
							"douche" => TAG_SHOWERS_TOTAL,
							"caves" => TAG_CELLARS,
							"dressing" => TAG_DRESSINGS,
							"telephone" => TAG_TELEPHONE,
							"videophone" => TAG_VIDEOPHONE,
							"manger" => TAG_DININGS,
							"ecoles" => TAG_DISTANCE_SCHOOL,
							"sejour" => TAG_SURFACE_LIVING_AREA,
							"ascenseur" => TAG_LIFT,
							"largeur_du_lot" => TAG_LOT_WIDTH,
							"mazout" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"citerne" => TAG_WELL,
							"chauffage" => TAG_HEATING_FR,
							"electricite " => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"inondation" => TAG_FLOOD_INFORMATION_FR,
							"egouts" => TAG_CONNECTION_TO_SEWER,
							"cuisine" => TAG_KITCHEN_TYPE_FR,
							"construction_type" => TAG_CONSTRUCTION_TYPE,
							"chauffage" => TAG_HEATING_FR,
							"debarras" => TAG_STOREROOMS,
							"telephoniques" => TAG_TELEPHONE_CONNECTION,
							"dacces" => TAG_ACCESS_SEMIVALID,
							"lotissement" => TAG_SUBDIVISION_PERMIT,
							"batir" => TAG_PLANNING_PERMISSION,
							"cadastrales" => TAG_CADASTRAL_SECTION,
							"prix" => TAG_PRICE, 
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"mail" => TAG_EMAIL,
							"commun" => TAG_COMMON_COSTS,
							"feu" => TAG_OPEN_FIRE,
							"beaucoup_de_profondeur" => TAG_LOT_DEPTH,
							"facade_largeur" => TAG_FRONTAGE_WIDTH,
							"emission_co2" => TAG_CO2_EMISSION,
                                                     ),
				);
	
	$keys = array_keys($attributeTagsArray[$language]); // Returning Keys
	$key = clearForLowerCase($key); // Converting to lower case
	
	foreach($keys as $k){
	   
		   $check = stripos("X$key","$k");
		   if(!empty($check))
		   return $attributeTagsArray[$language][$k];
	    }
	 
	return '';	 
}

function GetExactAttrib($key,$val){
    //debugx($key.'~'.$val);
    switch($key){
    case TAG_PRICE:
        return toNumber($val);
        break;
    case TAG_BATHROOMS_TOTAL:
        return toNumber($val);
        break;
    case TAG_BEDROOMS_TOTAL:
        return toNumber($val);
        break;
    case TAG_GARAGES_TOTAL:
        return toNumber($val);
        break;
    case TAG_TOILETS_TOTAL:
        return toNumber($val);
        break;
    case TAG_CONSTRUCTION_YEAR:
        return toYear($val);
        break;
    case TAG_RENOVATION_YEAR:
        return toYear($val);
        break;
     case TAG_FREE_FROM_DATE:
        return toUnixTimestamp($val);
        break;
    case TAG_KI:
        return toNumber($val);
        break;
    case TAG_EPC_VALUE:
        return toEpc($val);
        break;
    case TAG_EPC_CERTIFICATE_NUMBER:
        return toNumber($val);
        break;
    case TAG_SURFACE_LIVING_AREA:
       return toNumber($val);
       break;
    case TAG_SURFACE_GROUND:
       return toNumber($val);
       break;
    case TAG_MOST_RECENT_DESTINATION:
       return trim($val);
       break;
    case TAG_PLANNING_PERMISSION:
       return 1;
       break;
    case TAG_SUBDIVISION_PERMIT:
       return toNumber($val); 
    break;
    default:
	$val = trim($val);
	if($val=='Ja' || $val=='Nee')
        return ($val=='Ja') ? 1 : 0;  
    break;
     
    }
}

/// Basic checking for 
function clearForLowerCase($str = ''){ 
    $str = strtolower(str_replace(' ','_',$str)); 
    $str = trim(strip_tags($str)); 
    $str = preg_replace('![^a-z0-9_\-\. ]!','',$str); 
    // $str = trim(preg_replace('!nbsp!','',$str)); 
    $str = trim(preg_replace('!m!','',$str)); 
    $str = trim(preg_replace('!ja,!','',$str));
    //$str = trim(preg_replace('!,!','',$str));
    $str = trim(normalize_str($str));
    return $str ;
 
}

function toNumber($str)
{
    ///return $str;
	$value = 0;
    $str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
    $str = preg_replace("/,(\d{3})|\.(\d{3})/",  "$1$2", $str);
    if(preg_match("/(-?\d+)/", $str, $match)) $value = intval($match[1]);
    return $value;
}

function toUnixTimestamp($str)
{
	return strtotime($str);
}

function toEpc($str){
	$epc = toNumber($str);
	if($epc > 0 && $epc <= 999) return $epc;
}

function toYear($str){
	$year = toNumber($str);
	if($year > 0 && strlen($year) == 4) return $year;
}

function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");
        foreach($invalid as $k => $v){
            $str = str_replace($k, $v, $str); //array_values($invalid)
        }

        return $str;
    }

/**
 * Get a Lat Long format other wise It will give XSD invalid
*/
function getLatLong($str)
{
	$str = floatval($str);
	return substr($str,0,8) ;
}

 //When having to deal with parsing an IIS4 or IIS5 metabase dump
function hex_decode($string)  {
        for ($i=0; $i < strlen($string); $i)  {
        $decoded .= chr(hexdec(substr($string,$i,2)));
        $i = (float)($i)+2;
        }
return $decoded;
} 

//Get Attributes
function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}





/**
 * Get a list of next pages
 */
function getPages($html)
{
    $parser = new PageParser($html);

	$pages = array();
	$nodes = $parser->getNodes("div[@class = 'pages']/a");
	$page = 1;
	$uri = $xtext = '';
	 
    if($nodes->length > 1)
    {
        foreach($nodes as $node)
        {
	    $uri = $parser->getAttr($node, "href");
	     
	    $page = $parser->regex("/page=(\d+)/", $uri );
	    //debugx($page);
        }
    }
 
    for($i=1; $i <= $page; $i++){
	
	$pages[] = (strstr($uri,'jaarverhuur'))?$uri='http://jaarverhuur.sissau.be/nl/jaarverhuur?page='.$i:$uri='http://verkoop.sissau.be/nl/verkoop?page='.$i.'&view=list&goal=0';
    }
 
    return array_unique($pages);
}

/**
 * Get a list of next pages
 */
function getNextPage($html)
{
    $parser = new PageParser($html);

    $pages = array();
    $nodes = $parser->getNodes("div[@class = 'paging-box']/a");
    $page = 1;
    $str = $xtext ='';
    if($nodes->length > 1)
    {
        foreach($nodes as $node)
        {
	    $str = $parser->getAttr($node, "href");
	    
	    preg_match_all('#/(.*?)=#s', $str, $result);
	    debug($result);
	    if(empty($xtext))
	    $xtext = $result[0][0];
	    
	    $page = $parser->regex("/pageindex=(\d+)/", $str );
	    debugx($page);
        }
    }
    
   
 
    //http://www.vastgoedlapeire.be/te-koop?pageindex=5
    for($i=1; $i <= $page; $i++)
	$pages[] = "http://www.vastgoedlapeire.be" .$xtext.$i;

    return array_unique($pages);
}




?>