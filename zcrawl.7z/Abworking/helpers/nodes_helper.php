<?php

	
/**********************Technique 1 ********************************////*****************************************************************************************************	
$nodes = $parser->getNodes("div[contains(@class, 'eight columns')]");
	
/**********************Technique 2  *********************************************************************************************************************/	
$nodes = $parser->getNodes("table[contains(@id, 'ObjectList')]/descendant::a[contains(@href, '&objectid=')][img]");

/**********************Technique A *********************************************************************************************************************/	
$nodes = $parser->getNodes("a[contains(@href, 'Detail')][img]");
$nodes = $parser->getNodes("a[contains(@href, 'GetFile.ashx?path=Documents')]");
	
/**********************Technique B *********************************************************************************************************************/			
	$nodes = $parser->getNodes("div[@class = 'main']");
	
/**********************Technique C *********************************************************************************************************************/	
	$nodes = $parser->getNodes("table[@class = 'full-width table details']/tr");

/**********************Technique D *********************************************************************************************************************/	
    $nodes = $parser->getNodes("table[@cellpadding=1][@border=0][@style='width: 100%;']/tr/td[2]");
    foreach($nodes as $node)
    {
	  //Getting html
	 $imgHtml = $parser->getHTML( $node );
	 
	 // Getting Text
	 $vals[] = $parser->getText($node); 
	 
	 //Getting Attributes text
	 $link = $parser->extract_xpath("div[@class = 'title']/h2/a/@href", RETURN_TYPE_TEXT, null, $node);
		   
	 //Getting numaric value
	 $price = $parser->extract_xpath("parent::div[1]/preceding-sibling::div[1]/h2", RETURN_TYPE_NUMBER, null, $node);
    }
    

	  //Getting Nodes with text
	  $nodes = $parser->getNodes("a[. = 'Meer info']");
	   
	  /// Geting html with paras
	  $para = $parser->getHTML($parser->getNode("section[@class = 'entry']/p"));
	  
	  $para = str_replace('<br />','<br>',$para);
	  $par = explode('<br>', $para);
    
//Library Techniche for get text and Regex


/**********************Technique E *********************************************************************************************************************/

     if($nodes->length < 1)
	  $nodes = $parser->getNodes("div[@class = 'blokje_list_RP']");
	
 
     if($nodes->length < 1)
         $nodes = $parser->getNodes("a[contains(text(), 'meer details')]");
	
  
     if($nodes->length < 1 )
	$nodes = $parser->getNodes("div[@class = 'main']");
	











?>