<?php
//To on Error reporting 
error_reporting(E_ALL);
ini_set('display_errors', '1'); 
 
/************** Issue Type 1 ********************************************************************************/
//error Detail: typeNotBlank
//Solution:
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));

//If type still not coming, check kitchen is avaialable and attribute price per metter squar than It will be Apartment
//if just kitchen available then type will be house. 


/************** Issue Type 2 ********************************************************************************/
//error Detail: Entity Ref : No Name 
// Solution: it is due to & sign in xml. Just replace with &amp;


/************** Issue Type 3 ********************************************************************************/
//error Detail: addressCombo
//Solution:

	//Out of Belgium 
	if(strtolower($property[TAG_CITY]) == strtolower('Sie') )
	return;

//If address is not correct but coming on website
if(empty($property[TAG_CITY])){
	
	$address = $parser->extract_xpath("table[@class = 'infolijst']/tr/td[2]", RETURN_TYPE_TEXT);
	
	$address = $parser->extract_xpath("p[@class = 'extrainfo']", RETURN_TYPE_TEXT); 
	    CrawlerTool::parseAddress($address,$property);
	    
	$addr = explode(' ',$address);
	$property[TAG_CITY] = trim($addr[count($addr)-1]);
	$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
	
	if(strlen($property[TAG_ZIP]) < 4){
		$address = str_replace($property[TAG_ZIP],'',$address );
		$property[TAG_BOX_NUMBER] = $property[TAG_ZIP];
		$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
		
		if(strlen($property[TAG_ZIP]) < 4)
		unset($property[TAG_ZIP]) ;
	}
	
	$property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
	$property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
	
	$property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
	$property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
	
	if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
	
	if(strlen($property[TAG_BOX_NUMBER]) < 3 || strlen($property[TAG_BOX_NUMBER]) > 3 )
	unset($property[TAG_BOX_NUMBER]);
}

	 
	
/////// Or You can use this function for address process /////////////

//////Function to return number and text string
function extractAddress($address){
	$street = "";
	if (strpos($address, ',') !== false) {
		list($number, $street) = explode(',', $address, 2);
	} else {
		preg_match('~^(.*?)((?:unit )?(?:[0-9]+\s?-\s?[0-9]+|[0-9]+))(.*)$~is', $address, $parts);
		
		$number = $parts[2];
		if (trim($parts[1]) != '') {
			$street .= trim($parts[1]);
		}
		if(trim($parts[3]) != '') {
			if($street ==""){
				$street .= trim($parts[3]);
			}
			else{
				$street .= " ".trim($parts[3]);	
			}
		}
	}

	return $number."|||".$street;

}


/************** Issue Type 4 ********************************************************************************/
//error Detail: Stuts wrong or empty
//Solution:
	$propertyStatus = CrawlerTool::getPropertyStatus($text);
	if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
	{
	    $property[TAG_STATUS] = $propertyStatus;
	}
		
	//Return in case of sold or rented
	if($property[TAG_STATUS]==STATUS_SOLD)	 return ;
	if($property[TAG_STATUS]==STATUS_RENTED) return ;
	
	
	if(strpos(strtolower(str_replace(' ','_',$html)),"verhuurd")){
	    $property[TAG_STATUS] = "rented"; return;
	}
	if(strpos(strtolower(str_replace(' ','_',$html)),"vrkocht")){
	    $property[TAG_STATUS] = "sold"; return;
	}
	  
	if(strpos($html,"VERHUURD") || strpos($html,"Verhuurd")){
	    $property[TAG_STATUS] = "rented"; return;
	}
	if(strpos($html,"VERKOCHT") || strpos($html,"Verkocht")){
	    $property[TAG_STATUS] = "sold"; return;
	}
	
	 /// Never Crawl
	if(!empty(strpos($html,"Loué")))
		return;
	 
	$stpos = strpos($html, "in optie");
	if(!empty($stpos))
		return;

	$stpos = strpos($html, "met optie");
	if(!empty( $stpos ))
		return;
	
	$stpos = strpos($html, "optie");
	if(!empty( $stpos ))
		return;
	
	$stpos = strpos($html, "verkocht");
	if(!empty( $stpos ))
		return;

/************** Issue Type 5 ********************************************************************************/
//error Detail: French/Dutch Character Issue and Get multiple languages data
//Solution:
	//Prepairing Urls you can modify 
	$property[TAG_UNIQUE_URL_NL] = str_replace('fr-fr','nl-be',$property[TAG_UNIQUE_URL_FR]);
	$property[TAG_UNIQUE_URL_EN] = str_replace('fr-fr','en-gb',$property[TAG_UNIQUE_URL_FR]);
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_NL]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	
	$property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]");
	$property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);
    
	$property[TAG_TEXT_DESC_NL] = utf8_decode(CrawlerTool::encode($property[TAG_TEXT_DESC_NL])); 
	$property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode(CrawlerTool::encode($property[TAG_PLAIN_TEXT_ALL_NL])); 
	if(empty($property[TAG_TEXT_DESC_NL])){
		
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res); 
		$res[1] = str_replace(chr(11),'',$res[1]); 
		$property[TAG_TEXT_DESC_NL] = utf8_decode(CrawlerTool::encode(strip_tags($res[1]))); 
	}
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_EN]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	
	$property[TAG_TEXT_DESC_EN] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]");
	$property[TAG_PLAIN_TEXT_ALL_EN] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);
    
	$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode($property[TAG_TEXT_DESC_EN])); 
	$property[TAG_PLAIN_TEXT_ALL_EN] = utf8_decode(CrawlerTool::encode($property[TAG_PLAIN_TEXT_ALL_EN])); 
		
	if(empty($property[TAG_TEXT_DESC_EN])){
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
		$res[1] = str_replace(chr(11),'',$res[1]);
		$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode(strip_tags($res[1])));
	}
	
	$html = str_replace("±", "", $html);
	
	$property[TAG_TEXT_DESC_EN] = htmlspecialchars_decode(htmlentities($property[TAG_TEXT_DESC_EN]));
	$property[TAG_TEXT_DESC_FR] = htmlspecialchars_decode(htmlentities($property[TAG_TEXT_DESC_FR]));
	$property[TAG_TEXT_DESC_NL] = htmlspecialchars_decode(htmlentities($property[TAG_TEXT_DESC_NL]));
	$property[TAG_TEXT_SHORT_DESC_FR] = htmlspecialchars_decode(htmlentities($property[TAG_TEXT_SHORT_DESC_FR]));
	
	$property[TAG_PLAIN_TEXT_ALL_EN] = htmlspecialchars_decode(htmlentities($property[TAG_PLAIN_TEXT_ALL_EN]));
	$property[TAG_PLAIN_TEXT_ALL_FR] = htmlspecialchars_decode(htmlentities($property[TAG_PLAIN_TEXT_ALL_FR]));
	$property[TAG_PLAIN_TEXT_ALL_NL] = preg_replace('![^a-z0-9_\-\. ]!','',htmlspecialchars_decode(htmlentities($property[TAG_PLAIN_TEXT_ALL_NL])));
	
//************************************************

///Fixing Characters
//Dutch
if(isset($property[TAG_TEXT_TITLE_NL]))
$property[TAG_TEXT_TITLE_NL]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_TEXT_TITLE_NL])));

if(isset($property[TAG_TEXT_SHORT_DESC_NL]))
$property[TAG_TEXT_SHORT_DESC_NL]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_TEXT_SHORT_DESC_NL])));

if(isset($property[TAG_TEXT_DESC_NL]))
$property[TAG_TEXT_DESC_NL]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_TEXT_DESC_NL])));

if(isset($property[TAG_PLAIN_TEXT_ALL_NL]))
$property[TAG_PLAIN_TEXT_ALL_NL]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_PLAIN_TEXT_ALL_NL])));

///French

if(isset($property[TAG_TEXT_TITLE_NL]))
$property[TAG_TEXT_TITLE_NL]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_TEXT_TITLE_NL])));

if(isset($property[TAG_TEXT_SHORT_DESC_FR]))
$property[TAG_TEXT_SHORT_DESC_FR]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_TEXT_SHORT_DESC_FR])));

if(isset($property[TAG_TEXT_DESC_FR]))
$property[TAG_TEXT_DESC_FR]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_TEXT_DESC_FR])));

if(isset($property[TAG_PLAIN_TEXT_ALL_FR]))
$property[TAG_PLAIN_TEXT_ALL_FR]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_PLAIN_TEXT_ALL_FR])));

///English
if(isset($property[TAG_TEXT_SHORT_DESC_EN]))
$property[TAG_TEXT_SHORT_DESC_EN]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_TEXT_SHORT_DESC_EN])));

if(isset($property[TAG_TEXT_DESC_EN]))
$property[TAG_TEXT_DESC_EN]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_TEXT_DESC_EN])));

if(isset($property[TAG_PLAIN_TEXT_ALL_EN]))
$property[TAG_PLAIN_TEXT_ALL_EN]  = utf8_decode(CrawlerTool::encode(strip_tags($property[TAG_PLAIN_TEXT_ALL_EN])));

 
//	Ã90mÂ² 


 ////////////////Adding Lat and log by Google Map
 
	/*//////////// Technique A ////////// */
	if (preg_match('!google\.maps\.LatLng\(([0-9.]+),([0-9.]+)\)!',$html,$res))
	{
		$property[TAG_LATITUDE]  = $res[1];
		$property[TAG_LONGITUDE]  = $res[2];
	}
	
	/*//////////// Technique B ////////// */
	preg_match_all('#GoogleMapV3.AddMarker\((.*?)\)#s', $html, $result);
	
	/*//////////// Technique C ////////// */
	preg_match_all('#google.maps.LatLng\((.*?)\)#s', $html, $result);
	
	$latlog = str_replace("'","",$result[1][0]);
	$latlog = explode(',', $latlog);
	
	$property[TAG_LATITUDE] = getLatLong($latlog[0]);
	$property[TAG_LONGITUDE] = getLatLong($latlog[1]); 

	 
function getLatLong($str)
{
	$str = floatval($str);
	return substr($str, 0, 8) ;
}



//// Fixing Special Charachter Issue
function fixSpecialChr($str){
    return mb_convert_encoding(utf8_decode(strip_tags($str)), 'HTML-ENTITIES', 'UTF-8');
}

	
?>