<?php
/**********************Technique A ****************////*****************************************************************************************************

	$vars = array(); 
	$nodes = $parser->getNodes("table[@cellpadding=2][@border=0][@style='width: 100%;']/tr");
	foreach($nodes as $node)
	{
	    
	    $key = $parser->extract_xpath("td[1]",  RETURN_TYPE_TEXT, null, $node); 
	    $val = $parser->extract_xpath("td[2]", RETURN_TYPE_TEXT, null, $node);
	    $key = clearForLowerCase($key);
	    if(!empty($key)) $vars[$key]= trim(utf8_decode($val));
	    
	}
	 
// --------------------------------------------------------------------------------------------------- ////
	
	$nodes = $parser->getNodes("div[@class = 'infos-generales']/span");
 	debug($nodes); //checking if nodes come or not
 	foreach($nodes as $node)
	{
	    $arr[1] = $parser->getText($node);
	    $arr[2] = $parser->extract_xpath("span[@style = 'width: 115px; color: #999999; font-size: 14px; position: absolute; left: 140px;']", RETURN_TYPE_TEXT, null, $node); 
	    $arr[1] = clearForLowerCase($arr);
	    if(!empty($arr[1])) $vars[$arr[1]]= trim(utf8_decode($arr[2])); 
	}
         
        //----------------------------------------------------------------------------------//
	$vars = $arr = $unmatched_variables = array();
	
	foreach ($vars as $label => $value)
	{ 
		$attribute = getAttributes(clearForLowerCase($label));
		if(!empty($attribute) ){
		    if(empty($property[$attribute]))
		    $property[$attribute] = GetExactAttrib($attribute,$value);
		}
		else
		    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
		
	}
	
	unset($property['cellphone']);
	unset($property['fax']);
	unset($property['email']);
	unset($property['telephone']);
	
	///Obligatory Attrib Info
	if(!isset($property[TAG_HAS_PROCEEDING]) || $property[TAG_HAS_PROCEEDING] !=1 )
	$property[TAG_HAS_PROCEEDING] = '';
	
	if(!isset($property['planning_permission']) || $property['planning_permission'] !=1)
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || $property['subdivision_permit'] !=1)
	$property['subdivision_permit'] = '';
	
	
	if(!isset($property['most_recent_destination']) || $property['most_recent_destination'] !=1)
	$property['most_recent_destination'] = '';
	
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
	 
	
/**
 * Getting Exact Attribute Key for XML
*/
function getAttributes($key, $language='nl'){ //String Function always return string

    $attributeTagsArray	= array('en' => array(	'pric' 			=>  TAG_PRICE,
                                                'constr'		=> TAG_CONSTRUCTION_YEAR,
                                                'ground'		=> TAG_SURFACE_GROUND,
                                                'living' 		=> TAG_SURFACE_LIVING_AREA,
                                                'bath'			=> TAG_BATHROOMS_TOTAL,
                                                'warm'			=> TAG_HEATING_EN,
                                                'heat'			=> TAG_HEATING_EN,
                                                'sewer'			=> TAG_CONNECTION_TO_SEWER,
                                                'telep'			=> TAG_TELEPHONE_CONNECTION,
                                                'intern'		=> TAG_INTERNET_CONNECTION,
                                                'permission'		=> TAG_PLANNING_PERMISSION,
                                                'subdivision'		=> TAG_SUBDIVISION_PERMIT,
                                                'electri'		=> TAG_METER_FOR_ELECTRICITY,
                                                'hall'			=> TAG_HALLS,
                                                'dining'		=> TAG_DININGS,
                                                'kitch'			=> TAG_KITCHENS,
                                                'laundr'		=> TAG_LAUNDRY_ROOMS,
                                                'dress'			=> TAG_DRESSING,
                                                'bed'			=> TAG_BEDROOMS_TOTAL,
                                                'room'			=> TAG_BEDROOMS_TOTAL,
                                                'park'			=> TAG_PARKINGS,
                                                'garage'		=> TAG_GARAGES_TOTAL,
                                                'type'			=> TAG_TYPE,
                                                'garden'		=> TAG_GARDEN_AVAILABLE,
                                                'floor'			=> TAG_AMOUNT_OF_FLOORS,
                                                'winter'		=> TAG_WINTERGARDENS,
                                                'furnish'		=> TAG_FURNISHED,
                                                'water'			=> TAG_CONNECTION_TO_WATER,
                                                'lift'			=> TAG_LIFT,
                                                'glaz'			=> TAG_DOUBLE_GLAZING,
                                                'terrac'		=> TAG_TERRACES,
                                                'fronts'		=> TAG_AMOUNT_OF_FACADES,
                                                'category'		=> TAG_TYPE,
                                                'free'			=> TAG_FREE_FROM_DATE,
                                                'habit'			=> TAG_SURFACE_LIVING_AREA,
                                                'plot'			=> TAG_SURFACE_GROUND,
                                                'shops'			=> TAG_DISTANCE_SHOPS,
                                                'schools'		=> TAG_DISTANCE_SCHOOL,
                                                'transport'		=> TAG_DISTANCE_PUBLIC_TRANSPORT,
                                                'shower'		=> TAG_SHOWERS_TOTAL,
                                                'stor'			=> TAG_STOREROOMS,
                                                'gas'			=> TAG_GAS_CONNECTION,
                                                'alarm'			=> TAG_ALARM,
                                                'security'		=> TAG_SECURITY_DOOR,
                                                'parlo'			=> TAG_PARLOPHONE,
                                                'video'			=> TAG_VIDEOPHONE,
                                                'elevat'		=> TAG_LIFT,
                                                'blind'			=> TAG_SUN_BLINDS,
                                                'renova'		=> TAG_RENOVATION_YEAR,
                                                'control'		=> TAG_ACCESS_SEMIVALID,
                                                        ),
                                //Function written by Team
                                'nl' => array(  "prij"                  =>  TAG_PRICE,
                                                "type"                  =>  TAG_TYPE,
                                                "adres"                 =>  TAG_ADDRESS_VISIBLE,
                                                "bouwjaar"              => TAG_CONSTRUCTION_YEAR,
                                                "grondopp"              => TAG_SURFACE_GROUND, 
                                                "bewoonbare"            => TAG_SURFACE_LIVING_AREA,
                                                "antal_kamer"           => TAG_BEDROOMS_TOTAL,
                                                "slaapkamer"            => TAG_BEDROOMS_TOTAL,
                                                "antal_badkam"          => TAG_BATHROOMS_TOTAL,
                                                "badkam"                => TAG_BATHROOMS_TOTAL,
                                                "epc_certi"             => TAG_EPC_CERTIFICATE_NUMBER,
                                                "certificaatnr"         => TAG_EPC_CERTIFICATE_NUMBER,
                                                "epc_ind"               => TAG_EPC_VALUE,
                                                "epc_waa"               => TAG_EPC_VALUE,
                                                "epc"                   => TAG_EPC_VALUE,
                                                "adastraal_inkomen"     => TAG_KI,
                                                "adastraal"             => TAG_KI,
                                                "inkomen"               => TAG_KI,
                                                "ki"                    => TAG_KI,
                                                "adastrale_numme"       => TAG_KI_INDEX,
                                                "verdieping"            => TAG_AMOUNT_OF_FLOORS,
                                                "living"                => TAG_SURFACE_LIVING_AREA,
                                                "renovatie"             => TAG_RENOVATION_YEAR,
                                                "kadaster_sectie"       => TAG_CADASTRAL_SECTION,
                                                "beschikbaar"           => TAG_FREE_FROM,
                                                "fax"                   => TAG_FAX,
                                                "tel"                   => TAG_CELLPHONE,
                                                "mail"                  => TAG_EMAIL,
                                                "winkels"               => TAG_DISTANCE_SHOPS,
                                                "vervoer"               => TAG_DISTANCE_PUBLIC_TRANSPORT,
                                                "overstromings"         => TAG_FLOOD_INFORMATION_NL,
                                                "garage"                => TAG_GARAGES_TOTAL,
                                                "toilet"                => TAG_TOILETS_TOTAL,
                                                "parking"               => TAG_PARKINGS_TOTAL,
                                                "gevels"                => TAG_AMOUNT_OF_FACADES,
                                                "lasten"                => TAG_COMMON_COSTS,
                                                "gas"                   => TAG_GAS_CONNECTION,
                                                "water"                 => TAG_CONNECTION_TO_WATER,
                                                "telefoon"              => TAG_TELEPHONE,
                                                "lift"                  => TAG_LIFT,
                                                "gemeubeld"             => TAG_FURNISHED,
                                                "tuin"                  => TAG_GARDEN_AVAILABLE,
                                                "haard"                 => TAG_OPEN_FIRE,
                                                "alarm"                 => TAG_ALARM,
                                                "parlofoon"             => TAG_PARLOPHONE,
                                                "videofoon"             => TAG_VIDEOPHONE,
                                                "breedte"               => TAG_LOT_WIDTH,
                                                "diepte"                => TAG_LOT_DEPTH,
                                                "constructie"           => TAG_CONSTRUCTION_TYPE,
                                                "gevelbreedte"          => TAG_FRONTAGE_WIDTH,
                                                "winkel"                => TAG_HEATING_NL,
                                                "douche"                => TAG_SHOWERS_TOTAL,
                                                "keuken"                => TAG_KITCHEN_TYPE_NL,
                                                "ligging"               => TAG_SUBDIVISION_PERMIT,
                                                "stedenbouwkundige"     => TAG_PLANNING_PERMISSION,
                                                "terras"                => TAG_TERRACES,
                                                "terrein"               => TAG_SURFACE_GROUND,
                                                "scholen"               => TAG_DISTANCE_SCHOOL,
                                                "oppervlakte"           => TAG_SURFACE_LIVING_AREA,
                                                "eetkamer"              => TAG_DININGS,
                                                "dressing"              => TAG_DRESSINGS,
                                                "kelder"                => TAG_CELLARS,
                                                "beroep"                => TAG_FREE_PROFESSIONS,
                                                "berging"               => TAG_STOREROOMS,
                                                "wasplaats"             => TAG_LAUNDRY_ROOMS,
                                                "elektric"              => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
                                                "beglazing"             => TAG_DOUBLE_GLAZING,
                                                "verwarming"            => TAG_HEATING_NL,
                                                "riolering"             => TAG_CONNECTION_TO_SEWER,
                                                "olietank"              => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
                                                "waterput"              => TAG_WELL,
                                                "telefoonbekabeling"    => TAG_TELEPHONE_CONNECTION,
                                                "toegangscontrole"      => TAG_ACCESS_SEMIVALID,
                                                "computer"              => TAG_INTERNET_CONNECTION,
                                                "nroerende_voorhef"     => TAG_PROPERTY_TAX,
                                                        ),
                                'fr' => array(	"prij"                  =>  TAG_PRICE,
                                                "Meuble"                => TAG_FURNISHED,
                                                "facades"               => TAG_AMOUNT_OF_FACADES,
                                                "nombre_de_chambre"     => TAG_BEDROOMS_TOTAL,
                                                "chambres"              => TAG_BEDROOMS_TOTAL,
                                                "chambre"               => TAG_BEDROOMS_TOTAL,
                                                "nombre_de_salle_de_bain"=> TAG_BATHROOMS_TOTAL,
                                                "jardin"                => TAG_GARDEN_AVAILABLE,
                                                "garage"                => TAG_GARAGES_TOTAL,
                                                "terras"                => TAG_TERRACES,
                                                "parking"               => TAG_PARKINGS_TOTAL,
                                                "habita"                => TAG_SURFACE_LIVING_AREA,
                                                "surface"               => TAG_SURFACE_LIVING_AREA,
                                                "terrain"               => TAG_SURFACE_GROUND,
                                                "disponible"            => TAG_FREE_FROM,
                                                "magasins"              => TAG_DISTANCE_SHOPS,
                                                "transport"             => TAG_DISTANCE_PUBLIC_TRANSPORT,
                                                "toilet"                => TAG_TOILETS_TOTAL,
                                                "construction_annee"    => TAG_CONSTRUCTION_YEAR,
                                                "renovation_annee"      => TAG_RENOVATION_YEAR,
                                                "tages"                 => TAG_AMOUNT_OF_FLOORS,
                                                "alarm"                 => TAG_ALARM,
                                                "gaz"                   => TAG_GAS_CONNECTION,
                                                "eau"                   => TAG_CONNECTION_TO_WATER,
                                                "parlophone"            => TAG_PARLOPHONE,
                                                "vitrage"               => TAG_DOUBLE_GLAZING,
                                                "network"               => TAG_INTERNET_CONNECTION,
                                                "douche"                => TAG_SHOWERS_TOTAL,
                                                "caves"                 => TAG_CELLARS,
                                                "dressing"              => TAG_DRESSINGS,
                                                "telephone"             => TAG_TELEPHONE,
                                                "videophone"            => TAG_VIDEOPHONE,
                                                "manger"                => TAG_DININGS,
                                                "ecoles"                => TAG_DISTANCE_SCHOOL,
                                                "sejour"                => TAG_SURFACE_LIVING_AREA,
                                                "ascenseur"             => TAG_LIFT,
                                                "largeur_du_lot"        => TAG_LOT_WIDTH,
                                                "mazout"                => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
                                                "citerne"               => TAG_WELL,
                                                "chauffage"             => TAG_HEATING_FR,
                                                "electricite"           => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
                                                "fax"                   => TAG_FAX,
                                                "tel"                   => TAG_CELLPHONE,
                                                "inondation"            => TAG_FLOOD_INFORMATION_FR,
                                                "egouts"                => TAG_CONNECTION_TO_SEWER,
                                                "cuisine"               => TAG_KITCHEN_TYPE_FR,
                                                "construction_type"     => TAG_CONSTRUCTION_TYPE,
                                                "chauffage"             => TAG_HEATING_FR,
                                                "debarras"              => TAG_STOREROOMS,
                                                "telephoniques"         => TAG_TELEPHONE_CONNECTION,
                                                "dacces"                => TAG_ACCESS_SEMIVALID,
                                                "lotissement"           => TAG_SUBDIVISION_PERMIT,
                                                "batir"                 => TAG_PLANNING_PERMISSION,
                                                "cadastrales"           => TAG_CADASTRAL_SECTION,
                                                "prix"                  => TAG_PRICE, 
                                                "epc"                   => TAG_EPC_VALUE,
                                                "ki"                    => TAG_KI,
                                                "mail"                  => TAG_EMAIL,
                                                "commun"                => TAG_COMMON_COSTS,
                                                "feu"                   => TAG_OPEN_FIRE,
                                                "beaucoup_de_profondeur" => TAG_LOT_DEPTH,
                                                "facade_largeur"        => TAG_FRONTAGE_WIDTH,
                                                "emission_co2"          => TAG_CO2_EMISSION,
                                             ),
                            );
    
    $keys = array_keys($attributeTagsArray[$language]); // Returning Keys
    $key = clearForLowerCase($key); // Converting to lower case and trim
    
    foreach($keys as $k){
       $check = stripos("X$key","$k");
       if(!empty($check))
       return $attributeTagsArray[$language][$k];
    }
     
    return '';	 
}

/**
 * Getting Exact Attribute Value for XML
*/
function GetExactAttrib($key, $val){
 
    $a = array();
    
    switch($key){
        case TAG_CONSTRUCTION_YEAR:
            return toYear($val);
            break;
        case TAG_RENOVATION_YEAR:
            return toYear($val);
            break;
        case TAG_FREE_FROM_DATE:
            return toUnixTimestamp($val);
            break;
        
        case TAG_EPC_VALUE:
            return toEpc($val);
            break;
        case TAG_GARDEN_AVAILABLE:
            return (strtolower($val)=='ja') ? 1 : 0;
        break;
        
        case TAG_CONNECTION_TO_WATER:
            return (strtolower($val)=='ja') ? 1 : 0;
        break;
      
        case TAG_OPEN_FIRE:
            return (strtolower($val)=='ja') ? 1 : 0;
        break;
      
        case TAG_TERRACES:
            return $a[] = toNumber($val); 
        break;
        
        default:
             
            $val = trim($val);
            
            if(stripos($key,"_permission") !== false)
                return (strtolower($val)=='ja') ? 1 : '';
            
             if(stripos($key,"_visible") !== false)
                return (strtolower($val)=='ja') ? 1 : 0;
            
            if(strtolower($val)=='ja' || strtolower($val)=='nee' || strtolower($val)=='neen')
                return (strtolower($val)=='ja') ? 1 : 0;
    
            else{
    
                if(stripos($key,"_nl") !== false)
                    return $val;
                
                if(stripos($key,"_fr") !== false)
                    return $val;
            
                if(stripos($key,"_en") !== false)
                    return $val;
                else
                    return toNumber($val);
                
            }
            
        break;
     
    }
}

/**
 * Basic Fixing for array
*/
function clearForLowerCase($str = ''){ 
    $str = strtolower(str_replace(' ','_',$str)); 
    $str = trim(strip_tags($str)); 
    $str = trim(preg_replace('!ja,!','',$str));
    $str = trim(normalize_str($str));
    return $str ;
}

/**
 * Returning Number
*/
function toNumber($str)
{
    
    $value = 0;
    $str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
    $str = preg_replace("/,(\d{3})|\.(\d{3})/",  "$1$2", $str);
    if(preg_match("/(-?\d+)/", $str, $match)) $value = intval($match[1]);
    
    if(empty($value))
        return 0;
    else
        return $value;
}

/**
 * Returning Timestamp
*/
function toUnixTimestamp($str)
{
	return strtotime($str);
}

/**
 * Returning EPC Value
*/
function toEpc($str){
	$epc = toNumber($str);
	if($epc > 0 && $epc <= 999) return $epc;
}

/**
 * Returning Year format
*/
function toYear($str){
	$year = toNumber($str);
	if($year > 0 && strlen($year) == 4) return $year;
}

/**
 * Normalizing Special Characters
*/
function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");
        foreach($invalid as $k => $v){
            $str = str_replace($k, $v, $str);  
        }

        return $str;
    }

/**
 * Get a Lat Long format other wise It will give XSD invalid
*/
function getLatLong($str)
{
    return floatval(substr($str, 0, 8));
}

/**
 * Fixing Special Charachter Issue
 */
function fixSpecialChr($str){
	$str =  CrawlerTool::strip(CrawlerTool::fixUTF8(strip_tags(trim($str)))); 
	//toUTF8 
	return $str;
}


//function for print array
function debug($obj)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
}

//function for print string
function debugx($obj, $e = false)
{
    echo "<br />************************<br/>";
    echo $obj;
    echo "<br/>************************<br/>";
    if($e)
      exit;
}    
    
//Get Attributes
function get_var(&$vars,$field,$regex = '')
{
    if (isset($vars[$field]))
    {
	    $x = $vars[$field];
	    unset($vars[$field]);

	    if (!empty($regex))
	    {
			    return (preg_match($regex,$x,$res)) ? $res[1] : false;
	    }
	    return trim($x);
    }

    return false;
}
/**********************Technique B ****************////*****************************************************************************************************

// In case of li 
$parser->setQueryTemplate("li[contains(text(),'" .XPATH_QUERY_TEMPLATE . "')]");

// In some case
$parser->setQueryTemplate("b[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::text()[1]");
	
// START using XPath query template
$parser->setQueryTemplate("table[@cellpadding=1][@border=0][@style='width: 100%;']//td[contains(text(),'" .XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]"); 

// In case of Lable in TD
$parser->setQueryTemplate("td[label[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]]/following-sibling::td[1]");

//In case of TD and get next td val
$parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

//In case of span and get next span val
$parser->setQueryTemplate("span[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::span[1]");
 
//kwh/m² = TAG_EPC_VALUE 
if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC score", RETURN_TYPE_EPC);
if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC Index:", RETURN_TYPE_EPC);
if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC Index:", RETURN_TYPE_EPC);
    
$property[TAG_KI] = $parser->extract_xpath("kadastraal inkomen", RETURN_TYPE_NUMBER);
$property[TAG_KI_INDEX] = $parser->extract_xpath("kad.ink.", RETURN_TYPE_NUMBER);
$property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("bouwjaar", RETURN_TYPE_YEAR);
$property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("Renovatie jaar", RETURN_TYPE_YEAR);
$property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Bewoonbare opp.:", RETURN_TYPE_NUMBER);
$property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Oppervlakte terrein:", RETURN_TYPE_NUMBER);
$property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Aantal slaapkamers:", RETURN_TYPE_NUMBER);
$property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
$property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toiletten aantal", RETURN_TYPE_NUMBER);
$property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("garage aantal", RETURN_TYPE_NUMBER);
$property[TAG_PARKINGS_TOTAL] = $parser->extract_xpath("parking buiten aantal", RETURN_TYPE_NUMBER);
$property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels", RETURN_TYPE_NUMBER);
$property[TAG_AMOUNT_OF_FLOORS] = $parser->extract_xpath("verdiepingen aantal", RETURN_TYPE_NUMBER);
$property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Beschikbaar vanaf", RETURN_TYPE_UNIX_TIMESTAMP); 
$property[TAG_COMMON_COSTS] = $parser->extract_xpath("lasten", RETURN_TYPE_NUMBER); 
$property[TAG_GAS_CONNECTION] = ($parser->extract_xpath("gas") === "Ja" ? 1 : 0); 
$property[TAG_CONNECTION_TO_WATER] = ($parser->extract_xpath("water") === "Ja" ? 1 : 0); 
$property[TAG_TELEPHONE_CONNECTION] = ($parser->extract_xpath("telefoon") === "Ja" ? 1 : 0); 
$property[TAG_LIFT] = ($parser->extract_xpath("lift") === "Ja" ? 1 : 0); 
$property[TAG_FURNISHED] = ($parser->extract_xpath("Gemeubeld") === "Ja" ? 1 : 0); 
$property[TAG_GARDEN_AVAILABLE] = ($parser->extract_xpath("Tuin") === "Ja" ? 1 : 0); 
$property[TAG_OPEN_FIRE] = ($parser->extract_xpath("open haard aantal") ? 1 : 0); 
$property[TAG_ALARM] = ($parser->extract_xpath("alarm") ? 1 : 0); 
$property[TAG_PARLOPHONE] = ($parser->extract_xpath("parlofoon") ? 1 : 0); 
$property[TAG_VIDEOPHONE] = ($parser->extract_xpath("videofoon") === "Ja" ? 1 : 0); 
$property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels:", RETURN_TYPE_NUMBER); 
$property[TAG_LOT_WIDTH] 		= $parser->extract_xpath("Perceelbreedte:", RETURN_TYPE_NUMBER); 
$property[TAG_LOT_DEPTH] 		= $parser->extract_xpath("Perceeldiepte:", RETURN_TYPE_NUMBER); 
$property[TAG_CONSTRUCTION_TYPE] 	= $parser->extract_xpath("Type constructie:", RETURN_TYPE_TEXT);
$property[TAG_FRONTAGE_WIDTH] 	= $parser->extract_xpath("Gevelbreedte:", RETURN_TYPE_NUMBER); 
$property[TAG_HEATING_NL]		= $parser->extract_xpath("Winkel:", RETURN_TYPE_NUMBER); 
$property[TAG_SHOWERS_TOTAL]        = $parser->extract_xpath("salle de douches nombre", RETURN_TYPE_NUMBER); 
$property[TAG_FREE_FROM]            =  $parser->extract_xpath("beschikbaar vanaf", RETURN_TYPE_TEXT); 
$property[TAG_KITCHEN_TYPE_FR]      = $parser->extract_xpath("keuken type", RETURN_TYPE_TEXT);  
$property[TAG_SUBDIVISION_PERMIT]   = $parser->extract_xpath("Ligging:", RETURN_TYPE_NUMBER);
$property[TAG_PRIORITY_PURCHASE]   = $parser->extract_xpath("keuken type", RETURN_TYPE_NUMBER);
$property[TAG_HAS_PROCEEDING]   = $parser->extract_xpath("keuken type", RETURN_TYPE_NUMBER);


/**********************Technique C ****************/ //*****************************************************************************************************



  
    $nodes = $parser->getNodes("tr[@valign='top']");
    foreach($nodes as $node)
    {
        $key = utf8_decode(CrawlerTool::encode($parser->extract_xpath("td[1]",  RETURN_TYPE_TEXT, null, $node))); 
        $val = $parser->extract_xpath("td[2]", RETURN_TYPE_TEXT, null, $node); 
        $k = getAttributes($key, 'fr');
        if(!empty($k))
            $property[$k] = GetExactAttrib($k,$val);
        else
            $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $key, TAG_VARIABLE_VALUE => $val);
    }
 
    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;



/**********************Technique D ****************///*****************************************************************************************************
$keys = $vals = $vars = array();
    
    $nodes = $parser->getNodes("table[@cellpadding=1][@border=0][@style='width: 100%;']/tr/td[1]");
    foreach($nodes as $node)
    {
	//$imgHtml = $parser->getHTML( $node );
	 $key[] = $parser->getText($node); 
	 //debugx($text); 
	///Getting link with node html
	//$link = $parser->extract_xpath("div[@class = 'title']/h2/a/@href", RETURN_TYPE_TEXT, null, $node);
	
    }
    
    $nodes = $parser->getNodes("table[@cellpadding=1][@border=0][@style='width: 100%;']/tr/td[2]");
    foreach($nodes as $node)
    {
	//$imgHtml = $parser->getHTML( $node );
	 $vals[] = $parser->getText($node); 
	
    }
    
    foreach($vals as $k=>$v){
	if($v=="Ja" || $v=="Nee")
	$vars[str_replace(' ','_',$key[$k])] = $v=="Ja"?1:0;
	else
	$vars[str_replace(' ','_',$key[$k])] = $v;
    }
    
    $unmatched_variables = array(); 
    foreach ($vars as $label => $value)
    { 
	    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
    } 
    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables; 
    
    
    $unmatched_var_arr = array('Beschikbaar vanaf','Grootte terrein','keuken type','Tuin','buurt type','vloerbedekking type','vloerbedekking type','riolering','olietank','dubbele beglazing','schrijnwerkerij type','wasplaats');
	foreach($unmatched_var_arr as $var){
		$tag_unmatched_var = $parser->extract_xpath($var, RETURN_TYPE_TEXT);
		if($tag_unmatched_var){
			if($tag_unmatched_var=="Ja" || $tag_unmatched_var=="Nee")
				$property[TAG_UNMATCHED_VARIABLES][]=array(TAG_VARIABLE_LABEL=>$var,TAG_VARIABLE_VALUE=>$tag_unmatched_var=="Ja"?1:0);
			else
				$property[TAG_UNMATCHED_VARIABLES][]=array(TAG_VARIABLE_LABEL=>$var,TAG_VARIABLE_VALUE=>$tag_unmatched_var);
		}		
	}
  
/**********************Technique E ****************////*****************************************************************************************************

//parse fields if td are without any class or attribute
$unmatched_variables = array();
	$attributes = $parser->getNodes("table[@class = 'full-width table details']/tr");
	foreach($attributes as $attr){
		
		$AttribDetail = explode(' ',trim($attr->nodeValue)); 
		 $key = str_replace(' ','_', trim($AttribDetail[0]) );
                 $val = str_replace(' ','_', trim($AttribDetail[1]) );
		$attribute = setAtributesX($key);
                
        }

        
/**********************Technique F ****************////*****************************************************************************************************
  // get all the labels and there values 
    $Labels=$parser->extract_regex('@<td class="kenmerklabel">([^<>]+)</td>@',RETURN_TYPE_ARRAY);
    $Values=$parser->extract_regex('@<div class="kenmerk">([^<>]+)</div>@',RETURN_TYPE_ARRAY);
    unset($Labels[count($Labels)-1]);
 
/**********************Technique G ****************////***************************************************************************************************** 
        $vars = $arr =array();
	 
	$nodes = $parser->getNodes("div[@class = 'field']");
 
 	foreach($nodes as $node)
	{
	    $arr[1] = $parser->extract_xpath("div[@class= 'name']", RETURN_TYPE_TEXT, null, $node);
	    $arr[2] = $parser->extract_xpath("div[@class= 'value']", RETURN_TYPE_TEXT, null, $node);
	    $arr[1] = strtolower($arr[1]);
	    $arr[1] = trim(strip_tags($arr[1]));
	    $arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
	    $arr[1] = trim(preg_replace('!nbsp!','',$arr[1]));
	
	    if(empty($property[TAG_PRICE])) $property[TAG_PRICE] =  toNumber(trim($arr[2]));
	  
	    if(!empty($arr[1])) $vars[str_replace(' ','_',$arr[1])] = trim(utf8_decode($arr[2])); 
	}
   
        //----------------------------------------------------------------------------------//
        $unmatched_variables = array();
	$address = '';
	foreach ($vars as $label => $value)
	{
	    
	    if($label=='adres')
		$address = $value; 
	    
		$attribute = getAttributes($label);
		
		if(!empty($attribute)){
		    if(empty($property[$attribute]))
		    $property[$attribute] = GetExactAttrib($attribute, $value);
		}
		else
		    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
		
	}
	
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;


/**********************Technique H ****************////***************************************************************************************************** 
	 //Handling unmatched variables
	 $unmatched_var_arr = array('Beschikbaar vanaf','Grootte terrein','keuken type','Tuin','buurt type','vloerbedekking type','vloerbedekking type','riolering','olietank','dubbele beglazing','schrijnwerkerij type','wasplaats');
	foreach($unmatched_var_arr as $var){
		$tag_unmatched_var = $parser->extract_xpath($var, RETURN_TYPE_TEXT);
		if($tag_unmatched_var){
			if($tag_unmatched_var=="Ja" || $tag_unmatched_var=="Nee")
				$property[TAG_UNMATCHED_VARIABLES][]=array(TAG_VARIABLE_LABEL=>$var,TAG_VARIABLE_VALUE=>$tag_unmatched_var=="Ja"?1:0);
			else
				$property[TAG_UNMATCHED_VARIABLES][]=array(TAG_VARIABLE_LABEL=>$var,TAG_VARIABLE_VALUE=>$tag_unmatched_var);
		}		
	}

	


    $property[TAG_GAS_CONNECTION] = ($parser->extract_xpath("gas") === "Ja" ? 1 : 0);
    $property[TAG_CONNECTION_TO_WATER] = ($parser->extract_xpath("water") === "Ja" ? 1 : 0);
    $property[TAG_TELEPHONE_CONNECTION] = ($parser->extract_xpath("telefoon") === "Ja" ? 1 : 0);
    $property[TAG_LIFT] = ($parser->extract_xpath("lift") === "Ja" ? 1 : 0);
    $property[TAG_FURNISHED] = ($parser->extract_xpath("Gemeubeld") === "Ja" ? 1 : 0);
    $property[TAG_GARDEN_AVAILABLE] = ($parser->extract_xpath("Tuin") === "Ja" ? 1 : 0);
    $property[TAG_OPEN_FIRE] = ($parser->extract_xpath("open haard aantal") ? 1 : 0);
    $property[TAG_ALARM] = ($parser->extract_xpath("alarm") ? 1 : 0);
    $property[TAG_PARLOPHONE] = ($parser->extract_xpath("parlofoon") ? 1 : 0);
    $property[TAG_VIDEOPHONE] = ($parser->extract_xpath("videofoon") === "Ja" ? 1 : 0);
    
    
    $property[TAG_GAS_CONNECTION] = (get_var($vars,'gas') === "Ja" ? 1 : 0);
    $property[TAG_CONNECTION_TO_WATER] = (get_var($vars,'water') === "Ja" ? 1 : 0);
    $property[TAG_TELEPHONE_CONNECTION] = (get_var($vars,'telefoon') === "Ja" ? 1 : 0);
    $property[TAG_DOUBLE_GLAZING]=CrawlerTool::contains(get_var($vars,'dubbele beglazing') ,"Ja");
    $property[TAG_LIFT] = (get_var($vars,'lift') === "Ja" ? 1 : 0);
    $property[TAG_FURNISHED] = (get_var($vars,'gemeubeld') === "Ja" ? 1 : 0);
    $property[TAG_GARDEN_AVAILABLE] = (get_var($vars,'tuin') === "Ja" ? 1 : 0);
    $property[TAG_OPEN_FIRE] = (get_var($vars,'open haard aantal') === "Ja" ? 1 : 0);
    $property[TAG_ALARM] = (get_var($vars,'alarm') === "Ja" ? 1 : 0);
    $property[TAG_PARLOPHONE] = (get_var($vars,'parlofoon') === "Ja" ? 1 : 0);
    $property[TAG_VIDEOPHONE] = (get_var($vars,'videofoon') === "Ja" ? 1 : 0);
    $property[TAG_SUBDIVISION_PERMIT]=(get_var($vars,'verkavelingsvergunning') === "Ja" ? 1 : '');
    $property[TAG_PRIORITY_PURCHASE]=(get_var($vars,'voorkooprecht') === "Ja" ? 1 : '');
    $property[TAG_MOST_RECENT_DESTINATION]=(get_var($vars,'terrein bestemming') === "Ja" ? 1 : '');
    $property[TAG_PLANNING_PERMISSION]=(get_var($vars,'bouwvergunning') === "Ja" ? 1 : '');
    
    
    $property[TAG_GAS_CONNECTION] =(preg_match('!Aardgas!',$features,$res)) ? 1 : '';
    $property[TAG_CONNECTION_TO_WATER] =(preg_match('!Stadswater!',$features,$res)) ? 1 : 0;
    $property[TAG_TELEPHONE_CONNECTION] =(preg_match('!Telefoon!',$features,$res)) ? 1 : 0;
    $property[TAG_INTERNET_CONNECTION] =(preg_match('!Internet!',$features,$res)) ? 1 : 0;
    $property[TAG_VIDEOPHONE] =(preg_match('!Videofoon!',$features,$res)) ? 1 : 0;
    $property[TAG_DISTRIBUTION] =(preg_match('!Distributie!',$features,$res)) ? 1 : 0;
    $property[TAG_CONNECTION_TO_SEWER] =(preg_match('!Riolering!',$features,$res)) ? 1 : 0;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

    $bedrooms =  strtolower(str_replace(' ', '_', $property[TAG_TEXT_DESC_FR]));
    
    if(stripos('x'.$bedrooms,"1_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 1;
	      
    if(stripos('x'.$bedrooms,"3_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 3;
	      
    if(stripos('x'.$bedrooms,"4_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 4;

    if(stripos('x'.$bedrooms,"2_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 2;

if(stripos('x'.$bedrooms,"3_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 3;
	      
    if(stripos('x'.$bedrooms,"6_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 6;

    if(stripos('x'.$bedrooms,"5_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 5;	      
	      
	      

?>