<?php

/* ============================= CONFIG ============================= */

// Crawler ID 994

require_once("../../crawler_classes.php");


CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.hyboma.be/" 
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://hyboma.be/te-koop" 
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://hyboma.be/nieuwbouw" 
    ),
);

  
/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/



/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            debugx($page);
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("div[@class = 'estate row']");
     
    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
	
	$link = $parser->extract_xpath("a[@class = 'imgLink']/@href", RETURN_TYPE_TEXT, null, $node);
	
        $property[TAG_UNIQUE_URL_NL] =  'http://hyboma.be'.$link ;
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
        
	$price = $parser->extract_xpath("span[@class ='price']/b", RETURN_TYPE_NUMBER, null, $node);
	$property[TAG_PRICE] = $price ;
	
        $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Aantal slaapkamers:", RETURN_TYPE_NUMBER);
        $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
	
	$bed = $parser->extract_xpath("span[@class ='icon bed']", RETURN_TYPE_NUMBER, null, $node);
	$property[TAG_BEDROOMS_TOTAL] = $bed ;
	
	$bath = $parser->extract_xpath("span[@class ='icon bad']", RETURN_TYPE_NUMBER, null, $node);
	$property[TAG_BATHROOMS_TOTAL] = $bath ;
	
	$garea = $parser->extract_xpath("span[@class ='icon bewopp']", RETURN_TYPE_NUMBER, null, $node);
	$property[TAG_SURFACE_GROUND] = $garea ; 
	
	$area = $parser->extract_xpath("span[@class ='icon terras']", RETURN_TYPE_NUMBER, null, $node);
	$property[TAG_SURFACE_LIVING_AREA] = $area ; 
	 
	
        $parser->extract_xpath("parent::div[1]/following-sibling::div[1]/descendant::span[@class = 'c_Style02red']", RETURN_TYPE_TEXT, function($text) use(&$property)
        {
            $propertyStatus = CrawlerTool::getPropertyStatus($text);
            if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
            {
                $property[TAG_STATUS] = $propertyStatus;
            }
        }, $node);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Download and extract item detail information http://www.av-vastgoed.be/images/panden/1366631738.jpg
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html, true);
      
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_DESC_NL] = utf8_decode($parser->extract_xpath("div[@class = 'descr']")); 
    $property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode($parser->extract_xpath("div[@id = 'estate-detail']", RETURN_TYPE_TEXT_ALL)); 
    
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));
  
    $address = $parser->extract_xpath("div[@class = 'adres col-sm-12']/p");
    CrawlerTool::parseAddress($address, $property);
    
    $addr = explode(' ',$address);
    $property[TAG_ZIP] =  $parser->regex("/(\d{4})/", $address );  
    $property[TAG_CITY] = trim($addr[count($addr)-1]);
    
    unset($property[TAG_BOX_NUMBER]);
 
    $property[TAG_PICTURES] =  $parser->extract_xpath("ul[@class = 'slides']/li/img/@src", RETURN_TYPE_ARRAY, function($pics)
    {
	$picUrls = array();
	foreach($pics as $pic) {

	    $picUrls[] = array(TAG_PICTURE_URL => $pic);

	}

	return $picUrls;
    });
 
    $nodes = $parser->getNodes("div[@class = 'col-sm-12']");
     
    
    foreach($nodes as $node)
    {
	$key = $parser->extract_xpath("span[@class = 'left']",  RETURN_TYPE_TEXT, null, $node);
	$val = $parser->extract_xpath("span[@class = 'right']", RETURN_TYPE_TEXT, null, $node);
	
	$k = setAtributesX($key);
	if(!empty($k))
	    $property[$k] = GetExactAttrib($key,$val);
	else
	    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $key, TAG_VARIABLE_VALUE => $val);
    }
	
    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
 
    debug($property);  
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
    
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}




//Function for Handle Attributes 
function setAtributesX($key='',$lan='nl'){ 
    
    $attrib['nl'] = array('Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Badkamer'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'Kadastraal_inkomen'=>TAG_KI, 'Geïndexeerd_kad._inkomen'=>TAG_KI_INDEX,
			'Grondoppervlakte'=>TAG_SURFACE_GROUND, 'Gevelbreedte'=>TAG_FRONTAGE_WIDTH,
			'Verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Badkamer'=>TAG_BATHROOM_SURFACE,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'keuken'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Aantal_slaapkamers'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'Bouwjaar'=>TAG_CONSTRUCTION_YEAR, 'Bewoonb_opp.'=>TAG_SURFACE_GROUND,
			'Parkings'=>TAG_PARKINGS,'Garages'=>TAG_GARAGES_TOTAL, 'Aantal_garages'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'Bewoonbare_oppervlakte'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Tuin'=>TAG_WINTERGARDENS,
			'Gemeubeld'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terras'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE, 'EPC'=>TAG_EPC_VALUE, 'EPC_Certificaat'=>TAG_EPC_CERTIFICATE_NUMBER,
			'Bestemming'=>TAG_MOST_RECENT_DESTINATION, 'Verkavelingvergunning'=>TAG_SUBDIVISION_PERMIT, 'Bouwvergunning'=>TAG_PLANNING_PERMISSION,
			'Voorkooprecht'=>TAG_PRIORITY_PURCHASE
			);
    
    $attrib['fr'] = array( 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Nombre_de_salle_de_bain'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'cuisine'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'année_de_construction_année'=>TAG_CONSTRUCTION_YEAR, 'Taille_terrain_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'surface_nette_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Jardin'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrasse'=>TAG_TERRACES,'Facades'=>TAG_AMOUNT_OF_FACADES,
			'Catégorie'=>TAG_TYPE
			);
    
    $attrib['en'] = array('Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Number_of_bathrooms'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'kitchen'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Number_of_rooms'=>TAG_BEDROOMS_TOTAL,
			'construction_year_year'=>TAG_CONSTRUCTION_YEAR, 'Plot_size_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL, 'Type'=>TAG_TYPE,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'habitable_-_surface_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Garden'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrace'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE
			);
    
    if(!empty($key)){
	
	if( array_key_exists($key, $attrib[$lan]) ){
	    return $attrib[$lan][$key];
	}
	else
	    return '';
    }else
	return '';
	
}
        
	
	

function GetExactAttrib($key,$val){
 
    switch($key){
	
	case TAG_BATHROOMS_TOTAL:
	    return CrawlerTool::toNumber($val); 
	break;
    
	case TAG_BEDROOMS_TOTAL:
	    return CrawlerTool::toNumber($val); 
	break;
    
	case TAG_CONSTRUCTION_YEAR:
	    return CrawlerTool::toNumber($val); 
	break;
	
	case TAG_EPC_CERTIFICATE_NUMBER:
	    return CrawlerTool::toNumber($val); 
	break;
	
	case TAG_SURFACE_LIVING_AREA:
	   return CrawlerTool::toNumber($val); 
	break;

	case TAG_MOST_RECENT_DESTINATION:
	   return array(TAG_MOST_RECENT_DESTINATION_INFORMATION_NL=>$val); 
	break;

	case TAG_PLANNING_PERMISSION:
	   return 1; 
	break;
	
	case TAG_SUBDIVISION_PERMIT:
	   return CrawlerTool::toNumber($val); 
	break;


	default:
		return CrawlerTool::toNumber($val);  
	break;
	 
    }
}


