<?php

/**********************Technique 1 ********************************////*****************************************************************************************************/
	$files = array();
	$nodes = $parser->getNodes("a[contains(@href, 'GetFile.ashx?path=Documents')]");
	foreach($nodes as $node)
	{
		$fileUrl = "http://www.teamproperty.be/" . $parser->regex("/path=(.*)&/", $parser->getAttr($node, "href"));
		$fileTitle = $parser->getText($node);
		$files[] = array(TAG_FILE_URL => $fileUrl, TAG_FILE_TITLE_NL => $fileTitle);
	}
	if(!empty($files)) $property[TAG_FILES] = $files;
 
	$property[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
	     {
		     $fileUrls = array();
		     foreach($files as $file)
		     {
			     if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => "http://www.hetlandgoed.be/".str_replace('../','',$file));
		     }
		     return $fileUrls;
	});

/**********************Technique 2 ********************************////*****************************************************************************************************/
	//Iframe url Scanner
	$contact_href = $parser->extract_xpath("iframe[contains(@src, 'contactform')]/@src");
	

/**********************Technique 3 ********************************////*****************************************************************************************************/
//Debuging Page detail
	///Ajax to HTML
	$html = $crawler->request("http://www.immogie.be/wp-admin/admin-ajax.php", "action=wpp_property_overview_pagination&wpp_ajax_query%5Bshow_children%5D=true&wpp_ajax_query%5Bchild_properties_title%5D=Floor+plans+at+location%3A&wpp_ajax_query%5Bfancybox_preview%5D=true&wpp_ajax_query%5Bbottom_pagination_flag%5D=false&wpp_ajax_query%5Bthumbnail_size%5D=tiny_thumb&wpp_ajax_query%5Bsort_by_text%5D=Sort+By%3A&wpp_ajax_query%5Bsort_by%5D=menu_order&wpp_ajax_query%5Bsort_order%5D=ASC&wpp_ajax_query%5Btemplate%5D=false&wpp_ajax_query%5Bajax_call%5D=true&wpp_ajax_query%5Bdisable_wrapper%5D=false&wpp_ajax_query%5Bsorter_type%5D=buttons&wpp_ajax_query%5Bpagination%5D=on&wpp_ajax_query%5Bhide_count%5D=false&wpp_ajax_query%5Bper_page%5D=5&wpp_ajax_query%5Bstarting_row%5D=0&wpp_ajax_query%5Bunique_hash%5D=25243&wpp_ajax_query%5Bdetail_button%5D=false&wpp_ajax_query%5Bstats%5D=&wpp_ajax_query%5Bclass%5D=wpp_property_overview_shortcode&wpp_ajax_query%5Bin_new_window%5D=false&wpp_ajax_query%5Bquery%5D%5Bproperty_type%5D=Rental&wpp_ajax_query%5Bquery%5D%5Bsort_by%5D=menu_order&wpp_ajax_query%5Bquery%5D%5Bsort_order%5D=ASC&wpp_ajax_query%5Bquery%5D%5Bpagi%5D=0--5&wpp_ajax_query%5Bquery%5D%5Brequested_page%5D=2&wpp_ajax_query%5Bcurrent_page%5D=1&wpp_ajax_query%5Bsortable_attrs%5D%5Bmenu_order%5D=Default&wpp_ajax_query%5Bsortable_attrs%5D%5Bpost_title%5D=Title&wpp_ajax_query%5Bproperties%5D%5Btotal%5D=7&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=74&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=86&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=109&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=113&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=116&wpp_ajax_query%5Bpages%5D=2&wpp_ajax_query%5Bdefault_query%5D%5Bproperty_type%5D=Rental&wpp_ajax_query%5Bdefault_query%5D%5Bsort_by%5D=menu_order&wpp_ajax_query%5Bdefault_query%5D%5Bsort_order%5D=ASC&wpp_ajax_query%5Bdefault_query%5D%5Bpagi%5D=0--5&wpp_ajax_query%5Bdefault_query%5D%5Brequested_page%5D=2&wpp_ajax_query%5Brequested_page%5D=2");
	$ojb = json_decode($html);
	if(!empty($ojb))
	{
	    $html = $ojb->display;
	}

/**********************Technique 4 ********************************////*****************************************************************************************************/
	$post = '&__EVENTTARGET=ctl00%24ContentPlaceHolder1%24ctl00%24dlBottomNext%24ctl0'.$i.'%24lnkPage&__VIEWSTATE='.urlencode($viewStat); 
	$html = $crawler->request($page,$post);
		    
	
?>