<?php

/* ============================= CONFIG ============================= */
// Crawler ID 12611
require_once("../../crawler_classes.php");

CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.hyboma.be/" 
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://hyboma.be/te-koop" 
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://hyboma.be/nieuwbouw" 
    ),
);

/* ============================= END CONFIG ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "OPEN THE DOOR";
$office[TAG_OFFICE_URL] = "http://www.bkgroup.be/";
$office[TAG_STREET] = "Chaussée de la hulpe";
$office[TAG_NUMBER] = "177";
$office[TAG_ZIP] = "1170";
$office[TAG_CITY] = "Bruxelles";
$office[TAG_TELEPHONE] = "026632745";
$office[TAG_EMAIL] = "info@bkgroup.be";

CrawlerTool::saveOffice($office);

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            debugx($page);
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
            
            $nextPages = getPages($html);
            foreach($nextPages as $nextPage)
            {
                debugx($nextPage);
                $html = $crawler->request($nextPage);
                processPage($crawler, $status, $type, $html);
            }
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);
    $nodes = $parser->getNodes("a[contains(@href, 'Detail')][img]");
     debug($nodes ); exit;
    $items = array();
    foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type; 
        $property[TAG_UNIQUE_URL_NL] = "http://www.bkgroup.be" . $parser->getAttr($node, "href"); 
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]); 
        $property[TAG_UNIQUE_URL_FR] =  str_replace("fr-fr", "nl-be", $property[TAG_UNIQUE_URL_FR]); 

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_FR]);
    }    

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...".$item["itemUrl"];
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}
/**
 * Get a list of next pages
 */
function getPages($html)
{
    $parser = new PageParser($html);

    $pages = array();
    $nodes = $parser->getNodes("a[@class = 'Link PaginationLink']");

    if(!empty($nodes))
    {
        foreach($nodes as $node)
        {
            $pages[] = "http://www.bkgroup.be" . $parser->getAttr($node, "href");
        }
    }

    return array_unique($pages);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $html = str_replace("±", "", $html);
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    if(empty($property[TAG_STATUS])) $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($parser->extract_xpath("td[contains(text(), 'Ref:')]/following-sibling::td[1]"));
    if(empty($property[TAG_STATUS])) $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($parser->extract_xpath("head/title"));
    
    $property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]");
    $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.bkgroup.be" . $pic);

        return $picUrls;
    });

    CrawlerTool::parseAddress($parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[1]"), $property);
    $parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[2]", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(\d{4,})(.*)/", $text, $match))
        {
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
    });

    if(empty($property[TAG_CITY]))
    return;
    
    $property[TAG_PRICE] = $parser->extract_xpath("td[contains(text(), 'Prix')]", RETURN_TYPE_NUMBER);
    
    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("Catégorie"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_FR]);
    $property[TAG_EPC_VALUE] = $parser->extract_regex("/(\d+)\skwh/i", RETURN_TYPE_EPC);
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("année de construction année", RETURN_TYPE_YEAR);
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("rénovation annee", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Taille terrain", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Surface habitable", RETURN_TYPE_NUMBER);
    $property[TAG_FRONTAGE_WIDTH] = $parser->extract_xpath("largeur façade largeur", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Nombre de chambres", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Nombre de salle de bain", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toilettes nombre", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Facades", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FLOORS] = $parser->extract_xpath("étages nombre", RETURN_TYPE_NUMBER);
    $property[TAG_GARDEN_AVAILABLE] = CrawlerTool::contains($parser->extract_xpath("Jardin"), "Oui");
    $property[TAG_GARAGES_TOTAL] = CrawlerTool::contains($parser->extract_xpath("Garage"), "Oui");
    $property[TAG_PARKINGS_TOTAL] = CrawlerTool::contains($parser->extract_xpath("Parking"), "Oui");
    $property[TAG_GAS_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("gaz"), "Oui");
    $property[TAG_LIFT] = CrawlerTool::contains($parser->extract_xpath("ascenseur"), "Oui");
    $property[TAG_DOUBLE_GLAZING] = CrawlerTool::contains($parser->extract_xpath("double vitrage"), "Oui");
    $property[TAG_HEATING_FR] = $parser->extract_xpath("chauffage type");

    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Disponible de", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM] = $parser->extract_xpath("Disponible de");

    getLanguageText($crawler, $property);
    // WRITING item data to output.xml file
    
    debug($property); exit; 
    CrawlerTool::saveProperty($property);
}

function getLanguageText($crawler, &$property)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
    $html = str_replace("±", "", $html);
    $parser = new PageParser($html, true);

    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);

}


function processProject($crawler, $project)
{
	#$html = $crawler->request('http://www.jemar.be/nl/te-koop?view=details&id=14');
	$html = $crawler->request($project[TAG_UNIQUE_URL_NL]);

    $html1=preg_replace('/\<div class="sep"\>:\<\/div\>/',"",$html);
	$parser = new PageParser($html);
	$parser->deleteTags(array("script", "style"));
    $project[TAG_PICTURES] = $parser->extract_xpath("a[contains(@rel, 'fancyBoxImg')]", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => $pic);

        return $picUrls;
    });
    preg_match('/<div class="fright">\s+(.*?),\s+(.*?)\s+<\/div>/',$html,$res);
	$project[TAG_STREET] = preg_replace("/[0-9]/", '',$res[1]);
	$project[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$res[1]);
	$project[TAG_ZIP] = preg_replace("/\D/", "", strip_tags($res[2]));
	$project[TAG_CITY] = trim(preg_replace("/\(.+?\)|\d|&nbsp;/", "", strip_tags($res[2])));
    $project[TAG_TEXT_SHORT_DESC_NL]= (preg_match('/proj-htmlDescr.*?\<body\>(.*?)\<\/body\>/s',$html,$res)) ? trim(strip_tags(($res[1]))) : '';
    preg_match('/ProjectDetails.ShowBuildingDetails\(\'(.*?)\'/si',$html,$res) ? $res[1]: '';
    $html = $crawler->request('http://www.jemar.be'.$res[1]);
    $parser = new PageParser($html);
    $nodes = $parser->getNodes("a[contains(@target, '_blank')]");
	$SoldNodes = $parser->getNodes("div[contains(@style,'icon_list_sold')]");
    echo $project[TAG_SOLD_PERCENTAGE_MAX]=$nodes->length;
	echo $project[TAG_SOLD_PERCENTAGE_VALUE] =$SoldNodes->length;
    if($project[TAG_SOLD_PERCENTAGE_MAX]<=0){
	unset($project[TAG_SOLD_PERCENTAGE_MAX]);
	unset($project[TAG_SOLD_PERCENTAGE_VALUE]);
		}
    CrawlerTool::saveProject($project);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}
