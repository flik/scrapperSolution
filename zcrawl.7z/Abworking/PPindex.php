<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');
/* ============================= CONFIG ============================= */

// Crawler ID 5605

require_once("../crawler_classes.php");

$crawler->enable_delay_between_requests(5, 10); 

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.agencimmo.be/lister_bien.php?but=1"
    ),
);
$startPages[STATUS_TORENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.agencimmo.be/lister_bien.php?but=4"
    ),
);

/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/

/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
			echo "Complete processing page ..." . "<br /><br />";
			$nextPage = getNextPage($html);
			unset($html);

			while(strlen($nextPage) > 0) {
				echo "Downloading page content..." . "<br />";
				$html = $crawler->request($nextPage);
				echo "Complete downloading page content..." . "<br />";

				// process page content
				echo "Processing page ..." . "<br />";
                processPage($crawler, $status, $type, $html);
				echo "Complete processing page ..." . "<br /><br />";

				$nextPage = getNextPage($html);
				unset($html);
			}
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

/**
 *  Get next page
 */
function getNextPage($html) {
	
	$nextPage = "";
	$parser = new PageParser($html);
	$node = $parser->getNode("a[. = 'Page suivante']");
	if($node) $nextPage = "http://www.agencimmo.be" . $parser->getAttr($node, "href");

	// free memory used
	unset($dom);
	unset($xpath);

	return $nextPage;
}

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[contains(@href, 'details_bien.php?id_bien=')][img]");

    $items = array();
    foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;

		$n = $parser->getNode("preceding-sibling::tr[4]/td[3]", parentNode($node, 2)); 
		if($n) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->getText($n)); 

        $property[TAG_UNIQUE_URL_NL] ="http://www.agencimmo.be/".$parser->getAttr($node, "href").'&lang=nl'; 
	$property[TAG_UNIQUE_URL_FR] = "http://www.agencimmo.be/".$parser->getAttr($node, "href").'&lang=fr'; 
	$property[TAG_UNIQUE_URL_EN] = "http://www.agencimmo.be/".$parser->getAttr($node, "href").'&lang=en'; 
	
        $property[TAG_UNIQUE_ID]=getUniqueId($property[TAG_UNIQUE_URL_NL]); 
		$n = $parser->getNode("preceding-sibling::tr[1]", parentNode($node, 2)); 
		if($n) {
			$text = $n->nodeValue;
				if(stripos($text, "vendu") !== false) $property[TAG_STATUS]= "sold";
				if(stripos($text, "lou") !== false) $property[TAG_STATUS]="rented";

		}

		$n = $parser->getNode("preceding-sibling::tr[1]", parentNode($node, 2));
		if($n) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $parser->getText($n)));

		
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
    }   //CrawlerTool::test($items);
	 
    foreach($items as $item)
    {

        // keep track of number of properties processed
        $propertyCount += 1;
        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

function getUniqueId($url) {
	preg_match("/id_bien=(\d+)/", $url, $match);
	if($match) return $match[1];
}
function parentNode($node, $n = 1) {
	$parentNode = $node;
	for($i = 1; $i <= $n; $i++) $parentNode = $parentNode->parentNode;

	return $parentNode;
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{

    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));
    
    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("tr[descendant::*[contains(text(), 'Description')]]/following-sibling::tr[1]", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("td[@class = 'w2']", RETURN_TYPE_TEXT_ALL);
    
    if(empty($property[TAG_TEXT_DESC_NL])){
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
		$res[1] = str_replace(chr(11),'',$res[1]);
		$property[TAG_TEXT_DESC_EN] = strip_tags($res[1]);
	}
	
    
    $property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode(CrawlerTool::encode(strip_tags( $property[TAG_PLAIN_TEXT_ALL_NL] ))); 
    $property[TAG_TEXT_DESC_NL] = utf8_decode(CrawlerTool::encode(strip_tags( $property[TAG_TEXT_DESC_NL] ))); 
    
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("td[contains(text(), 'gorie')]/following-sibling::td[1]"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL]);
    
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@class = 'slideshowThumbnail']/@href", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.agencimmo.be/" . str_replace("../", "", $pic));

        return $picUrls;
    });

    if(empty($property[TAG_CITY])){
	
    $street = $parser->extract_xpath("td[@class= 'txt2']", RETURN_TYPE_TEXT_ALL); 
		
    $address = GetBetween($street, 'Prix', 'Description' );
     
       CrawlerTool::parseAddress($address,$property);
	    
	$addr = explode(' ',$address);
	$property[TAG_CITY] = trim($addr[count($addr)-1]);
	$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
	
	if(strlen($property[TAG_ZIP]) < 4){
		$address = str_replace($property[TAG_ZIP],'',$address );
		$property[TAG_BOX_NUMBER] = $property[TAG_ZIP];
		$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
	}
	
	$property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
	$property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
	
	$property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
	$property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
	
	if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
	
	if(strlen($property[TAG_BOX_NUMBER]) < 3 || strlen($property[TAG_BOX_NUMBER]) > 3 )
	unset($property[TAG_BOX_NUMBER]);
    
	}
	 
	$price = $parser->extract_xpath("table[@style = 'border:solid 0px;padding-left: 15ex;']/tr/td[3]", RETURN_TYPE_NUMBER);
	if(empty($property[TAG_PRICE]))
	$property[TAG_PRICE] = $price;
	
    //parse fields
    $vars = array();
    preg_match_all('!<td>([^<>]+)</td>\s+<td>([^<>]+)<!',$html,$res,PREG_SET_ORDER);
    foreach ($res as $arr)
    {
	    $arr[1] = strtolower($arr[1]);
	    $arr[1] = trim(strip_tags($arr[1]));
	    $arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
	    $arr[1] = preg_replace('!nbsp!','',$arr[1]);
	    $arr[2] = preg_replace('!:!','',$arr[2]);
	    $vars[$arr[1]] = trim(strip_tags($arr[2]));
	    #echo '<br>';
    }
    preg_match_all('!<td nowrap>([^<>]+)</td>\s+<td width="60%">([^<>]+)<!',$html,$res,PREG_SET_ORDER);
    foreach ($res as $arr)
    {
	    $arr[1] = strtolower($arr[1]);
	    $arr[1] = trim(strip_tags($arr[1]));
	    $arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
	    $arr[1] = preg_replace('!nbsp!','',$arr[1]);
	    $vars[$arr[1]] = trim(strip_tags($arr[2]));
	    #echo '<br>';
    }
	
	$unmatched_variables = array();
 
	foreach ($vars as $label => $value)
	{
		$label =clearForLowerCase($label);
		$attribute = getAttributes($label);
		if(!empty($attribute) ){
		    if(empty($property[$attribute]))
		    $property[$attribute] = GetExactAttrib($attribute,$value);
		}
		else
		    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
		
	}
	
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
	 
	$html = $crawler->request($property[TAG_UNIQUE_URL_FR]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode(strip_tags($parser->extract_xpath("tr[descendant::*[contains(text(), 'Description')]]/following-sibling::tr[1]", RETURN_TYPE_TEXT_ALL)))); 
	$property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode(CrawlerTool::encode(strip_tags($parser->extract_xpath("td[@class = 'w2']", RETURN_TYPE_TEXT_ALL))));
	if(empty($property[TAG_TEXT_DESC_FR])){
		
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res); 
		$res[1] = str_replace(chr(11),'',$res[1]); 
		$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode(strip_tags($res[1]))); 
	}
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_EN]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode(strip_tags($parser->extract_xpath("tr[descendant::*[contains(text(), 'Description')]]/following-sibling::tr[1]", RETURN_TYPE_TEXT_ALL)))); 
	$property[TAG_PLAIN_TEXT_ALL_EN] = utf8_decode(CrawlerTool::encode(strip_tags($parser->extract_xpath("td[@class = 'w2']", RETURN_TYPE_TEXT_ALL)))); 
	
	if(empty($property[TAG_TEXT_DESC_EN])){
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
		$res[1] = str_replace(chr(11),'',$res[1]);
		$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode(strip_tags($res[1])));
	}
	
    debug($property); exit;
     
    CrawlerTool::saveProperty(removeEmptyIndex($property));

}

function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
			return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function getvalue($parser,$start,$follow) {
    $nodes = $parser->getNodes("h1[contains(text(), $start)]/following-sibling::p/text()");
    foreach($nodes as $node) {
        $text = $parser->GetText($node);
        if(stripos($text, $follow) !== false) {
            $n = $parser->getNodes("following-sibling::strong[1]",$node);
            if($n) return $parser->GetText($n);
        }
    }
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}
 
function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
} 

function getAttributes($key, $language='nl'){ //String Function always return string

	$attributeTagsArray	= array('en' => array(	'pric' 			=>  TAG_PRICE,
							'constr'		=> TAG_CONSTRUCTION_YEAR,
							'ground'		=> TAG_SURFACE_GROUND,
							'living' 		=> TAG_SURFACE_LIVING_AREA,
							'bath'			=> TAG_BATHROOMS_TOTAL,
							'warm'			=> TAG_HEATING_EN,
							'heat'			=> TAG_HEATING_EN,
							'sewer'			=> TAG_CONNECTION_TO_SEWER,
							'telep'			=> TAG_TELEPHONE_CONNECTION,
							'intern'		=> TAG_INTERNET_CONNECTION,
							'permission'	=> TAG_PLANNING_PERMISSION,
							'subdivision'	=> TAG_SUBDIVISION_PERMIT,
							'electri'		=> TAG_METER_FOR_ELECTRICITY,
							'hall'			=> TAG_HALLS,
							'dining'		=> TAG_DININGS,
							'kitch'			=> TAG_KITCHENS,
							'laundr'		=> TAG_LAUNDRY_ROOMS,
							'dress'			=> TAG_DRESSING,
							'bed'			=> TAG_BEDROOMS_TOTAL,
							'room'			=> TAG_BEDROOMS_TOTAL,
							'park'			=> TAG_PARKINGS,
							'garage'		=> TAG_GARAGES_TOTAL,
							'type'			=> TAG_TYPE,
							'garden'		=> TAG_GARDEN_AVAILABLE,
							'floor'			=> TAG_AMOUNT_OF_FLOORS,
							'winter'		=> TAG_WINTERGARDENS,
							'furnish'		=> TAG_FURNISHED,
							'water'			=> TAG_CONNECTION_TO_WATER,
							'lift'			=> TAG_LIFT,
							'glaz'			=> TAG_DOUBLE_GLAZING,
							'terrac'		=> TAG_TERRACES,
							'fronts'		=> TAG_AMOUNT_OF_FACADES,
							'category'		=> TAG_TYPE,
							'free'			=> TAG_FREE_FROM_DATE,
							'habit'			=> TAG_SURFACE_LIVING_AREA,
							'plot'			=> TAG_SURFACE_GROUND,
							'shops'			=> TAG_DISTANCE_SHOPS,
							'schools'		=> TAG_DISTANCE_SCHOOL,
							'transport'		=> TAG_DISTANCE_PUBLIC_TRANSPORT,
							'shower'		=> TAG_SHOWERS_TOTAL,
							'stor'			=> TAG_STOREROOMS,
							'gas'			=> TAG_GAS_CONNECTION,
							'alarm'			=> TAG_ALARM,
							'security'		=> TAG_SECURITY_DOOR,
							'parlo'			=> TAG_PARLOPHONE,
							'video'			=> TAG_VIDEOPHONE,
							'elevat'		=> TAG_LIFT,
							'blind'			=> TAG_SUN_BLINDS,
							'renova'		=> TAG_RENOVATION_YEAR,
							'control'		=> TAG_ACCESS_SEMIVALID,
								),
					'nl' => array(	"prij" =>  TAG_PRICE,
							"bouwjaar" => TAG_CONSTRUCTION_YEAR,
							"grondopp" => TAG_SURFACE_GROUND, 
							"bewoonbare" => TAG_SURFACE_LIVING_AREA,
							"antal_kamer"=> TAG_BEDROOMS_TOTAL,
							"slaapkamer"=> TAG_BEDROOMS_TOTAL,
							"antal_badkam"=> TAG_BATHROOMS_TOTAL,
							"badkam"=> TAG_BATHROOMS_TOTAL,
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"verdieping" => TAG_AMOUNT_OF_FLOORS,
							"living" => TAG_SURFACE_LIVING_AREA,
							"renovatie" => TAG_RENOVATION_YEAR,
							"kadaster_sectie" => TAG_CADASTRAL_SECTION,
							"beschikbaar" => TAG_FREE_FROM,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"mail" => TAG_EMAIL,
							"winkels" => TAG_DISTANCE_SHOPS,
							"vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"overstromings" => TAG_FLOOD_INFORMATION_NL,
							"garage" => TAG_GARAGES_TOTAL,
							"toilet" => TAG_TOILETS_TOTAL,
							"parking" => TAG_PARKINGS_TOTAL,
							"gevels" => TAG_AMOUNT_OF_FACADES,
							"lasten" => TAG_COMMON_COSTS,
							"gas" => TAG_GAS_CONNECTION,
							"water" => TAG_CONNECTION_TO_WATER,
							"telefoon" => TAG_TELEPHONE,
							"lift" => TAG_LIFT,
							"gemeubeld" => TAG_FURNISHED,
							"tuin" => TAG_GARDEN_AVAILABLE,
							"haard" => TAG_OPEN_FIRE,
							"alarm" => TAG_ALARM,
							"parlofoon" => TAG_PARLOPHONE,
							"videofoon" => TAG_VIDEOPHONE,
							"breedte" => TAG_LOT_WIDTH,
							"diepte" => TAG_LOT_DEPTH,
							"constructie" => TAG_CONSTRUCTION_TYPE,
							"gevelbreedte" => TAG_FRONTAGE_WIDTH,
							"winkel" => TAG_HEATING_NL,
							"douche" => TAG_SHOWERS_TOTAL,
							"keuken" => TAG_KITCHEN_TYPE_NL,
							"ligging" => TAG_SUBDIVISION_PERMIT,
							"stedenbouwkundige" => TAG_PLANNING_PERMISSION,
							"terras" => TAG_TERRACES,
							"terrein" => TAG_SURFACE_GROUND,
							"scholen" => TAG_DISTANCE_SCHOOL,
							"oppervlakte" => TAG_SURFACE_LIVING_AREA,
							"eetkamer" => TAG_DININGS,
							"dressing" => TAG_DRESSINGS,
							"kelder" => TAG_CELLARS,
							"beroep" => TAG_FREE_PROFESSIONS,
							"berging" => TAG_STOREROOMS,
							"wasplaats" => TAG_LAUNDRY_ROOMS,
							"elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"beglazing" => TAG_DOUBLE_GLAZING,
							"verwarming" => TAG_HEATING_NL,
							"riolering" => TAG_CONNECTION_TO_SEWER,
							"olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"waterput" => TAG_WELL,
							"telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
							"toegangscontrole" => TAG_ACCESS_SEMIVALID,
							"computer" => TAG_INTERNET_CONNECTION,
							"nroerende_voorhef" => TAG_PROPERTY_TAX,
								),
                                        'fr' => array(	"prij" =>  TAG_PRICE,
							"Meuble" => TAG_FURNISHED,
							"facades" => TAG_AMOUNT_OF_FACADES,
							"nombre_de_chambre"=> TAG_BEDROOMS_TOTAL,
							"nombre_de_salle_de_bain"=> TAG_BATHROOMS_TOTAL,
							"jardin" => TAG_GARDEN_AVAILABLE,
							"garage" => TAG_GARAGES_TOTAL,
							"terras" => TAG_TERRACES,
							"parking" => TAG_PARKINGS_TOTAL,
							"habita" => TAG_SURFACE_LIVING_AREA,
							"terrain" => TAG_SURFACE_GROUND,
							"disponible" => TAG_FREE_FROM,
							"magasins" => TAG_DISTANCE_SHOPS,
							"transport" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"toilet" => TAG_TOILETS_TOTAL,
							"construction_annee" => TAG_CONSTRUCTION_YEAR,
							"renovation_annee" => TAG_RENOVATION_YEAR,
							"tages" => TAG_AMOUNT_OF_FLOORS,
							"alarm" => TAG_ALARM,
							"gaz" => TAG_GAS_CONNECTION,
							"eau" => TAG_CONNECTION_TO_WATER,
							"parlophone" => TAG_PARLOPHONE,
							"vitrage" => TAG_DOUBLE_GLAZING,
							"network" => TAG_INTERNET_CONNECTION,
							"douche" => TAG_SHOWERS_TOTAL,
							"caves" => TAG_CELLARS,
							"dressing" => TAG_DRESSINGS,
							"telephone" => TAG_TELEPHONE,
							"videophone" => TAG_VIDEOPHONE,
							"manger" => TAG_DININGS,
							"ecoles" => TAG_DISTANCE_SCHOOL,
							"sejour" => TAG_SURFACE_LIVING_AREA,
							"ascenseur" => TAG_LIFT,
							"largeur_du_lot" => TAG_LOT_WIDTH,
							"mazout" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"citerne" => TAG_WELL,
							"chauffage" => TAG_HEATING_FR,
							"electricite " => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"inondation" => TAG_FLOOD_INFORMATION_FR,
							"egouts" => TAG_CONNECTION_TO_SEWER,
							"cuisine" => TAG_KITCHEN_TYPE_FR,
							"construction_type" => TAG_CONSTRUCTION_TYPE,
							"chauffage" => TAG_HEATING_FR,
							"debarras" => TAG_STOREROOMS,
							"telephoniques" => TAG_TELEPHONE_CONNECTION,
							"dacces" => TAG_ACCESS_SEMIVALID,
							"lotissement" => TAG_SUBDIVISION_PERMIT,
							"batir" => TAG_PLANNING_PERMISSION,
							"cadastrales" => TAG_CADASTRAL_SECTION,
							"prix" => TAG_PRICE, 
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"mail" => TAG_EMAIL,
							"commun" => TAG_COMMON_COSTS,
							"feu" => TAG_OPEN_FIRE,
							"beaucoup_de_profondeur" => TAG_LOT_DEPTH,
							"facade_largeur" => TAG_FRONTAGE_WIDTH,
							"emission_co2" => TAG_CO2_EMISSION,
                                                     ),
				);
	
	$keys = array_keys($attributeTagsArray[$language]); // Returning Keys
	$key = clearForLowerCase($key); // Converting to lower case
	
	foreach($keys as $k){
	    
		   $check = stripos("X$key","$k");
		   if(!empty($check))
		   return $attributeTagsArray[$language][$k];
	    }
	 
	return '';	 
}

function GetExactAttrib($key,$val){
 
	/*if(stripos($key,"total") !== false)
	return toNumber($val);
	 */
    switch($key){
    case TAG_PROPERTY_TAX:
        return toNumber($val);
        break;	
    case TAG_PRICE:
        return toNumber($val);
        break;
    case TAG_CONSTRUCTION_YEAR:
        return toYear($val);
        break;
    case TAG_RENOVATION_YEAR:
        return toYear($val);
        break;
     case TAG_FREE_FROM_DATE:
        return toUnixTimestamp($val);
        break;
    case TAG_KI:
        return toNumber($val);
        break;
    case TAG_EPC_VALUE:
        return toEpc($val);
        break;
    case TAG_EPC_CERTIFICATE_NUMBER:
        return toNumber($val);
        break;
    case TAG_SURFACE_LIVING_AREA:
       return toNumber($val);
       break;
    case TAG_SURFACE_GROUND:
       return toNumber($val);
       break;
    case TAG_MOST_RECENT_DESTINATION:
       return trim($val);
       break;
    case TAG_PLANNING_PERMISSION:
       return $val;
       break;
    case TAG_SUBDIVISION_PERMIT:
       return toNumber($val); 
    break;
    
    default:
	$val = trim($val);
	if($val=='Ja' || $val=='Nee' || $val=='Neen')
	  return ($val=='Ja') ? 1 : 0; 
	else{

	    if(stripos($key,"_nl") !== false)
	    return $val;
	    
	    if(stripos($key,"_fr") !== false)
	    return $val;
	
	    if(stripos($key,"_en") !== false)
	    return $val;
	    else
	    return toNumber($val);
	    
	}
	
    break;
     
    }
}

/// Basic checking for 
function clearForLowerCase($str = ''){ 
    $str = strtolower(str_replace(' ','_',$str)); 
    $str = trim(strip_tags($str)); 
    //$str = preg_replace('![^a-z0-9_\-\. ]!','',$str); 
    // $str = trim(preg_replace('!nbsp!','',$str)); 
    $str = trim(preg_replace('!ja,!','',$str));
    //$str = trim(preg_replace('!,!','',$str));
    $str = trim(normalize_str($str));
    return $str ;
 
}

function toNumber($str)
{
	///return $str;
	$value = 0;
	$str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
	$str = preg_replace("/,(\d{3})|\.(\d{3})/",  "$1$2", $str);
	if(preg_match("/(-?\d+)/", $str, $match)) $value = intval($match[1]);

	if(empty(trim($value)))
	return 0;
	else
	return $value;
}

function toUnixTimestamp($str)
{
	return strtotime($str);
}

function toEpc($str){
	$epc = toNumber($str);
	if($epc > 0 && $epc <= 999) return $epc;
}

function toYear($str){
	$year = toNumber($str);
	if($year > 0 && strlen($year) == 4) return $year;
}

function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");
        foreach($invalid as $k => $v){
            $str = str_replace($k, $v, $str); //array_values($invalid)
        }

        return $str;
    }

    
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
///Clear Empity index
function removeEmptyIndex($property){
 foreach($property as $k=>$v){
		if(empty($v))
		unset($property[$k]);
		
			if(is_array($v)){ 
				foreach($v as $kx=>$vx){ 
					if(empty($vx)){ 
						unset($v[$kx]);
						unset($property[$k]);
					}
				}
			}	
	}
	return $property; 
}

?>
