<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1446

require_once("../crawler_classes.php");


$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.lapeirre.be/te-koop/projecten/"
    ),
    TYPE_HOUSE        =>  array
    (
        "http://www.lapeirre.be/te-koop/tendenshuis/"
    ),
    TYPE_APARTMENT    =>  array
    (
        "http://www.lapeirre.be/te-koop/appartementen/"
    ),
    TYPE_PLOT         =>  array
    (
        "http://www.lapeirre.be/te-koop/bouwgrond/"
    )
);


/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/




/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Lapeirre Woningbouw";
$office[TAG_OFFICE_URL] = "http://www.lapeirre.be";
$office[TAG_STREET] = "Liebeekstraat";
$office[TAG_NUMBER] = "23";
$office[TAG_ZIP] = "8800";
$office[TAG_CITY] = "Roeselare";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "32 51 26 36 86 - 32 51 26 36 80";
$office[TAG_FAX] = "32 51 26 36 88";
$office[TAG_EMAIL] = "info@lapeirre.be";

CrawlerTool::saveOffice($office);

$propertyCount = 0;
$properties = array();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    global $propertyCount;
    global $properties;

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[. = 'Meer info...']");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_NL] = "http://www.lapeirre.be/" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  $parser->regex("/vg=(\d+)/", $property[TAG_UNIQUE_URL_NL]);
        $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $parser->extract_xpath("ancestor::div[@class = 'descr']/h2", RETURN_TYPE_TEXT, null, $node)));
        CrawlerTool::parseAddress($parser->extract_xpath("ancestor::div[@class = 'descr']/h2/following-sibling::text()[1]", RETURN_TYPE_TEXT, null, $node), $property);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    $node = $parser->getNode("table[@class = 'loten']");
    if($node)
    {
        processProject($crawler, $parser, $property);
        return;
    }

    $propertyStatus = CrawlerTool::getPropertyStatus($parser->extract_xpath("div[@id = 'content']/div/h1"));
    if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
    {
        $property[TAG_STATUS] = $propertyStatus;
    }
    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("h3[contains(text(), 'Omschrijving')]/following-sibling::p[1]");
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL]);
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox[lb32]']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.lapeirre.be/" . $pic);

        return $picUrls;
    });

    if(empty($property[TAG_PICTURES])){
	
	$pics = $parser->getNodes("img[contains(@src, 'fotos')]");
	 
	foreach($pics as $picx){
	    
	    $pic = $parser->getAttr($picx, "src");        
	    $picUrls[] = array(TAG_PICTURE_URL => 'http://www.lapeirre.be/'.$pic);
	}
	
	$property[TAG_PICTURES] = $picUrls;
    }
    
    CrawlerTool::parseAddress($parser->extract_xpath("div[@class = 'adres']/text()[1]"), $property);
    $parser->extract_xpath("div[@class = 'adres']/text()[2]", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(\d{4,})(.*)/", $text, $match))
        {
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
    });

    if(empty($property[TAG_CITY]))
    {
        $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|(-\s.*)/", "", $parser->extract_xpath("title")));
    }

    // get document files
    $nodes = $parser->getNodes("h3[. = 'Andere informatie']/following-sibling::div[1]/a");
    foreach($nodes as $node)
    {
        $fileUrl = "http://www.lapeirre.be/" . $parser->getAttr($node, "href");
        $fileTitle = $parser->getText($node);
        if(stripos($fileUrl, ".jpg") !== false)
        {
            $property[TAG_PICTURES][] = array(TAG_PICTURE_URL => $fileUrl, TAG_PICTURE_TITLE_NL => $fileTitle);
        }
        else
        {
            $property[TAG_FILES][] = array(TAG_FILE_URL_NL => $fileUrl, TAG_FILE_TITLE_NL => $fileTitle);
        }
    }
    $property[TAG_PRICE] = $parser->extract_xpath("div[@class = 'prijs']", RETURN_TYPE_NUMBER);

    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");


    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("Bouwjaar", RETURN_TYPE_YEAR);
    $property[TAG_CONSTRUCTION_TYPE] = CrawlerTool::getConstructionType($parser->extract_xpath("Bestemming"));
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("Renovatie", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Bewoonbare oppervlakte", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Oppervlakte terrein", RETURN_TYPE_NUMBER);
    $property[TAG_LOT_WIDTH] = $parser->extract_xpath("Breedte grond", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Aantal slaapkamers", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
    $property[TAG_PLANNING_PERMISSION] = CrawlerTool::contains($parser->extract_xpath("Bouwvergunning"), "Ja");
    $property[TAG_SUBDIVISION_PERMIT] = CrawlerTool::contains($parser->extract_xpath("Verkavelingsvergunning"), "Ja");

    //CrawlerTool::test($property);

    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}

function processProject($crawler, $parser, $property)
{
    global $propertyCount;
    global $properties;

    $project = array();
    $project[TAG_PROJECT_ID] = $property[TAG_UNIQUE_ID];
    $project[TAG_UNIQUE_URL_NL] = $property[TAG_UNIQUE_URL_NL];

    $project[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox[lb32]']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.lapeirre.be/" . $pic);

        return $picUrls;
    });

    
    
    if(empty($project[TAG_PICTURES])){
	
	$pics = $parser->getNodes("img[contains(@src, 'fotos')]");
	 
	foreach($pics as $picx){
	    
	    $pic = $parser->getAttr($picx, "src");        
	    $picUrls[] = array(TAG_PICTURE_URL => 'http://www.lapeirre.be/'.$pic);
	}
	
	$project[TAG_PICTURES] = $picUrls;
    }
    
    CrawlerTool::parseAddress($parser->extract_xpath("div[@class = 'adres']/text()[1]"), $project);
    $parser->extract_xpath("div[@class = 'adres']/text()[2]", RETURN_TYPE_TEXT, function($text) use(&$project)
    {
        if(preg_match("/(\d{4,})(.*)/", $text, $match))
        {
            $project[TAG_ZIP] = $match[1];
            $project[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
    });
    if(empty($project[TAG_CITY])) $project[TAG_CITY] = $property[TAG_CITY];
    if(empty($project[TAG_STREET])) $project[TAG_STREET] = $property[TAG_STREET];

    $project[TAG_TEXT_TITLE_NL] = $parser->extract_xpath("div[@class = 'vastgoed']/preceding-sibling::h1");
    $project[TAG_TEXT_DESC_NL] = $parser->extract_xpath("h3[contains(text(), 'Omschrijving')]/following-sibling::p[1]");

    $nodes = $parser->getNodes("table[@class = 'loten']/tr[position() > 1]");
    $project[TAG_SOLD_PERCENTAGE_MAX] = $nodes->length;

    $nodes = $parser->getNodes("table[@class = 'loten']/descendant::a[. = 'Detail']");
    $project[TAG_SOLD_PERCENTAGE_VALUE] = $project[TAG_SOLD_PERCENTAGE_MAX] - $nodes->length;

    $count = 0;
    foreach($nodes as $node)
    {
        $innerProperty = array();
        $innerProperty[TAG_PROJECT_ID] = $project[TAG_PROJECT_ID];
        $innerProperty[TAG_STATUS] = $property[TAG_STATUS];
        $innerProperty[TAG_UNIQUE_URL_NL] = "http://www.lapeirre.be/" . $parser->getAttr($node, "href");
        $innerProperty[TAG_UNIQUE_ID] =  $parser->regex("/vg=(\d+)/", $innerProperty[TAG_UNIQUE_URL_NL]);
        $innerProperty[TAG_CITY] = $project[TAG_CITY];
        if(!empty($project[TAG_ZIP])) $innerProperty[TAG_ZIP] = $project[TAG_ZIP];
        $innerProperty[TAG_STREET] = $project[TAG_STREET];
        if(!empty($project[TAG_NUMBER])) $innerProperty[TAG_NUMBER] = $project[TAG_NUMBER];
        if(!empty($project[TAG_BOX_NUMBER])) $innerProperty[TAG_BOX_NUMBER] = $project[TAG_BOX_NUMBER];

        if(in_array($innerProperty[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $innerProperty[TAG_UNIQUE_ID];

        $count += 1;

        // process item to obtain detail information
        if($count > 1) echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $innerProperty, $crawler->request($innerProperty[TAG_UNIQUE_URL_NL]));
        if($count < $nodes->length) echo "--------- Completed<br />";

        $propertyCount += 1;
    }

    if($count > 0) CrawlerTool::saveProject($project);
}
