<?php
header('Content-Type: text/html; charset=utf-8');
/* ============================= CONFIG ============================= */

// Crawler ID 8980
require_once("./../crawler_classes.php");

//$crawler->enable_delay_between_requests(5, 10);
$crawler->use_cookies(true);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.haussmannproperties.com/index.php?phppage=search&PurposeStatusIDList=1&lang=nl",

    ),
);
$startPages[STATUS_TORENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.haussmannproperties.com/index.php?phppage=search&PurposeStatusIDList=2&lang=nl"
    ),
);
/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsell", "house", $html);
exit;*/



/*$html = file_get_contents("p-1.htm");
$pages = getPages($html);

echo "<pre>";
print_r($pages);
echo "</pre>";

exit;*/



/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_NL => "", TAG_STATUS => "forsell", TAG_TYPE => "house"), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Haussmann Properties";
$office[TAG_OFFICE_URL] = "http://www.haussmannproperties.be/";
$office[TAG_STREET] = "Boulevard Baudoin";
$office[TAG_NUMBER] = "14/15";
$office[TAG_ZIP] = "1000";
$office[TAG_CITY] = "Bruxelles";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "+32 2 880 68 68";
$office[TAG_FAX] = "+32 2 514 44 92";
$office[TAG_EMAIL] = "info@haussmannproperties.com";
CrawlerTool::saveOffice($office);

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
            $cp = 1;
            while(true)
            {
                $html = $crawler->request($page . "&Page=" . $cp);
                $numOfProperty = processPage($crawler, $status, $type, $html);
                if($numOfProperty == 0) break;

                $cp += 1;
            }



        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

/**
 * Get a list of next pages
 */
function getPageList($html) {
	$dom = new DOMDocument();
	$dom->preserveWhiteSpace = false;
	@$dom->loadHTML($html);
	$xpath = new DOMXPath($dom);
	$parser = new PageParser($html);

	$pageList = array();
	$nodes = $parser->getNodes("a[contains(@href, '&OxyPage=')]");

	if($nodes) {
		foreach($nodes as $node) {
			$pageList[] = "http://www.immo-tt.be/" . str_replace(" ", "%20", $parser->getAttr($node, "href"));
		}
	}

	// free memory used
	unset($dom);
	unset($xpath);

	return array_unique($pageList);
}


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);
    $items = array();
    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[contains(@href, 'EstateID')]");
    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
		$property[TAG_UNIQUE_URL_NL] =  preg_replace('/&Page=(\d)/','',"http://www.haussmannproperties.com/" . $parser->getAttr($node, "href"));
        $property[TAG_UNIQUE_URL_FR] =  preg_replace('/&Page=(\d)/','',"http://www.haussmannproperties.com/" . str_replace('lang=nl','lang=fr',$parser->getAttr($node, "href")));
        $property[TAG_UNIQUE_URL_EN] =  preg_replace('/&Page=(\d)/','',"http://www.haussmannproperties.com/" . str_replace('lang=nl','lang=en',$parser->getAttr($node, "href")));
        
        $property[TAG_UNIQUE_ID] = getUniqueId($property[TAG_UNIQUE_URL_NL]);
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

	//if($item["item"][TAG_UNIQUE_ID]=='1496229'){
		
		// process item to obtain detail information
		echo "--------- Processing property #$propertyCount ...";
		processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
		echo "--------- Completed<br />";
	
	//}
    }

    return sizeof($items);
}

function getUniqueId($url) {
	preg_match("/ID=(\d+)/", $url, $match);
	if($match) return $match[1];
}


/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
     // $property[TAG_UNIQUE_URL_FR] = 'http://www.haussmannproperties.com/index.php?phppage=search&PurposeStatusIDList=1&lang=fr&EstateID=1877810';
     // $property[TAG_UNIQUE_URL_NL] = 'http://www.haussmannproperties.com/index.php?phppage=search&PurposeStatusIDList=1&lang=nl&EstateID=1877810';

    $html=$crawler->request($property[TAG_UNIQUE_URL_FR]);
    $parser = new PageParser($html,true);
    
    if (preg_match('!google\.maps\.LatLng\(([0-9.]+),([0-9.]+)\)!',$html,$res))
	{
		$property[TAG_LATITUDE]  = $res[1];
		$property[TAG_LONGITUDE]  = $res[2];
	}

	if(empty($property[TAG_LONGITUDE])){
		//google.maps.LatLng(50.80241,4.34067);
		preg_match_all('#google.maps.LatLng\((.*?)\)#s', $html, $result);
		debug($result);
		$latlog = str_replace("'","",$result[1][0]);
		$latlog = explode(',', $latlog);
		
		$property[TAG_LATITUDE] = getLatLong($latlog[0]);
		$property[TAG_LONGITUDE] = getLatLong($latlog[1]); 
	}
	 
    $parser->deleteTags(array("script", "style"));
    $property[TAG_TEXT_DESC_FR]     = $parser->extract_xpath("div[@id='tab_details']/p",RETURN_TYPE_TEXT);
    $property[TAG_PLAIN_TEXT_ALL_FR]= $parser->extract_xpath("div[@id='maincontent']",RETURN_TYPE_TEXT);

    $street = '';
    
    $street = $parser->extract_xpath("div[@id='house_details']/p[2]",RETURN_TYPE_TEXT_ALL);
    debugx($street);
    if(!empty($street)){
	
	if(stripos('x'.$street,"adres") !== false){
	    
	   
	    $address = str_replace('Adresse:','',$street);
	    // debugx($street);
	     
	    CrawlerTool::parseAddress($address , $property);
	    $addr = explode(' ',$address);
	      
	    if(strlen($property[TAG_ZIP]) < 4){
		    $address = str_replace($property[TAG_ZIP],'',$address );
		    $property[TAG_BOX_NUMBER] = $property[TAG_ZIP];
		    $property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
	    }
	    
	    $property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
	    $property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
	    
	    $property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
	    $property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
	    
	    if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
	    
	    if(strlen($property[TAG_BOX_NUMBER]) < 3 || strlen($property[TAG_BOX_NUMBER]) > 3 )
	    unset($property[TAG_BOX_NUMBER]);
	    
	}
	
    }
     $property[TAG_PICTURES] = $parser->extract_xpath("img[@alt = 'Image']/@src", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic)
        {
            if(!empty($pic)) $picUrls[] = array(TAG_PICTURE_URL =>  $pic);
        }
        return $picUrls;
    });
    
    $html=$crawler->request($property[TAG_UNIQUE_URL_EN]);
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));
    $property[TAG_TEXT_DESC_EN] = $parser->extract_xpath("div[@id='tab_details']/p",RETURN_TYPE_TEXT);
    $property[TAG_PLAIN_TEXT_ALL_EN]= $parser->extract_xpath("div[@id='maincontent']",RETURN_TYPE_TEXT);

    $html=$crawler->request($property[TAG_UNIQUE_URL_NL]);
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));
    $text     =  trim($parser->extract_xpath("h2"));

    //Updated by Naveed
    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("div[@id='tab_details']/p",RETURN_TYPE_TEXT);
    $property[TAG_PLAIN_TEXT_ALL_NL]= $parser->extract_xpath("div[@id='maincontent']",RETURN_TYPE_TEXT);
    
   
    preg_match("/(\d{4,})\s(.*)/", $text, $match);
    if($match) {
        if($match[0] != $match[1].' '.$match[2]){
           // $property[TAG_STREET] = $match[0];
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));    
        }else{
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));    
        }
        
    }
    
    if(strlen($property[TAG_ZIP]) > 4) return;
    $property[TAG_PRICE]     =  trim($parser->extract_xpath("p[@class = 'house_price']",RETURN_TYPE_NUMBER));
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("p[span[contains(text(), 'Category:')]]"));
    
    if(empty($property[TAG_TYPE])){
        $getType = ($parser->extract_xpath("div[@id='house_details']/p[3]",RETURN_TYPE_TEXT));
        $propType= explode(':', $getType);
        $property[TAG_TYPE] = trim($propType[1]);
    }    
    
    $terracetotal = ($parser->extract_xpath("td[img[@alt='terrace']]"));
    if(!empty($terracetotal)){
        if($terracetotal == "Nee"){
            $terracetotal = 0;
        }
        else{
            $terracetotal = ($parser->extract_xpath("td[img[@alt='terrace']]",RETURN_TYPE_NUMBER));
        }
        $property[TAG_TERRACES][TAG_TOTAL_AMOUNT] = $terracetotal;
    }

    $bedroomtotal = ($parser->extract_xpath("td[img[@alt='bedrooms']]"));
    if(!empty($bedroomtotal)){
        if($bedroomtotal == "Nee"){
            $bedroomtotal = 0;
        }
        else{
            $bedroomtotal = ($parser->extract_xpath("td[img[@alt='bedrooms']]",RETURN_TYPE_NUMBER));
        }
        $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT]=$bedroomtotal;
    }
    
    $bathroomtotal = ($parser->extract_xpath("td[img[@alt='bathrooms']]"));
    if(!empty($bathroomtotal)){
        if($bathroomtotal == "Nee"){
            $bathroomtotal = 0;
        }
        else{
            $bathroomtotal = ($parser->extract_xpath("td[img[@alt='bathrooms']]",RETURN_TYPE_NUMBER));
        }
        $property[TAG_BATHROOMS][TAG_TOTAL_AMOUNT]=$bathroomtotal;
    }
    
    $garagetotal = ($parser->extract_xpath("td[img[@alt='garages']]"));
    if(!empty($garagetotal)){
        if($garagetotal == "Nee"){
            $garagetotal = 0;
        }
        else{
            $garagetotal = ($parser->extract_xpath("td[img[@alt='garages']]",RETURN_TYPE_NUMBER));
        }
        $property[TAG_GARAGES][TAG_TOTAL_AMOUNT] = $garagetotal;
    }

    $areatotal = ($parser->extract_xpath("td[img[@alt='area']]"));
    if(!empty($areatotal)){
        if($areatotal == "Nee" || $areatotal == "-"){
            $areatotal = 0;
        }
        else{
            $areatotal = ($parser->extract_xpath("td[img[@alt='area']]",RETURN_TYPE_NUMBER));
        }
        $property[TAG_SURFACE_LIVING_AREA] = $areatotal;
    }
   
 
    debug($property); 

    CrawlerTool::saveProperty($property);

}

function processInnerItems($nodes, $status,$parser,$crawler) {
    $property = array();
    static $properties = array();
    static $propertyCount = 0;


    foreach($nodes as $node) {
        $property[TAG_STATUS] = $status;
        echo $property[TAG_UNIQUE_URL_NL] ="http://www.haussmannproperties.com".$parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);

    }

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]),$status);
        echo "--------- Completed<br />";
    }

}

function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function get_short_description($html, $length=255) {
    return trim(substr(preg_replace('@\s+@', ' ', get_text($html)), 0, $length));
}
function get_text($html) {
    $search = array(
        '@<style[^>]*?>.*?</style>@siU',
        '@<script[^>]*?>.*?</script>@si',
        '@<[\/\!]*?[^<>]*?>@si',
        '@<![\s\S]*?--[ \t\n\r]*>@'
    );
    $text = preg_replace($search, '', $html);
    return trim(html_entity_decode(preg_replace("/\s+\n/s", "\n", strip_tags($text))));
}
function debug($obj, $e = false)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
    if($e)
      exit;
    
}
	 
function getLatLong($str)
{
	$str = floatval($str);
	return substr($str, 0, 8) ;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function to get html between two points in htm source
function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
}


//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}    
