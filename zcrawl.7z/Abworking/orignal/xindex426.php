<?php
require_once("../crawler_classes.php");

define('SITE_URL','http://www.zkr.be/');

$office[TAG_OFFICE_ID]   = "1";
$office[TAG_OFFICE_URL]  = "www.zkr.be";
$office[TAG_OFFICE_NAME] = "Zakenkantoor Robijns bvba";
$office[TAG_STREET]      = "Grote Markt";
$office[TAG_NUMBER]      = "7";
$office[TAG_BOX_NUMBER]  = "";
$office[TAG_ZIP]         = "3440";
$office[TAG_CITY]        = "Zoutleeuw";
$office[TAG_COUNTRY]     = "Belgium";

$office[TAG_TELEPHONE]   = "011/78 03 04";
$office[TAG_FAX]         = "011/78 50 05";
$office[TAG_EMAIL]       = "info@zkr.be";

$start_links = array(
STATUS_FORSELL   => SITE_URL . 'pand_overzicht.aspx?transactie=1;3;5',
STATUS_TORENT    => SITE_URL . 'pand_overzicht.aspx?transactie=2;4;6',
);

$properties = array();
foreach ($start_links as $status => $tkth_url)
{
	$html   = $crawler->request($tkth_url);

	for ($page = 2; $page <= 200; $page++)
	{
		//extract links to properties
		preg_match_all('!href="pand_detail\.aspx\?pandid=(\d+)&amp;id=(\d*)">!',$html,$res,PREG_SET_ORDER);
		foreach ($res as $v)
		{
			$property                         = array();
			$property[TAG_UNIQUE_ID]          = $v[1];//$v[1].'.'.$v[2];
			$property[TAG_UNIQUE_URL_NL]      = SITE_URL . 'pand_detail.aspx?pandid=' .$v[1] . '&id=' . $v[2];
			$property[TAG_STATUS]             = $status;

			$properties[] = $property;
		}


		//break if no next page link
		if (strpos($html,'_doPostBack(\'ctl00_ContentPlaceHolder1_dlPandOverzicht:' . $page . '\'')===false)
		{
			break;
		}

		preg_match('!id="__VIEWSTATE" value="(.*?)"!',$html,$res);
		$viewstate  = urlencode($res[1]);

		preg_match('!id="__EVENTVALIDATION" value="(.*?)"!',$html,$res);
		$eventvalidation  = urlencode($res[1]);

		$post = "__EVENTTARGET=ctl00_ContentPlaceHolder1_dlPandOverzicht%3A$page&__EVENTARGUMENT=&__VIEWSTATE=$viewstate&__SCROLLPOSITIONX=0&__SCROLLPOSITIONY=0&__EVENTVALIDATION=$eventvalidation&ctl00%24ContentPlaceHolder1%24Pand_zoeken%24city=0&ctl00%24ContentPlaceHolder1%24Pand_zoeken%24type=0&ctl00%24ContentPlaceHolder1%24Pand_zoeken%24price_class=0";
		$html = $crawler->request($tkth_url,$post,$tkth_url);
	}
}


CrawlerTool::startXML();
CrawlerTool::saveOffice($office);

//procces properties
$done_cnt  = 0;
$total_cnt = count($properties);
echo "start scraping ads\r\n<br>Total count:$total_cnt\r\n<br>";
foreach ($properties as $property)
{
	extract_info($crawler,$property);
	$done_cnt++;
	$z = round(($done_cnt/$total_cnt)*100,2);
	echo "Done:$done_cnt/$total_cnt ($z% completed)\r\n<br>";
}

CrawlerTool::endXML();

echo "<br /><b>Completed!</b>";


function extract_info($crawler,$property)
{
	$html   = $crawler->request($property[TAG_UNIQUE_URL_NL]);

	if (CrawlerTool::skipWordFound($html))	{echo "property skipped<br>\r\n";return ;}

	$parser = new PageParser($html);


	$arr                                   = $parser->regex_all('!class="fancy"[^<>]+href="/(App_Themes/[^"]+)"><img!i', $html);
	$property[TAG_PICTURES]                = CrawlerTool::addTextToPicUrls($arr,SITE_URL);

	if (preg_match('!lblTitel">([^<>]+)<!',$html,$res))
	{
		$property[TAG_TEXT_TITLE_NL] = trim($res[1]);
	}

	if (preg_match('!lblBeschrijving">([^<>]+)<!',$html,$res))
	{
		$property[TAG_TEXT_DESC_NL] = trim($res[1]);
	}

	if (preg_match('!Web\.GoogleMap.*?\,\"Latitude\"\:(.*?)\,\"Longitude\"\:(.*?)\,\"!si', $html, $map))
	{
		$property[TAG_LATITUDE]  = $map[1];
		$property[TAG_LONGITUDE] = $map[2];
	}


	//parse fields
	$vars = array();

	preg_match_all('!class="lblDetail">([^<>]+)</span>\s+</td>\s+</td>\s+</table>\s+</td><td>\s+<span[^<>]+class="lblDetailValue">(.*?)</span>!s',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$vars[$arr[1]] = trim(strip_tags($arr[2]));
	}

	$property[TAG_TYPE]                    = CrawlerTool::getPropertyType(get_var($vars,'type'));
	if ($property[TAG_TYPE] == '')	{$property[TAG_TYPE]     =  CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL],300);}
	$property[TAG_CITY]                    = trim(preg_replace('!\(.*?\)!','',get_var($vars,'gemeente')));
	$property[TAG_ZIP]                     = get_var($vars,'postcode','!(\d{4,5})!');
	if (strlen($property[TAG_ZIP])>4)
	{
		echo "property #{$property[TAG_UNIQUE_ID]} skipped, because zip code is  {$property[TAG_ZIP]} (more than 4 chars)<br>\r\n";
		return ;
	}
	$property[TAG_PRICE]                   = CrawlerTool::toNumber(get_var($vars,'prijs','![^<>0-9]*([0-9,.]+)!'));
	$property[TAG_STREET]                  = get_var($vars,'straat');
	$property[TAG_NUMBER]                  = get_var($vars,'nr.');
	$property[TAG_ORIGINAL_REFERENCE]      = get_var($vars,'referentie');

	$property[TAG_CONSTRUCTION_YEAR]       = get_var($vars,'bouwjaar','!(\d{4})!');
	$property[TAG_K_LEVEL]                 = get_var($vars,'k peil','!(\d+)!');
	$property[TAG_EPC_VALUE]               = get_var($vars,'epc waarde','!(\d+)!');
	$property[TAG_EPC_CERTIFICATE_NUMBER]  = get_var($vars,'epc referentie');

	$property[TAG_PLANNING_PERMISSION]     = get_var($vars,'bouwvergunning') == 'Ja' ? 1 : '';
	$property[TAG_IS_NEW_CONSTRUCTION]     = get_var($vars,'nieuwbouw') == 'Ja' ? 1 : '';
	$property[TAG_PRIORITY_PURCHASE]       = get_var($vars,'voorkooprecht') == 'Ja' ? 1 : '';

	$property[TAG_MOST_RECENT_DESTINATION] = get_var($vars,'stedenbouwkundige bestemming');
	if (empty($property[TAG_MOST_RECENT_DESTINATION])) 	{unset($property[TAG_MOST_RECENT_DESTINATION]);}

	$property[TAG_KI_INDEX]                = str_replace('.','',get_var($vars,'ki','![^<>0-9]*([0-9.]+)!'));
	$property[TAG_KI]                      = str_replace('.','',get_var($vars,'k.i. niet-gendexeerd','![^<>0-9]*([0-9.]+)!'));
	$property[TAG_RENOVATION_YEAR]         = get_var($vars,'renovatie jaar','!(\d{4})!');
	$property[TAG_SURFACE_LIVING_AREA]     = get_var($vars,'oppervlakte bewoonbaar','!(\d+)!');
	$property[TAG_SURFACE_GROUND]          = get_var($vars,'oppervlakte grond','!(\d+)!');

	$property[TAG_LOT_WIDTH]               = get_var($vars,'breedte grond','!(\d+)!');
	$property[TAG_LOT_DEPTH]               = get_var($vars,'diepte grond','!(\d+)!');

	$property[TAG_SURFACE_CONSTRUCTION]    = str_replace(',','.',get_var($vars,'oppervlakte bebouwd','!([0-9,]+)!'));
	$property[TAG_FLOOR]                   = get_var($vars,'verdieping','!(\d+)!');
	if (empty($property[TAG_FLOOR])) {unset($property[TAG_FLOOR]);}
	$property[TAG_CONSTRUCTION_TYPE]       = CrawlerTool::getConstructionType(get_var($vars,'bebouwing'));
	$property[TAG_FRONTAGE_WIDTH]          = str_replace(',','.',get_var($vars,'breedte huis','!([0-9,]+)!'));
	$property[TAG_DEPTH_GROUND_FLOOR]      = str_replace(',','.',get_var($vars,'diepte huis','!([0-9,]+)!'));
	$property[TAG_LIFT]                    = get_var($vars,'lift') == 'Ja' ? 1 : '';
	$property[TAG_SUBDIVISION_PERMIT]      = get_var($vars,'verkavelings vergunning') == 'Ja' ? 1 : '';
	$property[TAG_FURNISHED]               = get_var($vars,'bemeubeld') == 'Ja' ? 1 : '';
	$property[TAG_HAS_ELECTRICAL_INSPECTION_CERTIFICATE] = get_var($vars,'keuringsattest elektriciteit') == 'Ja' ? 1 : '';
	$property[TAG_FREE_FROM]               = get_var($vars,'beschikbaar');
	$property[TAG_DOMESTIC_ANIMALS_ALLOWED]= get_var($vars,'huisdieren toegelaten') == 'Ja' ? 1 : '';
	

	$tuin = get_var($vars,'orientatie tuin');
	if (!empty($tuin))
	{
		$property[TAG_GARDEN_AVAILABLE] = 1;

		$raw = trim(strtolower($tuin));
		$raw = str_replace('-','',$raw);

		if ($raw=='noordwest')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'NW';
		}
		elseif ($raw=='zuidwest')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'SW';
		}
		elseif ($raw=='zuidoost')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'SE';
		}
		elseif ($raw=='noordoost')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'NE';
		}
		elseif ($raw=='noordoost')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'NE';
		}
		elseif ($raw=='noord')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'N';
		}
		elseif ($raw=='oost')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'E';
		}
		elseif ($raw=='west')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'W';
		}
		elseif ($raw=='zuid')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'S';
		}
	}


	$unmatched_variables = array();
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	}
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;


	CrawlerTool::saveProperty($property);
}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
			return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}