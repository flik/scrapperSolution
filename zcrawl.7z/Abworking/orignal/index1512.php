<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1512

require_once("../crawler_classes.php");


CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.immovillages.com"
    )
);


$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE         =>  array
    (
        "http://www.immovillages.com/constructions-neuves"
    ),
    TYPE_HOUSE        =>  array
    (
       "http://www.immovillages.com/a-vendre/residentiel/moins-de-250000",
       "http://www.immovillages.com/a-vendre/residentiel/plus-de-250000",
    ),

    TYPE_COMMERCIAL   =>  array
    (
        "http://www.immovillages.com/a-vendre/commerce",
    ),
    TYPE_PLOT         =>  array
    (
        "http://www.immovillages.com/a-vendre/terrain"
    ),

);

$startPages[STATUS_FORRENT] = array
(
    TYPE_HOUSE        =>  array
    (
       "http://www.immovillages.com/a-louer"
    ),

);


/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/



/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();
$propertyCount = 0;
$properties = array();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    /*static $propertyCount = 0;
    static $properties = array();*/
    global $propertyCount;
    global $properties;

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("div[@class = 'cacheImg']/a[img] | a[.= 'En savoir plus ...']");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_FR] = "http://www.immovillages.com" . str_replace(array("../", "http://www.immovillages.com"),array("", ""), $parser->getAttr($node, "href"));
        if(stripos($property[TAG_UNIQUE_URL_FR], "http://www.immovillages.com#")!== false) continue;
        $property[TAG_UNIQUE_ID] =  $parser->regex("/(\d+)$/", $property[TAG_UNIQUE_URL_FR]);

        if(empty($property[TAG_UNIQUE_ID]) && empty($property[TAG_UNIQUE_URL_FR]))
        {
            $property[TAG_UNIQUE_URL_FR] = $parser->getAttr($node, "href");
            $property[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_FR]);
        }
        $property[TAG_PRICE] = $parser->extract_xpath("ancestor::tr[1]/following-sibling::tr[2]/td[3]", RETURN_TYPE_NUMBER, null, $node);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_FR]);
	}   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;
        // if($item["item"][TAG_UNIQUE_ID] == "3615389540" || $item["item"][TAG_UNIQUE_ID] == "1461"){
            // process item to obtain detail information
            echo "--------- Processing property #$propertyCount ...";
            processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
            echo "--------- Completed<br />";
        // }
    }

    return sizeof($items);
}


/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    // check for project, if this is a project page then go processing the project
    $node = $parser->getNode("a[contains(@href, 'code=')][img]");
    if($node)
    {
        processProject($crawler, $parser, $property);
        return;
    }

    $property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("h2[contains(text(), 'Description')]/following-sibling::p");
    $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL);

    $property[TAG_PICTURES] = $parser->extract_xpath("div/ul[@class = 'ad-thumb-list']/li/a[img]", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL =>  $pic);

        return $picUrls;
    });

    // get document files
    $nodes = $parser->getNodes("a[contains(@href, 'pdf')]");
    foreach($nodes as $node)
    {
        $property[TAG_FILES][] = array(TAG_FILE_URL_FR => "http://www.immovillages.com/" . str_replace("../","", $parser->getAttr($node, "href")), TAG_FILE_TITLE_FR=>$parser->getText($node));
    }


    $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "",$parser->extract_xpath("p[strong[contains(text(), 'Localité')]]/following-sibling::p[1]")));
    $property[TAG_ORIGINAL_REFERENCE] = $parser->extract_xpath("p[strong[contains(text(), 'Référence du bien')]]/following-sibling::p[1]");
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("p[strong[contains(text(), 'Disponibilité')]]/following-sibling::p[1]", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM] = $parser->extract_xpath("p[strong[contains(text(), 'Disponibilité')]]/following-sibling::p[1]");
    if(empty($property[TAG_PRICE])) $property[TAG_PRICE] = $parser->extract_xpath("p[strong[contains(text(), 'Prix')]]/following-sibling::p[1]", RETURN_TYPE_NUMBER);
    $parser->setQueryTemplate("strong[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::text()");

    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("Type de construction"));
    $property[TAG_KI] = $parser->extract_xpath("Revenu cadastral", RETURN_TYPE_NUMBER);
    $property[TAG_EPC_VALUE] = $parser->extract_regex("/(\d+)\skwh/i", RETURN_TYPE_EPC);
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_FR]);
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("riode de construction", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_CONSTRUCTION] = $parser->extract_xpath("Surfaces bâtie", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Surfaces utiles", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Surfaces du terrain", RETURN_TYPE_TEXT, function($text)
    {
        if(stripos($text, "a") !== false)
        {
            return CrawlerTool::toMeter($text);
        }
        else
        {
            return CrawlerTool::toNumber($text);
        }
    });
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("façades", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("chambres", RETURN_TYPE_NUMBER); //chambres
    $property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("Garages", RETURN_TYPE_NUMBER);
    $property[TAG_COMMON_COSTS] = $parser->extract_xpath("charges", RETURN_TYPE_NUMBER);
    $property[TAG_LIFT] = CrawlerTool::contains($parser->extract_xpath("Ascenseur"), "oui");
    $property[TAG_GARDEN_AVAILABLE] = CrawlerTool::contains($parser->extract_xpath("Jardin"), "/ oui");
    $property[TAG_FLOOR] = $parser->extract_xpath("Etage", RETURN_TYPE_NUMBER);
    $property[TAG_DOUBLE_GLAZING] = $parser->extract_regex("/(Double vitrage)/i") === "Double vitrage"? 1:0;
    $property[TAG_HEATING_FR] = $parser->extract_xpath("chauffage");
    $property[TAG_TELEPHONE_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("Téléphone"), "oui");
    $property[TAG_CONNECTION_TO_WATER] = CrawlerTool::contains($parser->extract_xpath("Eau"), "oui");
    $property[TAG_GAS_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("Gaz de ville"), "oui");

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_FR]));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_FR]));

    if($property[TAG_CITY] == 'SART D\'AVRIL'){
        $property[TAG_CITY] = 'Sart d\'Avril';
    }

    debug($property);
    //CrawlerTool::test($property);

    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}

function processProject($crawler, $parser, $property)
{
    global $propertyCount;
    global $properties;

    $project = array();
    $project[TAG_PROJECT_ID] = $property[TAG_UNIQUE_ID];
    $project[TAG_UNIQUE_URL_FR] = $property[TAG_UNIQUE_URL_FR];

    $project[TAG_TEXT_DESC_FR] = $parser->extract_xpath("div[@id = 'left-block']/div/h1", RETURN_TYPE_TEXT_ALL);
    $project[TAG_PICTURES] = $parser->extract_xpath("div[@id = 'gallery']/descendant::li/img", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.immovillages.com/old/compiegne/" . $pic);

        return $picUrls;
    });

    CrawlerTool::parseAddress($parser->extract_xpath("h2/address/text()[1]"), $project);
    $parser->extract_xpath("h2/address/text()[2]", RETURN_TYPE_TEXT, function($text) use(&$project)
    {
        if(preg_match("/(\d{4,})(.*)/", $text, $match))
        {
            $project[TAG_ZIP] = $match[1];
            $project[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
    });

    $project[TAG_SOLD_PERCENTAGE_MAX] = 0;
    $project[TAG_SOLD_PERCENTAGE_VALUE] = 0;
    $nodes = $parser->getNodes("a[contains(@href, 'code=')][img]");

    $project[TAG_SOLD_PERCENTAGE_MAX] =  $nodes->length;
    $count = 0;
    foreach($nodes as $node)
    {
        $innerProperty = array();
        $innerProperty[TAG_STATUS] = STATUS_FORSALE;
        $innerProperty[TAG_PROJECT_ID] = $project[TAG_PROJECT_ID];
        $innerProperty[TAG_CITY] = $project[TAG_CITY];
        $innerProperty[TAG_ZIP] = $project[TAG_ZIP];
        $innerProperty[TAG_STREET] = $project[TAG_STREET];
       // $innerProperty[TAG_NUMBER] = $project[TAG_NUMBER];

        $innerProperty[TAG_UNIQUE_URL_FR] = "http://www.immovillages.com/old/compiegne/" . $parser->getAttr($node, "href");
        $innerProperty[TAG_UNIQUE_ID] = $parser->regex("/code=(.*)/", $innerProperty[TAG_UNIQUE_URL_FR]) ;

        $innerProperty[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("parent::div[1]/following-sibling::div[1]/div[1]", RETURN_TYPE_TEXT, null, $node));

        if(in_array($innerProperty[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $innerProperty[TAG_UNIQUE_ID];

        $count += 1;

        // process item to obtain detail information
        if($count > 1) echo "--------- Processing property #$propertyCount ...";
        processInnerItem($crawler, $innerProperty, $crawler->request($innerProperty[TAG_UNIQUE_URL_FR]));
        if($count < $nodes->length) echo "--------- Completed<br />";

        $propertyCount += 1;
    }


    if($count > 0) CrawlerTool::saveProject($project);
}

function processInnerItem($crawler, $property, $html)
{
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("div[@id = 'left-block']/div[1]", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("div[@id = 'left-block']", RETURN_TYPE_TEXT_ALL);
    if(stripos($property[TAG_PLAIN_TEXT_ALL_FR], "VENDU")) $property[TAG_STATUS] = STATUS_SOLD;

    $property[TAG_PICTURES] = $parser->extract_xpath("a[@class = 'group']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.immovillages.com/old/compiegne/" . $pic);

        return $picUrls;
    });

    // get document files
    $files = array();
    $nodes = $parser->getNodes("a[.= '[ PDF ]']");
    foreach($nodes as $node)
    {
        $fileUrl = "http://www.immovillages.com/old/compiegne/" . $parser->getAttr($node, "href");
        $fileTitle = $parser->extract_xpath("parent::div[1]/preceding-sibling::div[1]", RETURN_TYPE_TEXT, null, $node);
        $files[] = array(TAG_FILE_URL => $fileUrl, TAG_FILE_TITLE_FR => $fileTitle);
    }
    if(!empty($files)) $property[TAG_FILES] = $files;

    $property[TAG_IS_NEW_CONSTRUCTION] = 1;
    $property[TAG_PRICE] = $parser->extract_xpath("p[@class = 'price']", RETURN_TYPE_NUMBER);
    if(empty($property[TAG_PRICE])) $property[TAG_PRICE] = $parser->extract_xpath("span[@class = 'price']", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_regex("/Surface :\s(\d+)/", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_regex("/Nombre de chambres :\s(\d)/", RETURN_TYPE_NUMBER);
    $terrasSurf = $parser->extract_regex("/Terrasse :\s(\d+)/", RETURN_TYPE_NUMBER);
    if($terrasSurf > 0) $property[TAG_TERRACES][] = array(TAG_TERRACE_SURFACE => $terrasSurf);
    //CrawlerTool::test($property);

    

    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}

function debug($obj, $e = false)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
    if($e)
      exit;
    
}
