<?php

/* ============================= CONFIG ============================= */
// Crawler ID 604
require_once("./../crawler_classes.php");
CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.immojanssen-marres.be/"
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immojanssen-marres.be/nl/zoek/tekoop"
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immojanssen-marres.be/nl/zoek/tehuur"
    ),
);

/* ============================= END TEST AREA ============================= */
// START writing data to output.xml file
CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
	    $post = "?keywords=&minprijs=0&maxprijs=0&slaapkamers=0&type=0&postcode=";
	    debugx($page);
            $html = $crawler->request($page,$post);
            processPage($crawler, $status, $type, $html);

            $nextPages = getPages($html);
            foreach($nextPages as $nextPage)
            {
		debugx($nextPage);
                $html = $crawler->request($nextPage, $post);
                processPage($crawler, $status, $type, $html);
            }
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);
 
    $nodes = $parser->getNodes("div[@class = 'product-item clickable']");
    debug($nodes); exit;
    $items = array();
    foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;

	///Getting link with node html
	$link = $parser->extract_xpath("div[@class = 'span4']/h3/a/@href", RETURN_TYPE_TEXT, null, $node); 

        $property[TAG_UNIQUE_URL_NL] = $link;
	$property[TAG_UNIQUE_URL_FR] = str_replace('nl','fr',$link);
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
        
	$price = $parser->extract_xpath("span[@class = 'price']", RETURN_TYPE_NUMBER, null, $node); 
	$property[TAG_PRICE] = $price; 
	
	$address = $parser->extract_xpath("div[@class = 'span4']/h3/a", RETURN_TYPE_TEXT, null, $node); 
	$addr = explode(' ',$address);
	$property[TAG_ZIP] =  $parser->regex("/(\d{4})/", $address );  
 	
	$property[TAG_CITY] = trim($addr[count($addr)-1]);
	 
	$property[TAG_BEDROOMS_TOTAL]  = $parser->extract_xpath("ul[@class = 'title-info']/li[1]/span", RETURN_TYPE_TEXT, null, $node);
	$property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("ul[@class = 'title-info']/li[2]/span", RETURN_TYPE_TEXT, null, $node);
	$property[TAG_SURFACE_GROUND]  	= $parser->extract_xpath("ul[@class = 'title-info']/li[3]/span", RETURN_TYPE_NUMBER, null, $node);
	$property[TAG_CONSTRUCTION_YEAR]  = $parser->extract_xpath("ul[@class = 'title-info']/li[4]/span", RETURN_TYPE_TEXT, null, $node);
	   
	
	
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
    }   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...".$item["itemUrl"];
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Get a list of next pages
 */
function getPages($html)
{
    $parser = new PageParser($html);

	$pages = array();
	$nodes = $parser->getNodes("div[@class = 'paging-box']/a");

    if(!empty($nodes))
    {
		foreach($nodes as $node)
        {
			$pages[] = "http://www.immodecimo.be" . $parser->getAttr($node, "href");
		}
	}

	return array_unique($pages);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("div[@class = 'excerpt']", RETURN_TYPE_TEXT);
    $property[TAG_TEXT_TITLE_NL] = $parser->extract_xpath("div[@class = 'infotext-detail']/h1");
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@class = 'property_detail']", RETURN_TYPE_TEXT_ALL);
    
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_PLAIN_TEXT_ALL_NL]);
    
    
    $property[TAG_PICTURES] = $parser->extract_xpath("img[contains(@src, 'jpg')]", RETURN_TYPE_ARRAY, function($files)
	     {
		     $fileUrls = array();
		     foreach($files as $file)
		     {
			     if(!empty($file)) $fileUrls[] = array(TAG_PICTURE_URL =>  str_replace('../','',$file));
		     }
		     return $fileUrls;
	});
    
    $nodes = $parser->getNodes("ul[@class='title-info']/li");
    
    $items = array();
    foreach($nodes as $node)
    {
	 
	$label = str_replace(' ','_',$node->nodeValue);
	$value = $parser->extract_xpath("span", RETURN_TYPE_TEXT, null, $node);
	$label = str_replace($value,'',$label);
	
	$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	 
    }
    
    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
    
    $html = $crawler->request($property["TAG_UNIQUE_URL_FR"]);
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("div[@class = 'excerpt']", RETURN_TYPE_TEXT);
    $property[TAG_TEXT_TITLE_FR] = $parser->extract_xpath("div[@class = 'infotext-detail']/h1");
    $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("div[@class = 'property_detail']", RETURN_TYPE_TEXT_ALL);
    
    //CrawlerTool::test($property);
debug($property);  
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

///0514437586 President Line... 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}



