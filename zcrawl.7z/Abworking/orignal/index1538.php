<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1598

require_once("../crawler_classes.php");


CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.immoforsale.be/"
    )
);


$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immoforsale.be/Web.mvc/nl-be/List1"
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immoforsale.be/Web.mvc/nl-be/List2"
    ),
);


/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/



/*
$html = file_get_contents("p-1.htm");
echo getNextPage($html);
exit;*/



/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);

            $pageNum = 1;
            while(true)
            {
                $html = $crawler->request($page . "?pageNumber=" . $pageNum);
                $numOfProperty = processPage($crawler, $status, $type, $html);
                if($numOfProperty == 0) break;

                $pageNum += 1;
            }

        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[.= 'Meer details']");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_FR] = "http://www.immoforsale.be/" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  $parser->regex("/(\d+)$/", $property[TAG_UNIQUE_URL_FR]);

        // check for sold or rented properties
        $parser->extract_xpath("ancestor::tr[1]/preceding-sibling::tr[2]/td[4]", RETURN_TYPE_TEXT, function($text) use(&$property)
        {
            $propertyStatus = CrawlerTool::getPropertyStatus($text);
            if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
            {
                $property[TAG_STATUS] = $propertyStatus;
            }
        }, $node);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_FR]);
	}   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;
        //if($item["item"][TAG_UNIQUE_ID] == "1658230"){
            // process item to obtain detail information
            echo "--------- Processing property #$propertyCount ...";
            processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
            echo "--------- Completed<br />";
        //}
    }

    return sizeof($items);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("table[@border = '1']/tr/td[@class = 'Text']");
    $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("table[@cellspacing = '10']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.immoforsale.be" . $pic);

        return $picUrls;
    });

    CrawlerTool::parseAddress($parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[1]"), $property);
    $parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[2]", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(\d{4,})(.*)/", $text, $match))
        {
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
        else $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $text));
    });
    if(!empty($property[TAG_ZIP]))
    {
        if(strlen($property[TAG_ZIP]) > 4) $property[TAG_ZIP] = "";
    }

    // get document files
      $files = array();
     $nodes = $parser->getNodes("a[contains(@href, '.pdf')]");
     foreach($nodes as $node)
     {
          $fileUrl =   "http://www.immoforsale.be" . $parser->getAttr($node, "href");
          $fileTitle = $parser->getText($node);
          $files[] = array(TAG_FILE_URL => $fileUrl, TAG_FILE_TITLE_FR => $fileTitle);
     }
     if(!empty($files)) $property[TAG_FILES] = $files;


    // get bedroom surface info
    $nodes = $parser->getNodes("td[contains(text(), 'slaapkamer')]/following-sibling::td[1]");
    $bedrooms = array();
    foreach($nodes as $node)
    {
        $surface = CrawlerTool::toNumber($parser->getText($node));
        if($surface > 0) $bedrooms[] = array(TAG_BEDROOM_SURFACE => $surface);
    }
    if(!empty($bedrooms)) $property[TAG_BEDROOMS] = $bedrooms;
    $property[TAG_BEDROOMS_TOTAL] = sizeof($bedrooms);


    // get bathroom surface info
    $nodes = $parser->getNodes("td[contains(text(), 'badkamer')]/following-sibling::td[1]");
    $bathrooms = array();
    foreach($nodes as $node)
    {
        $surface = CrawlerTool::toNumber($parser->getText($node));
        if($surface > 0) $bathrooms[] = array(TAG_BATHROOM_SURFACE => $surface);
    }
    if(!empty($bathrooms)) $property[TAG_BATHROOMS] = $bathrooms;
    $property[TAG_BATHROOMS_TOTAL] = sizeof($bathrooms);

    // get terraces surface info
    $nodes = $parser->getNodes("td[contains(text(), 'Terras')]/following-sibling::td[1]");
    $terraces = array();
    foreach($nodes as $node)
    {
        $surface = CrawlerTool::toNumber($parser->getText($node));
        if($surface > 0) $terraces[] = array(TAG_TERRACE_SURFACE => $surface);
    }
    if(!empty($terraces)) $property[TAG_TERRACES] = $terraces;

    if(stripos($property[TAG_TEXT_DESC_FR], "Nieuwbouw")) $property[TAG_IS_NEW_CONSTRUCTION] = 1;
    $property[TAG_PRICE] = $parser->extract_xpath("td[contains(text(), 'Prijs')]", RETURN_TYPE_NUMBER);

    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("Categorie"));
    $property[TAG_CONSTRUCTION_TYPE] = CrawlerTool::getConstructionType($parser->extract_xpath("Type bebouwing"));
    $property[TAG_EPC_VALUE] = $parser->extract_regex("/(\d+)\s?kwh/i", RETURN_TYPE_EPC);
    $property[TAG_KI] = $parser->extract_xpath("kadastraal inkomen", RETURN_TYPE_NUMBER);
    //$property[TAG_KI_INDEX] = $parser->extract_xpath("Kad. ink.", RETURN_TYPE_NUMBER);
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("bouwjaar jaar", RETURN_TYPE_YEAR);
    if($property[TAG_CONSTRUCTION_YEAR] <= 1800) $property[TAG_CONSTRUCTION_YEAR] = "";
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("Renovatie", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Bewoonbare oppervlakte", RETURN_TYPE_NUMBER); //Surface intérieure nette
    if(empty($property[TAG_SURFACE_LIVING_AREA])) $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Bruto oppervlakte", RETURN_TYPE_NUMBER);
    $property[TAG_FRONTAGE_WIDTH] = $parser->extract_xpath("gevelbreedte breedte", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Grootte terrein", RETURN_TYPE_NUMBER);//Surface brute
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Aantal kamers", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toiletten aantal", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("garage aantal", RETURN_TYPE_NUMBER);
    $property[TAG_PARKINGS_TOTAL] = $parser->extract_xpath("parking binnen aantal", RETURN_TYPE_NUMBER);
    $property[TAG_COMMON_COSTS] = $parser->extract_xpath("lasten", RETURN_TYPE_NUMBER);
    $property[TAG_GARDEN_AVAILABLE] = CrawlerTool::contains($parser->extract_xpath("Tuin"), "ja");
    $property[TAG_FLOOR] = $parser->extract_xpath("verdiepingen aantal", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels", RETURN_TYPE_NUMBER);
    $property[TAG_DOUBLE_GLAZING] = CrawlerTool::contains($parser->extract_xpath("Dubbele beglazing"), "ja");
    $property[TAG_LIFT] = CrawlerTool::contains($parser->extract_xpath("Lift"), "ja");
    $property[TAG_CONNECTION_TO_WATER] = CrawlerTool::contains($parser->extract_xpath("water"), "ja");
    $property[TAG_GAS_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("gas"), "ja");
    $property[TAG_TELEPHONE_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("Telefoon"), "ja");
    $property[TAG_PARLOPHONE] = CrawlerTool::contains($parser->extract_xpath("parlofoon"), "ja");
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Beschikbaar vanaf", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM] = $parser->extract_xpath("Beschikbaar vanaf");
    $property[TAG_PLANNING_PERMISSION] = CrawlerTool::contains($parser->extract_xpath("bouwvergunning"), "ja");
    $property[TAG_SUBDIVISION_PERMIT] = CrawlerTool::contains($parser->extract_xpath("verkavelingvergunning"), "ja");
    $property[TAG_HEATING_FR] = $parser->extract_xpath("verwarming type");
    $property[TAG_DISTANCE_PUBLIC_TRANSPORT] = $parser->extract_xpath("openbaar vervoer afstand", RETURN_TYPE_NUMBER);
    $property[TAG_DISTANCE_SCHOOL] = $parser->extract_xpath("scholen afstand", RETURN_TYPE_NUMBER);
    $property[TAG_DISTANCE_SHOPS] = $parser->extract_xpath("winkels afstand", RETURN_TYPE_NUMBER);

    $livingSurf = $parser->extract_xpath("woonkamer oppervlakte", RETURN_TYPE_NUMBER);
    if($livingSurf > 0) $property[TAG_LIVINGS][] = array(TAG_LIVING_SURFACE => $livingSurf);
    $kitchenSurf= $parser->extract_xpath("keuken oppervlakte", RETURN_TYPE_NUMBER);
    if($kitchenSurf > 0) $property[TAG_KITCHENS][] = array(TAG_KITCHEN_SURFACE => $kitchenSurf);
    $storeroomSurf = $parser->extract_xpath("berging oppervlakte", RETURN_TYPE_NUMBER);
    if($storeroomSurf > 0) $property[TAG_STOREROOMS][] = array(TAG_STOREROOM_SURFACE => $storeroomSurf);

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_FR]));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_FR]));

    //CrawlerTool::test($property);
    //getLanguageText($crawler, $property);

    debug($property);

    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}
function getLanguageText($crawler, &$property)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_FR]);
    $parser = new PageParser($html, true);

    $property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("table[@cellpadding = '6']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("td[@class = 'whomanTitle']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_HEATING_FR] = $parser->extract_xpath("td[contains(text(), 'Chauffage')]/following-sibling::td[1]");
}

function debug($obj, $e = false)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
    if($e)
      exit;
    
}