<?php

/* ============================= CONFIG ============================= */

// Crawler ID 665

require_once("./../crawler_classes.php");

CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.jansenrealestate.be"
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_HOUSE        =>  array
    (
        "http://www.jansenrealestate.be/immo_aanbod.asp?tType=frh,%20scw,%20hfh,%20clh,%20hkw",
        "http://www.jansenrealestate.be/immo_aanbod-excl.asp"
    ),
    TYPE_APARTMENT    =>  array
    (
        "http://www.jansenrealestate.be/immo_aanbod.asp?tType=app"
    ),
    TYPE_COMMERCIAL   =>  array
    (
        "http://www.jansenrealestate.be/immo_commercieel.asp?tType=off",
        "http://www.jansenrealestate.be/immo_commercieel.asp?tType=cat,%20sto",
        "http://www.jansenrealestate.be/immo_commercieel.asp?tType=int,%20wkp",
        "http://www.jansenrealestate.be/immo_commercieel.asp?tType=dep",
        "http://www.jansenrealestate.be/immo_commercieel.asp?tType=int"
    ),
    TYPE_PLOT         =>  array
    (
        "http://www.jansenrealestate.be/immo_aanbod.asp?tType=but,%20bgo,%20bgh,%20bgc,%20fat,%20wei,%20akk,%20bgd,%20rec,%20bos"
    )
);


/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "", "", $html);
exit;*/



/*$html = file_get_contents("p-1.htm");
$pages = getPages($html);

echo "<pre>";
print_r($pages);
echo "</pre>";

exit;*/

/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/

/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);

            $nextPages = getPages($html);
            foreach($nextPages as $nextPage)
            {
                $html = $crawler->request($nextPage);
                processPage($crawler, $status, $type, $html);
            }
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[contains(@href, 'immo_aanbod-detail.asp?ID=')][img]");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_NL] = "http://www.jansenrealestate.be/" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  $parser->regex("/id=(\d+)/i", $property[TAG_UNIQUE_URL_NL]);
        $propertStatus = CrawlerTool::getPropertyStatus($parser->extract_xpath("ancestor::tr[1]/following-sibling::tr[1]", RETURN_TYPE_TEXT, null, $node));
        if(!empty($property[TAG_STATUS])) $property[TAG_STATUS] = $propertStatus;

        // check for sold or rented properties
        $parser->extract_xpath("img[contains(@src, 'verkocht') or contains(@src, 'verhuurd')]/@src", RETURN_TYPE_TEXT, function($text) use(&$property)
        {
            $propertyStatus = CrawlerTool::getPropertyStatus($text);
            if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
            {
                $property[TAG_STATUS] = $propertyStatus;
		 
            }
        }, $node);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

	
	
        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

         
            // process item to obtain detail information
            echo "--------- Processing property #$propertyCount ...";
            processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
            echo "--------- Completed<br />";
         
    }

    return sizeof($items);
}

/**
 * Get a list of next pages
 */
function getPages($html)
{
    $parser = new PageParser($html);

	$pages = array();
	$nodes = $parser->getNodes("td[strong = 'Pagina:']/a");

    if(!empty($nodes))
    {
		foreach($nodes as $node)
        {
			$pages[] = "http://www.jansenrealestate.be" . $parser->getAttr($node, "href");
		}
	}

	return array_unique($pages);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    
    if($property[TAG_STATUS]==STATUS_SOLD)	 return ;
	if($property[TAG_STATUS]==STATUS_RENTED) return ;
	
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_TITLE_NL] = $parser->extract_xpath("td[@width = '475']/strong[1]");
    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("td[@width = '475']/div[@class = 'justify']");
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@width = '659']", RETURN_TYPE_TEXT_ALL);
    
    if(empty($property[TAG_STATUS])) $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($property[TAG_TEXT_TITLE_NL]);
    if(empty($property[TAG_STATUS])) $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($property[TAG_TEXT_DESC_NL]);
    if(empty($property[TAG_STATUS])) $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($property[TAG_PLAIN_TEXT_ALL_NL]);
    
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox[set1]']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.jansenrealestate.be/" . $pic);

        return $picUrls;
    });
    $property[TAG_PRICE] = $parser->extract_xpath("div[@class = 'box2']", RETURN_TYPE_NUMBER);

    // get document files
    $nodes = $parser->getNodes("tr/td[2]/a[contains(@href, 'downloads')]");
    foreach($nodes as $node)
    {
        $fileUrl = $parser->getAttr($node, "href");
        $fileTitle = $parser->getText($node);
        $property[TAG_FILES][] = array(TAG_FILE_URL_NL => $fileUrl, TAG_FILE_DESC_NL => $fileTitle);
    }

    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    $parser->extract_xpath("adres:", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(.*),(.*)/", $text, $match))
        {
            CrawlerTool::parseAddress($match[1], $property);
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
    });

    // Raheel Fix
    if(strtolower($property[TAG_CITY]) == "marbella"){
        return;
    }
    // Raheel Fix End

    $property[TAG_ORIGINAL_REFERENCE] = str_replace("&", "-", $parser->extract_xpath("referentie:"));
    $property[TAG_CONSTRUCTION_TYPE] = CrawlerTool::getConstructionType($parser->extract_xpath("type:"));
    $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC waarde", RETURN_TYPE_EPC);
    $property[TAG_EPC_CERTIFICATE_NUMBER] = $parser->extract_regex("/certificaatnummer\s*([\d-]+)/");
    $property[TAG_KI] = $parser->extract_xpath("KI:", RETURN_TYPE_NUMBER);
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("bouwjaar:", RETURN_TYPE_YEAR);
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("renovatiejaar", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("bewoonbare oppervlakte:", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("grond", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_CONSTRUCTION] = $parser->extract_xpath("bebouwde oppervlakte", RETURN_TYPE_NUMBER);
    $property[TAG_LOT_WIDTH] = $parser->extract_xpath("perceelbreedte", RETURN_TYPE_NUMBER);
    $property[TAG_LOT_DEPTH] = $parser->extract_xpath("perceeldiepte", RETURN_TYPE_NUMBER);
    $property[TAG_FRONTAGE_WIDTH] = $parser->extract_xpath("gevelbreedte", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("slaapkamers:", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("badkamers:", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("WC:", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("garage:", RETURN_TYPE_NUMBER);
    $property[TAG_PARKINGS_TOTAL] = $parser->extract_xpath("parkeerplaatsen:", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("badkamers:", RETURN_TYPE_NUMBER);
    $property[TAG_FLOOR] = $parser->extract_xpath("verdieping:", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FLOORS] = $parser->extract_xpath("bouwlagen:", RETURN_TYPE_NUMBER);
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("beschikbaarheid:", RETURN_TYPE_UNIX_TIMESTAMP);
    $property[TAG_HEATING_NL] = $parser->extract_xpath("verwarming");
    $property[TAG_DOUBLE_GLAZING] = CrawlerTool::contains($parser->extract_xpath("beglazing:"), "dubbel");
    if(empty($property[TAG_DOUBLE_GLAZING])) $property[TAG_DOUBLE_GLAZING] = CrawlerTool::contains($parser->extract_xpath("verkavelingsvergunning"), "ja");
    $property[TAG_GARDEN_AVAILABLE] = $parser->extract_xpath("tuin oppervlakte", RETURN_TYPE_NUMBER) > 0 ? 1 : 0;

    $livingSurf = $parser->extract_xpath("woonkamer oppervlakte:", RETURN_TYPE_NUMBER);
    if($livingSurf > 0) $property[TAG_LIVINGS][] = array(TAG_LIVING_SURFACE => $livingSurf);
    $kitchenSurf = $parser->extract_xpath("keuken oppervlakte:", RETURN_TYPE_NUMBER);
    if($kitchenSurf > 0) $property[TAG_KITCHENS][] = array(TAG_KITCHEN_SURFACE => $kitchenSurf);
    $terraceSurf = $parser->extract_xpath("terras:", RETURN_TYPE_NUMBER);
    if($terraceSurf > 0) $property[TAG_TERRACES][] = array(TAG_TERRACE_SURFACE => $terraceSurf);

    //CrawlerTool::test($property);
    if($property[TAG_STATUS] != 'sold' AND $property[TAG_STATUS] != 'rented' ){
        // WRITING item data to output.xml file

    debug($property);
        
    CrawlerTool::saveProperty($property);    
    }
    
}

function debug($obj, $e = false)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
    if($e)
      exit;
    
}
