<?php

/* ============================= CONFIG ============================= */

// Crawler ID 971
require_once("./../crawler_classes.php");

$startPages[STATUS_FORSELL] = array
(
    TYPE_HOUSE        =>  array
    (
        //"http://www.immotoma.be/index.php?option=com_properties&goal=0&Itemid=101"
        "http://www.immotoma.be/index.php?option=com_properties&pricefrom=0&priceto=&ptype=1&city=&sort=Price&CityName=&goal=0&Itemid=101"
    ),
    TYPE_APARTMENT        =>  array
    (
        "http://www.immotoma.be/index.php?option=com_properties&pricefrom=0&priceto=&ptype=2&city=&sort=Price&CityName=&goal=0&Itemid=101"
    ),
    TYPE_COMMERCIAL        =>  array
    (
        "http://www.immotoma.be/index.php?option=com_properties&pricefrom=0&priceto=&ptype=5&city=&sort=Price&CityName=&goal=0&Itemid=101"
    ),
    TYPE_PLOT        =>  array
    (

        "http://www.immotoma.be/index.php?option=com_properties&pricefrom=0&priceto=&ptype=3&city=&sort=Price&CityName=&goal=0&Itemid=101"
    ),
    TYPE_NONE        =>  array
    (
        "http://www.immotoma.be/index.php?option=com_properties&pricefrom=0&priceto=&ptype=4&city=&sort=Price&CityName=&goal=0&Itemid=101"
    ),
);

$startPages[STATUS_TORENT] = array
(
    TYPE_HOUSE        =>  array
    (
        //"http://www.immotoma.be/index.php?option=com_properties&goal=1&Itemid=101"
        "http://www.immotoma.be/index.php?option=com_properties&pricefrom=0&priceto=&ptype=1&city=&sort=Price&CityName=&goal=1&Itemid=101"
    ),
    TYPE_APARTMENT        =>  array
    (
        "http://www.immotoma.be/index.php?option=com_properties&pricefrom=0&priceto=&ptype=2&city=&sort=Price&CityName=&goal=1&Itemid=101"
    ),
    TYPE_COMMERCIAL        =>  array
    (
        "http://www.immotoma.be/index.php?option=com_properties&pricefrom=0&priceto=&ptype=5&city=&sort=Price&CityName=&goal=1&Itemid=101"
    ),
    TYPE_PLOT        =>  array
    (
        "http://www.immotoma.be/index.php?option=com_properties&pricefrom=0&priceto=&ptype=3&city=&sort=Price&CityName=&goal=1&Itemid=101"
    ),
    TYPE_NONE        =>  array
    (
        "http://www.immotoma.be/index.php?option=com_properties&pricefrom=0&priceto=&ptype=4&city=&sort=Price&CityName=&goal=1&Itemid=101"
    ),
);


/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsell", "house", $html);
exit;*/



/*$html = file_get_contents("p-1.htm");
$pages = getPages($html);

echo "<pre>";
print_r($pages);
echo "</pre>";

exit;*/




/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "forsell", TAG_TYPE => "house"), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);

            $nextPages = getPages($html);
            foreach($nextPages as $nextPage)
            {
                $html = $crawler->request($nextPage);
                processPage($crawler, $status, $type, $html);
            }
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


/**
 */
function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[img[@class = 'pandfoto']]");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_FR] = "http://www.immotoma.be" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_FR]) ;

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_FR]);
	}

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;
        
        //if($item["item"][TAG_UNIQUE_ID] == "11875" || $item["item"][TAG_UNIQUE_ID] == "12036"){
            // process item to obtain detail information
            echo "--------- Processing property #$propertyCount ...";
            echo $item["itemUrl"]."<br>";
            processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
            echo "--------- Completed<br />";
        // }

    }

    return sizeof($items);
}

/**
 * Get a list of next pages
 */
function getPages($html)
{
    $parser = new PageParser($html);

	$pages = array();
	$nodes = $parser->getNodes("div[@class = 'page']/a");

    if(!empty($nodes))
    {
		foreach($nodes as $node)
        {
			$pages[] = "http://www.immotoma.be" . $parser->getAttr($node, "href");
		}
	}

	return array_unique($pages);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_SHORT_DESC_FR] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[img[contains(@src, 'description.jpg')]]/following-sibling::div[1]")));
    $property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@class = 'content-detail'] | div[@class = 'detail_topright']", RETURN_TYPE_TEXT_ALL)));

    //$property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("div[@class = 'detail_Adressex']/following-sibling::div[1]"));
    // Raheel Fix
     
        if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
        if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
        if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_SHORT_DESC_FR]));
        if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_FR]));
    
    
    // Raheel Fix End

    $property[TAG_PICTURES] = $parser->extract_xpath("div[@class = 'thumbnail']/div/img", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => str_replace("S.jpg", "L.jpg", $pic));

        return $picUrls;
    });
    $property[TAG_PRICE] = $parser->extract_xpath("div[@class = 'detail_Prix']", RETURN_TYPE_NUMBER);

    $parser->extract_xpath("div[@class = 'detail_Adressex']", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/Adresse:(.*),\s(\d{4})(.*)/", $text, $match))
        {
            CrawlerTool::parseAddress($match[1], $property);
            $property[TAG_ZIP] = $match[2];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));
        }
    });
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("span[contains(text(), 'SUPERFICIE')]/following-sibling::span[2]", RETURN_TYPE_TEXT, function($text)
    {
        return CrawlerTool::toMeter($text);
    });
    $property[TAG_KI] = $parser->extract_xpath("span[contains(text(), 'R.C.')]/following-sibling::span[2]", RETURN_TYPE_NUMBER);

    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    $property[TAG_EPC_VALUE] = $parser->extract_xpath("PEB", RETURN_TYPE_EPC);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Nombre de chambres", RETURN_TYPE_NUMBER);

    if(empty($property[TAG_CITY]))
    {
       $parser->extract_xpath("Adresse", RETURN_TYPE_TEXT, function($text) use(&$property)
       {
           if(preg_match("/(.*),(.*)/", $text, $match))
           {
               CrawlerTool::parseAddress($match[2], $property);
               $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[1]));
           }
       });
    }

    $property[TAG_CITY] = utf8_decode(CrawlerTool::encode($property[TAG_CITY]));
    
	
    if(empty( $property[TAG_CITY]))
    return;

    debug($property);
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}

function debug($obj, $e = false)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
    if($e)
      exit;
    
}