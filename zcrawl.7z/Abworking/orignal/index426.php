<?php
header('Content-Type: text/html; charset=utf-8');
/* ============================= CONFIG ============================= */
// Crawler ID 426
require_once("../crawler_classes.php");

$crawler->enable_delay_between_requests(5,10);

CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.zkr.be/",
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.zkr.be/nl/te-koop.aspx",
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.zkr.be/nl/te-huur.aspx",
    ),
);
  
/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/



/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();


for($i=0; $i<10;$i++)
{
	$pageUrl1  = "http://www.zkr.be/Modules/ZoekModule/RESTService/SearchService.svc/GetPropertiesCount/3/0/0/1/0/0/0/0/0/0/0/0/0/0/0/20/".$i."/false/11625/NL/23/0/0/1/VURPJOEEANUDGXHJCFBICQTSMPUFCIPREFOVRWJMFDPXBLNZFG/10600713/0/0/1/0/11625/0/false/0/false/0/0/0?_=1416835946388";
    $html1 = $crawler->request($pageUrl1);
    processXML($crawler, STATUS_FORSALE, $type, $html1);
}


for($j=0; $j<10;$j++)
{
	$pageUrl2  = "http://www.zkr.be/Modules/ZoekModule/RESTService/SearchService.svc/GetPropertiesCount/3/0/0/2/0/0/0/0/0/0/0/0/0/0/0/20/".$j."/false/11626/NL/23/0/0/1/VURPJOEEANUDGXHJCFBICQTSMPUFCIPREFOVRWJMFDPXBLNZFG/0/0/0/1/0/11626/0/false/0/false/0/0/0?_=1416837094046";
    $html2 = $crawler->request($pageUrl2);
    processXML($crawler, STATUS_FORRENT, $type, $html2);
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


/**
 * Get a list of next pages
 */

function processXML($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $xml = simplexml_load_string($html);
    $xml = xml2array($xml);
    $items = array();
    
	foreach($xml as $node)
    {
    	$nodes = xml2array($node);
	
    	foreach($nodes as $n){
    		//debug($n);exit;
    		$property = array();
        	$property[TAG_STATUS] = $status;
        	$property[TAG_TYPE] = CrawlerTool::getPropertyType($n["Property_Type_Value"]);
        	$link = $n["Property_URL"];
	
        	$property[TAG_UNIQUE_URL_NL] =  'http://www.zkr.be/nl'.$link ;
        	$property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);

        	$property[TAG_TEXT_TITLE_NL] = $n["Property_Title"];
        	
        	$price = CrawlerTool::toNumber($n["Property_Price"]);
        	$property[TAG_PRICE] = $price;

        	if(!empty($n["Property_City_Value"])){
        		$city = $n["Property_City_Value"];
        		$property[TAG_CITY] = $city;
        	}

        	if(!empty($n["Property_Zip"])){
        		$zip = $n["Property_Zip"];
        		$property[TAG_ZIP] = $zip;
        	}

        	if(!empty($n["Property_Street"])){
        		$street = $n["Property_Street"];
        		$property[TAG_STREET] = $street;
        	}

        	if(!empty($n["Property_Number"])){
        		$property[TAG_NUMBER] = $n["Property_Number"];
        	}

        	if(!empty($n["Property_Description"])){
        		$description = $n["Property_Description"];
        		$property[TAG_TEXT_DESC_NL] = utf8_decode($description);
			}

			if(!empty($n["Property_Area_Ground"])){
        		$surface_ground = $n["Property_Area_Ground"];
        		$surface_ground = preg_replace("/[^0-9]/", "",$surface_ground);
        		$property[TAG_SURFACE_GROUND] = $surface_ground;
        	}

        	if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        	$properties[] = $property[TAG_UNIQUE_ID];

        	$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL],"itemId" => $n["FortissimmoID"]);
    	}
	}

	 foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        $itemUrl = "http://www.zkr.be/Modules/DataModule/RESTService/DataService.svc/GetDetailManagement/VURPJOEEANUDGXHJCFBICQTSMPUFCIPREFOVRWJMFDPXBLNZFG/NL/".$item["itemId"]."?_=1416900173601";
        processItem($crawler, $item["item"], $crawler->request($itemUrl));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Download and extract item detail information http://www.av-vastgoed.be/images/panden/1366631738.jpg
 */
function processItem($crawler, $property, $html)
{
	if(empty(trim($html))){
		CrawlerTool::saveProperty($property);
	}
	 
    $xml = simplexml_load_string($html);
    $xml = xml2array($xml);
    
	foreach($xml as $node)
    {
    	 
    	$picUrls = array();
    	
	$picturesArr = xml2array($node["Pictures"]["PropertyPictures"]);
	
    	foreach($picturesArr as $pic){
    		$picUrls[] = array(TAG_PICTURE_URL => "http://www.zkr.be/fortissimmo/zkr.be/images/".$pic["picture_file"]); 
    	}
	$property[TAG_PICTURES] = $picUrls;
	
    	$property[TAG_BEDROOMS_TOTAL] = $node["Detail"]["bedrooms"];
    	$property[TAG_AMOUNT_OF_FLOORS] = $node["Detail"]["floors_total"];
    	 
    	$layoutArr = xml2array($node["Layout"]["PropertyLayout"]);
		foreach($layoutArr as $layout){
			if($layout["value"] == "Badkamer"){
				$property[TAG_BATHROOMS_TOTAL] = $layout["count"];
			}
			if($layout["value"] == "Eetkamer"){
				$property[TAG_DININGS] = $layout["count"];
			}
			if($layout["value"] == "Woonkamer"){
				$property[TAG_LIVINGS] = $layout["count"];
			}
			if($layout["value"] == "Toilet"){
				$property[TAG_TOILETS_TOTAL] = $layout["count"];
			}
			if($layout["value"] == "Keuken"){
				$property[TAG_KITCHENS] = $layout["count"];
			}
			if($layout["value"] == "Slaapkamer"){
				$property[TAG_BEDROOMS_TOTAL] = $layout["count"];
			}
			if($layout["value"] == "Zolder"){
				$property[TAG_ATTICS] = $layout["count"];
			}
			if($layout["value"] == "Garage"){
				$property[TAG_GARAGES_TOTAL] = $layout["count"];
			}
			if($layout["value"] == "Wasplaats"){
				$property[TAG_LAUNDRY_ROOMS] = $layout["count"];
			}
			if($layout["value"] == "Berging"){
				$property[TAG_STOREROOMS] = $layout["count"];
			}
	 
		}
		  
	}

    $property[TAG_PLAIN_TEXT_ALL_NL] = $property[TAG_TEXT_DESC_NL]; 
     
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
      
    // Most Important 
    if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
    $property['planning_proceeding'] = 0;
    
    
    if(!isset($property['planning_permission']) || empty($property['planning_permission']))
    $property['planning_permission'] = 0;
    
    
    if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
    $property['subdivision_permit'] = 0;
    
    
    if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
    $property['planning_proceeding'] = 0;
    
    
    if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
    $property['most_recent_destination'] = 0;

	if(empty($property[TAG_CITY])){
		return;
	}

    debug($property);

    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
     

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}
function xml2array ( $xmlObject, $out = array () )
{
    foreach ( (array) $xmlObject as $index => $node )
        $out[$index] = ( is_object ( $node ) ) ? xml2array ( $node ) : $node;

    return $out;
}