<?php

//To on Error reporting 
error_reporting(E_ALL);
ini_set('display_errors', '1'); 
 
// Crawler ID 520  http://www.jokebat.be/

require_once("./../crawler_classes.php");
$crawler->use_cookies(true);

$startPages[STATUS_FORSELL] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.jokebat.be/showlist.aspx?pageId=9028&goal=0&cmMenu=4"
    ),
);

$startPages[STATUS_TORENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.jokebat.be/showlist.aspx?pageId=9029&goal=1&type=1,2,3,4,5,7&cmMenu=4",
    ),
);

/*
$html = file_get_contents("http://www.jokebat.be/showobject.aspx?pageid=9028&goal=0&cmmenu=4&objectid=1232&cp=1");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "forsell", TAG_TYPE => "house"), $html);
exit;
*/
CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        { 
		    $html = $crawler->request($page);
			processPage($crawler, $status, $type, $html);
			$totalPages = getTotalPages($html);
			if($totalPages>1){
			for($i=1;$i<$totalPages;$i++){
			$input=getInputs($html);
			$post='__EVENTTARGET=ctl00%24ContentPlaceHolder1%24ctl00%24dlBottomNext%24ctl00%24lnkPage&__VIEWSTATE='.urlencode($input['__VIEWSTATE']);
			$html=$crawler->request($page,$post);
			processPage($crawler, $status, $type, $html);		
				}	
				
			}
			
        }
    }
}

CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
   
	static $propertyCount=0;
    static $properties=array();
    $parser = new PageParser($html);

    $nodes = $parser->extract_regex('@([^<>"\']+objectid=[^<>"\']+)@',RETURN_TYPE_ARRAY);

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_NL] = "http://www.jokebat.be/" . $node;
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]) ;//$parser->regex("/objectid=(\d+)/", $property[TAG_UNIQUE_URL_NL]);
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}
   
    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;
	//debug($item);
        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
	//if($item["item"][TAG_UNIQUE_ID]==1471969854)
		 processItem($crawler, $item["item"], $crawler->request(str_replace('&amp;','&',$item["itemUrl"])));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

function getTotalPages($html)
{
    $parser = new PageParser($html);
	$total = $parser->extract_regex('@van[^<>"]+</TD>[^<>"]+<TD class="CurrentPage">([^<>"]+)</TD>@',RETURN_TYPE_NUMBER);

	return $total;
}



function processItem($crawler, $property, $html)
{
   $parser = new PageParser($html);
   
    $html=preg_replace('@(<style[^<>]*>[^<>]+</style>)@','',$html);
   
    $parser->deleteTags(array("script", "style"));
   
	if(CrawlerTool::skipWordFound($html)){echo 'property Skipped <br>'; return;}
    $property[TAG_TEXT_DESC_NL] = trim(preg_replace('@\s+@',' ',strip_tags(preg_replace('@(<style[^<>]*>[^<>]+</style>)@','',$parser->extract_regex('@Class="DescriptionEField">([^§]+?)</td>@')))));
    
    if(empty($property[TAG_TEXT_DESC_NL])) $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("td[@class = 'DescriptionEField']", RETURN_TYPE_TEXT_ALL);
    
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@width = '100%' and @cellspacing='2']", RETURN_TYPE_TEXT_ALL);
    
    if(empty($property[TAG_PLAIN_TEXT_ALL_NL])) $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@class = 'MainTable']", RETURN_TYPE_TEXT_ALL); 
    
    
    $property[TAG_PICTURES] = $parser->extract_regex('@picsID\[\d+\] = "([^<>"]+)"@', RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics[1] as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.jokebat.be/" . $pic);

        return $picUrls;
    });
	$street= $parser->extract_xpath("td[@class = 'DetailTitle' and @align='LEFT']");
		if(!empty($street)){
		$street=preg_replace('@,.+\Z@','',$street);
		$street=preg_replace('@\d{4} .+\Z@','',$street);
	    $property[TAG_STREET] = trim(preg_replace("/([^\d,]+).*?$/", "$1", strip_tags($street)));
        $property[TAG_NUMBER]  = trim(preg_replace("/^[^\d,]+([^\s,]*).*$/", "$1", strip_tags($street)));
		$property[TAG_BOX_NUMBER] = trim(strip_tags(preg_replace('/[^<>]*'.$property[TAG_NUMBER].'([^<>]*)$/','$1',$street)));
		}
    
    $parser->extract_xpath("td[@class = 'DetailTitle' and @align='LEFT']", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(\d{4})(.*)/", $text, $match))
        {
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
    });
           
    if(empty($property[TAG_CITY])){
	
	$parser->extract_xpath("td[@class = 'DetailTitle'] and [@align='LEFT']", RETURN_TYPE_TEXT, function($address) use(&$property)
	{
	    $addr = explode(' ',$address); 
	    $property[TAG_CITY] = trim($addr[count($addr)-1]);
	    $property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $addr[0] )); 
	    
	});
	
    }
	
	
	// get all the labels and there values
	 $Labels1=$parser->extract_regex('@<td width="30%"[^<>]+><B>([^<>]+)</B></td>@',RETURN_TYPE_ARRAY);
	$Values1=$parser->extract_regex('@<td align="Left" width="65%"[^<>]+>([^<>]+)</td>@',RETURN_TYPE_ARRAY);
	 
	$Labels2=$parser->extract_regex('@<td width="220px"[^<>]+"><strong>([^<>]+)</strong></td>@',RETURN_TYPE_ARRAY);
	$Values2=$parser->extract_regex('@<td class="DetailFieldValue">([^<>]+)</td>@',RETURN_TYPE_ARRAY);
	$Labels=array_merge($Labels1,$Labels2);
	$Values=array_merge($Values1,$Values2);
	if(count($Labels)<>count($Values)){
	echo 'Property skipped <br>';
	return;	
		}
	
	// debug($Labels); exit;
	foreach ($Labels as $index=>$label){
		
		$label =clearForLowerCase($label);
		$value = trim($Values[$index]);
		
		$attribute = getAttributes($label);
		if(!empty($attribute) ){
		    if(empty($property[$attribute]))
		    $property[$attribute] = GetExactAttrib($attribute,$value);
		}
		else
		    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
		
	}
		 
	 
	 // Most Important 
	if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
	$property['planning_proceeding'] = 0;
	
	
	if(!isset($property['planning_permission']) || empty($property['planning_permission']))
	$property['planning_permission'] = 0;
	
	
	if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
	$property['subdivision_permit'] = 0;
	 
	if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
	$property['most_recent_destination'] = 0;
	
	 
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));
	
	debug($property);
	if(empty( $property[TAG_CITY]))
	return;
	CrawlerTool::saveProperty($property);
	
}

function getInputs($html){
$parser=new PageParser($html);
$inputs=array();
$nodes=$parser->getNodes('input');
foreach($nodes as $node){
$inputs[$parser->getAttr($node,'name')]=$parser->getAttr($node,'value');	
	}	
return $inputs;	
	}

	
//function for print array
function debug($obj)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function to get html between two points in htm source
function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
}


	 foreach ($vars as $label => $value)
	{ 
		$attribute = getAttributes(clearForLowerCase($label));
		if(!empty($attribute) ){
		    if(empty($property[$attribute]))
		    $property[$attribute] = GetExactAttrib($attribute,$value);
		}
		else
		    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
		
	}
	
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
	 
	
function getAttributes($key, $language='nl'){ //String Function always return string

	$attributeTagsArray	= array('en' => array(	'pric' 			=>  TAG_PRICE,
							'constr'		=> TAG_CONSTRUCTION_YEAR,
							'ground'		=> TAG_SURFACE_GROUND,
							'living' 		=> TAG_SURFACE_LIVING_AREA,
							'bath'			=> TAG_BATHROOMS_TOTAL,
							'warm'			=> TAG_HEATING_EN,
							'heat'			=> TAG_HEATING_EN,
							'sewer'			=> TAG_CONNECTION_TO_SEWER,
							'telep'			=> TAG_TELEPHONE_CONNECTION,
							'intern'		=> TAG_INTERNET_CONNECTION,
							'permission'		=> TAG_PLANNING_PERMISSION,
							'subdivision'		=> TAG_SUBDIVISION_PERMIT,
							'electri'		=> TAG_METER_FOR_ELECTRICITY,
							'hall'			=> TAG_HALLS,
							'dining'		=> TAG_DININGS,
							'kitch'			=> TAG_KITCHENS,
							'laundr'		=> TAG_LAUNDRY_ROOMS,
							'dress'			=> TAG_DRESSING,
							'bed'			=> TAG_BEDROOMS_TOTAL,
							'room'			=> TAG_BEDROOMS_TOTAL,
							'park'			=> TAG_PARKINGS,
							'garage'		=> TAG_GARAGES_TOTAL,
							'type'			=> TAG_TYPE,
							'garden'		=> TAG_GARDEN_AVAILABLE,
							'floor'			=> TAG_AMOUNT_OF_FLOORS,
							'winter'		=> TAG_WINTERGARDENS,
							'furnish'		=> TAG_FURNISHED,
							'water'			=> TAG_CONNECTION_TO_WATER,
							'lift'			=> TAG_LIFT,
							'glaz'			=> TAG_DOUBLE_GLAZING,
							'terrac'		=> TAG_TERRACES,
							'fronts'		=> TAG_AMOUNT_OF_FACADES,
							'category'		=> TAG_TYPE,
							'free'			=> TAG_FREE_FROM_DATE,
							'habit'			=> TAG_SURFACE_LIVING_AREA,
							'plot'			=> TAG_SURFACE_GROUND,
							'shops'			=> TAG_DISTANCE_SHOPS,
							'schools'		=> TAG_DISTANCE_SCHOOL,
							'transport'		=> TAG_DISTANCE_PUBLIC_TRANSPORT,
							'shower'		=> TAG_SHOWERS_TOTAL,
							'stor'			=> TAG_STOREROOMS,
							'gas'			=> TAG_GAS_CONNECTION,
							'alarm'			=> TAG_ALARM,
							'security'		=> TAG_SECURITY_DOOR,
							'parlo'			=> TAG_PARLOPHONE,
							'video'			=> TAG_VIDEOPHONE,
							'elevat'		=> TAG_LIFT,
							'blind'			=> TAG_SUN_BLINDS,
							'renova'		=> TAG_RENOVATION_YEAR,
							'control'		=> TAG_ACCESS_SEMIVALID,
								),
					'nl' => array(	"prij" =>  TAG_PRICE,
							"type" =>  TAG_TYPE,
							"adres" =>  TAG_ADDRESS_VISIBLE,
							"bouwjaar" => TAG_CONSTRUCTION_YEAR,
							"grondopp" => TAG_SURFACE_GROUND, 
							"bewoonbare" => TAG_SURFACE_LIVING_AREA,
							"antal_kamer"=> TAG_BEDROOMS_TOTAL,
							"slaapkamer"=> TAG_BEDROOMS_TOTAL,
							"antal_badkam"=> TAG_BATHROOMS_TOTAL,
							"badkam"=> TAG_BATHROOMS_TOTAL,
							"epc_certi" => TAG_EPC_CERTIFICATE_NUMBER,
							"certificaatnr" => TAG_EPC_CERTIFICATE_NUMBER,
							"epc_ind" => TAG_EPC_VALUE,
							"epc_waa" => TAG_EPC_VALUE,
							"epc" => TAG_EPC_VALUE,
							"adastraal_inkomen" => TAG_KI,
							"adastraal" => TAG_KI,
							"inkomen" => TAG_KI,
							"ki" => TAG_KI,
							"adastrale_numme" => TAG_KI_INDEX,
							"verdieping" => TAG_AMOUNT_OF_FLOORS,
							"living" => TAG_SURFACE_LIVING_AREA,
							"renovatie" => TAG_RENOVATION_YEAR,
							"kadaster_sectie" => TAG_CADASTRAL_SECTION,
							"beschikbaar" => TAG_FREE_FROM,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"mail" => TAG_EMAIL,
							"winkels" => TAG_DISTANCE_SHOPS,
							"vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"overstromings" => TAG_FLOOD_INFORMATION_NL,
							"garage" => TAG_GARAGES_TOTAL,
							"toilet" => TAG_TOILETS_TOTAL,
							"parking" => TAG_PARKINGS_TOTAL,
							"gevels" => TAG_AMOUNT_OF_FACADES,
							"lasten" => TAG_COMMON_COSTS,
							"gas" => TAG_GAS_CONNECTION,
							"water" => TAG_CONNECTION_TO_WATER,
							"telefoon" => TAG_TELEPHONE,
							"lift" => TAG_LIFT,
							"gemeubeld" => TAG_FURNISHED,
							"tuin" => TAG_GARDEN_AVAILABLE,
							"haard" => TAG_OPEN_FIRE,
							"alarm" => TAG_ALARM,
							"parlofoon" => TAG_PARLOPHONE,
							"videofoon" => TAG_VIDEOPHONE,
							"breedte" => TAG_LOT_WIDTH,
							"diepte" => TAG_LOT_DEPTH,
							"constructie" => TAG_CONSTRUCTION_TYPE,
							"gevelbreedte" => TAG_FRONTAGE_WIDTH,
							"winkel" => TAG_HEATING_NL,
							"douche" => TAG_SHOWERS_TOTAL,
							"keuken" => TAG_KITCHEN_TYPE_NL,
							"ligging" => TAG_SUBDIVISION_PERMIT,
							"stedenbouwkundige" => TAG_PLANNING_PERMISSION,
							"terras" => TAG_TERRACES,
							"terrein" => TAG_SURFACE_GROUND,
							"scholen" => TAG_DISTANCE_SCHOOL,
							"oppervlakte" => TAG_SURFACE_LIVING_AREA,
							"eetkamer" => TAG_DININGS,
							"dressing" => TAG_DRESSINGS,
							"kelder" => TAG_CELLARS,
							"beroep" => TAG_FREE_PROFESSIONS,
							"berging" => TAG_STOREROOMS,
							"wasplaats" => TAG_LAUNDRY_ROOMS,
							"elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"beglazing" => TAG_DOUBLE_GLAZING,
							"verwarming" => TAG_HEATING_NL,
							"riolering" => TAG_CONNECTION_TO_SEWER,
							"olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"waterput" => TAG_WELL,
							"telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
							"toegangscontrole" => TAG_ACCESS_SEMIVALID,
							"computer" => TAG_INTERNET_CONNECTION,
							"nroerende_voorhef" => TAG_PROPERTY_TAX,
								),
                                        'fr' => array(	"prij" =>  TAG_PRICE,
							"Meuble" => TAG_FURNISHED,
							"facades" => TAG_AMOUNT_OF_FACADES,
							"nombre_de_chambre"=> TAG_BEDROOMS_TOTAL,
							"nombre_de_salle_de_bain"=> TAG_BATHROOMS_TOTAL,
							"jardin" => TAG_GARDEN_AVAILABLE,
							"garage" => TAG_GARAGES_TOTAL,
							"terras" => TAG_TERRACES,
							"parking" => TAG_PARKINGS_TOTAL,
							"habita" => TAG_SURFACE_LIVING_AREA,
							"terrain" => TAG_SURFACE_GROUND,
							"disponible" => TAG_FREE_FROM,
							"magasins" => TAG_DISTANCE_SHOPS,
							"transport" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"toilet" => TAG_TOILETS_TOTAL,
							"construction_annee" => TAG_CONSTRUCTION_YEAR,
							"renovation_annee" => TAG_RENOVATION_YEAR,
							"tages" => TAG_AMOUNT_OF_FLOORS,
							"alarm" => TAG_ALARM,
							"gaz" => TAG_GAS_CONNECTION,
							"eau" => TAG_CONNECTION_TO_WATER,
							"parlophone" => TAG_PARLOPHONE,
							"vitrage" => TAG_DOUBLE_GLAZING,
							"network" => TAG_INTERNET_CONNECTION,
							"douche" => TAG_SHOWERS_TOTAL,
							"caves" => TAG_CELLARS,
							"dressing" => TAG_DRESSINGS,
							"telephone" => TAG_TELEPHONE,
							"videophone" => TAG_VIDEOPHONE,
							"manger" => TAG_DININGS,
							"ecoles" => TAG_DISTANCE_SCHOOL,
							"sejour" => TAG_SURFACE_LIVING_AREA,
							"ascenseur" => TAG_LIFT,
							"largeur_du_lot" => TAG_LOT_WIDTH,
							"mazout" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"citerne" => TAG_WELL,
							"chauffage" => TAG_HEATING_FR,
							"electricite " => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"inondation" => TAG_FLOOD_INFORMATION_FR,
							"egouts" => TAG_CONNECTION_TO_SEWER,
							"cuisine" => TAG_KITCHEN_TYPE_FR,
							"construction_type" => TAG_CONSTRUCTION_TYPE,
							"chauffage" => TAG_HEATING_FR,
							"debarras" => TAG_STOREROOMS,
							"telephoniques" => TAG_TELEPHONE_CONNECTION,
							"dacces" => TAG_ACCESS_SEMIVALID,
							"lotissement" => TAG_SUBDIVISION_PERMIT,
							"batir" => TAG_PLANNING_PERMISSION,
							"cadastrales" => TAG_CADASTRAL_SECTION,
							"prix" => TAG_PRICE, 
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"mail" => TAG_EMAIL,
							"commun" => TAG_COMMON_COSTS,
							"feu" => TAG_OPEN_FIRE,
							"beaucoup_de_profondeur" => TAG_LOT_DEPTH,
							"facade_largeur" => TAG_FRONTAGE_WIDTH,
							"emission_co2" => TAG_CO2_EMISSION,
                                                     ),
				);
	
	$keys = array_keys($attributeTagsArray[$language]); // Returning Keys
	$key = clearForLowerCase($key); // Converting to lower case
	
	foreach($keys as $k){
	    
		   $check = stripos("X$key","$k");
		   if(!empty($check))
		   return $attributeTagsArray[$language][$k];
	    }
	 
	return '';	 
}

function GetExactAttrib($key,$val){
 
    $a = array();
    
    switch($key){
    case TAG_PROPERTY_TAX:
        return toNumber($val);
        break;	
    case TAG_PRICE:
        return toNumber($val);
        break;
    case TAG_CONSTRUCTION_YEAR:
        return toYear($val);
        break;
    case TAG_RENOVATION_YEAR:
        return toYear($val);
        break;
     case TAG_FREE_FROM_DATE:
        return toUnixTimestamp($val);
        break;
    case TAG_KI:
        return toNumber($val);
        break;
    case TAG_EPC_VALUE:
        return toEpc($val);
        break;
    case TAG_EPC_CERTIFICATE_NUMBER:
        return toNumber($val);
        break;
    case TAG_SURFACE_LIVING_AREA:
       return toNumber($val);
       break;
    case TAG_SURFACE_GROUND:
       return toNumber($val);
       break;

    case TAG_GARDEN_AVAILABLE:
       return ($val=='Ja') ? 1 : 0;
    break;
    
    case TAG_TERRACES:
       return $a[] = toNumber($val); 
    break;
    
    default:
	
	$val = trim($val);
	if($val=='Ja' || $val=='Nee' || $val=='Neen')
        return ($val=='Ja') ? 1 : 0;

	else{

		if(stripos($key,"_permission") !== false)
	    return ($val=='Ja') ? 1 : 0;
		
		if(stripos($key,"_visible") !== false)
	    return ($val=='Ja') ? 1 : 0;

	    if(stripos($key,"_nl") !== false)
	    return $val;
	    
	    if(stripos($key,"_fr") !== false)
	    return $val;
	
	    if(stripos($key,"_en") !== false)
	    return $val;
	    else
	    return toNumber($val);
	    
	}
	
    break;
     
    }
}


/// Basic checking for 
function clearForLowerCase($str = ''){ 
    $str = strtolower(str_replace(' ','_',$str)); 
    $str = trim(strip_tags($str)); 
    //$str = preg_replace('![^a-z0-9_\-\. ]!','',$str); 
    // $str = trim(preg_replace('!nbsp!','',$str)); 
    $str = trim(preg_replace('!ja,!','',$str));
    //$str = trim(preg_replace('!,!','',$str));
    $str = trim(normalize_str($str));
    return $str ;
 
}

function toNumber($str)
{
    ///return $str;
	$value = 0;
    $str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
    $str = preg_replace("/,(\d{3})|\.(\d{3})/",  "$1$2", $str);
    if(preg_match("/(-?\d+)/", $str, $match)) $value = intval($match[1]);
    
    if(empty($value))
    return 0;
    else
    return $value;
}

function toUnixTimestamp($str)
{
	return strtotime($str);
}

function toEpc($str){
	$epc = toNumber($str);
	if($epc > 0 && $epc <= 999) return $epc;
}

function toYear($str){
	$year = toNumber($str);
	if($year > 0 && strlen($year) == 4) return $year;
}

function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");
        foreach($invalid as $k => $v){
            $str = str_replace($k, $v, $str); //array_values($invalid)
        }

        return $str;
    }

