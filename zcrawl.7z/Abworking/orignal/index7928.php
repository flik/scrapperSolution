<?php

/* ============================= CONFIG ============================= */

// Crawler ID 7928

require_once("../crawler_classes.php");


$startPages[STATUS_FORSALE] = array
(
    TYPE_HOUSE        =>  array
    (
        "http://www.unicas.be/NL/woningen-overview-1.html",
        "http://www.unicas.be/NL/renovaties-overview-1.html"

    ),
    TYPE_APARTMENT    =>  array
    (
        "http://www.unicas.be/NL/appartementen-overview-1.html"
    ),
);


/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsell", "house", $html);
exit;*/



/*$html = file_get_contents("p-1.htm");
$pages = getPages($html);

echo "<pre>";
print_r($pages);
echo "</pre>";

exit;*/



/*$propertyCount = 0;
$properties = array();
$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "forsell", TAG_TYPE => "house"), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();
$propertyCount = 0;
$properties = array();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "UNICAS nv";
$office[TAG_OFFICE_URL] = "http://www.unicas.be";
$office[TAG_STREET] = "Kerkstraat";
$office[TAG_NUMBER] = "38";
$office[TAG_ZIP] = "1755";
$office[TAG_CITY] = "Gooik";
$office[TAG_TELEPHONE] = "054300301";
$office[TAG_FAX] = "054568027";
$office[TAG_EMAIL] = "info@unicas.be";

CrawlerTool::saveOffice($office);

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);

            $nextPages = getPages($html);
            foreach($nextPages as $nextPage)
            {
                $html = $crawler->request($nextPage);
                processPage($crawler, $status, $type, $html);
            }
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    global $propertyCount;
    global $properties;

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("td[@class = 'projectthumbpicture']/a");

    $items = array();
    foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_NL] = "http://www.unicas.be/NL/" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
    }   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Get a list of next pages
 */
function getPages($html)
{
    $parser = new PageParser($html);

    $pages = array();
    $nodes = $parser->getNodes("td[@class  = 'pagenumbering']/a");

    if(!empty($nodes))
    {
        foreach($nodes as $node)
        {
            $pages[] = "http://www.unicas.be/NL/" . $parser->getAttr($node, "href");
        }
    }

    $pages = array_unique($pages);
    array_shift($pages); // delete first array item

    return $pages;
}


/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    // check for project, if this is a project page then go processing the project
    $nodes = $parser->getNodes("td[@class = 'projectextratable']/table/tr[position() > 1 and not(@class)]");
    if($nodes->length > 0)
    {
        processProject($crawler, $parser, $property);
        return;
    }

    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("td[@class = 'projectextra']");
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@class = 'containercontact']", RETURN_TYPE_TEXT_ALL);
    if(stripos($property[TAG_PLAIN_TEXT_ALL_NL], "verkocht") !== false) return;
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'shadowbox[LARGE]']", RETURN_TYPE_ARRAY, function($pics) use ($property)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL =>  str_replace("project.html", "", $property[TAG_UNIQUE_URL_NL]) . $pic);

        return $picUrls;
    });

    $parser->extract_xpath("td[@class = 'containercontactframetitle']", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(.*)\s*-\s*(.*)/", $text, $match))
        {
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[1]));
            CrawlerTool::parseAddress($match[2], $property);
        }
    });
    if(stripos($property[TAG_CITY], "HAMME") !== false) $property[TAG_ZIP] = "9220";
    $property[TAG_IS_NEW_CONSTRUCTION] = 1;

    // get document files
    $nodes = $parser->getNodes("td[@class = 'projectextradownload']/a");
    foreach($nodes as $node)
    {
        $fileUrl = str_replace("project.html", "", $property[TAG_UNIQUE_URL_NL]) . $parser->getAttr($node, "href");
        $fileTitle = $parser->getText($parser->getNode("text()[last()]", $node));
        $property[TAG_FILES][] = array(TAG_FILE_URL_NL => $fileUrl, TAG_FILE_TITLE_NL => $fileTitle);
    }

    //CrawlerTool::test($property);

    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}

function processProject($crawler, $parser, $property)
{
    global $propertyCount;
    global $properties;

    $project = array();
    $project[TAG_PROJECT_ID] = $property[TAG_UNIQUE_ID];
    $project[TAG_UNIQUE_URL_NL] = $property[TAG_UNIQUE_URL_NL];
    $project[TAG_TEXT_DESC_NL] = $parser->extract_xpath("td[@class = 'projectextra']");
    $project[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'shadowbox[LARGE]']", RETURN_TYPE_ARRAY, function($pics) use ($project)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL =>  str_replace("project.html", "", $project[TAG_UNIQUE_URL_NL]) . $pic);

        return $picUrls;
    });

    $parser->extract_xpath("td[@class = 'containercontactframetitle']", RETURN_TYPE_TEXT, function($text) use(&$project)
    {
        if(preg_match("/(.*)\s*-\s*(.*)/", $text, $match))
        {
            $project[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[1]));
            CrawlerTool::parseAddress($match[2], $project);
        }
    });
    if(stripos($project[TAG_CITY], "HAMME") !== false) $project[TAG_ZIP] = "9220";

    $nodes = $parser->getNodes("td[@class = 'projectextradownload']/a");
    foreach($nodes as $node)
    {
        $fileUrl = str_replace("project.html", "", $project[TAG_UNIQUE_URL_NL]) . $parser->getAttr($node, "href");
        $fileTitle = $parser->getText($parser->getNode("text()[last()]", $node));
        $project[TAG_FILES][] = array(TAG_FILE_URL_NL => $fileUrl, TAG_FILE_TITLE_NL => $fileTitle);
    }

    $nodes = $parser->getNodes("td[@class = 'projectextratable']/table/tr[position() > 1]");
    $project[TAG_SOLD_PERCENTAGE_MAX] = $nodes->length;

    $nodes = $parser->getNodes("td[@class = 'projectextratable']/table/tr[position() > 1 and not(@class)]");
    $project[TAG_SOLD_PERCENTAGE_VALUE] = $project[TAG_SOLD_PERCENTAGE_MAX] - $nodes->length;

    $count = 0;
    foreach($nodes as $node)
    {
        $innerProperty = array();
        $innerProperty[TAG_PROJECT_ID] = $project[TAG_PROJECT_ID];
        $innerProperty[TAG_UNIQUE_ID] =  $project[TAG_PROJECT_ID] . "-" . CrawlerTool::generateId($parser->getText($node));
        $innerProperty[TAG_UNIQUE_URL_NL] = $project[TAG_UNIQUE_URL_NL];
        $innerProperty[TAG_STATUS] = $property[TAG_STATUS];
        $innerProperty[TAG_TEXT_DESC_NL] = $project[TAG_TEXT_DESC_NL];
        $innerProperty[TAG_CITY] = $project[TAG_CITY];
        $innerProperty[TAG_ZIP] = $project[TAG_ZIP];
        $innerProperty[TAG_STREET] = $project[TAG_STREET];
        if(!empty($project[TAG_NUMBER])) $innerProperty[TAG_NUMBER] = $project[TAG_NUMBER];
        if(!empty($project[TAG_BOX_NUMBER])) $innerProperty[TAG_BOX_NUMBER] = $project[TAG_BOX_NUMBER];
        $innerProperty[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("td[1]", RETURN_TYPE_TEXT, null, $node));
        if(empty($innerProperty[TAG_TYPE])) $innerProperty[TAG_TYPE] = $property[TAG_TYPE];
        $innerProperty[TAG_TEXT_TITLE_NL] = $parser->extract_xpath("td[1]", RETURN_TYPE_TEXT, null, $node);
        $fileUrl = $parser->extract_xpath("td[last() - 1]/a/@href", RETURN_TYPE_TEXT, null, $node);
        if(!empty($fileUrl)) $innerProperty[TAG_FILES][] = array(TAG_FILE_URL_NL => str_replace("project.html", "", $project[TAG_UNIQUE_URL_NL]) . $fileUrl);
        $innerProperty[TAG_SURFACE_GROUND] = $parser->extract_xpath("td[last() - 2]", RETURN_TYPE_NUMBER, null, $node);
        if($property[TAG_TYPE] === TYPE_APARTMENT)
        {
            $innerProperty[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("td[2]", RETURN_TYPE_NUMBER, null, $node);
            $innerProperty[TAG_FLOOR] = $parser->extract_xpath("td[3]", RETURN_TYPE_NUMBER, null, $node);
        }

        if(in_array($innerProperty[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $innerProperty[TAG_UNIQUE_ID];
        $count += 1;

        // process item to obtain detail information
        if($count > 1) echo "--------- Processing property #$propertyCount ...";
        CrawlerTool::saveProperty($innerProperty);
        if($count < $nodes->length) echo "--------- Completed<br />";

        $propertyCount += 1;
    }

    if($count > 0) CrawlerTool::saveProject($project);
}



