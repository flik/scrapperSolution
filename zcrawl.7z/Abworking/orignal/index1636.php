<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1204

require_once("../crawler_classes.php");

$crawler->enable_delay_between_requests(5, 10);
$crawler->use_cookies(true);

$startPages[STATUS_FORSALE] = array
(
	"http://www.activo.be/nl/aanbod-te-koop/t/1/fabriek"=>TYPE_COMMERCIAL,
	"http://www.activo.be/nl/aanbod-te-koop/t/4/magazijn"=>TYPE_COMMERCIAL,
	"http://www.activo.be/nl/aanbod-te-koop/t/5/winkel"=>TYPE_COMMERCIAL,
	"http://www.activo.be/nl/aanbod-te-koop/t/3/kantoor"=>TYPE_COMMERCIAL,
	"http://www.activo.be/nl/aanbod-te-koop/t/2/grond"=>TYPE_COMMERCIAL,
);
$startPages[STATUS_TORENT] = array
(
	"http://www.activo.be/nl/aanbod-te-huur/t/1/fabriek"=>TYPE_COMMERCIAL,
	"http://www.activo.be/nl/aanbod-te-huur/t/4/magazijn"=>TYPE_COMMERCIAL,
	"http://www.activo.be/nl/aanbod-te-huur/t/5/winkel"=>TYPE_COMMERCIAL,
	"http://www.activo.be/nl/aanbod-te-huur/t/3/kantoor"=>TYPE_COMMERCIAL,
	"http://www.activo.be/nl/aanbod-te-huur/t/2/grond"=>TYPE_COMMERCIAL,

);
/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsell", "house", $html);
exit;*/



/*$html = file_get_contents("p-1.htm");
$pages = getPages($html);

echo "<pre>";
print_r($pages);
echo "</pre>";

exit;*/



/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_NL => "", TAG_STATUS => "forsell", TAG_TYPE => "house"), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();
foreach($startPages as $status => $types)
{
	foreach($types as $page => $type)
	{
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);

    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

/**
 * Get a list of next pages
 */
function getPageList($html) {
	$dom = new DOMDocument();
	$dom->preserveWhiteSpace = false;
	@$dom->loadHTML($html);
	$xpath = new DOMXPath($dom);
	$parser = new PageParser($html);

	$pageList = array();
	$nodes = $parser->getNodes("a[contains(@href, '&OxyPage=')]");

	if($nodes) {
		foreach($nodes as $node) {
			$pageList[] = "http://www.immo-tt.be/" . str_replace(" ", "%20", $parser->getAttr($node, "href"));
		}
	}

	// free memory used
	unset($dom);
	unset($xpath);

	return array_unique($pageList);
}


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);
    $items = array();
    $parser = new PageParser($html);

    $pattern  = "href='([^<>]+)' class='item'>";
    $property = array();
	preg_match_all ( "/" . $pattern . "/is", $html, $items_matches, PREG_SET_ORDER);
	
    foreach ($items_matches as $match) {

        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;

        if (stristr($match[0], 'verkocht')) {
            $property[TAG_STATUS]="sold";
        }
        if (stristr($match[0], 'verhuurd')) {
            $property[TAG_STATUS]="rented";
        }
		$property[TAG_UNIQUE_URL_NL]=  'http://www.activo.be'.html_entity_decode($match[1]);
        $property[TAG_UNIQUE_ID] = preg_replace("/.*p\/|\/\d+.*/", "\$1", $match[1]);
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

function getUniqueId($url) {
	preg_match("/ID=(\d+)/", $url, $match);
	if($match) return $match[1];
}


/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $html=$crawler->request($property[TAG_UNIQUE_URL_NL]);
    $parser = new PageParser($html);
    $property[TAG_PLAIN_TEXT_ALL_NL]=getTextAll($html);

    $pattern = "Beschrijving<\/div>\s+<div class='text'>(.+?)<\/div>";
    preg_match ( "/" . $pattern . "/is", $html, $shortdescr);
	if (isset($shortdescr[1])) {

        $property[TAG_TEXT_SHORT_DESC_NL]=trim((trim (preg_replace("/(&nbsp;|\n|\r|\s+)/s", " ", ( strip_tags ($shortdescr[1]))))));
    }

	$pattern = "Adres<\/div>\s+<div class='text'>(.+?)<br \/>(.+?)<\/div>";
	preg_match ( "/" . $pattern . "/is", $html, $unique_id);
	if (isset($unique_id[1])) {
		$adres= trim(substr (trim (preg_replace("/(&nbsp;|\n|\r|\s+|,)/s", " ", ( strip_tags ($unique_id[1])))), 0, 255));
		$property[TAG_STREET]=preg_replace('/[0-9,.]/','',$adres);
		$property[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);

		$property[TAG_ZIP] = preg_replace("/\D/", "", strip_tags($unique_id[2]));
	    $property[TAG_CITY] = trim(preg_replace("/\(.+?\)|\d|&nbsp;|\.|- /", "", strip_tags($unique_id[2])));
	}
    if(strlen($property[TAG_ZIP]) > 4) return;
	$pattern = "([^<>']+\(Small\).jpg)' \/><\/a>";
	preg_match_all ( "/" . $pattern . "/is", $html, $pic_url);
	if (isset($pic_url[1])) {
	   foreach($pic_url[1] as $picture){
		$picUrls[]  = array(TAG_PICTURE_URL =>'http://www.activo.be'.trim($picture));
        }
	}
	$property[TAG_PICTURES]=$picUrls;


    CrawlerTool::saveProperty($property);

}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function get_short_description($html, $length=255) {
    return trim(substr(preg_replace('@\s+@', ' ', get_text($html)), 0, $length));
}
function get_text($html) {
    $search = array(
        '@<style[^>]*?>.*?</style>@siU',
        '@<script[^>]*?>.*?</script>@si',
        '@<[\/\!]*?[^<>]*?>@si',
        '@<![\s\S]*?--[ \t\n\r]*>@'
    );
    $text = preg_replace($search, '', $html);
    return trim(html_entity_decode(preg_replace("/\s+\n/s", "\n", strip_tags($text))));
}
function getTextAll($html) {

    $search = array(
        '@<style[^>]*?>.*?</style>@siU',
        '@<script[^>]*?>.*?</script>@si',
        '@<[\/\!]*?[^<>]*?>@si',
        '@<![\s\S]*?--[ \t\n\r]*>@'
    );

    $text = preg_replace($search, '', $html);
    return trim(html_entity_decode(preg_replace("/\s+\n/s", "\n", strip_tags($text))));
    //return trim(html_entity_decode(strip_tags( $text )));
}
