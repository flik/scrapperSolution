<?php

require_once("./../crawler_classes.php");
//$crawler->set_script_dir(realpath(dirname(__FILE__)).'/');

//$crawler->enable_delay_between_requests(5,15);
//$crawler->use_cookies(true);
//$crawler->clean_cookies();
//$crawler->use_gzip(false);

$startPages[STATUS_FORSALE] = array
(

    "http://www.hylebos.be/Kopen/" =>'',



);
$startPages[STATUS_FORRENT] = array
(
    'http://www.hylebos.be/Huren/'=>'',

);

CrawlerTool::startXML();


foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
		debugx($page_url);
	    $html = $crawler->request($page_url);
        $parser = new PageParser($html);
	    processPage($crawler, $status, $type, $html);
		$nextPage = getNextPage($html,$crawler);
		unset($html);

		while(strlen($nextPage) > 0) {
			
			debugx($nextPage); 
			echo "Downloading page content..." . "<br />";
			$html = $crawler->request($nextPage);
			echo "Complete downloading page content..." . "<br />";

			// process page content
			echo "Processing page ..." . "<br />";
			processPage($crawler, $status, $type, $html);
			echo "Complete processing page ..." . "<br /><br />";

			$nextPage = getNextPage($html,$crawler);
			unset($html);
		}
	}

}


CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;

    static $properties = array();
    $parser = new PageParser($html);

    $count=0;
 	$nodes = $parser->getNodes("div[@class = 'property-info property-line' and not(img[contains(@src, 'sold') or contains(@src, 'rent')])]/descendant::a[@class = 'morinfo']");

 	$items = array();
 	foreach($nodes as $node)
	{
	    $property[TAG_STATUS] = $status;
		echo $property[TAG_UNIQUE_URL_NL]      = "http://www.hylebos.be".$parser->getAttr($node, "href");
		echo $property[TAG_UNIQUE_ID]=getUniqueId($property[TAG_UNIQUE_URL_NL]);
		$count=$count+1;
		$propertyCount += 1;
		flush();
		ob_flush();
        //if($property[TAG_UNIQUE_ID] == "957" || $property[TAG_UNIQUE_ID] == "1363" || $property[TAG_UNIQUE_ID] == "1364"){
            // process item to obtain detail information
            echo "--------- Processing property #$propertyCount ...";
            processItem($crawler,$property,$type,$status);
            echo "--------- Completed<br />";
        //}

	}


}

function getUniqueId($url) {
	preg_match("/\/(\d+)\//", $url, $match);
	if($match) return $match[1];
}

/**
 *  Get next page
 */
function getNextPage($html,$crawler) {
    $parser = new PageParser($html);
    $nextPage="";

	$node = $parser->getNode("a[contains(text(), 'Volgende')]");
	if($node) $nextPage =  "http://www.hylebos.be" .$parser->getAttr($node, "href");

	return $nextPage;
}


function processItem($crawler, $property ,$type)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_NL]);

    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    $features = $parser->extract_xpath("div[label[contains(text(), 'Aansluitingen')]]");
	$text = $parser->extract_xpath("div[label[contains(text(), 'Adres:')]]");
	if($text) {
		preg_match("/(.*)(\d{4})\s(.*)/", $text, $match);
		if($match) {
            $adres = trim($match[1]);
			$property[TAG_ZIP] = $match[2];
			$property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));

            $property[TAG_STREET]=(preg_match('/(.*?)\d/s',$adres,$res)) ? trim(strip_tags(($res[1]))) : '';
			preg_match("/bus (\d+|\d+[.]\d+)$/", $adres, $match);
			if($match) {

					$property[TAG_BOX_NUMBER]=trim(preg_replace("/[a-zA-Z,]/", "", $match[1]));
			}

			preg_match("/ (\d+) bus/", $adres, $match);
			if($match) {

			    $property[TAG_NUMBER]=trim(preg_replace("/[a-zA-Z]/", "", $match[1]));
			}

			if(empty($property[TAG_NUMBER])) $property[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);

		}
	}

    $property[TAG_PICTURES] = $parser->extract_xpath("div[contains(@class, 'image-thumb-holder')]/img", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic)
        {
            if(!empty($pic)) $picUrls[] = array(TAG_PICTURE_URL => "http://www.hylebos.be" . str_replace("thumb", "large", $pic));
        }
        return $picUrls;
    });

    $property[TAG_PRICE] = $parser->extract_xpath("div[label[contains(text(), 'Prijs') or contains(text(), 'prijs')]]", RETURN_TYPE_NUMBER);
    $property[TAG_PLAIN_TEXT_ALL_NL] =  $parser->extract_xpath("div[@id = 'content']");
    $property[TAG_TEXT_DESC_NL] =  preg_match('/<h3>Omschrijving<\/h3>(.*?)<\/div><\/div>/si',$html,$res) ? strip_tags($res[1]) : '';
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("div[@id = 'h3']"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL], 999);

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h3")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));


    $html1=preg_replace('/<div class="sublist">|<div class="col full">/','',$html);

	preg_match_all('!<label class=\'plus\'>([^<>]+)</label><span>(.+?)</span></div>!s',$html1,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = strip_tags(trim($arr[1]));
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$vars[$arr[1]] = strip_tags($arr[2]);
		#echo "<br>";
	}

    if(strpos($html,"VERHUURD") || strpos($html,"verhuurd")){
        $property[TAG_STATUS] = "rented"; return;
    }
    if(strpos($html,"VERKOCHT") || strpos($html,"verkocht")){
        $property[TAG_STATUS] = "sold"; return;
    }

    if (isset($vars['adres'])) {unset($vars['adres']);}
    if (isset($vars['oppervlakte ruimtes'])) {unset($vars['oppervlakte ruimtes']);}
    if (isset($vars['beschrijving interieur'])) {unset($vars['beschrijving interieur']);}
    if (isset($vars['aantal slaapkamers'])) {unset($vars['aantal slaapkamers']);}
    if (isset($vars['aansluitingen'])) {unset($vars['aansluitingen']);}


    $property[TAG_PROPERTY_TAX] = get_var($vars,'algemene kosten','!(\d+)!');
    $property[TAG_COMMON_COSTS] = get_var($vars,'provisie','!(\d+)!');
    if(empty($property[TAG_PRICE])) $property[TAG_PRICE] = CrawlerTool::toNumber(get_var($vars,"prijs"));
    
/*
	$property[TAG_MOST_RECENT_DESTINATION]=(get_var($vars,'planologische bestemming'));
    $property[TAG_PLANNING_PERMISSION] = CrawlerTool::contains(get_var($vars,'stedenbouwkundige vergunning'),"Geen");
    $property[TAG_MOST_RECENT_DESTINATION]=(get_var($vars,'bestemming'));
    $property[TAG_HAS_PROCEEDING] = CrawlerTool::contains(get_var($vars,'dagvaardingen'),"Geen");
    $property[TAG_PRIORITY_PURCHASE] = CrawlerTool::contains(get_var($vars,'voorkooprecht'),"Geen");
*/

    $property[TAG_CONSTRUCTION_TYPE]       = CrawlerTool::getConstructionType(get_var($vars,'type bebouwing'));
    
    $property[TAG_CONSTRUCTION_YEAR]       = get_var($vars,'bouwjaar','!(\d{4})!');
    
    $property[TAG_CONSTRUCTION_YEAR]       = get_var($vars,'bouwjaar','!(\d{4})!');
    $property[TAG_RENOVATION_YEAR]         = get_var($vars,'vernieuwd','!(\d{4})!');
    $property[TAG_FREE_FROM_DATE] = CrawlerTool::toUnixTimestamp(get_var($vars,'vrij vanaf'));
    $property[TAG_KI]                      = str_replace('.','',get_var($vars,'kadastraal inkomen','![^<>0-9]*([0-9.]+)!'));
	$terrace                  = get_var($vars,'terras') === "ja"? 1: 0;;
    if(!empty($terrace)) $property[TAG_TERRACES][TAG_TOTAL_AMOUNT]=$terrace;
    $property[TAG_EPC_VALUE]              = get_var($vars,'epc-waarde','!(\d+)!');
    $property[TAG_SURFACE_LIVING_AREA]     = get_var($vars,'bewoonbare oppervlakte','!(\d+)!');
    $property[TAG_SURFACE_GROUND]          = get_var($vars,'totale oppervlakte grond','!(\d+)!');
    $property[TAG_LOT_WIDTH] = get_var($vars,'breedte grond straat');
    $property[TAG_LOT_DEPTH] = get_var($vars,'diepte terrein');
        $property[TAG_DEPTH_FLOOR]               = get_var($vars,'diepte verdieping','!(\d+)!');

    $floor                   = get_var($vars,'verdieping','!(\d+)!');
    if(!empty($floor)) $property[TAG_FLOOR]=$floor;
    $property[TAG_FURNISHED] =  CrawlerTool::contains(get_var($vars,'gemeubeld'),'ja');
    $property[TAG_SURFACE_CONSTRUCTION] = get_var($vars,'bruto oppervlakte','!(\d+)!');
    $property[TAG_FRONTAGE_WIDTH]          = str_replace(',','.',get_var($vars,'breedte gevel','!([0-9,]+)!'));
	$parser->extract_xpath("div[contains(text(), 'Slaapkamer')]/following-sibling::div[1]", RETURN_TYPE_ARRAY, function($arr) use(&$property)
	{
		$bedrooms = array();
		foreach($arr as $count=>$surface)
		{
			echo $surface = CrawlerTool::toNumber($surface);
			$bedroom = array(TAG_BEDROOM_SURFACE => $surface, TAG_BEDROOM_DESC_NL => "slaapkamer " . ($count + 1) . " oppervlakte (m²)");
			$bedrooms[] = $bedroom;
		}

		if(!empty($bedrooms)) $property[TAG_BEDROOMS] = $bedrooms;
});

    $livings=get_var($vars,'woonkamer');
    $bedrooms=get_var($vars,'aantal badkamers');
    $Garages=get_var($vars,'aantal garages');
    $bathrooms=get_var($vars,'aantal badkamers');
    $toilets=get_var($vars,'aantal toiletten');
    $kitchens=get_var($vars,'keuken');
    $storages=get_var($vars,'berging');
    $terraces=get_var($vars,'terras');
    $cellars=get_var($vars,'kelder');
    $wintergardens=get_var($vars,'veranda','!(\d+)!');
    $studies=get_var($vars,'kantoor','!(\d+)!');
    $freepossesions=get_var($vars,'praktijkruimte');
    $attics=get_var($vars,'zolder');
    $rooms=get_var($vars,'aantal kamers');
    if(!empty($rooms)) $room=$parser->regex("/(\d)$/", $rooms);

    if(!empty($attics)) $attictotal=$parser->regex("/(\d)$/", $attics);
    if(!empty($livings)) $livingtotal=$parser->regex("/(\d)$/", $livings);
    if(!empty($Garages)) $garagetotal=$parser->regex("/(\d)$/", $Garages);
    if(!empty($bathrooms)) $bathroomtotal=$parser->regex("/(\d)$/", $bathrooms);
    if(!empty($toilets)) $toilettotal=$parser->regex("/(\d)$/", $toilets);
    if(!empty($kitchens)) $kitchentotal=$parser->regex("/(\d)$/", $kitchens);
    if(!empty($storages)) $storagetotal=$parser->regex("/(\d)$/", $storages);
    if(!empty($terraces)) $terracetotal=$parser->regex("/(\d)$/", $terraces);
    if(!empty($cellars)) $cellartotal=$parser->regex("/(\d)$/", $cellars);
    if(!empty($wintergardens)) $wintergardentotal=$parser->regex("/(\d)$/", $wintergardens);
    if(!empty($studies)) $studytotal=$parser->regex("/(\d)$/", $studies);
    if(!empty($freepossesions)) $freepossesiontotal=$parser->regex("/(\d)$/", $freepossesions);

    if(!empty($attics)) $atticsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $attics);
    if(!empty($livings)) $livingsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $livings);
    if(!empty($Garages)) $garagesurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $Garages);
    if(!empty($bathrooms)) $bathroomsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $bathrooms);
    if(!empty($toilets)) $toiletsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $toilets);
    if(!empty($kitchens)) $kitchensurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $kitchens);
    if(!empty($storages)) $storagesurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $storages);
    if(!empty($terraces)) $terracesurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $terraces);
    if(!empty($cellars)) $cellarsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $cellars);
    if(!empty($wintergardens)) $wintergardensurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $wintergardens);
    if(!empty($studies)) $studysurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $studies);
    if(!empty($freepossesions)) $freepossesionsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $freepossesions);


  #  if(empty($terracesurface)) $terracesurface=$parser->extract_xpath("Terras opervlakte",RETURN_TYPE_NUMBER);
  #  if(empty($cellarsurface)) $cellarsurface=$parser->extract_xpath("Kelder opp",RETURN_TYPE_NUMBER);

    $atticdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $attics);

    $garagedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $Garages);
    $bathroomdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $bathrooms);
    $toiletdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $toilets);
    $kitchendesc=$parser->regex("/([a-zA-Z_-\s]*)/", $kitchens);
    $storagedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $storages);
    $terracedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $terraces);
    $cellardesc=$parser->regex("/([a-zA-Z_-\s]*)/", $cellars);
    $livingdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $livings);
    $floorplandesc=$parser->regex("/([a-zA-Z_-\s]*)/", $parser->extract_xpath("Grondplannen"));
    $wintergardendesc=$parser->regex("/([a-zA-Z_-\s]*)/", $wintergardens);
    $studydesc=$parser->regex("/([a-zA-Z_-\s]*)/", $studies);
    $freepossesiondesc=$parser->regex("/([a-zA-Z_-\s]*)/", $freepossesions);


    $wintergarden = array();
    $totalwintergardens = array();
    if(!empty($wintergardendesc)) 		 $wintergarden[TAG_WINTERGARDEN_DESC_NL]=$wintergardendesc;
    if(!empty($wintergardensurface)) 		 $wintergarden[TAG_WINTERGARDEN_SURFACE]=$wintergardensurface;
    if(!empty($wintergarden)) $totalwintergardens[] = $wintergarden;
    if(!empty($totalwintergardens)) $property[TAG_WINTERGARDENS] = $totalwintergardens;

    $freepossesion = array();
    $totalfreepossesions = array();
    if(!empty($freepossesiondesc)) 		 $freepossesion[TAG_FREE_PROFESSION_DESC_NL]=$freepossesiondesc;
    if(!empty($freepossesionsurface)) 		 $freepossesion[TAG_FREE_PROFESSION_SURFACE]=$freepossesionsurface;
    if(!empty($freepossesion)) $totalfreepossesions[] = $freepossesion;
    if(!empty($totalfreepossesions)) $property[TAG_FREE_PROFESSIONS] = $totalfreepossesions;

    $study = array();
    $totalstudys = array();
    if(!empty($studydesc)) 		 $study[TAG_STUDY_DESC_NL]=$studydesc;
    if(!empty($studysurface)) 		 $study[TAG_STUDY_SURFACE]=$studysurface;
    if(!empty($study)) $totalstudys[] = $study;
    if(!empty($totalstudys)) $property[TAG_STUDIES] = $totalstudys;


    $bathroom = array();
    $totalbathrooms = array();
    if(!empty($bathroomdesc)) 		 $bathroom[TAG_BATHROOM_DESC_NL]=$bathroomdesc;
    if(!empty($bathroomsurface)) 		 $bathroom[TAG_BATHROOM_SURFACE]=$bathroomsurface;
    if(!empty($bathroom)) $totalbathrooms[] = $bathroom;
    if(!empty($totalbathrooms)) $property[TAG_BATHROOMS] = $totalbathrooms;

    $attic = array();
    $totalattics = array();
    if(!empty($atticdesc)) 		 $bathroom[TAG_ATTIC_DESC_NL]=$atticdesc;
    if(!empty($atticsurface)) 		 $bathroom[TAG_ATTIC_SURFACE]=$atticsurface;
    if(!empty($attic)) $totalattics[] = $attic;
    if(!empty($totalattics)) $property[TAG_ATTICS] = $totalattics;

    $cellar = array();
    $totalcellars = array();
    if(!empty($cellardesc)) 		 $cellar[TAG_CELLAR_DESC_NL]=$cellardesc;
    if(!empty($cellarsurface)) 		 $cellar[TAG_CELLAR_SURFACE]=$cellarsurface;
    if(!empty($cellar)) $totalcellars[] = $cellar;
    if(!empty($totalcellars)) $property[TAG_CELLARS] = $totalcellars;

    $toilet = array();
    $totaltoilets = array();
    if(!empty($toiletdesc)) 		 $toilet[TAG_TOILET_DESC_NL]=$toiletdesc;
    if(!empty($toiletsurface)) 		 $toilet[TAG_TOILET_SURFACE]=$toiletsurface;
    if(!empty($toilet)) $totaltoilets[] = $toilet;
    if(!empty($totaltoilets)) $property[TAG_TOILETS] = $totaltoilets;

    $garage = array();
    $totalgarages = array();
    if(!empty($garagedesc)) 		 $garage[TAG_GARAGE_DESC_NL]=$garagedesc;
    if(!empty($garagesurface)) 		 $garage[TAG_GARAGE_SURFACE]=$garagesurface;
    if(!empty($garage)) $totalgarages[] = $garage;
    if(!empty($totalgarages)) $property[TAG_GARAGES] = $totalgarages;

    $kitchen = array();
    $totalkitchens = array();

    if(!empty($kitchendesc)) 		 $kitchen[TAG_KITCHEN_DESC_NL]=$kitchendesc;
    if(!empty($kitchensurface)) 		 $kitchen[TAG_KITCHEN_SURFACE]=$kitchensurface;
    if(!empty($kitchen)) $totalkitchens[] = $kitchen;
    if(!empty($totalkitchens)) $property[TAG_KITCHENS] = $totalkitchens;

    $storage = array();
    $totalstorages = array();
    if(!empty($storagedesc)) 		 $storage[TAG_STOREROOM_DESC_NL]=$storagedesc;
    if(!empty($storagesurface)) 		 $storage[TAG_STOREROOM_SURFACE]=$storagesurface;
    if(!empty($storage)) $totalstorages[] = $storage;
    if(!empty($totalstorages)) $property[TAG_STOREROOMS] = $totalstorages;

    $terrace = array();
    $totalterraces = array();
    if(!empty($terracedesc)) 		 $terrace[TAG_TERRACE_DESC_NL]=$terracedesc;
    if(!empty($terracesurface)) 		 $terrace[TAG_TERRACE_SURFACE]=$terracesurface;
    if(!empty($terrace)) $totalterraces[] = $terrace;
    if(!empty($totalterraces)) $property[TAG_TERRACES] = $totalterraces;

    $living = array();
    $totallivings = array();
    if(!empty($livingdesc)) 		 $living[TAG_LIVING_DESC_NL]=$livingdesc;
    if(!empty($livingsurface)) 		 $living[TAG_LIVING_SURFACE]=$livingsurface;
    if(!empty($living)) $totallivings[] = $living;
    if(!empty($totallivings)) $property[TAG_LIVINGS] = $totallivings;


    if(!empty($livingtotal))  $property[TAG_LIVINGS][TAG_TOTAL_AMOUNT]=$livingtotal;
    if(!empty($toilettotal)) $property[TAG_TOILETS][TAG_TOTAL_AMOUNT]=$toilettotal;
    if(!empty($bathroomtotal)) $property[TAG_BATHROOMS][TAG_TOTAL_AMOUNT]=$bathroomtotal;
    if(!empty($cellartotal)) $property[TAG_CELLARS][TAG_TOTAL_AMOUNT]=$cellartotal;
    if(!empty($kitchentotal)) $property[TAG_KITCHENS][TAG_TOTAL_AMOUNT]=$kitchentotal;

    if(!empty($bedrooms) && empty($property[TAG_BEDROOMS]))   $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT]=CrawlerTool::toNumber($bedrooms);
    if(!empty($garagetotal)) $property[TAG_GARAGES][TAG_TOTAL_AMOUNT]=$garagetotal;
    if(!empty($terracetotal)) $property[TAG_TERRACES][TAG_TOTAL_AMOUNT]=$terracetotal;
    if(!empty($storagetotal)) $property[TAG_STOREROOMS][TAG_TOTAL_AMOUNT]=$storagetotal;
    if(!empty($attictotal)) $property[TAG_ATTICS][TAG_TOTAL_AMOUNT]=$attictotal;

    if(!empty($garagetotal)) $property[TAG_GARAGES][TAG_TOTAL_AMOUNT]=$garagetotal;
    $property[TAG_GARDEN_AVAILABLE] =get_var($vars,'tuin') == 'Ja' ? 1 : '';
    $parkingtotal=get_var($vars,'parkeerplaatsen','!(\d+)!');
    if(!empty($parkingtotal))  $property[TAG_PARKINGS_TOTAL]=$parkingtotal;

    $property[TAG_HEATING_NL] = get_var($vars,'verwarming');
    $property[TAG_LIFT]                    = CrawlerTool::contains(get_var($vars,'lift'),'ja');
    $property[TAG_DOUBLE_GLAZING]=CrawlerTool::contains(get_var($vars,'dubbele beglazing') ,"ja");

    $atticDesc = get_var($vars,'zolder');
    if($atticDesc) $property[TAG_ATTICS][] = array(TAG_ATTIC_DESC_NL => $atticDesc);
    $property[TAG_GARDEN_AVAILABLE]=get_var($vars,'tuin') == 'ja' ? 1 : '';
    $property[TAG_PARKINGS_TOTAL]         = get_var($vars,'parking buiten') == 'ja' ? 1 : '';
    $property[TAG_GAS_CONNECTION] =(preg_match('!Aardgas!',$features,$res)) ? 1 : '';
    $property[TAG_CONNECTION_TO_WATER] =(preg_match('!aansluiting!',$features,$res)) ? 1 : 0;
    $property[TAG_TELEPHONE_CONNECTION] =(preg_match('!Telefoon!',$features,$res)) ? 1 : 0;
    $property[TAG_INTERNET_CONNECTION] =(preg_match('!Internet!',$features,$res)) ? 1 : 0;
    $property[TAG_VIDEOPHONE] =(preg_match('!Videofoon!',$features,$res)) ? 1 : 0;
    $property[TAG_DISTRIBUTION] =(preg_match('!Distributie!',$features,$res)) ? 1 : 0;
    $property[TAG_CONNECTION_TO_SEWER] =(preg_match('!Riolering!',$features,$res)) ? 1 : 0;



	$unmatched_variables = array();
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => trim($value));
	}
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;


    // Most Important 
    if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
    $property['planning_proceeding'] = 0;
    
    
    if(!isset($property['planning_permission']) || empty($property['planning_permission']))
    $property['planning_permission'] = 0;
    
    
    if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
    $property['subdivision_permit'] = 0;
    
    
    if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
    $property['planning_proceeding'] = 0;
    
    
    if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
    $property['most_recent_destination'] = 0;


	debug($property);
    CrawlerTool::saveProperty($property);
}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function toEuroCode($str) {
	return iconv("utf-8", "iso-8859-1", $str);
}

function checkItemValidity($text) {
	if (stripos($text, "pand-") !== false) return false;
	if (stripos($text, "estate-") !== false) return false;
	return true;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}

function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
} 

function removeBrackets($str){
	$str = str_replace('–','',$str);
	$str = str_replace('(','',$str);
	$str = str_replace(')','',$str);
	$str = str_replace('-','',$str);
	return $str;
}

//Function for Handle Attributes 
function setAtributesX($key='',$lan='nl'){ 
    
    $attrib['nl'] = array('Gemeubeld'=>BEBOUWING, 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Badkamer'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'keuken'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Aantal_slaapkamers'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'Bouwjaar'=>TAG_CONSTRUCTION_YEAR, 'Bewoonb_opp.'=>TAG_SURFACE_GROUND,
			'Parkings'=>TAG_PARKINGS,'Garages'=>TAG_GARAGES_TOTAL, 'Aantal_garages'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'Bewoonbare_oppervlakte'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Tuin'=>TAG_WINTERGARDENS,
			'Gemeubeld'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terras'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE
			
			);
    
    $attrib['fr'] = array('Gemeubeld'=>BEBOUWING, 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Nombre_de_salle_de_bain'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'cuisine'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'année_de_construction_année'=>TAG_CONSTRUCTION_YEAR, 'Taille_terrain_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'surface_nette_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Jardin'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrasse'=>TAG_TERRACES,'Facades'=>TAG_AMOUNT_OF_FACADES,
			'Catégorie'=>TAG_TYPE
			);
    
    $attrib['en'] = array('Gemeubeld'=>BEBOUWING, 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Number_of_bathrooms'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'kitchen'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Number_of_rooms'=>TAG_BEDROOMS_TOTAL,
			'construction_year_year'=>TAG_CONSTRUCTION_YEAR, 'Plot_size_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL, 'Type'=>TAG_TYPE,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'habitable_-_surface_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Garden'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrace'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE
			);
    
    if(!empty($key)){
	
	if( array_key_exists($key, $attrib[$lan]) ){
	    return $attrib[$lan][$key];
	}
	else
	    return '';
    }else
	return '';
	
}
        
	
	

function GetExactAttrib($key,$val){
    
    switch($key){
	
	case TAG_BATHROOMS_TOTAL:
	    return CrawlerTool::toNumber($val); 
	break;
    
	case TAG_BEDROOMS_TOTAL:
	    return CrawlerTool::toNumber($val); 
	break;
    
	case TAG_CONSTRUCTION_YEAR:
	    return CrawlerTool::toNumber($val); 
	break;
	
	default:
		return $val;
	break;
	 
    }
}

?>
