<?php
require_once("../crawler_classes.php");

define('SITE_URL','http://www.immolacle.be/');

$office[TAG_OFFICE_ID]   = "1";
$office[TAG_OFFICE_URL]  = "www.immolacle.be";
$office[TAG_OFFICE_NAME] = "IMMO LA CLE";
$office[TAG_STREET]      = "Vrijdagmarkt";
$office[TAG_NUMBER]      = "4";
$office[TAG_BOX_NUMBER]  = "";
$office[TAG_ZIP]         = "8000";
$office[TAG_CITY]        = "Brugge";
$office[TAG_COUNTRY]     = "Belgium";
$office[TAG_TELEPHONE]   = "+32 (0)50 39 39 36";
$office[TAG_FAX]         = "+32 (0)50 39 00 12";
$office[TAG_EMAIL]       = "immolacle@skynet.be";

$start_links = array(
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=9&idprov=+&idcity=+&order=1"  => array(STATUS_FORSELL,TYPE_HOUSE),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=10&idprov=+&idcity=+&order=1" => array(STATUS_FORSELL,TYPE_HOUSE),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=11&idprov=+&idcity=+&order=1" => array(STATUS_FORSELL,TYPE_HOUSE),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=2&idprov=+&idcity=+&order=1"  => array(STATUS_FORSELL,TYPE_APARTMENT),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=8&idprov=+&idcity=+&order=1"  => array(STATUS_FORSELL,TYPE_APARTMENT),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=5&idprov=+&idcity=+&order=1"  => array(STATUS_FORSELL,TYPE_COMMERCIAL),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=12&idprov=+&idcity=+&order=1" => array(STATUS_FORSELL,TYPE_COMMERCIAL),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=3&idprov=+&idcity=+&order=1"  => array(STATUS_FORSELL,TYPE_COMMERCIAL),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=4&idprov=+&idcity=+&order=1"  => array(STATUS_FORSELL,TYPE_GARAGE),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=6&idprov=+&idcity=+&order=1"  => array(STATUS_FORSELL,TYPE_PLOT),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=S&idtype=7&idprov=+&idcity=+&order=1"  => array(STATUS_FORSELL,''),

SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=9&idprov=+&idcity=+&order=1"  => array(STATUS_FORRENT,TYPE_HOUSE),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=10&idprov=+&idcity=+&order=1" => array(STATUS_FORRENT,TYPE_HOUSE),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=11&idprov=+&idcity=+&order=1" => array(STATUS_FORRENT,TYPE_HOUSE),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=2&idprov=+&idcity=+&order=1"  => array(STATUS_FORRENT,TYPE_APARTMENT),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=8&idprov=+&idcity=+&order=1"  => array(STATUS_FORRENT,TYPE_APARTMENT),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=5&idprov=+&idcity=+&order=1"  => array(STATUS_FORRENT,TYPE_COMMERCIAL),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=12&idprov=+&idcity=+&order=1" => array(STATUS_FORRENT,TYPE_COMMERCIAL),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=3&idprov=+&idcity=+&order=1"  => array(STATUS_FORRENT,TYPE_COMMERCIAL),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=4&idprov=+&idcity=+&order=1"  => array(STATUS_FORRENT,TYPE_GARAGE),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=6&idprov=+&idcity=+&order=1"  => array(STATUS_FORRENT,TYPE_PLOT),
SITE_URL . "building/list_nl.phtml?quicksearch=true&t=R&idtype=7&idprov=+&idcity=+&order=1"  => array(STATUS_FORRENT,''),
);

$properties = array();

foreach ($start_links as  $tkth_url => $info_arr)
{
	list($status,$type) = $info_arr;

	$html   = $crawler->request($tkth_url);

	for ($page = 2; $page <= 500; $page++)
	{
		//extract links to properties
		preg_match_all('!<TD><B><A HREF="detail_nl\.phtml\?id=(\d+)(&[^"]+)">!',$html,$res,PREG_SET_ORDER);
		foreach ($res as $v)
		{
			$property                         = array();
			$property[TAG_UNIQUE_ID]          = $v[1];
			$property[TAG_UNIQUE_URL_NL]      = SITE_URL . 'building/detail_nl.phtml?id=' .$v[1]  . $v[2];
			$property[TAG_STATUS]             = $status;
			$property[TAG_TYPE]               = $type;

			if (isset($properties[$property[TAG_UNIQUE_ID]])) {continue;}
			$properties[$property[TAG_UNIQUE_ID]] = $property;
		}

		//break if no next page link
		if (!preg_match('!<A HREF="(list_nl\.phtml\?start=[^"]+)"><span class=navigbar>' . $page . '</span></A>!',$html,$res))
		{
			break;
		}
		$res[1] = str_replace('&amp;','&',$res[1]);
		$html = $crawler->request(SITE_URL . 'building/' . $res[1]);
	}
}

CrawlerTool::startXML();

CrawlerTool::saveOffice($office);

//procces projects/properties
$done_cnt  = 0;
$total_cnt = count($properties);
echo "start proccesing property/project pages\r\n<br>Total count:$total_cnt\r\n<br>";
foreach ($properties as $property)
{
	extract_info($crawler,$property);
	$done_cnt++;
	$z = round(($done_cnt/$total_cnt)*100,2);
	echo "Done:$done_cnt/$total_cnt ($z% completed)\r\n<br>";
}

CrawlerTool::endXML();

echo "<br /><b>Completed!</b>";

function extract_info($crawler,$property)
{
	$html   = $crawler->request($property[TAG_UNIQUE_URL_NL]);

	if (CrawlerTool::skipWordFound($html))
	{
		echo "property skipped<br>\r\n";
		//return ;
	}

	$parser = new PageParser($html);

	//price
	if (preg_match('!<TD CLASS="txtbig" ALIGN="right">&euro; ([0-9.]+)</TD>!',$html,$res))
	{
		$property[TAG_PRICE] = str_replace('.','',$res[1]);
	}


	if (preg_match('!<tr>\s+<td colspan="2"><br>([^<>]+)</td>\s+</tr>!',$html,$res))
	{
		$res[1] = trim($res[1]);
		if (!empty($res[1]))
		{
			$property[TAG_ORIGINAL_REFERENCE]      = $res[1];
		}
	}



	//desc,type,city,zip
	preg_match('!</td>\s+</tr>\s+</TABLE>\s+(?:<img[^<>]+>|)<BR>\s+<b>([^<>]+)<BR>\s+<BR>(.*?)<TD VALIGN="top">!s',$html,$res);
	$property[TAG_TEXT_DESC_NL] = trim(strip_tags($res[2]));
	
	$property[TAG_PLAIN_TEXT_ALL_NL] =  $parser->extract_xpath("td[@class = 'contentarea' and @valign='top']", RETURN_TYPE_TEXT);
	
	if ($property[TAG_TYPE] == '' || (is_array($property[TAG_TYPE]) && count($property[TAG_TYPE])==0))	{$property[TAG_TYPE]     =  CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL],300);}
	
	$arr                                   = $parser->regex_all('!<div class="gammaSlideShowThumbImage">\s+<a href="(http://[^"]+)" name="txt_\d+"!', $html);
	$property[TAG_PICTURES]                = CrawlerTool::addTextToPicUrls($arr,'');

	if (strpos($html,'verhuurd.gif'))
	{
		$property[TAG_STATUS] = STATUS_RENTED;
		return;
	}
	elseif (strpos($html,'verkocht.gif'))
	{
		$property[TAG_STATUS] = STATUS_SOLD;
		return;
		
	}
		
	//If address is not correct but coming on website
	if(empty($property[TAG_CITY])){
		
		$address = $parser->extract_xpath("td[@width = '400' and @valign='top']/b", RETURN_TYPE_TEXT);
		 
		    CrawlerTool::parseAddress($address,$property);
		    
		$addr = explode(' ',$address);
		$property[TAG_CITY] = trim($addr[count($addr)-1]);
		$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
		
		if(strlen($property[TAG_ZIP]) < 4){
			$address = str_replace($property[TAG_ZIP],'',$address );
			$property[TAG_BOX_NUMBER] = $property[TAG_ZIP];
			$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
		}
		
		$property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
		$property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
		
		$property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
		$property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
		
		if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
		
		if(strlen($property[TAG_BOX_NUMBER]) < 3 || strlen($property[TAG_BOX_NUMBER]) > 3 )
		unset($property[TAG_BOX_NUMBER]);
	}

	 if(empty($property[TAG_CITY])){
		
		$property[TAG_CITY]                    = trim(preg_replace('!\d+!','',$res[1]));
		 
		if (preg_match('!\d{4,5}!',$res[1],$res))
		{
			$property[TAG_ZIP] = $res[0];
			if (strlen($property[TAG_ZIP])>4)
			{
				echo "property #{$property[TAG_UNIQUE_ID]} skipped, because zip code is  {$property[TAG_ZIP]} (more than 4 chars)<br>\r\n";
				 
			}
		}
	 }
	 
		
       if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
       if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
       if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
       if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));


	 if(empty($property[TAG_CITY]))
	 return;
	
	debug($property); 
	
	CrawlerTool::saveProperty($property);
}


//function for print array
function debug($obj)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}    
    