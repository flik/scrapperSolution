<?php
require_once("./../crawler_classes.php");
$crawler->set_script_dir(realpath(dirname(__FILE__)).'/');

//$crawler->enable_delay_between_requests(5,15);
//$crawler->use_cookies(true);
//$crawler->clean_cookies();
//$crawler->use_gzip(false);
$startPages[STATUS_FORRENT] = array(
  "http://www.devry-immo.be/index.php?option=com_hotproperty&view=types&layout=properties&id=1&Itemid=53" => TYPE_APARTMENT,
  "http://www.devry-immo.be/index.php?option=com_hotproperty&view=types&layout=properties&id=7&Itemid=53" => TYPE_COMMERCIAL,
  "http://www.devry-immo.be/index.php?option=com_hotproperty&view=types&layout=properties&id=3&Itemid=53" => TYPE_GARAGE,
  "http://www.devry-immo.be/index.php?option=com_hotproperty&view=types&layout=properties&id=2&Itemid=53" => TYPE_PLOT,
  "http://www.devry-immo.be/index.php?option=com_hotproperty&view=types&layout=properties&id=4&Itemid=53" => TYPE_COMMERCIAL,
  "http://www.devry-immo.be/index.php?option=com_hotproperty&view=types&layout=properties&id=6&Itemid=53" => TYPE_HOUSE,
  "http://www.devry-immo.be/index.php?option=com_hotproperty&view=types&layout=properties&id=5&Itemid=53" => TYPE_HOUSE,
);

$startPages[STATUS_FORSALE] = array( "http://devry-immo.be/Te_koop/Overzicht/Alle/"=>'');

CrawlerTool::startXML();


$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "IMMO DE VRY";
$office[TAG_OFFICE_URL] = "http://www.devry-immo.be";
$office[TAG_STREET] = "Dorpsweg";
$office[TAG_NUMBER] = "3";
$office[TAG_ZIP] = "2390";
$office[TAG_CITY] = "Oostmalle";
$office[TAG_TELEPHONE] = "+32 (0)3 312 07 58";
$office[TAG_EMAIL] = "info@devry-immo.be";
CrawlerTool::saveOffice($office);

foreach ($startPages as $status => $types) {
  foreach ($types as $page_url => $type) {
    
    debugx($page_url);
    $html = $crawler->request($page_url);
    processPage($crawler, $status, $type, $html, $page_url);
    do {
      $pattern = '@<a.+href="(.+?)" title="Volgende">Volgende@';
      preg_match ($pattern, $html, $next_match);
      
      if (isset($next_match[1])) {
        
        $url = 'http://www.devry-immo.be'.trim(str_replace(' ', '%20', html_entity_decode($next_match[1])));
        debugx($url);
        $html = $crawler->request($url);
        processPage($crawler, $status, $type, $html, $url);
        
        unset($post);
      }
      else {
        unset($url);
      }
    }
    while ($url);
  }
}


CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';

function processPage($crawler, $status, $type, $html, $page_url) {
  static $propertyCount = 0;
  static $properties = array();
  $parser = new PageParser($html);
  $nodes = $parser->getNodes("a[. = 'Meer info']");
  //debug($nodes); exit;
  $item = array();
  //print $html;
  foreach ($nodes as $node) {
    
    if (stristr($match[2], 'koop')) {
      $property[TAG_STATUS] = 'forsale';
    }
    else {
      $property[TAG_STATUS] = 'torent';
    }
    
    echo $property[TAG_UNIQUE_URL_NL] = 'http://www.devry-immo.be'.html_entity_decode(str_replace(' ', '%20', $parser->getAttr($node, "href")));
    $property[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
    
    $propertyCount += 1;
    flush();
    ob_flush();
    if (in_array($property[TAG_UNIQUE_ID], $properties)) {
        continue;
    }
    $properties[] = $property[TAG_UNIQUE_ID];
    
    // process item to obtain detail information
    echo "--------- Processing property #$propertyCount ...";
    processItem($crawler, $property, $type, $status, $page_url);
    echo "--------- Completed<br />";
  }
}

function getUniqueId($url) {
  preg_match("/id=(\d+)/", $url, $match);
  if ($match) {
    return $match[1];
  }
}

/**
 *  Get next page
 */
function getNextPage($html, $crawler) {
  $parser = new PageParser($html);
  $nextPage = "";
  
  $node = $parser->getNode("a[. = 'Next \&gt\;']");
  if ($node) {
    $nextPage = "http://www.immo3f.be".str_replace(" ", "%20", getAttr($node, "href"));
  }
  
  return $nextPage;
}

function processItem($crawler, $property, $type, $page_url) {
  
  $html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
  $parser = new PageParser($html, true);
  $parser->deleteTags(array("script", "style"));
  
  $property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode($parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL));
  $property[TAG_TEXT_DESC_NL] = utf8_decode($parser->extract_xpath("div[@class = 'txtveldextra']", RETURN_TYPE_TEXT));
  
  $iframe = $parser->extract_xpath("iframe/@src");
  $htmlx = $crawler->request('http://devry-immo.be'.$iframe);
  $parserx = new PageParser($htmlx, true);
  $parserx->deleteTags(array("script", "style"));
  
  $id = $parser->regex("/(\d+)$/", $property[TAG_UNIQUE_URL_NL]);
  
  $picUrls = array();
  $nodes = $parserx->getNodes("div[contains(@class, 'ws_images')]/ul/li/img/@src");
  foreach ($nodes as $node) {
    $picUrls[] = array(
      TAG_PICTURE_URL => 'http://devry-immo.be/bestanden/Eigendommen/'.$id.'/'.$parser->getText($node),
    );
  }
  $property[TAG_PICTURES] = $picUrls;

  #    $html1=preg_replace('/(\swidth="150"|\svalign="top"|<b>|<\/b>)/si','',$html);
  preg_match_all('!<span class=.*?">([^<>]+)</span>\s+<span class=".*?">([^<>]+)<!', $html, $res, PREG_SET_ORDER);
  foreach ($res as $arr) {
    $arr[1] = strtolower($arr[1]);
    $arr[1] = trim($arr[1]);
    $arr[1] = preg_replace('![^a-z0-9_\-\. ]!', '', $arr[1]);
    $arr[1] = preg_replace('!nbsp!', '', $arr[1]);
    $vars[$arr[1]] = $arr[2];

    #echo "<br>";
  }
  //rename k.i. to ki
  if (isset($vars['k.i.'])) {
    $vars['ki'] = $vars['k.i.'];
    unset($vars['k.i.']);
  }
  //remove transactie (i.e. te koop or te huur)
  if (isset($vars['beschrijving'])) {
    unset($vars['beschrijving']);
  }
  if (isset($vars['informatieplicht decreet ruimtelijke ordening'])) {
    unset($vars['informatieplicht decreet ruimtelijke ordening']);
  }
  
  //
  if (empty($property[TAG_CITY])) {
    
    $address = $parser->extract_xpath("div[@class = 'txtgroep']/span", RETURN_TYPE_TEXT);

    CrawlerTool::parseAddress(preg_replace("/,|\//", "", $address), $property);
    $addr = explode(' ', $address);
    $property[TAG_CITY] = trim($addr[count($addr) - 1]);
    $property[TAG_ZIP] = $parser->regex("/(\d{4})/", $address);
    
    $property[TAG_STREET] = str_replace($property[TAG_CITY], '', $property[TAG_STREET]);
    $property[TAG_STREET] = str_replace($property[TAG_ZIP], '', $property[TAG_STREET]);
    
    $property[TAG_NUMBER] = str_replace($property[TAG_CITY], '', $property[TAG_NUMBER]);
    $property[TAG_NUMBER] = str_replace($property[TAG_ZIP], '', $property[TAG_NUMBER]);
    
    if (empty($property[TAG_CITY])) {
      $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER]));
    }
    unset($property[TAG_BOX_NUMBER]);
  }
  
  $pattern = '@<span class="txtvraagprijswaarde">(.+?)</span>@si';
  preg_match($pattern, $html, $price);
  if (isset($price[1])) {
    $property[TAG_PRICE] = CrawlerTool::toNumber(str_replace('&#8364;', '', (strip_tags($price[1]))));
  }
  $property[TAG_KI] = str_replace('.', '', get_var($vars, 'kadastraal inkomen', '![^<>0-9]*([0-9.]+)!'));
  $property[TAG_CONSTRUCTION_TYPE] = CrawlerTool::getConstructionType(get_var($vars, 'type woning'));
  $property[TAG_CONSTRUCTION_YEAR] = get_var($vars, 'bouwjaar', '!(\d{4})!');
  $property[TAG_READY_TO_MOVE_IN] = get_var($vars, 'algemene staat') === "Instapklaar" ? 1 : 0;
  $property[TAG_FREE_FROM_DATE] = CrawlerTool::toUnixTimestamp(get_var($vars, "beschikbaar"));
  $property[TAG_SURFACE_GROUND] = CrawlerTool::toNumber(get_var($vars, "grondoppervlakte"));
  $property[TAG_SURFACE_CONSTRUCTION] = CrawlerTool::toNumber(get_var($vars, 'bebouwde opp.'));
  $property[TAG_SURFACE_LIVING_AREA] = CrawlerTool::toNumber(get_var($vars, 'woonoppervlakte'));
  if (empty($property[TAG_SURFACE_LIVING_AREA])) {
    $property[TAG_SURFACE_LIVING_AREA] = get_var($vars, 'bewoonbare oppervlakte', '!(\d+)!');
  }
  $property[TAG_LOT_WIDTH] = get_var($vars, 'perceelbreedte');
  $property[TAG_FRONTAGE_WIDTH] = get_var($vars, 'gevelbreedte');
  $property[TAG_LOT_DEPTH] = get_var($vars, 'perceeldiepte');
  $property[TAG_AMOUNT_OF_FLOORS] = get_var($vars, 'woonlagen');
  $property[TAG_KI_INDEX] = str_replace('.', '', get_var($vars, 'ki', '![^<>0-9]*([0-9.]+)!'));
  $property[TAG_HEATING_NL] = get_var($vars, 'verwarming');
  $property[TAG_LIFT] = get_var($vars, 'lift') == 'Ja' ? 1 : '';
  $property[TAG_DOUBLE_GLAZING] = CrawlerTool::contains(get_var($vars, 'beglazing types'), "Dubbel");
  $property[TAG_COMMON_COSTS] = get_var($vars, 'gemeenschappelijke lasten per maand', '!(\d+)!');
  $property[TAG_EPC_VALUE] = $parser->extract_regex("/(\d+)\s*kWh/i", RETURN_TYPE_EPC);
  $property[TAG_EPC_CERTIFICATE_NUMBER] = $parser->extract_regex("/certificaatnummer\s:\s([-\d]+)/i");
  $property[TAG_RENOVATION_YEAR] = get_var($vars, 'renovatiejaar', '!(\d{4})!');
  $floor = get_var($vars, 'verdiepingen', '!(\d+)!');
  
  if (!empty($floor)) {
    $property[TAG_FLOOR] = $floor;
  }
  

  $kitchendesc = get_var($vars, 'keuken');
  
  $kitchen = array();
  $totalkitchens = array();
  if (!empty($kitchendesc)) {
    $kitchen[TAG_KITCHEN_DESC_NL] = $kitchendesc;
  }
  if (!empty($kitchen)) {
    $totalkitchens[] = $kitchen;
  }
  if (!empty($totalkitchens)) {
    $property[TAG_KITCHENS] = $totalkitchens;
  }
  
  $bedrooms = get_var($vars, 'aantal slaapkamers');
  $livings = get_var($vars, 'woonkamer');
  $Garages = get_var($vars, 'aantal garages');
  $bathrooms = get_var($vars, 'Aantal badkamers:');
  $toilets = get_var($vars, 'wc');
  $kitchens = get_var($vars, 'keuken');
  $storages = get_var($vars, 'berging');
  $terraces = get_var($vars, 'terras');
  $cellars = get_var($vars, 'kelder');
  $wintergardens = get_var($vars, 'veranda');
  $studies = get_var($vars, 'kantoor');
  $freepossesions = get_var($vars, 'praktijkruimte');
  $attics = get_var($vars, 'zolder');
  $rooms = get_var($vars, 'aantal kamers');
  if (!empty($rooms)) {
    $room = $parser->regex("/(\d)$/", $rooms);
  }
  
  if (!empty($bedrooms)) {
    $bedroomtotal = $parser->regex("/\((\d)\)/", $bedrooms);
  }
  if (!empty($attics)) {
    $attictotal = $parser->regex("/(\d)$/", $attics);
  }
  if (!empty($livings)) {
    $livingtotal = $parser->regex("/(\d)$/", $livings);
  }
  if (!empty($Garages)) {
    $garagetotal = $parser->regex("/(\d)$/", $Garages);
  }
  if (!empty($bathrooms)) {
    $bathroomtotal = $parser->regex("/(\d)$/", $bathrooms);
  }
  if (!empty($toilets)) {
    $toilettotal = $parser->regex("/(\d)$/", $toilets);
  }
  if (!empty($kitchens)) {
    $kitchentotal = $parser->regex("/(\d)$/", $kitchens);
  }
  if (!empty($storages)) {
    $storagetotal = $parser->regex("/(\d)$/", $storages);
  }
  if (!empty($terraces)) {
    $terracetotal = $parser->regex("/(\d)$/", $terraces);
  }
  if (!empty($cellars)) {
    $cellartotal = $parser->regex("/(\d)$/", $cellars);
  }
  if (!empty($wintergardens)) {
    $wintergardentotal = $parser->regex("/(\d)$/", $wintergardens);
  }
  if (!empty($studies)) {
    $studytotal = $parser->regex("/(\d)$/", $studies);
  }
  if (!empty($freepossesions)) {
    $freepossesiontotal = $parser->regex("/(\d)$/", $freepossesions);
  }
  
  if (!empty($bedrooms)) {
    $bedroomsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $bedrooms);
  }
  if (!empty($attics)) {
    $atticsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $attics);
  }
  if (!empty($livings)) {
    $livingsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $livings);
  }
  if (!empty($Garages)) {
    $garagesurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $Garages);
  }
  if (!empty($bathrooms)) {
    $bathroomsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $bathrooms);
  }
  if (!empty($toilets)) {
    $toiletsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $toilets);
  }
  if (!empty($kitchens)) {
    $kitchensurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $kitchens);
  }
  if (!empty($storages)) {
    $storagesurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $storages);
  }
  if (!empty($terraces)) {
    $terracesurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $terraces);
  }
  if (!empty($cellars)) {
    $cellarsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $cellars);
  }
  if (!empty($wintergardens)) {
    $wintergardensurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $wintergardens);
  }
  if (!empty($studies)) {
    $studysurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $studies);
  }
  if (!empty($freepossesions)) {
    $freepossesionsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $freepossesions);
  }

  #  if(empty($terracesurface)) $terracesurface=$parser->extract_xpath("Terras opervlakte",RETURN_TYPE_NUMBER);
  #  if(empty($cellarsurface)) $cellarsurface=$parser->extract_xpath("Kelder opp",RETURN_TYPE_NUMBER);
  $bedroomdesc = $parser->regex("/([a-zA-Z_-\s]*)/", $bedrooms);
  $atticdesc = $parser->regex("/([a-zA-Z_-\s]*)/", $attics);
  
  $garagedesc = $parser->regex("/([a-zA-Z_-\s]*)/", $Garages);
  $bathroomdesc = $parser->regex("/([a-zA-Z_-\s]*)/", $bathrooms);
  $toiletdesc = $parser->regex("/([a-zA-Z_-\s]*)/", $toilets);
  $kitchendesc = $parser->regex("/([a-zA-Z_-\s]*)/", $kitchens);
  $storagedesc = $parser->regex("/([a-zA-Z_-\s]*)/", $storages);
  $terracedesc = $parser->regex("/([a-zA-Z_-\s]*)/", $terraces);
  $cellardesc = $parser->regex("/([a-zA-Z_-\s]*)/", $cellars);
  $livingdesc = $parser->regex("/([a-zA-Z_-\s]*)/", $livings);
  $floorplandesc = $parser->regex("/([a-zA-Z_-\s]*)/", $parser->extract_xpath("Grondplannen"));
  $wintergardendesc = $parser->regex("/([a-zA-Z_-\s]*)/", $wintergardens);
  $studydesc = $parser->regex("/([a-zA-Z_-\s]*)/", $studies);
  $freepossesiondesc = $parser->regex("/([a-zA-Z_-\s]*)/", $freepossesions);
  

  $wintergarden = array();
  $totalwintergardens = array();
  if (!empty($wintergardendesc)) {
    $wintergarden[TAG_WINTERGARDEN_DESC_NL] = $wintergardendesc;
  }
  if (!empty($wintergardensurface)) {
    $wintergarden[TAG_WINTERGARDEN_SURFACE] = $wintergardensurface;
  }
  if (!empty($wintergarden)) {
    $totalwintergardens[] = $wintergarden;
  }
  if (!empty($totalwintergardens)) {
    $property[TAG_WINTERGARDENS] = $totalwintergardens;
  }
  
  $freepossesion = array();
  $totalfreepossesions = array();
  if (!empty($freepossesiondesc)) {
    $freepossesion[TAG_FREE_PROFESSION_DESC_NL] = $freepossesiondesc;
  }
  if (!empty($freepossesionsurface)) {
    $freepossesion[TAG_FREE_PROFESSION_SURFACE] = $freepossesionsurface;
  }
  if (!empty($freepossesion)) {
    $totalfreepossesions[] = $freepossesion;
  }
  if (!empty($totalfreepossesions)) {
    $property[TAG_FREE_PROFESSIONS] = $totalfreepossesions;
  }
  
  $study = array();
  $totalstudys = array();
  if (!empty($studydesc)) {
    $study[TAG_STUDY_DESC_NL] = $studydesc;
  }
  if (!empty($studysurface)) {
    $study[TAG_STUDY_SURFACE] = $studysurface;
  }
  if (!empty($study)) {
    $totalstudys[] = $study;
  }
  if (!empty($totalstudys)) {
    $property[TAG_STUDIES] = $totalstudys;
  }
  

  $bathroom = array();
  $totalbathrooms = array();
  if (!empty($bathroomdesc)) {
    $bathroom[TAG_BATHROOM_DESC_NL] = $bathroomdesc;
  }
  if (!empty($bathroomsurface)) {
    $bathroom[TAG_BATHROOM_SURFACE] = $bathroomsurface;
  }
  if (!empty($bathroom)) {
    $totalbathrooms[] = $bathroom;
  }
  if (!empty($totalbathrooms)) {
    $property[TAG_BATHROOMS] = $totalbathrooms;
  }
  
  $attic = array();
  $totalattics = array();
  if (!empty($atticdesc)) {
    $bathroom[TAG_ATTIC_DESC_NL] = $atticdesc;
  }
  if (!empty($atticsurface)) {
    $bathroom[TAG_ATTIC_SURFACE] = $atticsurface;
  }
  if (!empty($attic)) {
    $totalattics[] = $attic;
  }
  if (!empty($totalattics)) {
    $property[TAG_ATTICS] = $totalattics;
  }
  
  $cellar = array();
  $totalcellars = array();
  if (!empty($cellardesc)) {
    $cellar[TAG_CELLAR_DESC_NL] = $cellardesc;
  }
  if (!empty($cellarsurface)) {
    $cellar[TAG_CELLAR_SURFACE] = $cellarsurface;
  }
  if (!empty($cellar)) {
    $totalcellars[] = $cellar;
  }
  if (!empty($totalcellars)) {
    $property[TAG_CELLARS] = $totalcellars;
  }
  
  $bedroom = array();
  if (!empty($bedroomdesc)) {
    $bedroom[TAG_BEDROOM_DESC_NL] = $bedroomdesc;
  }
  if (!empty($bedroomsurface)) {
    $bedroom[TAG_BEDROOM_SURFACE] = $bedroomsurface;
  }
  //if(!empty($bedroom)) $totalbedrooms = $bedroom;
  if ($bedroomdesc == 'twee') {
    $totalbedrooms = 2;
  }
  $property[TAG_BEDROOMS] = $totalbedrooms;
  
  $toilet = array();
  $totaltoilets = array();
  if (!empty($toiletdesc)) {
    $toilet[TAG_TOILET_DESC_NL] = $toiletdesc;
  }
  if (!empty($toiletsurface)) {
    $toilet[TAG_TOILET_SURFACE] = $toiletsurface;
  }
  if (!empty($toilet)) {
    $totaltoilets[] = $toilet;
  }
  
  if ($toiletdesc == 'twee') {
    $totaltoilets = 2;
  }
  
  $property[TAG_TOILETS] = $totaltoilets;
  
  $garage = array();
  $totalgarages = array();
  if (!empty($garagedesc)) {
    $garage[TAG_GARAGE_DESC_NL] = $garagedesc;
  }
  if (!empty($garagesurface)) {
    $garage[TAG_GARAGE_SURFACE] = $garagesurface;
  }
  if (!empty($garage)) {
    $totalgarages[] = $garage;
  }
  if (!empty($totalgarages)) {
    $property[TAG_GARAGES] = $totalgarages;
  }
  
  $kitchen = array();
  $totalkitchens = array();
  
  if (!empty($kitchendesc)) {
    $kitchen[TAG_KITCHEN_DESC_NL] = $kitchendesc;
  }
  if (!empty($kitchensurface)) {
    $kitchen[TAG_KITCHEN_SURFACE] = $kitchensurface;
  }
  if (!empty($kitchen)) {
    $totalkitchens[] = $kitchen;
  }
  if (!empty($totalkitchens)) {
    $property[TAG_KITCHENS] = $totalkitchens;
  }
  
  $storage = array();
  $totalstorages = array();
  if (!empty($storagedesc)) {
    $storage[TAG_STOREROOM_DESC_NL] = $storagedesc;
  }
  if (!empty($storagesurface)) {
    $storage[TAG_STOREROOM_SURFACE] = $storagesurface;
  }
  if (!empty($storage)) {
    $totalstorages[] = $storage;
  }
  if (!empty($totalstorages)) {
    $property[TAG_STOREROOMS] = $totalstorages;
  }
  
  $terrace = array();
  $totalterraces = array();
  if (!empty($terracedesc)) {
    $terrace[TAG_TERRACE_DESC_NL] = $terracedesc;
  }
  if (!empty($terracesurface)) {
    $terrace[TAG_TERRACE_SURFACE] = $terracesurface;
  }
  if (!empty($terrace)) {
    $totalterraces[] = $terrace;
  }
  if (!empty($totalterraces)) {
    $property[TAG_TERRACES] = $totalterraces;
  }
  
  $living = array();
  $totallivings = array();
  if (!empty($livingdesc)) {
    $living[TAG_LIVING_DESC_NL] = $livingdesc;
  }
  if (!empty($livingsurface)) {
    $living[TAG_LIVING_SURFACE] = $livingsurface;
  }
  if (!empty($living)) {
    $totallivings[] = $living;
  }
  if (!empty($totallivings)) {
    $property[TAG_LIVINGS] = $totallivings;
  }
  
  //if(empty($bedroomtotal) && !empty($room))  $bedroomtotal=$room;
  $bedroomtotal = $totalbedrooms;
  if (!empty($livingtotal)) {
    $property[TAG_LIVINGS][TAG_TOTAL_AMOUNT] = $livingtotal;
  }
  if (!empty($toilettotal)) {
    $property[TAG_TOILETS][TAG_TOTAL_AMOUNT] = $toilettotal;
  }
  if (!empty($bathroomtotal)) {
    $property[TAG_BATHROOMS][TAG_TOTAL_AMOUNT] = $bathroomtotal;
  }
  if (!empty($cellartotal)) {
    $property[TAG_CELLARS][TAG_TOTAL_AMOUNT] = $cellartotal;
  }
  if (!empty($kitchentotal)) {
    $property[TAG_KITCHENS][TAG_TOTAL_AMOUNT] = $kitchentotal;
  }
  
  if (!empty($bedroomtotal)) {
    $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT] = $bedroomtotal;
  }
  if (!empty($garagetotal)) {
    $property[TAG_GARAGES][TAG_TOTAL_AMOUNT] = $garagetotal;
  }
  if (!empty($terracetotal)) {
    $property[TAG_TERRACES][TAG_TOTAL_AMOUNT] = $terracetotal;
  }
  if (!empty($storagetotal)) {
    $property[TAG_STOREROOMS][TAG_TOTAL_AMOUNT] = $storagetotal;
  }
  if (!empty($attictotal)) {
    $property[TAG_ATTICS][TAG_TOTAL_AMOUNT] = $attictotal;
  }
  
  if (!empty($garagetotal)) {
    $property[TAG_GARAGES][TAG_TOTAL_AMOUNT] = $garagetotal;
  }
  $property[TAG_GARDEN_AVAILABLE] = get_var($vars, 'tuin') == 'Ja' ? 1 : '';
  $parkingtotal = get_var($vars, 'parkeerplaatsen', '!(\d+)!');
  if (!empty($parkingtotal)) {
    $property[TAG_PARKINGS_TOTAL] = $parkingtotal;
  }
  
  $unmatched_variables = array();
  foreach ($vars as $label => $value) {
    $unmatched_variables[] = array(
      TAG_VARIABLE_LABEL => $label,
      TAG_VARIABLE_VALUE => $value,
    );
  }
  $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
  


  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));
  }
  

  // Most Important
  if (!isset($property['priority_purchase']) || empty($property['priority_purchase']) || $property['priority_purchase'] != "1") {
    $property['priority_purchase'] = "";
  }
  
  if (!isset($property['has_proceeding']) || empty($property['has_proceeding']) || $property['has_proceeding'] != "1") {
    $property['has_proceeding'] = "";
  }
  

  if (!isset($property['planning_permission']) || empty($property['planning_permission']) || $property['planning_permission'] != "1") {
    $property['planning_permission'] = "";
  }
  

  if (!isset($property['subdivision_permit']) || empty($property['subdivision_permit']) || $property['subdivision_permit'] != "1") {
    $property['subdivision_permit'] = "";
  }
  
  if (!isset($property['most_recent_destination']) || empty($property['most_recent_destination']) || $property['most_recent_destination'] != "1") {
    $property['most_recent_destination'] = "";
  }
  

  debug($property);
  
  CrawlerTool::saveProperty($property);
}

function get_var(&$vars, $field, $regex = '') {
  if (isset($vars[$field])) {
    $x = $vars[$field];
    unset($vars[$field]);
    
    if (!empty($regex)) {
      return(preg_match($regex, $x, $res)) ? $res[1] : false;
    }
    return trim($x);
  }
  
  return false;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false) {
  echo "<pre>";
  print_r($obj);
  echo "</pre>";
  if ($e) {
    exit;
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false) {
  echo "<br />************************<br/>";
  echo $obj;
  echo "<br/>************************<br/>";
  if ($e) {
    exit;
  }
}


?>