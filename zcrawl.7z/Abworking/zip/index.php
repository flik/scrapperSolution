<?php

/* ============================= CONFIG ============================= */
// Crawler ID 12611
require_once("../../crawler_classes.php");

CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.bkgroup.be/"
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://belgium.rootsweb.ancestry.com/bel/_places/dorp_co_10xx.html"
    ),
);

/* ============================= END CONFIG ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "OPEN THE DOOR";
$office[TAG_OFFICE_URL] = "http://www.bkgroup.be/";
$office[TAG_STREET] = "Chaussée de la hulpe";
$office[TAG_NUMBER] = "177";
$office[TAG_ZIP] = "1170";
$office[TAG_CITY] = "Bruxelles";
$office[TAG_TELEPHONE] = "026632745";
$office[TAG_EMAIL] = "info@bkgroup.be";

CrawlerTool::saveOffice($office);

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            debugx($page); 
            $html = $crawler->request($page); 
            processPage($crawler, $status, $type, $html); 
           
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);
    $nodes = $parser->getNodes("font[contains(@class, 'header')]/a");
    $items = array();
    foreach($nodes as $node)
    {
        $property = array(); 
        $property[TAG_STATUS] = $status; 
        $property[TAG_TYPE] = $type; 
        $property[TAG_UNIQUE_URL_NL] = 'http://belgium.rootsweb.ancestry.com/bel/_places/'.$parser->getAttr($node, "href"); 
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]); 
      

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

	 

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
    }
    
 

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...".$item["itemUrl"];
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
	
    $html = str_replace("±", "", $html);
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    $nodes = $parser->getNodes("tr[contains(@align, 'left')]/td[2]");
    $items = $itemsa = $itemsb = array();
    foreach($nodes as $node)
    {
	$link =   $parser->getText($node);
	$itemsa[] = $link;
    }
    
    $nodes = $parser->getNodes("tr[contains(@align, 'left')]/td[1]");
    foreach($nodes as $node)
    {
	$link =   $parser->getText($node);
	$itemsb[] = $link;
    }
    
    foreach($itemsa as $k=>$v){
	
	$items[str_replace(' ','_',$itemsa[$k])] = $itemsb[$k];
	echo $itemsb[$k] .' -------- '.str_replace(' ','_',$itemsa[$k]).'</br>';
    }
    
    //debug($items);  
   // CrawlerTool::saveProperty($property);
}
 

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}
