<?php

/* ============================= CONFIG ============================= */

// Crawler ID 2023

require_once("./../crawler_classes.php");
$crawler->clean_cookies();

//$crawler->enable_delay_between_requests(5, 10);
$startPages[STATUS_FORSALE] = array
(
    "1"        =>  array
    (
       'search={"mode":"estate","PurposeIDList":["1"]}'
    ),
    "2"        =>  array
    (
        'param={"mode":"estate","PurposeIDList":["2"]}'
    ),
    "new"        =>  array
    (
        'search={"mode":"newestate","PurposeIDList":[1]}'
    )
);

$start_links[STATUS_FORRENT] = array(
TYPE_NONE        =>  array
    (
        "http://www.vansweevelt.be/aanbod"
    ),
);
/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/





/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();
 
//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Kantoor Turnhout";
$office[TAG_OFFICE_URL] = "http://www.vansweevelt.be/offices#turnhout";
$office[TAG_STREET] = "Graatakker";
$office[TAG_NUMBER] = "91";
$office[TAG_ZIP] = "2300";
$office[TAG_CITY] = "Turnhout ";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "+32 14 41 42 42";
$office[TAG_FAX] = "+32 14 45 15 61";
$office[TAG_EMAIL] = "info@vansweevelt.be";
CrawlerTool::saveOffice($office);

$office[TAG_OFFICE_ID] = 2;
$office[TAG_OFFICE_NAME] = "Kantoor Herentals";
$office[TAG_OFFICE_URL] = "http://www.vansweevelt.be/offices#herentals";
$office[TAG_STREET] = "Belgiëlaan";
$office[TAG_NUMBER] = "4";
$office[TAG_ZIP] = "2200";
$office[TAG_CITY] = "Herentals  ";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "+32 14 21 06 09";
$office[TAG_FAX] = "+32 14 21 06 10";
$office[TAG_EMAIL] = "info@vansweevelt.be";
CrawlerTool::saveOffice($office);

$office[TAG_OFFICE_ID] = 3;
$office[TAG_OFFICE_NAME] = "Kantoor Turnhout";
$office[TAG_OFFICE_URL] = "http://www.vansweevelt.be/offices#geel";
$office[TAG_STREET] = "Pas";
$office[TAG_NUMBER] = "151";
$office[TAG_ZIP] = "2440";
$office[TAG_CITY] = "Geel  ";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = " +32 14 58 05 05";
$office[TAG_FAX] = "+32 14 56 03 30";
$office[TAG_EMAIL] = "info@vansweevelt.be";
CrawlerTool::saveOffice($office);


$url="http://www.vansweevelt.be/estates";

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            if($type === "new"){
                debugx($url);
		$url="http://www.vansweevelt.be/newestates";
                $html = $crawler->request($url);
		
            }else{
		debugx($url.$page);
                $html = $crawler->request($url,$page);

            }
	    
            processPage($crawler, $status, $type, $html);
			echo "Complete processing page ..." . "<br /><br />";

			$nextPage = getNextPage($html);
			unset($html);

			while(strlen($nextPage) > 0) {
				echo "Downloading page content..." . "<br />";
				debugx($nextPage);
				$html = $crawler->request($nextPage);
				echo "Complete downloading page content..." . "<br />";

				// process page content
				echo "Processing page ..." . "<br />";
				processPage($crawler, $status, $type, $html);
				echo "Complete processing page ..." . "<br /><br />";

				$nextPage = getNextPage($html);
				unset($html);
			}

		}
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

/**
 * Get a list of next pages
 */
function getNextPage($html) {
	$pageList = array();
    $parser = new PageParser($html);
    $nextPage='';

	$node = $parser->getNode("span[@id = 'pagination_next']/a");
	if($node) $nextPage = str_replace(" ", "%20", $parser->getAttr($node, "href"));

	// free memory used
	unset($dom);
	unset($xpath);

	return $nextPage;
}



function processPage($crawler, $status, $type, $html)
{
	global $propertyCount;
	global $projectCount;
	global $properties;
	global $projects;

	if(empty($projectCount)) $projectCount = 0;
	if(empty($propertyCount)) $propertyCount = 0;

	if(empty($properties)) $properties = array();
	if(empty($projects)) $projects = array();

	$parser = new PageParser($html);

	if($type=="new") {

        $nodes = $parser->getNodes("a[. = 'details']");
		$items = array();
		foreach($nodes as $node)
		{
			//$project[TAG_STATUS] = $status;
			echo $project[TAG_UNIQUE_URL_NL] = $parser->getAttr($node, "href");
			echo $project[TAG_PROJECT_ID] =  getUniqueId($project[TAG_UNIQUE_URL_NL]);
			if(in_array($project[TAG_PROJECT_ID], $projects)) continue;
			$projects[] = $project[TAG_PROJECT_ID];
			$items[] = array("item"=>$project, "itemUrl" => $project[TAG_UNIQUE_URL_NL]);
		}

		foreach($items as $item)
		{
			// keep track of number of properties processed
			$projectCount += 1;

			// process item to obtain detail information
			echo "--------- Processing project #$projectCount ...";
			echo $item["itemUrl"]."<br>";
			processProject($crawler, $item["item"], $crawler->request($item["itemUrl"]));
			echo "--------- Completed<br />";
		}
    }else{
        $nodes = $parser->getNodes("a[. = ' details ']");

		$items = array();
		foreach($nodes as $node)
		{
			$property[TAG_STATUS] = $status;
			//$property[TAG_TYPE] = $type;
			echo $property[TAG_UNIQUE_URL_NL] = $parser->getAttr($node, "href");
			echo $property[TAG_UNIQUE_ID] = getUniqueId($property[TAG_UNIQUE_URL_NL]);
			#$property[TAG_SURFACE_GROUND]= CrawlerTool::toNumber($parser->extract_xpath("following-sibling::div[1]/descendant::span[contains(text(), 'Oppervlakte')]/following-sibling::span[1]",$node));
			if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
			$properties[] = $property[TAG_UNIQUE_ID];
			$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
		}   //CrawlerTool::test($items);

		foreach($items as $item)
		{
			// keep track of number of properties processed
			$propertyCount += 1;

			// process item to obtain detail information
			echo "--------- Processing property #$propertyCount ...";
			processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
			echo "--------- Completed<br />";
		}

		return sizeof($items);
    }
}

function getUniqueId($url) {
	preg_match("/detail\/(\d+)/", $url, $match);
	if($match) return $match[1];
}

function getTypeLong($parser, $node) {
	$n = $parser->getNodes("following-sibling::p[1]/a/text()", $node);
	if($n->length == 0) {
		return "Grond";
	}
	else {
		$text = $parser->getText($n);
		if(stripos($text, "Grond") !== false && $n->length == 1) return "Grond";
	}

	return "Handel-Kantoor";
}
/**
 * Download and extract item detail information
 */
function processProject($crawler, $project, $html)
{

    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));
    $project[TAG_TEXT_DESC_NL] = $parser->extract_xpath("meta[contains(@name, 'Description')]");
    $project[TAG_PICTURES] = $parser->extract_xpath("div[contains(@class, 'images')]/div/img", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) {
            $picUrls[] = array(TAG_PICTURE_URL =>  str_replace("des_", "", $pic));
        }

        return $picUrls;
    });

/*
	preg_match('/<p class="estateAddress">\s+(.*)<br>\s+(\d{4,})\s+(.*)<\/p> <p class="childrenCount">/si', $html, $match);
	if($match) {
		$adres = trim($match[1]);
#		$project[TAG_STREET]=preg_replace('/[0-9,.]/','',$adres);
#		$project[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);

		$project[TAG_ZIP] = $match[2];
		echo $project[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));
	}
#    if(empty($project[TAG_CITY])) return;
*/

	echo $text = $parser->extract_xpath("p[@class = 'estateAddress']");
	if($text) {
		preg_match("/(.*)\s+(\d{4,})\s+(.*)/", $text, $match);
		if($match) {
            echo $adres = trim($match[1]);
			echo $project[TAG_STREET]=(preg_match('/(.*?)\d/s',$adres,$res)) ? trim(strip_tags(($res[1]))) : '';
			preg_match("/bus (\d+|\d+[.]\d+)$/", $adres, $match1);
			if($match1) {

					$project[TAG_BOX_NUMBER]=trim(preg_replace("/[a-zA-Z,]/", "", $match1[1]));
			}

			preg_match("/ (\d+) bus/", $adres, $match2);
			if($match2) {

				$project[TAG_NUMBER]=trim(preg_replace("/[a-zA-Z]/", "", $match2[1]));
			}
			if(empty($project[TAG_NUMBER])) $project[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);

			echo $project[TAG_ZIP] = $match[2];
			echo $project[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));
		}
        if(empty($project[TAG_CITY])){
			preg_match("/(.*),\s(\d{4,})\s+(.*)/", $text, $match);
			if($match) {
				$adres = trim($match[1]);
				preg_match("/bus (\d+|\d+[.]\d+)$/", $adres, $match1);
				if($match1) {

						$project[TAG_BOX_NUMBER]=trim(preg_replace("/[a-zA-Z,]/", "", $match1[1]));
				}

				preg_match("/ (\d+) bus/", $adres, $match2);
				if($match2) {

					$project[TAG_NUMBER]=trim(preg_replace("/[a-zA-Z]/", "", $match2[1]));
				}
				echo $project[TAG_STREET]=(preg_match('/(.*?)\d/s',$adres,$res)) ? trim(strip_tags(($res[1]))) : '';
				if(empty($project[TAG_NUMBER])) $project[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);

				echo $project[TAG_ZIP] = $match[2];
				echo $project[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));
			}
    	}
	}

    if(empty($project[TAG_CITY])) return;
	//parse fields
	$vars = array();
	preg_match_all('!<dt>([^<>]+)</dt><dd>([^<>]+)</dd>!',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('!&nbsp;!','',$arr[1]);
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
  	    $vars[$arr[1]] = str_replace('&nbsp;','',$arr[2]);

		#echo "<br>";
	}
	if (isset($vars['tel'])) {unset($vars['tel']);}
	if (isset($vars['fax'])) {unset($vars['fax']);}
	if (isset($vars['subcategorie'])) {unset($vars['subcategorie']);}
	
	
	if(empty($project[TAG_TYPE])) $project[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
	if(empty($project[TAG_TYPE])) $project[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
	if(empty($project[TAG_TYPE])) $project[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($project[TAG_TEXT_DESC_NL]));
	if(empty($project[TAG_TYPE])) $project[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($project[TAG_PLAIN_TEXT_ALL_NL]));
       
	if(empty($project[TAG_TYPE])) $project[TAG_TYPE] = CrawlerTool::getpropertyType(get_var($vars,"categorie"));
	/**/ 
	$project[TAG_PRICE] = CrawlerTool::toNumber(get_var($vars,'prijs'));
	if(empty($project[TAG_PRICE])) echo $project[TAG_PRICE]=$parser->extract_xpath("p[@class = 'estatePrice']",RETURN_TYPE_NUMBER);

	$project[TAG_KI] = get_var($vars,'kadastraal inkomen  bedrag','!(\d+)!');
	$project[TAG_KI_INDEX] = get_var($vars,"kad.ink. gendexeerd bedrag",'!(\d+)!');
	$project[TAG_FRONTAGE_WIDTH] = get_var($vars,'gevelbreedte');
	$project[TAG_CONSTRUCTION_YEAR] = get_var($vars,'bouwjaar jaar','!(\d{4})!');
	$project[TAG_RENOVATION_YEAR] = get_var($vars,'renovatie jaar','!(\d{4})!');
	$project[TAG_SURFACE_LIVING_AREA] = get_var($vars,'oppervlakte bewoonbaar','!(\d+)!');
	$project[TAG_SURFACE_GROUND] = get_var($vars,'oppervlakte grond','!(\d+)!');
	$project[TAG_BEDROOMS_TOTAL] = get_var($vars,'aantal kamers','!(\d+)!');
	$project[TAG_BATHROOMS_TOTAL] = get_var($vars,'aantal badkamers','!(\d+)!');
	$project[TAG_TOILETS_TOTAL] = get_var($vars,'toiletten aantal','!(\d+)!');
	$project[TAG_FREE_FROM_DATE] = CrawlerTool::toUnixTimestamp(get_var($vars,'beschikbaarheid'));
	$project[TAG_GARAGES_TOTAL] = get_var($vars,'garage aantal','!(\d+)!');
	if(empty($project[TAG_GARAGES_TOTAL])) $project[TAG_GARAGES_TOTAL] = get_var($vars,'garage') == 'Ja' ? 1 : '';
	$project[TAG_PARKINGS_TOTAL] = get_var($vars,'parking buiten aantal','!(\d+)!');
	if(empty($project[TAG_PARKINGS_TOTAL])) $project[TAG_PARKINGS_TOTAL]         = get_var($vars,'parking') == 'Ja' ? 1 : '';
	$project[TAG_AMOUNT_OF_FACADES] = get_var($vars,'gevels','!(\d+)!');
	$project[TAG_AMOUNT_OF_FLOORS] = get_var($vars,'verdiepingen aantal','!(\d+)!');
	$project[TAG_COMMON_COSTS] = get_var($vars,'lasten','!(\d+)!');
	$project[TAG_GAS_CONNECTION] = (get_var($vars,'gas') === "Ja" ? 1 : 0);
	$project[TAG_CONNECTION_TO_WATER] = (get_var($vars,'water') === "Ja" ? 1 : 0);
	$project[TAG_TELEPHONE_CONNECTION] = (get_var($vars,'telefoon') === "Ja" ? 1 : 0);
	$project[TAG_DOUBLE_GLAZING]=CrawlerTool::contains(get_var($vars,'dubbele beglazing') ,"Ja");
	$project[TAG_LIFT] = (get_var($vars,'lift') === "Ja" ? 1 : 0);
	$project[TAG_FURNISHED] = (get_var($vars,'gemeubeld') === "Ja" ? 1 : 0);
	$project[TAG_GARDEN_AVAILABLE] = (get_var($vars,'tuin') === "Ja" ? 1 : 0);
	$project[TAG_OPEN_FIRE] = (get_var($vars,'open haard aantal') === "Ja" ? 1 : 0);
	$project[TAG_ALARM] = (get_var($vars,'alarm') === "Ja" ? 1 : 0);
	$project[TAG_PARLOPHONE] = (get_var($vars,'parlofoon') === "Ja" ? 1 : 0);
	$project[TAG_VIDEOPHONE] = (get_var($vars,'videofoon') === "Ja" ? 1 : 0);
	$project[TAG_SUBDIVISION_PERMIT]=(get_var($vars,'verkavelingvergunning') === "Ja" ? 1 : 0);
	$project[TAG_PRIORITY_PURCHASE]=(get_var($vars,'voorkooprecht') === "Ja" ? 1 : 0);
	$project[TAG_MOST_RECENT_DESTINATION]=(get_var($vars,'terrein bestemming') === "Ja" ? 1 : 0);
	$project[TAG_PLANNING_PERMISSION]=(get_var($vars,'bouwvergunning') === "Ja" ? 1 : 0);
	$project[TAG_FRONTAGE_WIDTH] =get_var($vars,'gevelbreedte breedte');
	$project[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
	{
		 $fileUrls = array();
		 foreach($files as $file)
		 {
			 if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => $file);
		 }
		 return $fileUrls;
	});

	debug($project);
	
	if(empty($project[TAG_STATUS]))
	    $project[TAG_STATUS] = STATUS_FORSALE;	
	
	// WRITING item data to output.xml file
	CrawlerTool::saveProject($project);
	
	if(empty($projectCount)) $projectCount = 0;
	
	if(empty($propertyCount)) $propertyCount = 0;

	if(empty($properties)) $properties = array();

    $items = array();

	$innerNodes = $parser->getNodes("td[contains(@class, 'property')]/span/a");
	foreach($innerNodes as $innerNode) {
		#$property[TAG_IS_NEW_CONSTRUCTION]=1;
        preg_match("/estate\/(\d+)$/", $parser->getAttr($innerNode, "href"), $match);
        if($match) $property[TAG_UNIQUE_ID] = $match[1];
		echo $property[TAG_UNIQUE_URL_NL] = "http://www.vansweevelt.be/estate/detail/" . $property[TAG_UNIQUE_ID];
		$property[TAG_PROJECT_ID]=$project[TAG_PROJECT_ID];
		if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
		$properties[] = $property[TAG_UNIQUE_ID];


		$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}

	foreach($items as $item)
	{
		// keep track of number of properties processed
		$propertyCount += 1;

		// process item to obtain detail information
		echo "--------- Processing property #$propertyCount ...";
		echo $item["itemUrl"]."<br>";
		processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
		echo "--------- Completed<br />";
	}
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
#     $html = $crawler->request('http://www.vansweevelt.be/detail/1615467');

    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));
    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("p[@class = 'sms']");
    if(empty($property[TAG_TEXT_DESC_NL])) $property[TAG_TEXT_DESC_NL]  = preg_match('/<h4>Beschrijving<\/h4>(.*?)<\/div>/si',$html,$res) ? trim(strip_tags($res[1])) : '';
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@id = 'result-detail-c']", RETURN_TYPE_TEXT_ALL);
    
   
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));
     /*  */
    
    $property[TAG_PICTURES] = $parser->extract_xpath("div[contains(@class, 'images')]/div/img", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) {
            $picUrls[] = array(TAG_PICTURE_URL =>  str_replace("des_", "", $pic));
        }

        return $picUrls;
    });


	echo $text = $parser->extract_xpath("p[@class = 'estateAddress']");
	if($text) {
		preg_match("/(.*)\s+(\d{4,})\s+(.*)/", $text, $match);
		if($match) {
            echo $adres = trim($match[1]);
			echo $property[TAG_STREET]=(preg_match('/(.*?)\d/s',$adres,$res)) ? trim(strip_tags(($res[1]))) : '';
			preg_match("/bus (\d+|\d+[.]\d+)$/", $adres, $match1);
			if($match1) {

					$property[TAG_BOX_NUMBER]=trim(preg_replace("/[a-zA-Z,]/", "", $match1[1]));
			}

			preg_match("/ (\d+) bus/", $adres, $match2);
			if($match2) {

				$property[TAG_NUMBER]=trim(preg_replace("/[a-zA-Z]/", "", $match2[1]));
			}
			if(empty($property[TAG_NUMBER])) $property[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);

			echo $property[TAG_ZIP] = $match[2];
			echo $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));
		}
        if(empty($property[TAG_CITY])){
		preg_match("/(.*),\s(\d{4,})\s+(.*)/", $text, $match);
		if($match) {
			$adres = trim($match[1]);
			preg_match("/bus (\d+|\d+[.]\d+)$/", $adres, $match1);
			if($match1) {

					$property[TAG_BOX_NUMBER]=trim(preg_replace("/[a-zA-Z,]/", "", $match1[1]));
			}

			preg_match("/ (\d+) bus/", $adres, $match2);
			if($match2) {

				$property[TAG_NUMBER]=trim(preg_replace("/[a-zA-Z]/", "", $match2[1]));
			}
			echo $property[TAG_STREET]=(preg_match('/(.*?)\d/s',$adres,$res)) ? trim(strip_tags(($res[1]))) : '';
			if(empty($property[TAG_NUMBER])) $property[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);

			echo $property[TAG_ZIP] = $match[2];
			echo $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));
		}
	    }
	}
    if(empty($property[TAG_CITY])) return;
	//parse fields
	$vars = array();
	preg_match_all('!<dt>([^<>]+)</dt><dd>([^<>]+)</dd>!',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('!&nbsp;!','',$arr[1]);
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
  	    $vars[$arr[1]] = str_replace('&nbsp;','',$arr[2]);

		#echo "<br>";
	}
	preg_match_all('!<dt>([^<>]+)</dt>\s+<dd>([^<>]+)</dd>!',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('!&nbsp;!','',$arr[1]);
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
  	    $vars[$arr[1]] = str_replace('&nbsp;','',$arr[2]);

		#echo "<br>";
	}
	if (isset($vars['tel'])) {unset($vars['tel']);}
	if (isset($vars['referentie'])) {unset($vars['referentie']);}
	if (isset($vars['subcategorie'])) {unset($vars['subcategorie']);}

    if(empty($property[TAG_STATUS]))
	$property[TAG_STATUS] = CrawlerTool::getPropertyStatus(get_var($vars,"doel"));
   
	
    
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(get_var($vars,"categorie"));
    $property[TAG_PRICE] = CrawlerTool::toNumber(get_var($vars,'prijs')); 
    if(empty($property[TAG_PRICE])) echo $property[TAG_PRICE]=$parser->extract_xpath("p[@class = 'estatePrice']",RETURN_TYPE_NUMBER);
	$property[TAG_KI] = get_var($vars,'kadastraal inkomen  bedrag','!(\d+)!');
	$property[TAG_KI_INDEX] = get_var($vars,"kad.ink. gendexeerd bedrag",'!(\d+)!');
	$property[TAG_PROPERTY_TAX] = get_var($vars,'onroerende voorheffing bedrag','!(\d+)!');
	$totalfloor = get_var($vars,'verdieping','!(\d+)!');
	if(!empty($totalfloor)) $property[TAG_AMOUNT_OF_FLOORS]=$totalfloor;

	$property[TAG_RENOVATION_YEAR] = get_var($vars,'renovatie jaar','!(\d{4})!');
	$property[TAG_SURFACE_LIVING_AREA] = get_var($vars,'oppervlakte bewoonbaar','!(\d+)!');
	$property[TAG_SURFACE_GROUND] = get_var($vars,'oppervlakte grond','!(\d+)!');
	$property[TAG_BEDROOMS_TOTAL] = get_var($vars,'aantal kamers','!(\d+)!');
	$property[TAG_BATHROOMS_TOTAL] = get_var($vars,'aantal badkamers','!(\d+)!');
	$property[TAG_TOILETS_TOTAL] = get_var($vars,'toiletten aantal','!(\d+)!');
	$property[TAG_FREE_FROM_DATE] = CrawlerTool::toUnixTimestamp(get_var($vars,'beschikbaarheid'));
	$property[TAG_GARAGES_TOTAL] = get_var($vars,'garage aantal','!(\d+)!');
	if(empty($property[TAG_GARAGES_TOTAL])) $property[TAG_GARAGES_TOTAL] = get_var($vars,'garage') == 'Ja' ? 1 : '';
	$property[TAG_PARKINGS_TOTAL] = get_var($vars,'parking buiten aantal','!(\d+)!');
	if(empty($property[TAG_PARKINGS_TOTAL])) $property[TAG_PARKINGS_TOTAL]         = get_var($vars,'parking') == 'Ja' ? 1 : '';
	$property[TAG_AMOUNT_OF_FACADES] = get_var($vars,'gevels','!(\d+)!');
	$property[TAG_AMOUNT_OF_FLOORS] = get_var($vars,'verdiepingen aantal','!(\d+)!');
	$property[TAG_COMMON_COSTS] = get_var($vars,'lasten','!(\d+)!');
	$property[TAG_GAS_CONNECTION] = (get_var($vars,'gas') === "Ja" ? 1 : 0);
	$property[TAG_CONNECTION_TO_WATER] = (get_var($vars,'water') === "Ja" ? 1 : 0);
	$property[TAG_TELEPHONE_CONNECTION] = (get_var($vars,'telefoon') === "Ja" ? 1 : 0);
	$property[TAG_DOUBLE_GLAZING]=CrawlerTool::contains(get_var($vars,'dubbele beglazing') ,"Ja");
	$property[TAG_LIFT] = (get_var($vars,'lift') === "Ja" ? 1 : 0);
	$property[TAG_FURNISHED] = (get_var($vars,'gemeubeld') === "Ja" ? 1 : 0);
	$property[TAG_GARDEN_AVAILABLE] = (get_var($vars,'tuin') === "Ja" ? 1 : 0);
	$property[TAG_OPEN_FIRE] = (get_var($vars,'open haard aantal') === "Ja" ? 1 : 0);
	$property[TAG_ALARM] = (get_var($vars,'alarm') === "Ja" ? 1 : 0);
	$property[TAG_PARLOPHONE] = (get_var($vars,'parlofoon') === "Ja" ? 1 : 0);
	$property[TAG_VIDEOPHONE] = (get_var($vars,'videofoon') === "Ja" ? 1 : 0);
	$property[TAG_SUBDIVISION_PERMIT]=(get_var($vars,'verkavelingvergunning') === "Ja" ? 1 : 0);
	$property[TAG_PRIORITY_PURCHASE]=(get_var($vars,'voorkooprecht') === "Ja" ? 1 : 0);
	$property[TAG_MOST_RECENT_DESTINATION]=(get_var($vars,'terrein bestemming') === "Ja" ? 1 : 0);
	$property[TAG_PLANNING_PERMISSION]=(get_var($vars,'bouwvergunning') === "Ja" ? 1 : 0);
	$property[TAG_FRONTAGE_WIDTH] =get_var($vars,'gevelbreedte');
	$property[TAG_SURFACE_CONSTRUCTION] = get_var($vars,'bruto oppervlakte','!(\d+)!');
	$property[TAG_HEATING_NL] = get_var($vars,'verwarming');
	$property[TAG_CONSTRUCTION_YEAR]=get_var($vars,'bouwjaar','!(\d{4})!');
	$property[TAG_HAS_PROCEEDING] =CrawlerTool::contains(get_var($vars,'dagvaarding'),'Ja');
 	preg_match_all("/slaapkamer (\d+)/s",$html,$res1);
    $count=0;
 	$set=0;
 	foreach($res1[1] as $arr)
	{
        $bedroomsurface=get_var($vars,'slaapkamer '.$arr,'!(\d+)!');

        $bedroom[TAG_BEDROOM_SURFACE]=$bedroomsurface;
        if(!empty($bedroom)) $totalbedrooms[] = $bedroom;
        if(!empty($totalbedrooms)) $property[TAG_BEDROOMS] = $totalbedrooms;

	}
    $bedrooms=get_var($vars,'slaapkamers');
    $livings=get_var($vars,'woonkamer');
    $Garages=get_var($vars,'garage');
    $bathrooms=get_var($vars,'badkamers');
    $toilets=get_var($vars,'toiletten');
    $kitchens=get_var($vars,'keuken');
    $storages=get_var($vars,'berging');
    $terraces=get_var($vars,'terras');
    if(empty($terraces)) $terraces=get_var($vars,'terras 1');
    $cellars=get_var($vars,'kelder');
    $halls=get_var($vars,'hal');
    $studies=get_var($vars,'kantoor','!(\d+)!');
    $freepossesions=get_var($vars,'praktijkruimte');
    $attics=get_var($vars,'zolder');
    $rooms=get_var($vars,'aantal kamers');
    if(!empty($rooms)) $room=$parser->regex("/(\d)$/", $rooms);

    if(!empty($bedrooms)) $bedroomtotal=$parser->regex("/(\d)$/", $bedrooms);
    if(!empty($attics)) $attictotal=$parser->regex("/(\d)$/", $attics);
    if(!empty($livings)) $livingtotal=$parser->regex("/(\d)$/", $livings);
    if(!empty($Garages)) $garagetotal=$parser->regex("/(\d)$/", $Garages);
    if(!empty($bathrooms)) $bathroomtotal=$parser->regex("/(\d)$/", $bathrooms);
    if(!empty($toilets)) $toilettotal=$parser->regex("/(\d)$/", $toilets);
    if(!empty($kitchens)) $kitchentotal=$parser->regex("/(\d)$/", $kitchens);
    if(!empty($storages)) $storagetotal=$parser->regex("/(\d)$/", $storages);
    if(!empty($terraces)) $terracetotal=$parser->regex("/(\d)$/", $terraces);
    if(!empty($cellars)) $cellartotal=$parser->regex("/(\d)$/", $cellars);
    if(!empty($halls)) $halltotal=$parser->regex("/(\d)$/", $halls);
    if(!empty($studies)) $studytotal=$parser->regex("/(\d)$/", $studies);
    if(!empty($freepossesions)) $freepossesiontotal=$parser->regex("/(\d)$/", $freepossesions);

    if(!empty($bedrooms)) $bedroomsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $bedrooms);
    if(!empty($attics)) $atticsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $attics);
    if(!empty($livings)) $livingsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $livings);
    if(!empty($Garages)) $garagesurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $Garages);
    if(!empty($bathrooms)) $bathroomsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $bathrooms);
    if(!empty($toilets)) $toiletsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $toilets);
    if(!empty($kitchens)) $kitchensurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $kitchens);
    if(!empty($storages)) $storagesurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $storages);
    if(!empty($terraces)) $terracesurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $terraces);
    if(!empty($cellars)) $cellarsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $cellars);
    if(!empty($halls)) $hallsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $halls);
    if(!empty($studies)) $studysurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $studies);
    if(!empty($freepossesions)) $freepossesionsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $freepossesions);

  #  if(empty($terracesurface)) $terracesurface=$parser->extract_xpath("Terras opervlakte",RETURN_TYPE_NUMBER);
  #  if(empty($cellarsurface)) $cellarsurface=$parser->extract_xpath("Kelder opp",RETURN_TYPE_NUMBER);

    $bedroomdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $bedrooms);
    $atticdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $attics);

    $garagedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $Garages);
    $bathroomdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $bathrooms);
    $toiletdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $toilets);
    $kitchendesc=$parser->regex("/([a-zA-Z_-\s]*)/", $kitchens);
    $storagedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $storages);
    $terracedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $terraces);
    $cellardesc=$parser->regex("/([a-zA-Z_-\s]*)/", $cellars);
    $livingdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $livings);
    $floorplandesc=$parser->regex("/([a-zA-Z_-\s]*)/", $parser->extract_xpath("Grondplannen"));
    $halldesc=$parser->regex("/([a-zA-Z_-\s]*)/", $halls);
    $studydesc=$parser->regex("/([a-zA-Z_-\s]*)/", $studies);
    $freepossesiondesc=$parser->regex("/([a-zA-Z_-\s]*)/", $freepossesions);


 	preg_match_all("/Slaapkamer (\d+)/s",$html,$res1);
    $count=0;
 	$set=0;
 	foreach($res1[1] as $arr)
	{
        $bedroomsurface=get_var($vars,'slaapkamer '.$arr,'!(\d+)!');

        $bedroom[TAG_BEDROOM_SURFACE]=$bedroomsurface;
        if(!empty($bedroom)) $totalbedrooms[] = $bedroom;
        if(!empty($totalbedrooms)) $property[TAG_BEDROOMS] = $totalbedrooms;

	}

 	preg_match_all("/Badkamer (\d+)/s",$html,$res1);
    $count=0;
 	$set=0;
 	foreach($res1[1] as $arr)
	{
        $bathroomsurface=get_var($vars,'badkamer '.$arr,'!(\d+)!');

        $bathroom[TAG_BATHROOM_SURFACE]=$bathroomsurface;
        if(!empty($bathroom)) $totalbathrooms[] = $bathroom;
        if(!empty($totalbathrooms)) $property[TAG_BATHROOMS] = $totalbathrooms;

	}

    $halls = array();
    $totalhalls = array();
    if(!empty($halldesc)) 		 $halls[TAG_HALL_DESC_NL]=$halldesc;
    if(!empty($hallsurface)) 		 $halls[TAG_HALL_SURFACE]=$hallsurface;
    if(!empty($halls)) $totalhalls[] = $halls;
    if(!empty($totalhalls)) $property[TAG_HALLS] = $totalhalls;

    $freepossesion = array();
    $totalfreepossesions = array();
    if(!empty($freepossesiondesc)) 		 $freepossesion[TAG_FREE_PROFESSION_DESC_NL]=$freepossesiondesc;
    if(!empty($freepossesionsurface)) 		 $freepossesion[TAG_FREE_PROFESSION_SURFACE]=$freepossesionsurface;
    if(!empty($freepossesion)) $totalfreepossesions[] = $freepossesion;
    if(!empty($totalfreepossesions)) $property[TAG_FREE_PROFESSIONS] = $totalfreepossesions;

    $study = array();
    $totalstudys = array();
    if(!empty($studydesc)) 		 $study[TAG_STUDY_DESC_NL]=$studydesc;
    if(!empty($studysurface)) 		 $study[TAG_STUDY_SURFACE]=$studysurface;
    if(!empty($study)) $totalstudys[] = $study;
    if(!empty($totalstudys)) $property[TAG_STUDIES] = $totalstudys;

    $attic = array();
    $totalattics = array();
    if(!empty($atticdesc)) 		 $bathroom[TAG_ATTIC_DESC_NL]=$atticdesc;
    if(!empty($atticsurface)) 		 $bathroom[TAG_ATTIC_SURFACE]=$atticsurface;
    if(!empty($attic)) $totalattics[] = $attic;
    if(!empty($totalattics)) $property[TAG_ATTICS] = $totalattics;

    $cellar = array();
    $totalcellars = array();
    if(!empty($cellardesc)) 		 $cellar[TAG_CELLAR_DESC_NL]=$cellardesc;
    if(!empty($cellarsurface)) 		 $cellar[TAG_CELLAR_SURFACE]=$cellarsurface;
    if(!empty($cellar)) $totalcellars[] = $cellar;
    if(!empty($totalcellars)) $property[TAG_CELLARS] = $totalcellars;

    $toilet = array();
    $totaltoilets = array();
    if(!empty($toiletdesc)) 		 $toilet[TAG_TOILET_DESC_NL]=$toiletdesc;
    if(!empty($toiletsurface)) 		 $toilet[TAG_TOILET_SURFACE]=$toiletsurface;
    if(!empty($toilet)) $totaltoilets[] = $toilet;
    if(!empty($totaltoilets)) $property[TAG_TOILETS] = $totaltoilets;

    $garage = array();
    $totalgarages = array();
    if(!empty($garagedesc)) 		 $garage[TAG_GARAGE_DESC_NL]=$garagedesc;
    if(!empty($garagesurface)) 		 $garage[TAG_GARAGE_SURFACE]=$garagesurface;
    if(!empty($garage)) $totalgarages[] = $garage;
    if(!empty($totalgarages)) $property[TAG_GARAGES] = $totalgarages;

    $kitchen = array();
    $totalkitchens = array();

    if(!empty($kitchendesc)) 		 $kitchen[TAG_KITCHEN_DESC_NL]=$kitchendesc;
    if(!empty($kitchensurface)) 		 $kitchen[TAG_KITCHEN_SURFACE]=$kitchensurface;
    if(!empty($kitchen)) $totalkitchens[] = $kitchen;
    if(!empty($totalkitchens)) $property[TAG_KITCHENS] = $totalkitchens;

    $storage = array();
    $totalstorages = array();
    if(!empty($storagedesc)) 		 $storage[TAG_STOREROOM_DESC_NL]=$storagedesc;
    if(!empty($storagesurface)) 		 $storage[TAG_STOREROOM_SURFACE]=$storagesurface;
    if(!empty($storage)) $totalstorages[] = $storage;
    if(!empty($totalstorages)) $property[TAG_STOREROOMS] = $totalstorages;

    $terrace = array();
    $totalterraces = array();
    if(!empty($terracedesc)) 		 $terrace[TAG_TERRACE_DESC_NL]=$terracedesc;
    if(!empty($terracesurface)) 		 $terrace[TAG_TERRACE_SURFACE]=$terracesurface;
    if(!empty($terrace)) $totalterraces[] = $terrace;
    if(!empty($totalterraces)) $property[TAG_TERRACES] = $totalterraces;

    $living = array();
    $totallivings = array();
    if(!empty($livingdesc)) 		 $living[TAG_LIVING_DESC_NL]=$livingdesc;
    if(!empty($livingsurface)) 		 $living[TAG_LIVING_SURFACE]=$livingsurface;
    if(!empty($living)) $totallivings[] = $living;
    if(!empty($totallivings)) $property[TAG_LIVINGS] = $totallivings;

    if(empty($bedroomtotal) && !empty($room))  $bedroomtotal=$room;
    if(!empty($bedroomtotal))  $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT]=$bedroomtotal;

    if(!empty($livingtotal))  $property[TAG_LIVINGS][TAG_TOTAL_AMOUNT]=$livingtotal;
    if(!empty($toilettotal)) $property[TAG_TOILETS][TAG_TOTAL_AMOUNT]=$toilettotal;
    if(!empty($cellartotal)) $property[TAG_CELLARS][TAG_TOTAL_AMOUNT]=$cellartotal;
    if(!empty($kitchentotal)) $property[TAG_KITCHENS][TAG_TOTAL_AMOUNT]=$kitchentotal;

    if(!empty($garagetotal)) $property[TAG_GARAGES][TAG_TOTAL_AMOUNT]=$garagetotal;
    if(!empty($terracetotal)) $property[TAG_TERRACES][TAG_TOTAL_AMOUNT]=$terracetotal;
    if(!empty($storagetotal)) $property[TAG_STOREROOMS][TAG_TOTAL_AMOUNT]=$storagetotal;
    if(!empty($attictotal)) $property[TAG_ATTICS][TAG_TOTAL_AMOUNT]=$attictotal;

    if(!empty($garagetotal)) $property[TAG_GARAGES][TAG_TOTAL_AMOUNT]=$garagetotal;
    $property[TAG_GARDEN_AVAILABLE] =get_var($vars,'tuin') == 'Ja' ? 1 : '';
    $parkingtotal=get_var($vars,'parkeerplaatsen','!(\d+)!');
    if(!empty($parkingtotal))  $property[TAG_PARKINGS_TOTAL]=$parkingtotal;

    $property[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
	 {
		 $fileUrls = array();
		 foreach($files as $file)
		 {
			 if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => $file);
		 }
		 return $fileUrls;
    });

	$unmatched_variables = array();
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	}
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;

	if(intval($property[TAG_PRICE]) < 1000)
	    $property[TAG_STATUS] = STATUS_FORRENT;
	    else
	    $property[TAG_STATUS] = STATUS_FORSALE;
	    
	$key = clearForLowerCase($property[TAG_CITY]);
	 
	if(stripos('x'.$key,"geel") !== false)
	$property[TAG_OFFICE_ID] = 3;
	
	if(stripos('x'.$key,"herentals") !== false)
	$property[TAG_OFFICE_ID] = 2;
	
	if(stripos('x'.$key,"turnhout ") !== false)
	$property[TAG_OFFICE_ID] = 1;
	 
	debug($property);
	// WRITING item data to output.xml file
	CrawlerTool::saveProperty($property);
}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

/// Basic checking for 
function clearForLowerCase($str = ''){ 
    $str = strtolower(str_replace(' ','_',$str)); 
    $str = trim(strip_tags($str)); 
    //$str = preg_replace('![^a-z0-9_\-\. ]!','',$str); 
    // $str = trim(preg_replace('!nbsp!','',$str)); 
    $str = trim(preg_replace('!ja,!','',$str));
    //$str = trim(preg_replace('!,!','',$str));
    $str = trim(normalize_str($str));
    return $str ;
 
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}