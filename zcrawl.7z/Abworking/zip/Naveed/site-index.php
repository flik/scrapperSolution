<title>Grab Website (Learning Task)</title>
<?php
	include('simple_html_dom.php');
	$url 		= "http://www.immocosemans.be/Web.mvc/nl-be/List1?Sel=VGUga29vcA%3D%3D"; // for sale only
	$html 		= file_get_html($url);
	$list 		= $html->find('div[class=list-mosaic-img]');
	$mainUrl	= 'http://www.immocosemans.be/';
	$properties = array();
	foreach($list as $property){
		$link 			= $property->children[0]->attr['href'];
		$propertyLink 	= $mainUrl.$link;

		$propertyHtml 	= file_get_html($propertyLink);

		$propertyTitle 	= $propertyHtml->find('p[class=Subtitle]');
		$prop['title']  = trim($propertyTitle[0]->innertext);

		$addressVar 	= $propertyHtml->find('td[class=SubtitleSmall4]');
		$address 		= explode(' ', trim($addressVar[0]->innertext));
		$prop['address']['zipcode']	= $address[0];
		$prop['address']['city']	= $address[1];

		$aboutVar 		= $propertyHtml->find('p[class=Text]');
		$prop['about']	= trim($aboutVar[0]->innertext);

		foreach($propertyHtml->find('ul[class=bxSlider] li') as $img){
			$prop['images'][] = $mainUrl.$img->children[0]->attr['href'];
		}

		$contactTitleVar= $propertyHtml->find('table[class=contact-details] span[class=SubtitleSmall6]');
		$contactPhoneVar= $propertyHtml->find('table[class=contact-details] span[class=TitleSmall6]');
		$contactEmailVar= $propertyHtml->find('table[class=contact-details] span[class=TitleSmall6]');
		$prop['contact']['title'] = trim($contactTitleVar[0]->innertext);
		$prop['contact']['phone'] = trim($contactPhoneVar[0]->innertext);
		$prop['contact']['email'] = trim($contactEmailVar[0]->innertext);

		$properties[]	= $prop;
	}
	pr($properties);
	/*****************/
	function pr($var){
		echo '<pre>';
		print_r($var);
		echo '</pre>';
	}
