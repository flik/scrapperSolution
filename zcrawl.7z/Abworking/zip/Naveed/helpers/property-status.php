<?php
$propertyStatus = CrawlerTool::getPropertyStatus($text);
if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
{
    $property[TAG_STATUS] = $propertyStatus;
}

//Out of Belgium
if($property[TAG_UNIQUE_ID] == '1590360' )
return;
	
//Return in case of sold or rented
if($property[TAG_STATUS]==STATUS_SOLD)	 return ;
if($property[TAG_STATUS]==STATUS_RENTED) return ;

if(strpos($html,"VERHUURD") || strpos($html,"Verhuurd")){
    $property[TAG_STATUS] = "rented"; return;
}
if(strpos($html,"VERKOCHT") || strpos($html,"Verkocht")){
    $property[TAG_STATUS] = "sold"; return;
}