<?php
if($property['is_project']==1){
	unset($property['is_project']);
	
	$property[TAG_PROJECT_ID] = $property[TAG_UNIQUE_ID] ;
	CrawlerTool::saveProject($property);
}else{
	CrawlerTool::saveProperty($property);
}