<?php
//returning value in defined type
function GetExactAttrib($key,$val){
 
    switch($key){
	
	case TAG_BATHROOMS_TOTAL:
	    return CrawlerTool::toNumber($val); 
	break;
    
	case TAG_BEDROOMS_TOTAL:
	    return CrawlerTool::toNumber($val); 
	break;
    
	case TAG_CONSTRUCTION_YEAR:
	    return CrawlerTool::toNumber($val); 
	break;
	
	case TAG_EPC_CERTIFICATE_NUMBER:
	    return CrawlerTool::toNumber($val); 
	break;
	
	case TAG_SURFACE_LIVING_AREA:
	   return CrawlerTool::toNumber($val); 
	break;

	case TAG_MOST_RECENT_DESTINATION:
	   return array(TAG_MOST_RECENT_DESTINATION_INFORMATION_NL=>$val); 
	break;

	case TAG_PLANNING_PERMISSION:
	   return 1; 
	break;
	
	case TAG_SUBDIVISION_PERMIT:
	   return CrawlerTool::toNumber($val); 
	break;


	default:
		return CrawlerTool::toNumber($val);  
	break;
	 
    }
}

//url friendly conversion of string (replaces space with dashes)
function clean($string) {
   $string = str_replace(' ', '', $string); // Replaces all spaces with hyphens.

   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}

//print_r a variable
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
}

//separting from top/bottom print_r a variable
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;	
}

//get value from html by giving start and end tokens (get between value)
function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
} 

//remove brakcets from string
function removeBrackets($str){
	$str = str_replace('–','',$str);
	$str = str_replace('(','',$str);
	$str = str_replace(')','',$str);
	$str = str_replace('-','',$str);
	return $str;
}
	
//get regex result from string	
function regex($exp, $text, Closure $closure = null){
	if(preg_match($exp, $text, $match))
	{
	    if(empty($closure))
	    {
		return trim($match[1]);
	    }
	    else
	    {
		return $closure($match);
	    }
	}
	
	return "";
}

//special characters
function normalize_str($str) {
    $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");

    $str = str_replace(array_keys($invalid), '', $str); //array_values($invalid)
    return $str;
}	

//extract Address from a string	
function extractAddress($address){
	$street = "";
	if (strpos($address, ',') !== false) {
		list($number, $street) = explode(',', $address, 2);
	} else {
		preg_match('~^(.*?)((?:unit )?(?:[0-9]+\s?-\s?[0-9]+|[0-9]+))(.*)$~is', $address, $parts);
		
		$number = $parts[2];
		if (trim($parts[1]) != '') {
			$street .= trim($parts[1]);
		}
		if(trim($parts[3]) != '') {
			if($street ==""){
				$street .= trim($parts[3]);
			}
			else{
				$street .= " ".trim($parts[3]);	
			}
		}
	}
	return $number."|||".$street;
}

//Function for Handle Attributes (by Ashfaq)
function setAtributesX($key='',$lan='nl'){ 
    
    $attrib['nl'] = array('Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Badkamer'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'Kadastraal_inkomen'=>TAG_KI, 'Geïndexeerd_kad._inkomen'=>TAG_KI_INDEX,
			'Grondoppervlakte'=>TAG_SURFACE_GROUND, 'Gevelbreedte'=>TAG_FRONTAGE_WIDTH,
			'Verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Badkamer'=>TAG_BATHROOM_SURFACE,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'keuken'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Aantal_slaapkamers'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'Bouwjaar'=>TAG_CONSTRUCTION_YEAR, 'Bewoonb_opp.'=>TAG_SURFACE_GROUND,
			'Parkings'=>TAG_PARKINGS,'Garages'=>TAG_GARAGES_TOTAL, 'Aantal_garages'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'Bewoonbare_oppervlakte'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Tuin'=>TAG_WINTERGARDENS,
			'Gemeubeld'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terras'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE, 'EPC'=>TAG_EPC_VALUE, 'EPC_Certificaat'=>TAG_EPC_CERTIFICATE_NUMBER,
			'Bestemming'=>TAG_MOST_RECENT_DESTINATION, 'Verkavelingvergunning'=>TAG_SUBDIVISION_PERMIT, 'Bouwvergunning'=>TAG_PLANNING_PERMISSION,
			'Voorkooprecht'=>TAG_PRIORITY_PURCHASE
			);
    
    $attrib['fr'] = array( 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Nombre_de_salle_de_bain'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'cuisine'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'année_de_construction_année'=>TAG_CONSTRUCTION_YEAR, 'Taille_terrain_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'surface_nette_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Jardin'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrasse'=>TAG_TERRACES,'Facades'=>TAG_AMOUNT_OF_FACADES,
			'Catégorie'=>TAG_TYPE
			);
    
    $attrib['en'] = array('Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Number_of_bathrooms'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'kitchen'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Number_of_rooms'=>TAG_BEDROOMS_TOTAL,
			'construction_year_year'=>TAG_CONSTRUCTION_YEAR, 'Plot_size_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL, 'Type'=>TAG_TYPE,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'habitable_-_surface_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Garden'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrace'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE
			);
    
    if(!empty($key)){
	
	if( array_key_exists($key, $attrib[$lan]) ){
	    return $attrib[$lan][$key];
	}
	else
	    return '';
    }else
	return '';
	
}

function getLanguageText($crawler, &$property)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
    $html = str_replace("±", "", $html);
    $parser = new PageParser($html, true);

    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);

}

function removeEmptyIndex($property){
 foreach($property as $k=>$v){
		if(empty($v))
		unset($property[$k]);
		
			if(is_array($v)){ 
				foreach($v as $kx=>$vx){ 
					if(empty($vx)){ 
						unset($v[$kx]);
						unset($property[$k]);
					}
				}
			}	
	}
	return $property; 
}