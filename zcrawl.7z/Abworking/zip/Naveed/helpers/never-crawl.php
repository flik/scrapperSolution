<?php
if(!empty(strpos($property[TAG_TEXT_DESC_NL],"Loué")))
	return;
 
$stpos = strpos($property[TAG_TEXT_DESC_NL], "in optie");
if(!empty($stpos))
	return;

$stpos = strpos($property[TAG_TEXT_DESC_NL], "met optie");
if(!empty( $stpos ))
	return;
	
$stpos = strpos($property[TAG_TEXT_DESC_NL], "optie");
if(!empty( $stpos ))
	return;
	
$stpos = strpos($property[TAG_TEXT_DESC_NL], "verkocht");
if(!empty( $stpos ))
	return;