<?php
	$files = array();
	$nodes = $parser->getNodes("a[contains(@href, 'GetFile.ashx?path=Documents')]");
	foreach($nodes as $node)
	{
		$fileUrl = "http://www.teamproperty.be/" . $parser->regex("/path=(.*)&/", $parser->getAttr($node, "href"));
		$fileTitle = $parser->getText($node);
		$files[] = array(TAG_FILE_URL => $fileUrl, TAG_FILE_TITLE_NL => $fileTitle);
	}
	if(!empty($files)) $property[TAG_FILES] = $files;
 
	$property[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
	     {
		     $fileUrls = array();
		     foreach($files as $file)
		     {
			     if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => "http://www.hetlandgoed.be/".str_replace('../','',$file));
		     }
		     return $fileUrls;
	});