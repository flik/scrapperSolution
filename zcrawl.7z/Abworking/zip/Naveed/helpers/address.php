<?php
// Getting 4 Digit number 
if(empty($property[TAG_CITY])){
	$address = $parser->extract_xpath("table[@class = 'infolijst']/tr/td[2]", RETURN_TYPE_TEXT);
	$address = $parser->extract_xpath("p[@class = 'extrainfo']", RETURN_TYPE_TEXT); 
		
	CrawlerTool::parseAddress(preg_replace("/,|\//", "", $address), $property);
		
	$addr = explode(' ',$address);
	$property[TAG_CITY] = trim($addr[count($addr)-1]);
	$property[TAG_ZIP] =  $parser->regex("/(\d{4})/", $address );
		
	$property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
	$property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
		
	$property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
	$property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
		
	if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
	unset($property[TAG_BOX_NUMBER]);
}
//$property[TAG_STREET] = trim($addr[0]);
//$property[TAG_NUMBER] = $parser->regex("/(\d{2})/", $address ); 
/*******************************************************************/
//Complex address 
$street= $parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[1]");
$property[TAG_CITY] = str_replace('REF','',str_replace('RES','',(preg_replace("/\(.*\)|\d/", "", $street ))));
/***********************************************************************/
$address = $parser->extract_xpath("table[@class = 'infolijst']/tr/td[2]", RETURN_TYPE_TEXT); 
CrawlerTool::parseAddress(preg_replace("/,|\//", "", $address), $property);
//debugx($address);
	
$addr = explode(' ',$address);
$zip = trim($addr[count($addr)-2]);
	
if(!empty($zip))
    $property[TAG_ZIP] = $zip;
	
//$property[TAG_STREET] = trim($addr[0]);
$bx = explode(' ',$property[TAG_BOX_NUMBER]);

if(isset($bx[2]))
$property[TAG_BOX_NUMBER] = $bx[0];
else
unset($property[TAG_BOX_NUMBER]);
	
$property[TAG_CITY] = trim($addr[count($addr)-1]);
/***************************************************************************/
// Seprate the Street
$street=preg_replace('@,.+\Z@','',$adress);
if(empty($property[TAG_NUMBER])) $property[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);
/****************************************************************************/
///Set  Street Detail another way
$property[TAG_STREET]=(preg_match('/(.*?)\d/s',$adres,$res)) ? trim(strip_tags(($res[1]))) : '';
preg_match('!\d+[A-Za-z]\d+|\d+\-\d+|\d+[A-Za-z]|\d+\s+\/\d+[A-Za-z]|\d+|$!',$adres,$res2);
$property[TAG_NUMBER]=trim($res2[0]);
/****************************************************************************/
$property[TAG_ZIP] = $parser->extract_xpath("b[contains(text(), 'postcode:')]/following-sibling::text()[1]");
     
$res = explode(' ', $adr);
$property[TAG_CITY] = trim($res[count($res)-1]);
	
//Parsing Address
CrawlerTool::parseAddress( trim($adr), $property );
	
$property[TAG_CITY] = trim($res[count($res)-1]);
	
///Zip Fixation with city name  (because these cities are double in belgium with different zips, and then the parser does not know which one to choose)
if(strtolower($property[TAG_CITY])=='kapellen')
	$property[TAG_ZIP] = "2950";
	
if(strtolower($property[TAG_CITY])=='halle')
	$property[TAG_ZIP] = "2980";
	
if(strtolower($property[TAG_CITY])=='deurne')
	$property[TAG_ZIP] = "2100";
		
if(strtolower($property[TAG_CITY])=='tielt')
	$property[TAG_ZIP] = "8700";