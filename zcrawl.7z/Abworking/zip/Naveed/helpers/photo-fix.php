<?php
	$property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox']", RETURN_TYPE_ARRAY, function($pics)
	{
		$picUrls = array();
		foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.uniximmo.com" . $pic);

		return $picUrls;
	});
 	
	$street = $parser->extract_xpath("div[@class= 'detail-part1']/table/tr[2]");
	
	//////////////////////////// TWO
	$pics = $parser->getNodes("ul[@class = 'bxSlider']/li/img");
	 
	foreach($pics as $picx){
	    
	    $pic = $parser->getAttr($picx, "src");        
	    $picUrls[] = array(TAG_PICTURE_URL => $pic);
	}
	
	$property[TAG_PICTURES] = $picUrls;

	//////////////////////////// THREE
	$property[TAG_PICTURES] =  $parser->extract_xpath("div[@id = 'wowslider-images']/a/img/@src", RETURN_TYPE_ARRAY, function($pics)
	{
	    $picUrls = array();
	    foreach($pics as $pic) {
    
		$picUrls[] = array(TAG_PICTURE_URL => $pic);
    
	    }
    
	    return $picUrls;
	});
/**************************************************/
////////////////////////////// Get Pictures by Script ///////////////////////////////////////////////
//if(preg_match("/Array\(([^"]*)\)/", $html, $match)){
preg_match_all('#Array\((.*?)\)#s', $html, $result);
    
$pics = array();
    
foreach($result[1] as $res){
    $pics[] = str_replace("'","",$res);
}
unset($pics[0]);
foreach($pics as $pic){
    $p = explode(', ',$pic);
    $picx = 'http://www.av-vastgoed.be/images/panden/'.$p[1];
    $picUrls[] = array(TAG_PICTURE_URL =>  $picx);
}
$property[TAG_PICTURES] = $picUrls;