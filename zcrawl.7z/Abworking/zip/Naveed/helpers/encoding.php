<?php
$parser = new PageParser($html, true); 
$property[TAG_TEXT_DESC_FR] = utf8_decode($parser->extract_xpath("table[@border = '1' and not(@cellpadding)]")); 
$property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode($parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL)); 