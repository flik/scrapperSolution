<?php
	$contact_href 	= $parser->extract_xpath("iframe[contains(@src, 'contactform')]/@src");
	$nodes 			= $parser->getNodes("a[. = 'Meer info']");
 	$pattern 		= '@<span class="txtvraagprijswaarde">(.+?)</span>@si';
	preg_match($pattern, $html, $price);
	if (isset($price[1])) {
	    $property[TAG_PRICE] = CrawlerTool::toNumber(str_replace('&#8364;', '', ( strip_tags($price[1]))));
	}

	//Get Gext Between td tags
	preg_match_all('#<td>(.*?)</td>#s', $html, $result);
	
	$property[TAG_UNIQUE_URL_FR] = str_replace('nl-be','fr-fr',$property[TAG_UNIQUE_URL_NL]);
	$property[TAG_UNIQUE_URL_EN] = str_replace('nl-be','en-gb',$property[TAG_UNIQUE_URL_NL]);
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_FR]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style"));
	$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@id = 'details_left']/div[1]"))); 
	$property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL)));
	if(empty($property[TAG_TEXT_DESC_NL])){
		
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
		$res[1] = str_replace(chr(11),'',$res[1]);
		$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode(strip_tags($res[1])));
	}