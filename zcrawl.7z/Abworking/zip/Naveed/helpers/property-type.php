<?php
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));


// website says type: meublé means that it is an apartment with furniture
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL], 999);
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(str_replace('meublé','apartment',$property[TAG_TEXT_DESC_NL]));
$propertyStatus = CrawlerTool::getPropertyStatus($text);
if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
{
    $property[TAG_STATUS] = $propertyStatus;
}


/*****************************************************/
$startPages[STATUS_FORSALE] = array
(
    TYPE_HOUSE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/woningen-villas/"
    ),
    TYPE_APARTMENT        =>  array
    (
        "http://www.immo-isca.be/nl/Type/appartement/"
    ),
    TYPE_NONE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/opbrengstpanden/"
    ),
    TYPE_COMMERCIAL        =>  array
    (
        "http://www.immo-isca.be/nl/Type/handel-kantoor/"
    ),
    TYPE_GARAGE        =>  array
    (
        "http://www.immo-isca.be/nl/Type/garages/"
    ),
    TYPE_PLOT        =>  array
    (
        "http://www.immo-isca.be/nl/Type/garages/"
    ),
);