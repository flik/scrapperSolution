<?php
$html 	= $crawler->request($property[TAG_UNIQUE_URL_EN]); 
$parser = new PageParser($html, true); 
$parser->deleteTags(array("script", "style")); 
$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@id = 'details_left']/div[1]"))); 
$property[TAG_PLAIN_TEXT_ALL_EN] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL))); 
	
if(empty($property[TAG_TEXT_DESC_NL])){
	preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
	$res[1] 					= str_replace(chr(11),'',$res[1]);
	$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode(strip_tags($res[1])));
}
	
///Getting Unique ID
CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL])
	 	
CrawlerTool::toNumber(); 
CrawlerTool::encode($property[TAG_STREET]); 
///Getting link with node html
$link = $parser->extract_xpath("div[@class = 'title']/h2/a/@href", RETURN_TYPE_TEXT, null, $node); 
	
$price = $parser->extract_xpath("parent::div[1]/preceding-sibling::div[1]/h2", RETURN_TYPE_NUMBER, null, $node);
	
CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
/************************************************************************/
CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
	
CrawlerTool::toNumber(); 
CrawlerTool::encode($property[TAG_STREET]);

if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
	
$hiddenFields = $parser->getNodes("input[@type = 'hidden']");

$postData = "";
foreach($hiddenFields as $field) {
    $name = $parser->getAttr($field, "name");
    $value = $parser->getAttr($field, "value");
    if($name !== "__EVENTTARGET") {
	$postData .= "&" . $name . "=" . urlencode($value);
    }
}
	
$pageList = array();

$property[TAG_TEXT_TITLE_NL]=$parser->extract_xpath("div[@class = 'bloc_content_title']/span[2]");
	
if(empty($property[TAG_PRICE])) $property[TAG_PRICE] = $parser->extract_xpath("div[@class = 'bloc_content_title']/span[1]",RETURN_TYPE_NUMBER);
$property[TAG_PRICE]=$parser->extract_xpath("div[@class = 'bloc_content_title']/span[1]",RETURN_TYPE_NUMBER);
	
$property[TAG_TEXT_DESC_NL]= strip_tags($parser->extract_xpath("div[@class = 'description ']"));
$property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);

/************************************************************************/
//Getting Just number
$parser->regex("/(\d+)$/", $property[TAG_UNIQUE_URL_NL]);
$parser->regex("/estate.id=(\d+)/", $property[TAG_UNIQUE_URL_NL] ); 
/************************************************************************/
//Getting Nodes with text
$nodes = $parser->getNodes("a[. = 'Meer info']");
	 
/// Geting html with paras
$para = $parser->getHTML($parser->getNode("section[@class = 'entry']/p"));
	
$para = str_replace('<br />','<br>',$para);
$par = explode('<br>', $para);
	
$imgHtml = $parser->getHTML( $node ); 
$parserx = new PageParser( $imgHtml ); 

///Getting link with node html
$link = $parser->extract_xpath("div[@class = 'title']/h2/a/@href", RETURN_TYPE_TEXT, null, $node); 
	
$price = $parser->extract_xpath("parent::div[1]/preceding-sibling::div[1]/h2", RETURN_TYPE_NUMBER, null, $node);
	
// In case of special characters 	
$parser = new PageParser($html,true);
	
//instead
$parser = new PageParser($html);
// strip_tags for text
	
// Get all text with Regex techniche (.*s)!s
preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
$res[1] = str_replace(chr(11),'',$res[1]);
$property[TAG_TEXT_DESC_FR] = (strip_tags($res[1]));
/****************************************************************************/
//Get Attribute
$property[TAG_UNIQUE_URL_NL] = 'http://www.realtycare.be/'. $parser->getAttr($node, "href");

///Separate text with comma like explode with regex
preg_match("/Immo\s(.*),/", $text, $match);
/***************************************************************************/
//Debuging Page detail
debugx($status.'->'.$type.'->'.'Page: -> '.$page);
	
///Ajax to HTML
$html = $crawler->request("http://www.immogie.be/wp-admin/admin-ajax.php", "action=wpp_property_overview_pagination&wpp_ajax_query%5Bshow_children%5D=true&wpp_ajax_query%5Bchild_properties_title%5D=Floor+plans+at+location%3A&wpp_ajax_query%5Bfancybox_preview%5D=true&wpp_ajax_query%5Bbottom_pagination_flag%5D=false&wpp_ajax_query%5Bthumbnail_size%5D=tiny_thumb&wpp_ajax_query%5Bsort_by_text%5D=Sort+By%3A&wpp_ajax_query%5Bsort_by%5D=menu_order&wpp_ajax_query%5Bsort_order%5D=ASC&wpp_ajax_query%5Btemplate%5D=false&wpp_ajax_query%5Bajax_call%5D=true&wpp_ajax_query%5Bdisable_wrapper%5D=false&wpp_ajax_query%5Bsorter_type%5D=buttons&wpp_ajax_query%5Bpagination%5D=on&wpp_ajax_query%5Bhide_count%5D=false&wpp_ajax_query%5Bper_page%5D=5&wpp_ajax_query%5Bstarting_row%5D=0&wpp_ajax_query%5Bunique_hash%5D=25243&wpp_ajax_query%5Bdetail_button%5D=false&wpp_ajax_query%5Bstats%5D=&wpp_ajax_query%5Bclass%5D=wpp_property_overview_shortcode&wpp_ajax_query%5Bin_new_window%5D=false&wpp_ajax_query%5Bquery%5D%5Bproperty_type%5D=Rental&wpp_ajax_query%5Bquery%5D%5Bsort_by%5D=menu_order&wpp_ajax_query%5Bquery%5D%5Bsort_order%5D=ASC&wpp_ajax_query%5Bquery%5D%5Bpagi%5D=0--5&wpp_ajax_query%5Bquery%5D%5Brequested_page%5D=2&wpp_ajax_query%5Bcurrent_page%5D=1&wpp_ajax_query%5Bsortable_attrs%5D%5Bmenu_order%5D=Default&wpp_ajax_query%5Bsortable_attrs%5D%5Bpost_title%5D=Title&wpp_ajax_query%5Bproperties%5D%5Btotal%5D=7&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=74&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=86&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=109&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=113&wpp_ajax_query%5Bproperties%5D%5Bresults%5D%5B%5D=116&wpp_ajax_query%5Bpages%5D=2&wpp_ajax_query%5Bdefault_query%5D%5Bproperty_type%5D=Rental&wpp_ajax_query%5Bdefault_query%5D%5Bsort_by%5D=menu_order&wpp_ajax_query%5Bdefault_query%5D%5Bsort_order%5D=ASC&wpp_ajax_query%5Bdefault_query%5D%5Bpagi%5D=0--5&wpp_ajax_query%5Bdefault_query%5D%5Brequested_page%5D=2&wpp_ajax_query%5Brequested_page%5D=2");
$ojb = json_decode($html);
if(!empty($ojb))
{
    $html = $ojb->display;
}