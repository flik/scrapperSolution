<?php
	$unmatched_variables = array();
	$attributes = $parser->getNodes("table[@class = 'full-width table details']/tr");
	foreach($attributes as $attr){
		
		$AttribDetail = explode(' ',trim($attr->nodeValue)); 
		 
		$attribute = setAtributesX(str_replace(' ','_', trim($AttribDetail[0]) ));
		if(!empty($attribute))
		    $property[$attribute] = ($AttribDetail[1] === "Ja" ? 1 : 0);
		else
		    $unmatched_variables[str_replace(' ','_', trim($AttribDetail[0])) ] = str_replace(' ','_', trim($AttribDetail[1])) ; 
		
	}
	  
	$unmatched_variables = array();
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	}
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;

    if($property[TAG_BEDROOMS_TOTAL]<1)
	unset($property[TAG_BEDROOMS_TOTAL]);
	
    if($property[TAG_BATHROOMS_TOTAL]<1)
	unset($property[TAG_BATHROOMS_TOTAL]);

    if($property[TAG_GARAGES_TOTAL]<1)
	unset($property[TAG_GARAGES_TOTAL]);
	
	// In case of li 
	$parser->setQueryTemplate("li[contains(text(),'" .XPATH_QUERY_TEMPLATE . "')]");
	
	// In some case
	$parser->setQueryTemplate("b[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::text()[1]");
	
	// In case of Lable in TD
	 $parser->setQueryTemplate("td[label[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]]/following-sibling::td[1]");

	//In case of TD and get next td val
	$parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC score", RETURN_TYPE_EPC);
    $property[TAG_KI] = $parser->extract_xpath("kadastraal inkomen", RETURN_TYPE_NUMBER);
    $property[TAG_KI_INDEX] = $parser->extract_xpath("kad.ink.", RETURN_TYPE_NUMBER);
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("bouwjaar", RETURN_TYPE_YEAR);
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("Renovatie jaar", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Bewoonbare opp.:", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Oppervlakte terrein:", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Aantal slaapkamers:", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toiletten aantal", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("garage aantal", RETURN_TYPE_NUMBER);
    $property[TAG_PARKINGS_TOTAL] = $parser->extract_xpath("parking buiten aantal", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FLOORS] = $parser->extract_xpath("verdiepingen aantal", RETURN_TYPE_NUMBER);
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Beschikbaar vanaf", RETURN_TYPE_UNIX_TIMESTAMP); 
    $property[TAG_COMMON_COSTS] = $parser->extract_xpath("lasten", RETURN_TYPE_NUMBER); 
    $property[TAG_GAS_CONNECTION] = ($parser->extract_xpath("gas") === "Ja" ? 1 : 0); 
    $property[TAG_CONNECTION_TO_WATER] = ($parser->extract_xpath("water") === "Ja" ? 1 : 0); 
    $property[TAG_TELEPHONE_CONNECTION] = ($parser->extract_xpath("telefoon") === "Ja" ? 1 : 0); 
    $property[TAG_LIFT] = ($parser->extract_xpath("lift") === "Ja" ? 1 : 0); 
    $property[TAG_FURNISHED] = ($parser->extract_xpath("Gemeubeld") === "Ja" ? 1 : 0); 
    $property[TAG_GARDEN_AVAILABLE] = ($parser->extract_xpath("Tuin") === "Ja" ? 1 : 0); 
    $property[TAG_OPEN_FIRE] = ($parser->extract_xpath("open haard aantal") ? 1 : 0); 
    $property[TAG_ALARM] = ($parser->extract_xpath("alarm") ? 1 : 0); 
    $property[TAG_PARLOPHONE] = ($parser->extract_xpath("parlofoon") ? 1 : 0); 
    $property[TAG_VIDEOPHONE] = ($parser->extract_xpath("videofoon") === "Ja" ? 1 : 0); 
	
	$property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels:", RETURN_TYPE_NUMBER); 
	
    $property[TAG_LOT_WIDTH] 		= $parser->extract_xpath("Perceelbreedte:", RETURN_TYPE_NUMBER); 
    $property[TAG_LOT_DEPTH] 		= $parser->extract_xpath("Perceeldiepte:", RETURN_TYPE_NUMBER); 
    $property[TAG_CONSTRUCTION_TYPE] 	= $parser->extract_xpath("Type constructie:", RETURN_TYPE_TEXT);
    $property[TAG_FRONTAGE_WIDTH] 	= $parser->extract_xpath("Gevelbreedte:", RETURN_TYPE_NUMBER); 
    $property[TAG_HEATING_NL]		= $parser->extract_xpath("Winkel:", RETURN_TYPE_NUMBER); 
    $property[TAG_SHOWERS_TOTAL]        = $parser->extract_xpath("salle de douches nombre", RETURN_TYPE_NUMBER); 
    $property[TAG_FREE_FROM]            =  $parser->extract_xpath("beschikbaar vanaf", RETURN_TYPE_TEXT); 
    $property[TAG_KITCHEN_TYPE_FR]      = $parser->extract_xpath("keuken type", RETURN_TYPE_TEXT);  

    $property[TAG_SUBDIVISION_PERMIT]   = $parser->extract_xpath("Ligging:", RETURN_TYPE_NUMBER);
    $property[TAG_PRIORITY_PURCHASE]   = $parser->extract_xpath("keuken type", RETURN_TYPE_NUMBER);
    $property[TAG_HAS_PROCEEDING]   = $parser->extract_xpath("keuken type", RETURN_TYPE_NUMBER);