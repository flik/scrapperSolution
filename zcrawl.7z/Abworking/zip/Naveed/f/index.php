<?php
/* ============================= CONFIG ============================= */

// Crawler ID 994 
// Created by Naveed For Test

require_once("../../../crawler_classes.php");

CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.sinjoor.be/" 
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        //"http://www.sinjoor.be/site/default.aspx?pagename=aanbod&highlight=tekoop,uitMenu&force=desktop"
        "http://flexplus.sinjoor.be/flexplus/websites/live/Sinjoor2010/viewEstates.action?&orderBy=e.websiteStats.latestPublication.creationDate+desc&estate.status-in=FOR_SALE,OPTION_FOR_SALE,SOLD&estate.category=Residential&estate.address.country.code-neq=ES"
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        //"http://www.sinjoor.be/site/default.aspx?pagename=aanbod&highlight=tehuur,uitMenu&force=desktop" 
        "http://flexplus.sinjoor.be/flexplus/websites/live/Sinjoor2010/viewEstates.action?&orderBy=e.websiteStats.latestPublication.creationDate+desc&estate.status-in=FOR_RENT,OPTION_FOR_RENT,SOLD&estate.category=Residential&estate.address.country.code-neq=ES"
    ),
);


/* ============================= END CONFIG ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "SINJOOR";
$office[TAG_OFFICE_URL] = "http://www.sinjoor.be/";
$office[TAG_STREET] = "Bredabaan 896";
$office[TAG_NUMBER] = "";
$office[TAG_ZIP] = "2170";
$office[TAG_CITY] = "Merksem";
$office[TAG_TELEPHONE] = "+32(0)3 646 66 55";
$office[TAG_EMAIL] = "info@investpro.be";
CrawlerTool::saveOffice($office);
$office2 = array();
$office2[TAG_OFFICE_ID] = 2;
$office2[TAG_OFFICE_NAME] = "SINJOOR";
$office2[TAG_OFFICE_URL] = "http://www.sinjoor.be/";
$office2[TAG_STREET] = "Veltwijcklaan 5";
$office2[TAG_NUMBER] = "";
$office2[TAG_ZIP] = "2180";
$office2[TAG_CITY] = "Ekeren";
$office2[TAG_TELEPHONE] = "+32(0)3 283 83 00";
$office2[TAG_EMAIL] = "noord@investpro.be";
CrawlerTool::saveOffice($office2);


foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("div[@class = 'pand_kader']");
    $items = array();
	foreach($nodes as $node)
    {
    	$property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
		
		$link = $parser->extract_xpath("a/@href", RETURN_TYPE_TEXT, null, $node);
		$property[TAG_UNIQUE_URL_NL] =  'http://flexplus.sinjoor.be/flexplus/websites/live/Sinjoor2010/'.$link ;
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
	
        // $parser->extract_xpath("parent::div[1]/following-sibling::div[1]/descendant::span[@class = 'c_Style02red']", RETURN_TYPE_TEXT, function($text) use(&$property)
        // {
        //     $propertyStatus = CrawlerTool::getPropertyStatus($text);
        //     if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
        //     {
        //         $property[TAG_STATUS] = $propertyStatus;
        //     }
        // }, $node);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}
	//debug($items);exit;
    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

function getPages($html)
{
    $parser = new PageParser($html);

    $pages = array();
    $nodes = $parser->getNodes("a[@class = 'pager']");

    if(!empty($nodes))
    {
        foreach($nodes as $node)
        {
            $pages[] = "http://flexplus.sinjoor.be/flexplus/websites/live/Sinjoor2010/" . $parser->getAttr($node, "href");
        }
    }

    return array_unique($pages);
}

/**
 * Download and extract item detail information http://www.av-vastgoed.be/images/panden/1366631738.jpg
 */
function processItem($crawler, $property, $html)
{
	//debug($html);  exit;
    $parser = new PageParser($html, true);
      
    $parser->deleteTags(array("script", "style"));
    
    $property[TAG_PRICE] = $parser->extract_xpath("div[@id = 'site_container']/table[2]/tr[1]/td[1]/table/tr/td[2]", RETURN_TYPE_NUMBER);

    $property[TAG_TEXT_DESC_NL] =  $parser->extract_xpath("div[@id = 'site_container']/table[2]/tr[1]/td[2]", RETURN_TYPE_TEXT_ALL);

    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@id = 'site_container']/table[2]", RETURN_TYPE_TEXT_ALL);
    $address = $parser->extract_xpath("div[@id = 'site_container']/table[2]/tr[1]/td[2]/strong", RETURN_TYPE_TEXT);
    $address1= explode(', ', $address);
    $address2= explode(' ', $address1[1]);
    $property[TAG_STREET] = $address1[0];
    $property[TAG_ZIP] = $address2[0];
    $property[TAG_CITY] = $address2[1];

    $property[TAG_PICTURES] =  $parser->extract_xpath("ul[@id = 'mycarousel']/li/table/tr/td/img/@src", RETURN_TYPE_ARRAY, function($pics)
    {
	$picUrls = array();
	foreach($pics as $pic) {
	    $picUrls[] = array(TAG_PICTURE_URL => $pic);
	}

	return $picUrls;
    });

    //fix of type issue
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_EN]));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_EN]));
  
  	//files grabbing
    $property[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
	{
	    $fileUrls = array();
	    foreach($files as $file)
	    {
	    	if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => str_replace('../','',$file));
		}
		return $fileUrls;
	});
    
    unset($property[TAG_BOX_NUMBER]);
 
    $nodes = $parser->getNodes("table[@class = 'velden']/tr");

    foreach($nodes as $node)
    {
		$key = $parser->extract_xpath("td[1]", RETURN_TYPE_TEXT, null, $node);
		$val = $parser->extract_xpath("td[2]", RETURN_TYPE_TEXT, null, $node);
		
		$att = getAttributes('en', $key);
		if(isset($att) && !empty($att)){
			$property[$att] = GetExactAttrib($att, $val);
		}else{
			$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $key, TAG_VARIABLE_VALUE => $val);
		}   
		unset($att);
    }
	
    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
 
    debug($property);exit;
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
    
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}




//Function for Handle Attributes 
function setAtributesX($key='',$lan='en'){ 
    
    $attrib['en'] = array('Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Badkamer'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_EN,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_EN, 'Vloerverwarming'=>TAG_HEATING_EN,
			'Kadastraal_inkomen'=>TAG_KI, 'Geïndexeerd_kad._inkomen'=>TAG_KI_INDEX,
			'Grondoppervlakte'=>TAG_SURFACE_GROUND, 'Gevelbreedte'=>TAG_FRONTAGE_WIDTH,
			'Verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Badkamer'=>TAG_BATHROOM_SURFACE,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'keuken'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Aantal_slaapkamers'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'Bouwjaar'=>TAG_CONSTRUCTION_YEAR, 'Bewoonb_opp.'=>TAG_SURFACE_GROUND,
			'Parkings'=>TAG_PARKINGS,'Garages'=>TAG_GARAGES_TOTAL, 'Aantal_garages'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'Bewoonbare_oppervlakte'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Tuin'=>TAG_WINTERGARDENS,
			'Gemeubeld'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terras'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE, 'EPC'=>TAG_EPC_VALUE, 'EPC_Certificaat'=>TAG_EPC_CERTIFICATE_NUMBER,
			'Bestemming'=>TAG_MOST_RECENT_DESTINATION, 'Verkavelingvergunning'=>TAG_SUBDIVISION_PERMIT, 'Bouwvergunning'=>TAG_PLANNING_PERMISSION,
			'Voorkooprecht'=>TAG_PRIORITY_PURCHASE
			);
    
    $attrib['fr'] = array( 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Nombre_de_salle_de_bain'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_EN,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_EN, 'Vloerverwarming'=>TAG_HEATING_EN,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'cuisine'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'année_de_construction_année'=>TAG_CONSTRUCTION_YEAR, 'Taille_terrain_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'surface_nette_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Jardin'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrasse'=>TAG_TERRACES,'Facades'=>TAG_AMOUNT_OF_FACADES,
			'Catégorie'=>TAG_TYPE
			);
    
    $attrib['en'] = array('Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Number_of_bathrooms'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_EN,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_EN, 'Vloerverwarming'=>TAG_HEATING_EN,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'kitchen'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Number_of_rooms'=>TAG_BEDROOMS_TOTAL,
			'construction_year_year'=>TAG_CONSTRUCTION_YEAR, 'Plot_size_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL, 'Type'=>TAG_TYPE,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'habitable_-_surface_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Garden'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrace'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE
			);
    
    if(!empty($key)){
	
	if( array_key_exists($key, $attrib[$lan]) ){
	    return $attrib[$lan][$key];
	}
	else
	    return '';
    }else
	return '';
	
}

function GetBetween($content,$start,$end){
  $r = explode($start, $content);
  if (isset($r[1])){
    $r = explode($end, $r[1]);
    return $r[0];
  }
  return '';
}        
	
	

function GetExactAttrib($key,$val){
 	switch($key){
		case TAG_BATHROOMS_TOTAL:
		    return CrawlerTool::toNumber($val); 
		break;
	    
		case TAG_BEDROOMS_TOTAL:
		    return CrawlerTool::toNumber($val); 
		break;
	    
		case TAG_CONSTRUCTION_YEAR:
		    return CrawlerTool::toNumber($val); 
		break;
		
		case TAG_EPC_CERTIFICATE_NUMBER:
		    return CrawlerTool::toNumber($val); 
		break;
		
		case TAG_SURFACE_LIVING_AREA:
		   return CrawlerTool::toNumber($val); 
		break;

		case TAG_MOST_RECENT_DESTINATION:
		   return array(TAG_MOST_RECENT_DESTINATION_INFORMATION_EN=>$val); 
		break;

		case TAG_PLANNING_PERMISSION:
		   return 1; 
		break;
		
		case TAG_SUBDIVISION_PERMIT:
		   return CrawlerTool::toNumber($val); 
		break;


		default:
			return CrawlerTool::toNumber($val);  
		break;
    }
}


function getAttributes($language, $key){

		$attributeTagsArray	= array('en'	=> array(	'pric' 			=> TAG_PRICE,
														'constr'		=> TAG_CONSTRUCTION_YEAR,
														'ground'		=> TAG_SURFACE_GROUND,
														'living' 		=> TAG_SURFACE_LIVING_AREA,
														'bath'			=> TAG_BATHROOMS_TOTAL,
														'warm'			=> TAG_HEATING_EN,
														'heat'			=> TAG_HEATING_EN,
														'sewer'			=> TAG_CONNECTION_TO_SEWER,
														'telep'			=> TAG_TELEPHONE_CONNECTION,
														'intern'		=> TAG_INTERNET_CONNECTION,
														'permission'	=> TAG_PLANNING_PERMISSION,
														'subdivision'	=> TAG_SUBDIVISION_PERMIT,
														'electri'		=> TAG_METER_FOR_ELECTRICITY,
														'hall'			=> TAG_HALLS,
														'dining'		=> TAG_DININGS,
														'kitch'			=> TAG_KITCHENS,
														'laundr'		=> TAG_LAUNDRY_ROOMS,
														'dress'			=> TAG_DRESSING,
														'bed'			=> TAG_BEDROOMS_TOTAL,
														'room'			=> TAG_BEDROOMS_TOTAL,
														'park'			=> TAG_PARKINGS,
														'garage'		=> TAG_GARAGES_TOTAL,
														'type'			=> TAG_TYPE,
														'garden'		=> TAG_GARDEN_AVAILABLE,
														'floor'			=> TAG_AMOUNT_OF_FLOORS,
														'winter'		=> TAG_WINTERGARDENS,
														'furnish'		=> TAG_FURNISHED,
														'water'			=> TAG_CONNECTION_TO_WATER,
														'lift'			=> TAG_LIFT,
														'glaz'			=> TAG_DOUBLE_GLAZING,
														'terrac'		=> TAG_TERRACES,
														'fronts'		=> TAG_AMOUNT_OF_FACADES,
														'category'		=> TAG_TYPE,
														'free'			=> TAG_FREE_FROM_DATE,
														'habit'			=> TAG_SURFACE_LIVING_AREA,
														'plot'			=> TAG_SURFACE_GROUND,
														'shops'			=> TAG_DISTANCE_SHOPS,
														'schools'		=> TAG_DISTANCE_SCHOOL,
														'transport'		=> TAG_DISTANCE_PUBLIC_TRANSPORT,
														'shower'		=> TAG_SHOWERS_TOTAL,
														'stor'			=> TAG_STOREROOMS,
														'gas'			=> TAG_GAS_CONNECTION,
														'alarm'			=> TAG_ALARM,
														'security'		=> TAG_SECURITY_DOOR,
														'parlo'			=> TAG_PARLOPHONE,
														'video'			=> TAG_VIDEOPHONE,
														'elevat'		=> TAG_LIFT,
														'blind'			=> TAG_SUN_BLINDS,
														'renova'		=> TAG_RENOVATION_YEAR,
														'control'		=> TAG_ACCESS_SEMIVALID,

												),
									'nl'	=> array(	'pri' 			=> TAG_PRICE,
														'bouwj'			=> TAG_CONSTRUCTION_YEAR,
														'gron'  		=> TAG_SURFACE_GROUND,
														'bewoon'		=> TAG_SURFACE_LIVING_AREA,
												),
								);

		$keys = array_keys($attributeTagsArray[$language]);
		foreach($keys as $k){
			
			if(strpos(strtolower($key), $k) !== false){
				return $attributeTagsArray[$language][$k];
			}
		}
	}