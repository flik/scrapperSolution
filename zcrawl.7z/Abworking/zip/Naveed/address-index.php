<title>Grab Address (Learning Task)</title>
<?php
	include('simple_html_dom.php');
	$url 		= $_GET['url'];
	$html 		= file_get_html($url);
	
	$addressVar = $html->find('td[class=SubtitleSmall4]');
	$addressD 		= explode(' ', trim($addressVar[0]->innertext));
	$address 	= 'Zipcode : '.$addressD[0];
	$address 	.= '<br>City : '.$addressD[1];
	
	echo $url.'<br>';
	echo $address;

	/*****************/
	function pr($var){
		echo '<pre>';
		print_r($var);
		echo '</pre>';
	}
