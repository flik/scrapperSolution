<?php
include_once('simple_html_dom.php');
$siteUrl = "http://www.immocosemans.be/Web.mvc/nl-be/Detail/1938059";
$res = file_get_contents($siteUrl);

$ht = new simple_html_dom();
$ht->load($res);
$streetAddress = $ht->find("p.TitleSmall4",0)->plaintext;
$cityState = $ht->find("td.SubtitleSmall4",0)->plaintext;
$ht->clear();

$number ="";
$street = "";
$streetNumberInfo = extractAddress($streetAddress);
$streetArr = explode("|||",$streetNumberInfo);
$streetNumber = $streetArr[0];
$streetName = $streetArr[1];

$cityStateInfo = extractAddress($cityState);
$cityArr = explode("|||",$cityStateInfo);
$zipcode = $cityArr[0];
$city = $cityArr[1];

echo "<br>Street Number : ". $streetNumber;
echo "<br>Street Name : ". $streetName;

echo "<br>City Name : ". $city;
echo "<br>zipcode : ". $zipcode;

function extractAddress($address){
	if (strpos($address, ',') !== false) {
		list($number, $street) = explode(',', $address, 2);
	} else {
		preg_match('~^(.*?)((?:unit )?(?:[0-9]+\s?-\s?[0-9]+|[0-9]+))(.*)$~is', $address, $parts);
		
		$number = $parts[2];
		if (trim($parts[1]) != '') {
			$street .= trim($parts[1]);
		}
		if(trim($parts[3]) != '') {
			if($street ==""){
				$street .= trim($parts[3]);
			}
			else{
				$street .= " ".trim($parts[3]);	
			}
		}
	}

	return $number."|||".$street;

}

?>