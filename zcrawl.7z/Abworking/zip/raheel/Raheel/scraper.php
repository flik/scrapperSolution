<?php
include_once('simple_html_dom.php');
$siteUrl = "http://www.immocosemans.be/Web.mvc/nl-be/Home";
$domainUrl = "http://www.immocosemans.be";
$property = array();

$res = file_get_contents($siteUrl);

$ht = new simple_html_dom();
$ht->load($res);
foreach($ht->find("ul#nav li") as $menu){
	$name = trim($menu->find("a",0)->plaintext);
	$link = trim($menu->find("a",0)->href);
	$pageUrl = $domainUrl.$link;
	if($name == "Te koop" || $name == "Te huur"){
		$res2 = file_get_contents($pageUrl);
		$ht2 = new simple_html_dom();
		$ht2->load($res2);
		foreach($ht2->find("div.list-mosaic ul li") as $propertyList){
			$link2 = trim($propertyList->find("a",0)->href);
			if($link2 != ""){
				$pageUrl2 = $domainUrl.$link2;
				$urlArr = explode("/",$pageUrl2);
				$propertyId = end($urlArr);

				$res3 = file_get_contents($pageUrl2);
				$ht3 = new simple_html_dom();
				$ht3->load($res3);
				$streetAddress = trim($ht3->find("p.TitleSmall4",0)->plaintext);
				$cityState = trim($ht3->find("td.SubtitleSmall4",0)->plaintext);


				$number ="";
				$street = "";
				$streetNumberInfo = extractAddress($streetAddress);
				$streetArr = explode("|||",$streetNumberInfo);
				$streetNumber = $streetArr[0];
				$streetName = $streetArr[1];

				$cityStateInfo = extractAddress($cityState);
				$cityArr = explode("|||",$cityStateInfo);
				$zipcode = $cityArr[0];
				$city = $cityArr[1];

				$propertyPrice = trim($ht3->find("div.detail-comment-price p.right",0)->plaintext);
				$propertyDescription = trim($ht3->find("div#shortDescription",0)->plaintext);
				$propertyDescription = str_replace("BESCHRIJVING PAND", "", $propertyDescription);
				$propertyDescription = trim($propertyDescription);

				if($propertyDescription == ""){
					$propertyDescription = trim($ht3->find("div#description",0)->plaintext);
				}
				$propertyType = trim($ht3->find("p.Subtitle",0)->plaintext);
				$images = array();
				foreach($ht3->find("ul.bxSlider li") as $sliderImages){
					$images[] = $domainUrl.$sliderImages->find("img",0)->src;
				}
				$propertyImages = $images;
				$property[$name][] = array("propertyId"=>$propertyId,"propertyPrice"=>$propertyPrice,"propertyType"=>$propertyType,"streetName"=>$streetName,"streetNumber"=>$streetNumber,"cityName"=>$city,"zipCode"=>$zipcode,"propertyDescription"=>$propertyDescription,"propertyImages"=>$propertyImages);
				$ht3->clear();

			}

		}
		$ht2->clear();

	}

}
$ht->clear();

echo "Property List: <br>";
echo "<pre>";print_r($property);


function extractAddress($address){
		if (strpos($address, ',') !== false) {
			list($number, $street) = explode(',', $address, 2);
		} else {
			preg_match('~^(.*?)((?:unit )?(?:[0-9]+\s?-\s?[0-9]+|[0-9]+))(.*)$~is', $address, $parts);
			
			$number = $parts[2];
			if (trim($parts[1]) != '') {
				$street .= trim($parts[1]);
			}
			if(trim($parts[3]) != '') {
				if($street ==""){
					$street .= trim($parts[3]);
				}
				else{
					$street .= " ".trim($parts[3]);	
				}
			}
		}

		return $number."|||".$street;

}


?>