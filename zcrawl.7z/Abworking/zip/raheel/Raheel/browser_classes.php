<?php
class Browser
{
    private $mimic_browser = false;
    private $encounteredErrors = 0;

    /** proxy options **/
    private $proxy_address = '';
    private $proxy_type = '';
    private $proxy_pwd = '';
    private $enable_cookie = false;
    private $cookie_name = 'cookie_0.txt';
    private $curlTimeout = 40; // will wait for X seconds before timing out.

    /** try to perform request again, if error **/
    private $reload_if_error = true;
    private $try_reload_max = 3;

    /** header options **/
    private $use_gzip = true;
    private $header_except_flag = false;
    private $header_xmlhttpreq_flag = false;
    private $header_accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
    private $header_ua = 'Mozilla/5.0 (Windows NT 6.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.116 Safari/537.36';
    private $header_accept_lang = 'en-US,en;q=0.8,nl;q=0.6,fr;q=0.4';
    private $header_connection = 'keep-alive';

    private $lastRequest = '';

    public function __construct(array $browserConfig = array())
    {
        foreach ($browserConfig as $key => $value) {
            if (isset($value)) {
                $this->$key = $value;
            }
        }
    }

    /**
     * Perform GET or POST request
     *
     * @param $url
     * @param bool $postData
     * @param string $refer
     * @param int $try
     * @return mixed|string
     * @throws CurlUnexpectedErrorException
     */
    public function request($url, $postData = false, $refer = '', $try = 0)
    {
        $ch = $this->createCurlHandle($url, $postData, $refer, $try);
        $html = curl_exec($ch);
        if ($err = curl_error($ch)) {
            echo "Url: $url  -- cURL error: $err<br>\r\n";
            $try++;
            if(!$this->tooManyAttemptsOnThisPage($try)){
                return $this->request($url, $postData, $refer, $try);
            }
            if($url == $this->lastRequest){
                return '';
            }
            $this->lastRequest = $url;

            echo "\nA lot of curl errors<br><br>\r\n";
            $unexpectedError = $this->isUnexpectedError(curl_errno($ch));
            curl_close($ch);
            if($unexpectedError){
                $this->encounteredErrors++;
                throw new CurlUnexpectedErrorException($err);
            }
            return '';
        }
        if($this->mimic_browser){
            $this->getAllFileAndImageUrlsToTouch($html, $url);
        }
        curl_close($ch);
        return $html;
    }

    /**
     * Get the amount of encounteredErrors.
     *
     * @return int
     */
    public function getAmountOfEncounteredErrors(){
        return $this->encounteredErrors;
    }

    /**
     * @return mixed
     */
    public function getProxyAddress()
    {
        return $this->proxy_address;
    }

    /**
     * @return string
     */
    public function getHeaderUa()
    {
        return $this->header_ua;
    }

    /**
     * Check if there were too many attempts to request this page yet.
     *
     * @param $attemptsDone
     * @return bool
     */
    private function tooManyAttemptsOnThisPage($attemptsDone){
        if($attemptsDone > $this->try_reload_max || $this->reload_if_error == false){
            return true;
        }
        return false;
    }

    /**
     * Check if the errorcode that was returned was something we should be aware of.
     *
     * @param $errorcode
     * @return bool
     */
    private function isUnexpectedError($errorcode){
        $importantCodes = array(
            5,      // CURLE_COULDNT_RESOLVE_PROXY
            6,      // CURLE_COULDNT_RESOLVE_HOST
            7,      // CURLE_COULDNT_CONNECT
            15,     // CURLE_FTP_CANT_GET_HOST
            28,     // CURLE_OPERATION_TIMEDOUT
            52,     // CURLE_GOT_NOTHING
        );
        if(in_array($errorcode, $importantCodes)){
            return true;
        } else {
            return false;
        }
    }

    /**
     * Check given URL for all files that need to be downloaded.
     *
     * @param $html
     * @param $url
     */
    private function getAllFileAndImageUrlsToTouch($html, $url)
    {
        $parser = new PageParser($html);
        $externalFiles['img'] = $parser->extract_xpath("//img/@src", RETURN_TYPE_ARRAY);
        $externalFiles['css'] = $parser->extract_xpath("//link/@href", RETURN_TYPE_ARRAY);
        $externalFiles['js'] = $parser->extract_xpath("//script/@src", RETURN_TYPE_ARRAY);
        $this->touchAllFilesAndPictures($externalFiles, $url);
    }

    /**
     * Start a cURL to all given files.
     *
     * @param array $externalFiles
     * @param $htmlUrl
     */
    private function touchAllFilesAndPictures(array $externalFiles, $htmlUrl)
    {
        $externalFiles = $this->expandRelativePaths($externalFiles, $htmlUrl);
        $handles = array();
        $mh = curl_multi_init();
        foreach ($externalFiles as $url) {
            $handle = $this->createCurlHandle($url);
            $handles[] = $handle;
            curl_multi_add_handle($mh, $handle);
        }

        $this->executeMultiCurlHandle($mh);
        $this->closeMultiCurlHandles($mh, $handles);
    }

    /**
     * Get all absolute paths of given (possibly) relative paths.
     *
     * @param $url
     * @param $baseUrl
     * @param array $list
     * @return array
     */
    private function expandRelativePaths($url, $baseUrl, $list = array())
    {
        if (is_array($url)) {
            foreach ($url as $urlItem) {
                $list = $this->expandRelativePaths($urlItem, $baseUrl, $list);
            }
            return $list;
        } else {
            require_once('phpuri.php');
            $base = phpUri::parse($baseUrl);
            $list[] = $base->join($url);
            return $list;
        }
    }

    /**
     * Execute the actual cURL of given MultiCurlHandle
     *
     * @param $mh
     * @return mixed
     */
    private function executeMultiCurlHandle($mh)
    {
        $active = null;
        $i = 0;
        //execute the handles
        do {
            $mrc = curl_multi_exec($mh, $active);
            sleep(1);
        } while ($active > 0);

        while ($active && $mrc == CURLM_OK) {
            if (curl_multi_select($mh) != -1) {
                do {
                    $mrc = curl_multi_exec($mh, $active);
                } while ($mrc == CURLM_CALL_MULTI_PERFORM);
            }
        }
        return $mh;
    }

    /**
     * Close all connections of given MultiCurlHandle
     *
     * @param $mh
     * @param array $handles
     * @return bool
     */
    private function closeMultiCurlHandles($mh, array $handles)
    {
        foreach ($handles as $key => $handle) {
            //file_put_contents('image_'. $key .'.jpg', curl_multi_getcontent($handle));
            curl_multi_remove_handle($mh, $handle);
            curl_close($handle);
        }
        curl_multi_close($mh);
        return true;
    }

    /**
     * Create the actual CurlHandle
     *
     * @param $url
     * @param bool $postData
     * @param string $refer
     * @param int $try
     * @return resource
     */
    private function createCurlHandle($url, $postData = false, $refer = '', $try = 0)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, str_replace(" ", "%20", $url));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
        curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
        curl_setopt($ch, CURLOPT_AUTOREFERER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
/*
        $proxy = 'http://ashfaq@zeropoint.it:bud102@p-ar1.biscience.com';
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
        curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
*/

        if ($this->use_gzip) {
            curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
        }

        curl_setopt($ch, CURLOPT_TIMEOUT, $this->curlTimeout);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->getHeaders());

        if ($this->enable_cookie) {
            curl_setopt($ch, CURLOPT_COOKIEFILE, SCRIPT_DIR . $this->cookie_name);
            curl_setopt($ch, CURLOPT_COOKIEJAR, SCRIPT_DIR . $this->cookie_name);
        }

        if (!empty($refer)) {
            curl_setopt($ch, CURLOPT_REFERER, $refer);
        }

        if ($postData !== false) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        }

        if (!empty($this->proxy_address)) {
            curl_setopt($ch, CURLOPT_PROXY, $this->proxy_address);
        }
        if (!empty($this->proxy_type) && $this->proxy_type == 'socks') {
            curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
        }
        if (!empty($this->proxy_pwd)) {
            curl_setopt($ch, CURLOPT_PROXYUSERPWD, $this->proxy_pwd);
        }
        return $ch;
    }

    /**
     * Get the headers for this Browser.
     *
     * @return array
     */
    private function getHeaders()
    {
        $header = array();

        if ($this->header_except_flag) {
            $header[] = 'Expect:';
        }
        if (!empty($this->header_accept)) {
            $header[] = 'Accept: ' . $this->header_accept;
        }
        if (!empty($this->header_ua)) {
            $header[] = 'User-Agent: ' . $this->header_ua;
        }
        if (!empty($this->header_accept_lang)) {
            $header[] = 'Accept-Language: ' . $this->header_accept_lang;
        }
        if (!empty($this->header_accept_chrst)) {
            $header[] = 'Accept-Charset: ' . $this->header_accept_chrst;
        }
        if ($this->header_xmlhttpreq_flag) {
            $header[] = 'X-Requested-With: XMLHttpRequest';
        }
        if (!empty($this->header_connection)) {
            $header[] = 'Connection: ' . $this->header_connection;
        }

        return $header;
    }

    /**
     * Clean cookies
     */
    public function cleanCookies()
    {
        file_put_contents(SCRIPT_DIR . $this->cookie_name, '');
    }

    /**
     * Enable or disable cookies for this browser
     *
     * @param boolean $v
     */
    public function setEnableCookies($v)
    {
        $this->enable_cookie = (bool)$v;
        $this->createCookie();
    }

    /**
     * Create a cookie for this browser
     */
    private function createCookie()
    {
        if (!file_exists(SCRIPT_DIR . $this->cookie_name)) {
            file_put_contents(SCRIPT_DIR . $this->cookie_name, '');
        }
    }

    /**
     * Enable or disable X-Requested-With: XMLHttpRequest header
     *
     * @param $boolean
     */
    public function setExceptHeader($boolean){
        $this->header_except_flag = (bool) $boolean;
    }

    /**
     * Set user agent
     *
     * @param $string
     */
    public function setUseragent($string)
    {
        $this->header_ua = $string;
    }

    /**
     * Set Accept-Language: header value
     *
     * @param $string
     */
    public function setAcceptLang($string)
    {
        $this->header_accept_lang = $string;
    }

    /**
     * Enable or disable X-Requested-With: XMLHttpRequest header
     *
     * @param $boolean
     */
    public function setXmlHttpReq($boolean)
    {
        $this->header_xmlhttpreq_flag = (bool) $boolean;
    }

    /**
     * Enable or disable gzip header in curl
     *
     * @param $boolean
     */
    public function setUseGzip($boolean)
    {
        $this->use_gzip = $boolean;
    }

    /**
     * Set whether a browser should mimic a real browser or not. (Download images and CSS/JS files)
     *
     * @param $boolean
     */
    public function setMimicBrowser($boolean)
    {
        $this->mimic_browser = $boolean;
    }
}

class CurlUnexpectedErrorException extends Exception{}
class OutOfBrowsersException extends Exception{}