<?php
/**
 *  PageParser class helps extract data from the given html document via 2 main methods:
 *      1. extract_xpath : Extract data by using DOM/XPath
 *      2. extract_regex : Extract data by using regular expression functions
 */

include_once('crawlerTool_classes.php');

class PageParser
{
    protected $html;
    protected $xpath;
    protected $queryTemplate;
    protected static $dom;

    public function __construct($html,$fix_utf8 = false)
    {
        $this->html = $html;
        if ($fix_utf8)
        {
            $html = mb_convert_encoding($html, 'HTML-ENTITIES', "UTF-8");
        }
        if(empty(self::$dom)){
            self::$dom = new DOMDocument('1.0', 'UTF-8');
        }
        self::$dom->preserveWhiteSpace = false;
        self::$dom->loadHTML($html);
        $this->xpath = new DOMXPath(self::$dom);
        $this->queryTemplate = "";
        unset($html);
    }

    public function __destruct(){
        unset($this->html);
        unset($this->xpath);
        unset($this->queryTemplate);
    }

    public function setQueryTemplate($text)
    {
        $this->queryTemplate = $text;
    }

    public function clearQueryTemplate()
    {
        $this->queryTemplate = "";
    }

    public function getXPathQuery($text)
    {
        if(empty($this->queryTemplate)) return $text;

        return str_replace(XPATH_QUERY_TEMPLATE, $text, $this->queryTemplate);
    }

    /** Extract property infomation via Regular Expression
     * @param $exp Regular expression string
     * @param $returnType Refer to Return type constants section in CrawlerConst class for available return type values
     * @param Closure|null $closure A kind of callback function to further process the return value
     */
    public function extract_regex($exp, $returnType = RETURN_TYPE_TEXT, Closure $closure = null)
    {
        if(RETURN_TYPE_ARRAY === $returnType)
        {
            return $this->regex_all($exp, $this->html, $closure);
        }
        else if(RETURN_TYPE_NUMBER === $returnType)
        {
            $number = CrawlerTool::toNumber($this->regex($exp, $this->html));

            if(empty($closure))
            {
                if($number > 0) return $number;
            }
            else
            {
                return $closure($number);
            }

            return "";
        }
        else if(RETURN_TYPE_EPC === $returnType)
        {
            $epc = CrawlerTool::toNumber($this->regex($exp, $this->html));

            if(empty($closure))
            {
                if($epc > 0 && $epc <= 999) return $epc;
            }
            else
            {
                return $closure($epc);
            }

            return "";
        }
        else if(RETURN_TYPE_YEAR === $returnType)
        {
            $year = CrawlerTool::toNumber($this->regex($exp, $this->html));

            if(empty($closure))
            {
                if($year > 0 && strlen($year) == 4) return $year;
            }
            else
            {
                return $closure($year);
            }

            return "";
        }
        else if(RETURN_TYPE_UNIX_TIMESTAMP === $returnType)
        {
            $timestamp = CrawlerTool::toUnixTimestamp($this->regex($exp, $this->html));

            if(empty($closure))
            {
                if($timestamp > 0) return $timestamp;
            }
            else
            {
                return $closure($timestamp);
            }

            return "";
        }
        else
        {
            return $this->regex($exp, $this->html, $closure);
        }
    }

    /** Extract property infomation via XPath
     * @param $exp XPath query string
     * @param $returnType Refer to Return type constants section in CrawlerConst class for available return type values
     * @param Closure|null $closure A kind of callback function to further process the return value
     * @param $contextNode
     */
    public function extract_xpath($exp, $returnType = RETURN_TYPE_TEXT, Closure $closure = null, $contextNode = null)
    {
        $exp = $this->getXPathQuery($exp);

        if(RETURN_TYPE_ARRAY === $returnType)
        {
            $nodes = $this->getNodes($exp, $contextNode);
            $arr = array();

            if(!empty($nodes) && $nodes->length > 0)
            {
                $node = $nodes->item(0);
                $nodeName = $node->nodeName;

                if($nodeName === "a")
                {
                    foreach($nodes as $node) $arr[] = $this->getAttr($node, "href");
                }
                else if($nodeName === "img")
                {
                    foreach($nodes as $node) $arr[] = $this->getAttr($node, "src");
                }
                else
                {
                    foreach($nodes as $node) $arr[] = $this->getText($node);
                }

                $arr = array_unique($arr);

                if(empty($closure))
                {
                    return $arr;
                }
                else
                {
                    return $closure($arr);
                }
            }

            return $arr;
        }
        else if(RETURN_TYPE_NUMBER === $returnType)
        {
            $node = $this->getNode($exp, $contextNode);
            if($node)
            {
                $number = CrawlerTool::toNumber($this->getText($node));
                if(empty($closure))
                {
                    if($number > 0) return $number;
                }
                else
                {
                    return $closure($number);
                }
            }

            return "";
        }
        else if(RETURN_TYPE_EPC === $returnType)
        {
            $node = $this->getNode($exp, $contextNode);
            if($node)
            {
                $epc = CrawlerTool::toNumber($this->getText($node));
                if(empty($closure))
                {
                    if($epc > 0 && $epc <= 999) return $epc;
                }
                else
                {
                    return $closure($epc);
                }
            }

            return "";
        }
        else if(RETURN_TYPE_YEAR === $returnType)
        {
            $node = $this->getNode($exp, $contextNode);
            if($node)
            {
                $year = CrawlerTool::toNumber($this->getText($node));
                if(empty($closure))
                {
                    if($year > 0 && strlen($year) == 4) return $year;
                }
                else
                {
                    return $closure($year);
                }
            }

            return "";
        }
        else if(RETURN_TYPE_UNIX_TIMESTAMP === $returnType)
        {
            $node = $this->getNode($exp, $contextNode);
            if($node)
            {
                $timestamp = CrawlerTool::toUnixTimestamp($this->getText($node));
                if(empty($closure))
                {
                    if($timestamp > 0) return $timestamp;
                }
                else
                {
                    return $closure($timestamp);
                }
            }

            return "";
        }
        else if(RETURN_TYPE_TEXT_ALL === $returnType)
        {
            $nodes = $this->getNodes($exp, $contextNode);
            if(!empty($nodes))
            {
                $text = $this->getText($nodes);
                if(empty($closure))
                {
                    return $text;
                }
                else
                {
                    return $closure($text);
                }
            }

            return "";
        }
        else
        {
            $node = $this->getNode($exp, $contextNode);
            if($node)
            {
                $text = $this->getText($node);
                if(empty($closure))
                {
                    return $text;
                }
                else
                {
                    return $closure($text);
                }
            }

            return "";
        }
    }

    public function regex_all($exp, $text, Closure $closure = null)
    {
        preg_match_all($exp, $text, $match);

        if(isset($match[1]))
        {
            if(empty($closure))
            {
                return $match[1];
            }
            else
            {
                return $closure($match);
            }
        }

        return array();
    }

    public function regex($exp, $text, Closure $closure = null)
    {
        if(preg_match($exp, $text, $match))
        {
            if(empty($closure))
            {
                return trim($match[1]);
            }
            else
            {
                return $closure($match);
            }
        }

        return "";
    }

    public function getNode($query, $contextNode = null, $index = 0)
    {
        $node = null;

        if(empty($contextNode))
        {
            $nodes = $this->xpath->query("//" . $query);
        }
        else
        {
            $nodes = $this->xpath->query(".//" . $query, $contextNode);
        }

        foreach($nodes as $i => $node)
        {
            if($i == $index) return $node;
        }

        return $node;
    }

    public function getNodes($query, $contextNode = null)
    {
        $query = str_replace("| ", "| //", $query);

        if(empty($contextNode))
        {
            $query = "//" . str_replace("| ", "| //", $query);
            $nodes = $this->xpath->query($query);
            return $nodes;
        }
        else
        {
            $query = ".//" . str_replace("| ", "| .//", $query);
            $nodes = $this->xpath->query($query, $contextNode);
            return $nodes;
        }
    }

    public function parentNode($node, $n = 1)
    {
        $parentNode = $node;
        for($i = 1; $i <= $n; $i++) $parentNode = $parentNode->parentNode;

        return $parentNode;
    }

    public function getHTML($node)
    {
        $dom = new DOMDocument('1.0', 'UTF-8');
        $dom->appendChild($dom->importNode($node, true));
        return $dom->saveHTML();
    }

    public function getText($nodes, $delim = " ")
    {
        $text = "";

        // if DOMNode
        if(property_exists($nodes, "nodeValue"))
        {
            $text = CrawlerTool::strip($nodes->nodeValue);
        }
        // if DOMNodeList
        else if(property_exists($nodes, "length"))
        {
            foreach($nodes as $node) $text .= $node->nodeValue . $delim;

            $text = CrawlerTool::strip($text);
            if($delim !== " ") $text = substr($text, 0, strlen($text) - strlen($delim));
        }

        return $text;
    }

    public function getAttr($node, $attrName)
    {
        $text = "";

        if(method_exists($node, "getAttribute")) {
            $text = $node->getAttribute($attrName);
        }

        return trim($text);
    }

    public function deleteTags($tags)
    {
        foreach($tags as $tag)
        {
            $nodes = $this->getNodes($tag);
            foreach($nodes as $node)
            {
                $node->parentNode->removeChild($node);
            }
        }
    }
}