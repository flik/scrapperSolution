<?php
//error_reporting(E_ALL);
//ini_set('display_errors', '1');
include_once('pageParser_classes.php');
$siteUrl = "http://www.immocosemans.be/Web.mvc/nl-be/Home";
$domainUrl = "http://www.immocosemans.be";
$property = array();

$res = file_get_contents($siteUrl);

$parser = new PageParser($res,true);
$parser->deleteTags(array("script", "style"));
foreach($parser->extract_xpath("ul[@id = 'nav']/li/table/tr/td/a/@href", RETURN_TYPE_ARRAY) as $link){
	$pageUrl = $domainUrl.$link;
	if($pageUrl != "http://www.immocosemans.be/Web.mvc/nl-be/Home?Sel=SG9tZQ%3D%3D"){
		$res2 = file_get_contents($pageUrl);
		$ht2 = new PageParser($res2,true);
		foreach($ht2->extract_xpath("div[@class='list-mosaic left']/ul/li/div/div/a/@href", RETURN_TYPE_ARRAY) as $link2){
			if($link2 != ""){
				$pageUrl2 = $domainUrl.$link2;
				$urlArr = explode("/",$pageUrl2);
				$propertyId = end($urlArr);
				$res3 = file_get_contents($pageUrl2);
				$ht3 = new PageParser($res3,true);
				$streetAddress = utf8_decode($ht3->extract_xpath("p[@class='TitleSmall4']",RETURN_TYPE_TEXT));
				$cityState = utf8_decode($ht3->extract_xpath("td[@class='SubtitleSmall4']",RETURN_TYPE_TEXT));
				

				$number ="";
				$street = "";
				$streetNumberInfo = extractAddress($streetAddress);
				$streetArr = explode("|||",$streetNumberInfo);
				$streetNumber = $streetArr[0];
				$streetName = $streetArr[1];

				$cityStateInfo = extractAddress($cityState);
				$cityArr = explode("|||",$cityStateInfo);
				$zipcode = $cityArr[0];
				$city = $cityArr[1];

				$propertyPrice = utf8_decode($ht3->extract_xpath("div[@class='detail-comment-price Title MenuSelected']/p[@class='right']",RETURN_TYPE_TEXT));
				$propertyDescription = utf8_decode($ht3->extract_xpath("div[@id='shortDescription']",RETURN_TYPE_TEXT));
				$propertyDescription = str_replace("BESCHRIJVING PAND", "", $propertyDescription);
				$propertyDescription = trim($propertyDescription);

				if($propertyDescription == ""){
					$propertyDescription = utf8_decode($ht3->extract_xpath("div[@id='description']",RETURN_TYPE_TEXT));
				}
				$propertyType = utf8_decode($ht3->extract_xpath("p[@class='Subtitle']",RETURN_TYPE_TEXT));
				$images = array();
				foreach($ht3->extract_xpath("ul[@class ='bxSlider']/li/a/img/@src",RETURN_TYPE_ARRAY) as $sliderImages){
					$images[] = $domainUrl.$sliderImages;
				}
				$propertyImages = $images;
				$property[] = array("propertyId"=>$propertyId,"propertyPrice"=>$propertyPrice,"propertyType"=>$propertyType,"streetName"=>$streetName,"streetNumber"=>$streetNumber,"cityName"=>$city,"zipCode"=>$zipcode,"propertyDescription"=>$propertyDescription,"propertyImages"=>$propertyImages);
			}
		}
	}
}

echo "Property List: <br>";
echo "<pre>";print_r($property);


function extractAddress($address){
		if (strpos($address, ',') !== false) {
			list($number, $street) = explode(',', $address, 2);
		} else {
			preg_match('~^(.*?)((?:unit )?(?:[0-9]+\s?-\s?[0-9]+|[0-9]+))(.*)$~is', $address, $parts);
			
			$number = $parts[2];
			if (trim($parts[1]) != '') {
				$street .= trim($parts[1]);
			}
			if(trim($parts[3]) != '') {
				if($street ==""){
					$street .= trim($parts[3]);
				}
				else{
					$street .= " ".trim($parts[3]);	
				}
			}
		}

		return $number."|||".$street;

}


?>