<?php

//error_reporting(E_ALL);
//ini_set('display_errors', '1');
include_once('pageParser_classes.php');

$siteUrl = "http://www.immocosemans.be/Web.mvc/nl-be/Detail/1938059";

$res = file_get_contents($siteUrl);

$parser = new PageParser($res,true);
$parser->deleteTags(array("script", "style"));

$streetAddress = utf8_decode($parser->extract_xpath('p[@class="TitleSmall4"]', RETURN_TYPE_TEXT_ALL));
$cityState = utf8_decode($parser->extract_xpath('td[@class="SubtitleSmall4"]', RETURN_TYPE_TEXT_ALL));

$number ="";
$street = "";
$streetNumberInfo = extractAddress($streetAddress);
$streetArr = explode("|||",$streetNumberInfo);
$streetNumber = $streetArr[0];
$streetName = $streetArr[1];

$cityStateInfo = extractAddress($cityState);
$cityArr = explode("|||",$cityStateInfo);
$zipcode = $cityArr[0];
$city = $cityArr[1];

echo "<br>Street Number : ". $streetNumber;
echo "<br>Street Name : ". $streetName;

echo "<br>City Name : ". $city;
echo "<br>zipcode : ". $zipcode;

function extractAddress($address){
	$street = "";
	if (strpos($address, ',') !== false) {
		list($number, $street) = explode(',', $address, 2);
	} else {
		preg_match('~^(.*?)((?:unit )?(?:[0-9]+\s?-\s?[0-9]+|[0-9]+))(.*)$~is', $address, $parts);
		
		$number = $parts[2];
		if (trim($parts[1]) != '') {
			$street .= trim($parts[1]);
		}
		if(trim($parts[3]) != '') {
			if($street ==""){
				$street .= trim($parts[3]);
			}
			else{
				$street .= " ".trim($parts[3]);	
			}
		}
	}

	return $number."|||".$street;

}

?>