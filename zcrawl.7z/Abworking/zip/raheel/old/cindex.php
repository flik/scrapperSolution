<?php
require_once("../crawler_classes.php");
$crawler->use_cookies(true);

//$crawler->enable_delay_between_requests(5,15);
//$crawler->use_cookies(true);
//$crawler->clean_cookies();
//$crawler->use_gzip(false);


$startPages[STATUS_FORSELL] = array
(
'http://www.promocon.be/te-koop' => '',
'http://www.promocon.be/nieuwbouw'=>'new',
);
$startPages[STATUS_TORENT] = array
(
'http://www.promocon.be/te-huur' => '',
);




CrawlerTool::startXML();


foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
	    echo $type;
	        $html = $crawler->request($page_url);
	        $page=2;
	    while(1){
		    processPage($crawler, $status, $type, $html);
		    if(!strpos($html,'Laatste')) break;
	        $html = $crawler->request($page_url.'?page='.$page);
	        $page++;
		 }


    }
}


CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();
    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[contains(@class, 'meet_info')]");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        if($type=="new") $property[TAG_IS_NEW_CONSTRUCTION]=1;
        $property[TAG_UNIQUE_URL_NL] = "http://www.promocon.be" . $parser->getAttr($node, "href");
        $property[TAG_TYPE]=CrawlerTool::getPropertyType($parser->extract_xpath("preceding-sibling::div[2]/descendant::b[1]",'', null, parentNode($node, 1)));
        $property[TAG_UNIQUE_ID] =  getUniqueId($property[TAG_UNIQUE_URL_NL]);
        if($property[TAG_UNIQUE_ID] == "6826" || $property[TAG_UNIQUE_ID] == "7062"){
        	$property[TAG_TYPE] = TYPE_PLOT;
        }
        $propertyCount += 1;
        flush();
   		ob_flush();
        // process item to obtain detail information
        
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $property);
        echo "--------- Completed<br />";
    	

    }
}
function parentNode($node, $n = 1) {
	$parentNode = $node;
	for($i = 1; $i <= $n; $i++) $parentNode = $parentNode->parentNode;

	return $parentNode;
}
function processItem($crawler, $property)
{
	$html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
    $html1=preg_replace('/\<div class="sep"\>:\<\/div\>/',"",$html);
	$parser = new PageParser($html);
	$parser->deleteTags(array("script", "style"));
    $property[TAG_PICTURES] = $parser->extract_xpath("a[contains(@href, 'pictures/')]", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic)
        {
            if(!empty($pic)) $picUrls[] = array(TAG_PICTURE_URL => $pic);
        }
        return $picUrls;
    });


    $maparr=getmapinfo($html);
    if(!empty($maparr[0])) # $property[TAG_LATITUDE]=trim($maparr[0]);
    if(!empty($maparr[1])) # $property[TAG_LONGITUDE]=trim($maparr[1]);

    $property[TAG_TEXT_SHORT_DESC_NL]= $parser->extract_xpath("div[contains(@class, 'content descr')]");
 	$property[TAG_TEXT_TITLE_NL] = $parser->extract_xpath("title");
    $property[TAG_CITY]=$parser->extract_xpath("h1[contains(@class, 'ident-city')]");
    echo $address_full=$parser->extract_xpath("p[contains(@class, 'ident-address')]");
    $property[TAG_STREET]=(preg_match('/(.*?)\d/s',$address_full,$res)) ? trim(strip_tags(($res[1]))) : '';
	preg_match('!\d+\-\d+|\d+[A-Za-z]|\d+\s+\/\d+[A-Za-z]|\d+|$!',$address_full,$res2);
	$property[TAG_NUMBER]=trim($res2[0]);

 	//parse fields
	$vars = array();
	preg_match_all('!<div class="name">([^<>]+)</div>\s+<div class="value">([^<>]+)</div>!',$html1,$res,PREG_SET_ORDER);

	foreach ($res as $arr)
	{
	    $arr[1] = strtolower($arr[1]);

		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$arr[1] = preg_replace('!nbsp|:!','',$arr[1]);
		$vars[$arr[1]] = $arr[2];
		#echo "<br>";
	}

	//rename k.i. to ki
	if (isset($vars['k.i.'])){$vars['ki'] = $vars['k.i.'];unset($vars['k.i.']);}

	//remove transactie (i.e. te koop or te huur)
	if (isset($vars['transactie'])) {unset($vars['transactie']);}

    $property[TAG_ORIGINAL_REFERENCE]=get_var($vars,'unieke code');
	$property[TAG_CONSTRUCTION_YEAR]       = get_var($vars,'bouwjaar','!(\d{4})!');
    $property[TAG_GAS_CONNECTION]          = (get_var($vars,'aansluiting aardgas') === "Ja" ? 1 : 0);
	$property[TAG_LIFT]                    = get_var($vars,'lift') === 'Ja' ? 1 : '';
    $property[TAG_HEATING_NL] = get_var($vars,'verwarming');
    $property[TAG_CONNECTION_TO_WATER]=get_var($vars,'aansluiting waterleiding') === 'Ja' ? 1 : '';
	$property[TAG_PRICE]                   = CrawlerTool::toNumber(get_var($vars,'prijs'));
	$property[TAG_PLANNING_PERMISSION]     = CrawlerTool::contains(get_var($vars,'bouwvergunning verkregen'),'Ja');
    $property[TAG_HAS_PROCEEDING] =CrawlerTool::contains(get_var($vars,'dagvaarding uitgebracht'),'Ja');
	$property[TAG_SUBDIVISION_PERMIT]      = CrawlerTool::contains(get_var($vars,'verkavelingsvergunning'),'Ja');
    $property[TAG_PRIORITY_PURCHASE] =  CrawlerTool::contains(get_var($vars,'voorkooprecht'),'Ja');
    $property[TAG_MOST_RECENT_DESTINATION] =  get_var($vars,'bestemming');
	$property[TAG_EPC_VALUE]               = get_var($vars,'epc','!(\d+)!');
	$property[TAG_KI]                      = str_replace('.','',get_var($vars,'kadastraal inkomen','![^<>0-9]*([0-9.]+)!'));
    $property[TAG_SURFACE_LIVING_AREA]     = get_var($vars,'bewoonbare oppervlakte','!(\d+)!');
    $property[TAG_DOUBLE_GLAZING]=CrawlerTool::contains(get_var($vars,'beglazing') ,"Dubbel");
    $property[TAG_SURFACE_GROUND] =   get_var($vars,'grondoppervlakte','!(\d+)!');
    $property[TAG_LOT_WIDTH] = get_var($vars,'perceel breedte');
	$totalbedrooms                  = get_var($vars,'aantal slaapkamers','!(\d+)!');
	$totalbathroom                  = get_var($vars,'aantal badkamers','!(\d+)!');
	$totalgarage                  = get_var($vars,'garage','!(\d+)!');

	$totallivings=get_var($vars,"woongedeelte");
	$totaltoilets=get_var($vars,"aantal toiletten");
	$totalkitchen=get_var($vars,"keuken");
	$totalstorage=get_var($vars,"berging");
	$totalterrace=get_var($vars,"terras");
	$totalcellar=get_var($vars,"kelder");
	$totalwintergarden=get_var($vars,"veranda");
	$totalstudies=get_var($vars,"kantoor");
	$totalfreepossesion=get_var($vars,"praktijkruimte");



    $bedroomtotal=preg_match("/(\d)$/", $totalbedrooms,$res) ? trim(strip_tags(($res[1]))) : '';
    $livingtotal=preg_match("/(\d)$/", $totallivings,$res) ? trim(strip_tags(($res[1]))) : '';
    $garagetotal=preg_match("/(\d)$/", $totalgarage,$res) ? trim(strip_tags(($res[1]))) : '';
    $bathroomtotal=preg_match("/(\d)$/", $totalbathroom,$res) ? trim(strip_tags(($res[1]))) : '';
    $toilettotal=preg_match("/(\d)$/", $totaltoilets,$res) ? trim(strip_tags(($res[1]))) : '';
    $kitchentotal=preg_match("/(\d)$/", $totalkitchen,$res) ? trim(strip_tags(($res[1]))) : '';
    $storagetotal=preg_match("/(\d)$/", $totalstorage,$res) ? trim(strip_tags(($res[1]))) : '';
    $terracetotal=preg_match("/(\d)$/", $totalterrace,$res) ? trim(strip_tags(($res[1]))) : '';
    $cellartotal=preg_match("/(\d)$/", $totalcellar,$res) ? trim(strip_tags(($res[1]))) : '';
    $wintergardentotal=preg_match("/(\d)$/", $totalwintergarden,$res) ? trim(strip_tags(($res[1]))) : '';
    $studytotal=preg_match("/(\d)$/", $totalstudies,$res) ? trim(strip_tags(($res[1]))) : '';
    $freepossesiontotal=preg_match("/(\d)$/", $totalfreepossesion,$res) ? trim(strip_tags(($res[1]))) : '';

    $bedroomdesc=preg_match("/([a-zA-Z_-\s]*)/", $totalbedrooms,$res) ? trim(strip_tags(($res[1]))) : '';
    $garagedesc=preg_match("/([a-zA-Z_-\s]*)/", $totalgarage,$res) ? trim(strip_tags(($res[1]))) : '';
    $bathroomdesc=preg_match("/([a-zA-Z_-\s]*)/", $totalbathroom,$res) ? trim(strip_tags(($res[1]))) : '';
    $toiletdesc=preg_match("/([a-zA-Z_-\s]*)/", $totaltoilets,$res) ? trim(strip_tags(($res[1]))) : '';
    $kitchendesc=preg_match("/([a-zA-Z_-\s]*)/", $totalkitchen,$res) ? trim(strip_tags(($res[1]))) : '';
    $storagedesc=preg_match("/([a-zA-Z_-\s]*)/", $totalstorage,$res) ? trim(strip_tags(($res[1]))) : '';
    $terracedesc=preg_match("/([a-zA-Z_-\s]*)/", $totalterrace,$res) ? trim(strip_tags(($res[1]))) : '';
    $cellardesc=preg_match("/([a-zA-Z_-\s]*)/", $totalcellar,$res) ? trim(strip_tags(($res[1]))) : '';
    $livingdesc=preg_match("/([a-zA-Z_-\s]*)/", $totallivings,$res) ? trim(strip_tags(($res[1]))) : '';
    $wintergardendesc=preg_match("/([a-zA-Z_-\s]*)/", $totalwintergarden,$res) ? trim(strip_tags(($res[1]))) : '';
    $studydesc=preg_match("/([a-zA-Z_-\s]*)/", $totalstudies,$res) ? trim(strip_tags(($res[1]))) : '';
    $freepossesiondesc=preg_match("/([a-zA-Z_-\s]*)/", $totalfreepossesion,$res) ? trim(strip_tags(($res[1]))) : '';


     $wintergarden = array();
     $totalwintergardens = array();
     if(!empty($wintergardendesc)) 		 $wintergarden[TAG_WINTERGARDEN_DESC_NL]=$wintergardendesc;
     if(!empty($wintergardensurface)) 		 $wintergarden[TAG_WINTERGARDEN_SURFACE]=$wintergardensurface;
     if(!empty($wintergarden)) $totalwintergardens[] = $wintergarden;
     if(!empty($totalwintergardens)) $property[TAG_WINTERGARDENS] = $totalwintergardens;


     $freepossesion = array();
     $totalfreepossesions = array();
     if(!empty($freepossesiondesc)) 		 $freepossesion[TAG_FREE_PROFESSION_DESC_NL]=$freepossesiondesc;
     if(!empty($freepossesionsurface)) 		 $freepossesion[TAG_FREE_PROFESSION_SURFACE]=$freepossesionsurface;
     if(!empty($freepossesion)) $totalfreepossesions[] = $freepossesion;
     if(!empty($totalfreepossesions)) $property[TAG_FREE_PROFESSIONS] = $totalfreepossesions;


     $study = array();
     $totalstudys = array();
     if(!empty($studydesc)) 		 $study[TAG_STUDY_DESC_NL]=$studydesc;
     if(!empty($studysurface)) 		 $study[TAG_STUDY_SURFACE]=$studysurface;
     if(!empty($study)) $totalstudys[] = $study;
     if(!empty($totalstudys)) $property[TAG_STUDIES] = $totalstudys;



     $bathroom = array();
     $totalbathrooms = array();
     if(!empty($bathroomdesc)) 		 $bathroom[TAG_BATHROOM_DESC_NL]=$bathroomdesc;
     if(!empty($bathroomsurface)) 		 $bathroom[TAG_BATHROOM_SURFACE]=$bathroomsurface;
     if(!empty($bathroom)) $totalbathrooms[] = $bathroom;
     if(!empty($totalbathrooms)) $property[TAG_BATHROOMS] = $totalbathrooms;

     $cellar = array();
     $totalcellars = array();
     if(!empty($cellardesc)) 		 $cellar[TAG_CELLAR_DESC_NL]=$cellardesc;
     if(!empty($cellarsurface)) 		 $cellar[TAG_CELLAR_SURFACE]=$cellarsurface;
     if(!empty($cellar)) $totalcellars[] = $cellar;
     if(!empty($totalcellars)) $property[TAG_CELLARS] = $totalcellars;

	 $bedroom = array();
	 $totalbedrooms = array();
	 if(!empty($bedroomdesc)) 	    	 $bedroom[TAG_BEDROOM_DESC_NL]=$bedroomdesc;
	 if(!empty($bedroomsurface)) 		 $bedroom[TAG_BEDROOM_SURFACE]=$bedroomsurface;
	 if(!empty($bedroom)) $totalbedrooms[] = $bedroom;
	 if(!empty($totalbedrooms)) $property[TAG_BEDROOMS] = $totalbedrooms;

     $toilet = array();
     $totaltoilets = array();
     if(!empty($toiletdesc)) 		 $toilet[TAG_TOILET_DESC_NL]=$toiletdesc;
     if(!empty($toiletsurface)) 		 $toilet[TAG_TOILET_SURFACE]=$toiletsurface;
     if(!empty($toilet)) $totaltoilets[] = $toilet;
     if(!empty($totaltoilets)) $property[TAG_TOILETS] = $totaltoilets;

     $garage = array();
     $totalgarages = array();
     if(!empty($garagedesc)) 		 $garage[TAG_GARAGE_DESC_NL]=$garagedesc;
     if(!empty($garagesurface)) 		 $garage[TAG_GARAGE_SURFACE]=$garagesurface;
     if(!empty($garage)) $totalgarages[] = $garage;
     if(!empty($totalgarages)) $property[TAG_GARAGES] = $totalgarages;

     $kitchen = array();
     $totalkitchens = array();

     if(!empty($kitchendesc)) 		 $kitchen[TAG_KITCHEN_DESC_NL]=$kitchendesc;
     if(!empty($kitchensurface)) 		 $kitchen[TAG_KITCHEN_SURFACE]=$kitchensurface;
     if(!empty($kitchen)) $totalkitchens[] = $kitchen;
     if(!empty($totalkitchens)) $property[TAG_KITCHENS] = $totalkitchens;

     $storage = array();
     $totalstorages = array();
     if(!empty($storagedesc)) 		 $storage[TAG_STOREROOM_DESC_NL]=$storagedesc;
     if(!empty($storagesurface)) 		 $storage[TAG_STOREROOM_SURFACE]=$storagesurface;
     if(!empty($storage)) $totalstorages[] = $storage;
     if(!empty($totalstorages)) $property[TAG_STOREROOMS] = $totalstorages;

     $terrace = array();
     $totalterraces = array();
     if(!empty($terracedesc)) 		 $terrace[TAG_TERRACE_DESC_NL]=$terracedesc;
     if(!empty($terracesurface)) 		 $terrace[TAG_TERRACE_SURFACE]=$terracesurface;
     if(!empty($terrace)) $totalterraces[] = $terrace;
     if(!empty($totalterraces)) $property[TAG_TERRACES] = $totalterraces;

     $living = array();
     $totallivings = array();
     if(!empty($livingdesc)) 		 $living[TAG_LIVING_DESC_NL]=$livingdesc;
     if(!empty($livingsurface)) 		 $living[TAG_LIVING_SURFACE]=$livingsurface;
     if(!empty($living)) $totallivings[] = $living;
     if(!empty($totallivings)) $property[TAG_LIVINGS] = $totallivings;

     $floorplan = array();
     $totalfloorplans = array();
     if(!empty($floorplandesc)) 		 $floorplan[TAG_FLOOR_PLAN_DESC_NL]=$floorplandesc;
     if(!empty($floorplan)) $totalfloorplans[] = $floorplan;
     if(!empty($totalfloorplans)) $property[TAG_FLOOR_PLANS] = $totalfloorplans;



    if(!empty($livingtotal))  $property[TAG_LIVINGS][TAG_TOTAL_AMOUNT]=$livingtotal;
    if(!empty($toilettotal)) $property[TAG_TOILETS][TAG_TOTAL_AMOUNT]=$toilettotal;
    if(!empty($bathroomtotal)) $property[TAG_BATHROOMS][TAG_TOTAL_AMOUNT]=$bathroomtotal;
    if(!empty($cellartotal)) $property[TAG_CELLARS][TAG_TOTAL_AMOUNT]=$cellartotal;
    if(!empty($kitchentotal)) $property[TAG_KITCHENS][TAG_TOTAL_AMOUNT]=$kitchentotal;
    if(!empty($bedroomtotal))  $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT]=$bedroomtotal;
    if(!empty($garagetotal)) $property[TAG_GARAGES][TAG_TOTAL_AMOUNT]=$garagetotal;
    if(!empty($terracetotal)) $property[TAG_TERRACES][TAG_TOTAL_AMOUNT]=$terracetotal;
    if(!empty($storagetotal)) $property[TAG_STOREROOMS][TAG_TOTAL_AMOUNT]=$storagetotal;

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_TITLE_NL]);
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_SHORT_DESC_NL]);

    $unmatched_variables = array();
    foreach ($vars as $key => $val)
    {
        $k = getAttributes($key);
        if(!empty($k)){
            $property[$k] = GetExactAttrib($k,$val);
        }
        else{
            if(trim($val) != ""){
                $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $key, TAG_VARIABLE_VALUE => $val);
            }
        }
    }

    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;

	// $unmatched_variables = array();
	// foreach ($vars as $label => $value)
	// {
	// 	$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	// }
	// $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
    debug($property);
	CrawlerTool::saveProperty($property);

}


function getUniqueId($url) {
	preg_match("/id=(\d+)/", $url, $match);
	if($match) return $match[1];
}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function getmapinfo($mapurl){
   preg_match('/AddMarker\((.*?)\, \'WindowInfo\'\)/',$mapurl,$res);
   if($res){
     $ret=explode(",", $res[1]);
     return $ret;
    }
}

function getAttributes($ke='',$lang='nl'){
    $attrib =array();
    $attrib[$lang] = array("prijs" => TAG_PRICE,
        "bouwjaar" => TAG_CONSTRUCTION_YEAR,
        "grondopp" => TAG_SURFACE_GROUND, 
        "bewoonbare" => TAG_SURFACE_LIVING_AREA,
        "slaapkamer"=> TAG_BEDROOMS_TOTAL,
        "badkam"=> TAG_BATHROOMS_TOTAL,
        "epc" => TAG_EPC_VALUE,
        "ki" => TAG_KI,
        "verdieping" => TAG_AMOUNT_OF_FLOORS,
        "living" => TAG_SURFACE_LIVING_AREA,
        "renovatie" => TAG_RENOVATION_YEAR,
        "kadaster sectie" => TAG_CADASTRAL_SECTION,
        "beschikbaar" => TAG_FREE_FROM,
        "fax" => TAG_FAX,
        "tel" => TAG_CELLPHONE,
        "mail" => TAG_EMAIL,
        "winkels" => TAG_DISTANCE_SHOPS,
        "vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
        "overstromings" => TAG_FLOOD_INFORMATION_NL,
        "garage" => TAG_GARAGES_TOTAL,
        "toilet" => TAG_TOILETS_TOTAL,
        "parking" => TAG_PARKINGS_TOTAL,
        "gevels" => TAG_AMOUNT_OF_FACADES,
        "lasten" => TAG_COMMON_COSTS,
        "gas" => TAG_GAS_CONNECTION,
        "water" => TAG_CONNECTION_TO_WATER,
        "telefoon" => TAG_TELEPHONE,
        "lift" => TAG_LIFT,
        "gemeubeld" => TAG_FURNISHED,
        "tuin" => TAG_GARDEN_AVAILABLE,
        "haard" => TAG_OPEN_FIRE,
        "alarm" => TAG_ALARM,
        "parlofoon" => TAG_PARLOPHONE,
        "videofoon" => TAG_VIDEOPHONE,
        "breedte" => TAG_LOT_WIDTH,
        "diepte" => TAG_LOT_DEPTH,
        "constructie" => TAG_CONSTRUCTION_TYPE,
        "gevelbreedte" => TAG_FRONTAGE_WIDTH,
        "winkel" => TAG_HEATING_NL,
        "douche" => TAG_SHOWERS_TOTAL,
        "keuken" => TAG_KITCHEN_TYPE_NL,
        "ligging" => TAG_SUBDIVISION_PERMIT,
        "stedenbouwkundige" => TAG_PLANNING_PERMISSION,
        "terras" => TAG_TERRACES,
        "terrein" => TAG_SURFACE_GROUND,
        "scholen" => TAG_DISTANCE_SCHOOL,
        "oppervlakte" => TAG_SURFACE_LIVING_AREA,
        "eetkamer" => TAG_DININGS,
        "dressing" => TAG_DRESSINGS,
        "kelder" => TAG_CELLARS,
        "beroep" => TAG_FREE_PROFESSIONS,
        "berging" => TAG_STOREROOMS,
        "wasplaats" => TAG_LAUNDRY_ROOMS,
        "elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
        "beglazing" => TAG_DOUBLE_GLAZING,
        "verwarming" => TAG_HEATING_NL,
        "riolering" => TAG_CONNECTION_TO_SEWER,
        "olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
        "waterput" => TAG_WELL,
        "telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
        "toegangscontrole" => TAG_ACCESS_SEMIVALID,
        "computer" => TAG_INTERNET_CONNECTION,
        );
    foreach($attrib[$lang] as $k => $s){
        $mystring = strtolower($ke);
        $pos = strpos($mystring, $k);
        if ($pos === false) {

        }
        else{
            return $attrib[$lang][$k];
        }
    }
}

function GetExactAttrib($key,$val){
    switch($key){
    case TAG_PRICE:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_BATHROOMS_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_BEDROOMS_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_GARAGES_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_TOILETS_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_CONSTRUCTION_YEAR:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_RENOVATION_YEAR:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_KI:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_EPC_VALUE:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_EPC_CERTIFICATE_NUMBER:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_SURFACE_LIVING_AREA:
       return CrawlerTool::toNumber($val);
       break;
    case TAG_SURFACE_GROUND:
       return CrawlerTool::toNumber($val);
       break;
    case TAG_MOST_RECENT_DESTINATION:
       return trim($val);
       break;
    case TAG_PLANNING_PERMISSION:
       return 1;
       break;
    case TAG_SUBDIVISION_PERMIT:
       return CrawlerTool::toNumber($val); 
    break;
    default:
        return $val;  
    break;
     
    }
}

function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}


?>
