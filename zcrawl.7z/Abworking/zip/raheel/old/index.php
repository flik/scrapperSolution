<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1028

require_once("../crawler_classes.php");



CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.immovip.be/"
    )
);


$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immovip.be/?page_id=4"
    ),
);



/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/


/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);

        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[contains(@href, 'detail&id=')][b]");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_NL] = "http://www.immovip.be" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  $parser->regex("/(\d+)$/", $property[TAG_UNIQUE_URL_NL]);
        $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($parser->getText($node));
        // check for sold or rented properties
        $propertyStatus = CrawlerTool::getPropertyStatus($parser->getText($node));
        if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
        {
            $property[TAG_STATUS] = $propertyStatus;
        }

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}  // CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;
       // if($item["item"][TAG_UNIQUE_ID] == "197" || $item["item"][TAG_UNIQUE_ID] == "117" || $item["item"][TAG_UNIQUE_ID] == "147"){
            // process item to obtain detail information
            echo "--------- Processing property #$propertyCount ...";
            echo $item["itemUrl"]."<br>";
            processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
            echo "--------- Completed<br />";
        //}

    }

    return sizeof($items);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("table/tr/td[@colspan = '2']/text()");
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@id= 'content']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PICTURES] = $parser->extract_xpath("a[contains(@href, 'popUpWindow')]/img", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.immovip.be" . $pic);

        return $picUrls;
    });

    $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $parser->extract_xpath("td[contains(text(), 'Gemeente')]/following-sibling::td[1]")));
    if(empty($property[TAG_CITY])) return;

    // Raheel Fix
    if(strtolower($property[TAG_CITY]) == "griekenland"){
        return;
    }
    // Raheel Fix End
    
    if(stripos($property[TAG_PLAIN_TEXT_ALL_NL], "opbrengsteigendom")!== false) $property[TAG_IS_INVESTMENT_PROPERTY] = 1;
    if(stripos($property[TAG_PLAIN_TEXT_ALL_NL], "Nieuwbouw")!== false) $property[TAG_IS_NEW_CONSTRUCTION] = 1;
    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("Categorie"));
    $property[TAG_PRICE] = $parser->extract_xpath("prijs", RETURN_TYPE_NUMBER);
    $property[TAG_EPC_VALUE] = $parser->extract_regex("/(\d+)\s?kwh/i", RETURN_TYPE_EPC);
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_regex("/epc\s?(\d+)/i", RETURN_TYPE_EPC);
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_regex("/Bouwjaar\s(\d+)/i", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_regex("/(\d)\s?(slaapkamers|slpk)/", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] = $parser->extract_regex("/(\d)\sgarageboxen/", RETURN_TYPE_NUMBER);
    $property[TAG_GARDEN_AVAILABLE] = CrawlerTool::contains($parser->extract_regex("/(tuin)/"), "tuin");


    //CrawlerTool::test($property);
    debug($property);

    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}


function debug($obj, $e = false)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
    if($e)
      exit;
    
}