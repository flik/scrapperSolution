<?php
/* ============================= CONFIG ============================= */
// Crawler ID 40
require_once("../../crawler_classes.php");

CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.sinjoor.be/" 
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://flexplus.sinjoor.be/flexplus/websites/live/Sinjoor2010/viewEstates.action?&orderBy=e.websiteStats.latestPublication.creationDate+desc&estate.status-in=FOR_SALE,OPTION_FOR_SALE,SOLD&estate.category=Residential" 
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://flexplus.sinjoor.be/flexplus/websites/live/Sinjoor2010/viewEstates.action?&orderBy=e.websiteStats.latestPublication.creationDate+desc&estate.status-in=FOR_RENT,OPTION_FOR_RENT,RENTED&estate.category=Residential"
        
    ),
);

/* ============================= END CONFIG ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "OPEN THE DOOR";
$office[TAG_OFFICE_URL] = "http://www.bkgroup.be/";
$office[TAG_STREET] = "Chaussée de la hulpe";
$office[TAG_NUMBER] = "177";
$office[TAG_ZIP] = "1170";
$office[TAG_CITY] = "Bruxelles";
$office[TAG_TELEPHONE] = "026632745";
$office[TAG_EMAIL] = "info@bkgroup.be";

CrawlerTool::saveOffice($office);
$status = STATUS_FORSALE;
$type = TYPE_NONE;
$html = $crawler->request("http://www.trianon-invest.be/Web.mvc/fr-fr/Detail/1496848");
processPage($crawler, $status, $type, $html);
// foreach($startPages as $status => $types)
// {
//     foreach($types as $type => $pages)
//     {
//         foreach($pages as $page)
//         {
//             debugx($page);
//             $html = $crawler->request($page);
//             processPage($crawler, $status, $type, $html);
            
//             $nextPages = getPages($html);
//             foreach($nextPages as $nextPage)
//             {
//                 debugx($nextPage);
//                 $html = $crawler->request($nextPage);
//                 processPage($crawler, $status, $type, $html);
//             }
//         }
//     }
// }

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

/**
 * Get a list of next pages
 */
function getPages($html)
{
    // $parser = new PageParser($html);

    // $pages = array();
    // $nodes = $parser->getNodes("a[@class = 'pager']"); 

    // if(!empty($nodes))
    // {
    //     foreach($nodes as $node)
    //     {
    //         $pages[] = "http://flexplus.sinjoor.be/flexplus/websites/live/Sinjoor2010/" . $parser->getAttr($node, "href");
    //     }
    // }

    // return array_unique($pages);
}

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    // $parser = new PageParser($html);
    // $nodes = $parser->getNodes("div[@class ='foto']/a");
    // // debug($nodes ); exit;
    // $items = array();
    // foreach($nodes as $node)
    // {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type; 
        $property[TAG_UNIQUE_URL_NL] = "http://www.trianon-invest.be/Web.mvc/fr-fr/Detail/1496848"; 
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]); 
        
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
    //}    

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...".$item["itemUrl"];
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}
/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    //debug($html);exit;
	//Out of Belgium
	if($property[TAG_UNIQUE_ID] == '1926903245' )
	return;

    $html = str_replace("±", "", $html);
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_DESC_NL] = utf8_decode($parser->extract_xpath("td[@width = '300']", RETURN_TYPE_TEXT_ALL)); 
    $property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode($parser->extract_xpath("div[@id= 'site_container']", RETURN_TYPE_TEXT_ALL)); 
    
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));
      
    // $property[TAG_PICTURES] = $parser->extract_xpath("td[@height = '462']/img/@src", RETURN_TYPE_ARRAY, function($pics)
    // {
    //     $picUrls = array();
    //     foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.bkgroup.be" . $pic); 
    //     return $picUrls;
    // });

    $address = utf8_decode($parser->extract_xpath("td[@width = '300']/strong", RETURN_TYPE_TEXT)); 
		
    CrawlerTool::parseAddress(preg_replace("/,|\//", "", $address), $property);
    
    $addr = explode(' ',$address);
    $property[TAG_CITY] = trim($addr[count($addr)-1]);
    $property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
    
    $property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
    $property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
    
    $property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
    $property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
    
    if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
    
    unset($property[TAG_BOX_NUMBER]);

    // if(strlen($property[TAG_ZIP]) < 4)
    // return;
    
    // if(empty($property[TAG_CITY]))
    // return;

    $labels = $values = $vars = array();
    $nodes = $parser->getNodes("td[@class = 'label']");
    foreach($nodes as $node)
    {
        $labels[] = $parser->getText($node);
    }

    $nodes = $parser->getNodes("td[@class = 'value']");
    foreach($nodes as $node)
    {
        $values[] = $parser->getText($node);
    }

    foreach($labels as $k => $label)
    {
        $key = $labels[$k];
        $val = $values[$k];
        $k = getAttributesFr($key);
        if(!empty($k)){
            if(!isset($property[$k])){
                $property[$k] = GetExactAttrib($k,$val);
            }
        }
        else{
            if(trim($val) != ""){
                $key = htmlentities($key, ENT_COMPAT, 'UTF-8');
                $val = htmlentities($val, ENT_COMPAT, 'UTF-8');
                $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $key, TAG_VARIABLE_VALUE => $val);
            }
        }
    }

    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
    
    //$property[TAG_PRICE] = $parser->extract_xpath("td[contains(text(), 'Prijs')]", RETURN_TYPE_NUMBER);
   //In case of TD and get next td val
	// $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");
 //    if(empty($property[TAG_PRICE])) $property[TAG_PRICE] = $parser->extract_xpath("Prijs", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC", RETURN_TYPE_EPC);
 //    if(empty($property[TAG_EPC_CERTIFICATE_NUMBER])) $property[TAG_EPC_CERTIFICATE_NUMBER] = $parser->extract_xpath("EPC certificaatnr.", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_KI]))$property[TAG_KI] = $parser->extract_xpath("KI", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_KI_INDEX]))$property[TAG_KI_INDEX] = $parser->extract_xpath("kad.ink.", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_PLANNING_PERMISSION]))$property[TAG_PLANNING_PERMISSION] = ($parser->extract_xpath("Stedenbouwkundige vergunning") === "Ja" ? 1 : 0);
 //    if(empty($property[TAG_CONSTRUCTION_YEAR]))$property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("Bouwjaar", RETURN_TYPE_YEAR);
 //    if(empty($property[TAG_RENOVATION_YEAR]))$property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("Renovatie jaar", RETURN_TYPE_YEAR);
 //    if(empty($property[TAG_SURFACE_LIVING_AREA]))$property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Bewoonbare opp.", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_SURFACE_GROUND]))$property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Grondopp.", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_BEDROOMS_TOTAL]))$property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Aantal slaapkamers", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_BATHROOMS_TOTAL]))$property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Badkamer", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_TOILETS_TOTAL]))$property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toiletten aantal", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_GARAGES_TOTAL]))$property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("garage aantal", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_PARKINGS_TOTAL]))$property[TAG_PARKINGS_TOTAL] = $parser->extract_xpath("parking buiten aantal", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_AMOUNT_OF_FACADES]))$property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_AMOUNT_OF_FLOORS]))$property[TAG_AMOUNT_OF_FLOORS] = $parser->extract_xpath("verdiepingen aantal", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_FREE_FROM_DATE]))$property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Beschikbaar vanaf", RETURN_TYPE_UNIX_TIMESTAMP); 
 //    if(empty($property[TAG_COMMON_COSTS]))$property[TAG_COMMON_COSTS] = $parser->extract_xpath("lasten", RETURN_TYPE_NUMBER); 
 //    if(empty($property[TAG_GAS_CONNECTION]))$property[TAG_GAS_CONNECTION] = ($parser->extract_xpath("gas") === "Ja" ? 1 : 0); 
 //    if(empty($property[TAG_CONNECTION_TO_WATER]))$property[TAG_CONNECTION_TO_WATER] = ($parser->extract_xpath("water") === "Ja" ? 1 : 0); 
 //    if(empty($property[TAG_TELEPHONE_CONNECTION]))$property[TAG_TELEPHONE_CONNECTION] = ($parser->extract_xpath("telefoon") === "Ja" ? 1 : 0); 
 //    if(empty($property[TAG_LIFT]))$property[TAG_LIFT] = ($parser->extract_xpath("lift") === "Ja" ? 1 : 0); 
 //    if(empty($property[TAG_FURNISHED]))$property[TAG_FURNISHED] = ($parser->extract_xpath("Gemeubeld") === "Ja" ? 1 : 0); 
 //    if(empty($property[TAG_GARDEN_AVAILABLE]))$property[TAG_GARDEN_AVAILABLE] = ($parser->extract_xpath("Tuin") === "Ja" ? 1 : 0); 
 //    if(empty($property[TAG_OPEN_FIRE]))$property[TAG_OPEN_FIRE] = ($parser->extract_xpath("open haard aantal") ? 1 : 0); 
 //    if(empty($property[TAG_ALARM]))$property[TAG_ALARM] = ($parser->extract_xpath("alarm") ? 1 : 0); 
 //    if(empty($property[TAG_PARLOPHONE]))$property[TAG_PARLOPHONE] = ($parser->extract_xpath("parlofoon") ? 1 : 0); 
 //    if(empty($property[TAG_VIDEOPHONE]))$property[TAG_VIDEOPHONE] = ($parser->extract_xpath("videofoon") === "Ja" ? 1 : 0); 
 //    if(empty($property[TAG_LOT_WIDTH]))$property[TAG_LOT_WIDTH] 		= $parser->extract_xpath("Perceelbreedte:", RETURN_TYPE_NUMBER); 
 //    if(empty($property[TAG_LOT_DEPTH]))$property[TAG_LOT_DEPTH] 		= $parser->extract_xpath("Perceeldiepte:", RETURN_TYPE_NUMBER); 
 //    if(empty($property[TAG_CONSTRUCTION_TYPE]))$property[TAG_CONSTRUCTION_TYPE] 	= $parser->extract_xpath("Type constructie:", RETURN_TYPE_TEXT);
 //    if(empty($property[TAG_FRONTAGE_WIDTH]))$property[TAG_FRONTAGE_WIDTH] 	= $parser->extract_xpath("Gevelbreedte:", RETURN_TYPE_NUMBER); 
 //    if(empty($property[TAG_HEATING_NL]))$property[TAG_HEATING_NL]		= $parser->extract_xpath("Winkel:", RETURN_TYPE_NUMBER); 
 //    if(empty($property[TAG_SHOWERS_TOTAL]))$property[TAG_SHOWERS_TOTAL]        = $parser->extract_xpath("salle de douches nombre", RETURN_TYPE_NUMBER); 
 //    if(empty($property[TAG_FREE_FROM]))$property[TAG_FREE_FROM]            =  $parser->extract_xpath("beschikbaar vanaf", RETURN_TYPE_TEXT); 
 //    if(empty($property[TAG_KITCHEN_TYPE_NL]))$property[TAG_KITCHEN_TYPE_NL]      = $parser->extract_xpath("keuken type", RETURN_TYPE_TEXT);
 //    if(empty($property[TAG_SUBDIVISION_PERMIT]))$property[TAG_SUBDIVISION_PERMIT]   = $parser->extract_xpath("Ligging:", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_PRIORITY_PURCHASE]))$property[TAG_PRIORITY_PURCHASE]   = $parser->extract_xpath("keuken type", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_HAS_PROCEEDING]))$property[TAG_HAS_PROCEEDING]   = $parser->extract_xpath("keuken type", RETURN_TYPE_NUMBER);
 //    if(empty($property[TAG_MOST_RECENT_DESTINATION]))$property[TAG_MOST_RECENT_DESTINATION] =  $parser->extract_xpath("Stedenbouwkundige bestemming", RETURN_TYPE_TEXT); 
    
    debug($property); exit;

    CrawlerTool::saveProperty($property);
}

function getLanguageText($crawler, &$property)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
    $html = str_replace("±", "", $html);
    $parser = new PageParser($html, true);

    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}

function getAttributes($ke='',$lang='nl'){
    $attrib =array();
    $attrib[$lang] = array("prijs" => TAG_PRICE,
        "bouwjaar" => TAG_CONSTRUCTION_YEAR,
        "grondopp" => TAG_SURFACE_GROUND, 
        "bewoonbare" => TAG_SURFACE_LIVING_AREA,
        "slaapkamer"=> TAG_BEDROOMS_TOTAL,
        "badkam"=> TAG_BATHROOMS_TOTAL,
        "epc" => TAG_EPC_VALUE,
        "ki" => TAG_KI,
        "verdieping" => TAG_AMOUNT_OF_FLOORS,
        "living" => TAG_SURFACE_LIVING_AREA,
        "renovatie" => TAG_RENOVATION_YEAR,
        "kadaster sectie" => TAG_CADASTRAL_SECTION,
        "beschikbaar" => TAG_FREE_FROM,
        "fax" => TAG_FAX,
        "tel" => TAG_CELLPHONE,
        "mail" => TAG_EMAIL,
        "winkels" => TAG_DISTANCE_SHOPS,
        "vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
        "overstromings" => TAG_FLOOD_INFORMATION_NL,
        "garage" => TAG_GARAGES_TOTAL,
        "toilet" => TAG_TOILETS_TOTAL,
        "parking" => TAG_PARKINGS_TOTAL,
        "gevels" => TAG_AMOUNT_OF_FACADES,
        "lasten" => TAG_COMMON_COSTS,
        "gas" => TAG_GAS_CONNECTION,
        "water" => TAG_CONNECTION_TO_WATER,
        "telefoon" => TAG_TELEPHONE,
        "lift" => TAG_LIFT,
        "gemeubeld" => TAG_FURNISHED,
        "tuin" => TAG_GARDEN_AVAILABLE,
        "haard" => TAG_OPEN_FIRE,
        "alarm" => TAG_ALARM,
        "parlofoon" => TAG_PARLOPHONE,
        "videofoon" => TAG_VIDEOPHONE,
        "breedte" => TAG_LOT_WIDTH,
        "diepte" => TAG_LOT_DEPTH,
        "constructie" => TAG_CONSTRUCTION_TYPE,
        "gevelbreedte" => TAG_FRONTAGE_WIDTH,
        "winkel" => TAG_HEATING_NL,
        "douche" => TAG_SHOWERS_TOTAL,
        "keuken" => TAG_KITCHEN_TYPE_NL,
        "ligging" => TAG_SUBDIVISION_PERMIT,
        "stedenbouwkundige" => TAG_PLANNING_PERMISSION,
        "terras" => TAG_TERRACES,
        "terrein" => TAG_SURFACE_GROUND,
        "scholen" => TAG_DISTANCE_SCHOOL,
        "oppervlakte" => TAG_SURFACE_LIVING_AREA,
        "eetkamer" => TAG_DININGS,
        "dressing" => TAG_DRESSINGS,
        "kelder" => TAG_CELLARS,
        "beroep" => TAG_FREE_PROFESSIONS,
        "berging" => TAG_STOREROOMS,
        "wasplaats" => TAG_LAUNDRY_ROOMS,
        "elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
        "beglazing" => TAG_DOUBLE_GLAZING,
        "verwarming" => TAG_HEATING_NL,
        "riolering" => TAG_CONNECTION_TO_SEWER,
        "olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
        "waterput" => TAG_WELL,
        "telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
        "toegangscontrole" => TAG_ACCESS_SEMIVALID,
        "network" => TAG_INTERNET_CONNECTION,
        );
    foreach($attrib[$lang] as $k => $s){
        $mystring = strtolower($ke);
        $pos = strpos($mystring, $k);
        if ($pos === false) {

        }
        else{
            return $attrib[$lang][$k];
        }
    }
}

function getAttributesFr($ke='',$lang='fr'){
    $attrib =array();
    $attrib[$lang] = array(
        "Meuble" => TAG_FURNISHED,
        "facades" => TAG_AMOUNT_OF_FACADES,
        "nombre_de_chambres"=> TAG_BEDROOMS_TOTAL,
        "nombre_de_salle_de_bain"=> TAG_BATHROOMS_TOTAL,
        "jardin" => TAG_GARDEN_AVAILABLE,
        "garage" => TAG_GARAGES_TOTAL,
        "terras" => TAG_TERRACES,
        "parking" => TAG_PARKINGS_TOTAL,
        "habita" => TAG_SURFACE_LIVING_AREA,
        "terrain" => TAG_SURFACE_GROUND,
        "disponible" => TAG_FREE_FROM,
        "magasins" => TAG_DISTANCE_SHOPS,
        "transport" => TAG_DISTANCE_PUBLIC_TRANSPORT,
        "toilet" => TAG_TOILETS_TOTAL,
        "construction_annee" => TAG_CONSTRUCTION_YEAR,
        "renovation_annee" => TAG_RENOVATION_YEAR,
        "tages" => TAG_AMOUNT_OF_FLOORS,
        "alarm" => TAG_ALARM,
        "gaz" => TAG_GAS_CONNECTION,
        "eau" => TAG_CONNECTION_TO_WATER,
        "parlophone" => TAG_PARLOPHONE,
        "vitrage" => TAG_DOUBLE_GLAZING,
        "network" => TAG_INTERNET_CONNECTION,
        "douche" => TAG_SHOWERS_TOTAL,
        "caves" => TAG_CELLARS,
        "dressing" => TAG_DRESSINGS,
        "telephone" => TAG_TELEPHONE,
        "videophone" => TAG_VIDEOPHONE,
        "manger" => TAG_DININGS,
        "ecoles" => TAG_DISTANCE_SCHOOL,
        "sejour" => TAG_SURFACE_LIVING_AREA,
        "ascenseur" => TAG_LIFT,
        "largeur_du_lot" => TAG_LOT_WIDTH,
        "mazout" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
        "citerne" => TAG_WELL,
        "chauffage" => TAG_HEATING_FR,
        "electricite " => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
        "fax" => TAG_FAX,
        "tel" => TAG_CELLPHONE,
        "inondation" => TAG_FLOOD_INFORMATION_FR,
        "egouts" => TAG_CONNECTION_TO_SEWER,
        "cuisine" => TAG_KITCHEN_TYPE_FR,
        "construction_type" => TAG_CONSTRUCTION_TYPE,
        "chauffage" => TAG_HEATING_FR,
        "debarras" => TAG_STOREROOMS,
        "telephoniques" => TAG_TELEPHONE_CONNECTION,
        "dacces" => TAG_ACCESS_SEMIVALID,
        "lotissement" => TAG_SUBDIVISION_PERMIT,
        "batir" => TAG_PLANNING_PERMISSION,
        "cadastrales" => TAG_CADASTRAL_SECTION,
        "prix" => TAG_PRICE, 
        "epc" => TAG_EPC_VALUE,
        "ki" => TAG_KI,
        "mail" => TAG_EMAIL,
        "commun" => TAG_COMMON_COSTS,
        "feu" => TAG_OPEN_FIRE,
        "beaucoup_de_profondeur" => TAG_LOT_DEPTH,
        "facade_largeur" => TAG_FRONTAGE_WIDTH,
        );
    $mystring = strtolower($ke);
    $mystring = str_replace(" ", "_", $mystring);
    $mystring = normalize_str($mystring);
    foreach($attrib[$lang] as $k => $s){
        $pos = strpos($mystring, $k);
        if ($pos !== false) {
            return $attrib[$lang][$k];
        }
    }
}
        
    
    

function GetExactAttrib($key,$val){
    switch($key){
    case TAG_PRICE:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_BATHROOMS_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_BEDROOMS_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_GARAGES_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_TOILETS_TOTAL:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_CONSTRUCTION_YEAR:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_RENOVATION_YEAR:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_KI:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_EPC_VALUE:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_EPC_CERTIFICATE_NUMBER:
        return CrawlerTool::toNumber($val);
        break;
    case TAG_SURFACE_LIVING_AREA:
       return CrawlerTool::toNumber($val);
       break;
    case TAG_SURFACE_GROUND:
       return CrawlerTool::toNumber($val);
       break;
    case TAG_MOST_RECENT_DESTINATION:
       return trim($val);
       break;
    case TAG_PLANNING_PERMISSION:
       return 1;
       break;
    case TAG_SUBDIVISION_PERMIT:
       return CrawlerTool::toNumber($val); 
    break;
    default:
        return CrawlerTool::toNumber($val);  
    break;
     
    }
}

function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");
        foreach($invalid as $k => $v){
            $str = str_replace($k, $v, $str); //array_values($invalid)
        }

        return $str;
    }
