<?php
//Coding Standards Version 1
header('Content-Type: text/html; charset=utf-8');

error_reporting(E_ALL);
ini_set('display_errors', '1');

/* ============================= CONFIG ============================= */
// Crawler ID 1xx3
require_once("./../crawler_classes.php");

CrawlerTool::setDefault(array(TAG_OFFICE_URL => "http://www.hyboma.be/"));

$startPages[STATUS_FORSALE] = array(
  TYPE_NONE => array(
    "http://hyboma.be/te-koop",
  ),
);

$startPages[STATUS_FORRENT] = array(
  TYPE_NONE => array(
    "http://hyboma.be/nieuwbouw",
  ),
);

/* ============================= END CONFIG ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "TopCompany";
$office[TAG_OFFICE_URL] = "http://www.topclassimmo.be/";
$office[TAG_STREET] = "Winterslagstraat";
$office[TAG_NUMBER] = "90";
$office[TAG_ZIP] = "3600";
$office[TAG_CITY] = "GENK";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "0478 34 89 36 ";
$office[TAG_FAX] = "089 24 68 16";
$office[TAG_EMAIL] = "info@telenet.be";
CrawlerTool::saveOffice($office);

foreach ($startPages as $status => $types) {
  foreach ($types as $type => $pages) {
    foreach ($pages as $page) {
      debugx($page);
      $html = $crawler->request($page);
      processPage($crawler, $status, $type, $html);
      
      $nextPages = getPages($html);
      foreach ($nextPages as $nextPage) {
        debugx($nextPage);
        $html = $crawler->request($nextPage);
        processPage($crawler, $status, $type, $html);
      }
    }
  }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html) {
  static $propertyCount = 0;
  static $properties = array();
  
  $parser = new PageParser($html);
  
  //$nodes = $parser->getNodes("a[@class = 'Detail']"); //Technique A
  $nodes = $parser->getNodes("a[contains(@href, 'Detail')][img]");
  //Technique B
  debug($nodes);
  exit;
  
  $items = array();
  if ($nodes->length >= 1) {
    
    foreach ($nodes as $node) {
      $property = array();
      $property[TAG_STATUS] = $status;
      $property[TAG_TYPE] = $type;
      $property[TAG_UNIQUE_URL_FR] = "http://www.bkgroup.be".$parser->getAttr($node, "href");
      $property[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
      
      if (in_array($property[TAG_UNIQUE_ID], $properties)) {
        continue;
      }
      $properties[] = $property[TAG_UNIQUE_ID];
      
      $propertyCount += 1;
      
      // process item to obtain detail information
      echo "--------- Processing property #$propertyCount ...".$item["itemUrl"];
      //processItem($crawler, $property, file_get_contents($property[TAG_UNIQUE_URL_FR])); /// We can use in case of this error: Url: cUrl error: malformed.
      processItem($crawler, $property, $crawler->request($property[TAG_UNIQUE_URL_FR]));
      echo "--------- Completed<br />";
    }
  }
  
  return sizeof($properties);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html) {
  $parser = new PageParser($html, true);
  //Setting True for Unicode Characters
  $parser->deleteTags(array("script", "style"));
  
  //-----------------------------------------  Getting Address -----------------------------------------//
  //Obligatory Info
  $address = $parser->extract_xpath("p[@class = 'extrainfo']", RETURN_TYPE_TEXT);
  CrawlerTool::parseAddress($address, $property);
  
  $addr = explode(' ', $address);
  $property[TAG_CITY] = trim($addr[count($addr) - 1]);
  $property[TAG_ZIP] = intval($parser->regex("/(\d{4})/", $address));
  
  if (strlen($property[TAG_ZIP]) < 4) {
    $address = str_replace($property[TAG_ZIP], '', $address);
    $property[TAG_BOX_NUMBER] = $property[TAG_ZIP];
    $address = str_replace($property[TAG_BOX_NUMBER], '', $address);
    $property[TAG_ZIP] = intval($parser->regex("/(\d{4})/", $address));
    
    if (strlen($property[TAG_ZIP]) < 4) {
      unset($property[TAG_ZIP]);
    }
  }
  
  $property[TAG_STREET] = str_replace($property[TAG_CITY], '', $property[TAG_STREET]);
  $property[TAG_STREET] = str_replace($property[TAG_ZIP], '', $property[TAG_STREET]);
  
  $property[TAG_NUMBER] = str_replace($property[TAG_CITY], '', $property[TAG_NUMBER]);
  $property[TAG_NUMBER] = str_replace($property[TAG_ZIP], '', $property[TAG_NUMBER]);
  
  if (empty($property[TAG_CITY])) {
    $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER]));
  }
  
  if (strlen($property[TAG_BOX_NUMBER]) < 3 || strlen($property[TAG_BOX_NUMBER]) > 3) {
    unset($property[TAG_BOX_NUMBER]);
  }
  
  if (empty($property[TAG_CITY])) {
    return;
  }
  
  //---------------------------------------  Getting description and all Text  -------------------------------------------//
  $property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("div[@class = 'Detail']", RETURN_TYPE_TEXT);
  $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("div[@class = 'main']", RETURN_TYPE_TEXT_ALL);
  //Obligatory Info
  //-----------------------------------------  Getting Pictures -----------------------------------------//
  $picUrls = array();
  $pics = $parser->getNodes("img[contains(@src, 'Utility')]");
  foreach ($pics as $picx) {
    $pic = $parser->getAttr($picx, "src");
    $picUrls[] = array(
      TAG_PICTURE_URL => 'http://www.topclassimmo.be/'.$pic,
    );
  }
  $property[TAG_PICTURES] = $picUrls;
  
  //-----------------------------------------  Getting Price -----------------------------------------//
  $property[TAG_PRICE] = $parser->extract_xpath("td[contains(text(), 'Prix')]", RETURN_TYPE_NUMBER);
  

  //-----------------------------------------  Getting Attrib Info -----------------------------------------//
  $vars = $arr = $unmatched_variables = array();
  
  $nodes = $parser->getNodes("table[@cellpadding=2][@border=0][@style='width: 100%;']/tr");
  foreach ($nodes as $node) {
    
    $key = $parser->extract_xpath("td[1]", RETURN_TYPE_TEXT, null, $node);
    $val = $parser->extract_xpath("td[2]", RETURN_TYPE_TEXT, null, $node);
    $key = clearForLowerCase($key);
    $val = fixSpecialChr($val);
    if (!empty($key)) {
      $vars[$key] = $val;
    }
  }
  
  foreach ($vars as $label => $value) {
    $attribute = getAttributes(clearForLowerCase($label));
    if (!empty($attribute)) {
      if (empty($property[$attribute])) {
        $property[$attribute] = GetExactAttrib($attribute, $value);
      }
    }
    else {
      $unmatched_variables[] = array(
        TAG_VARIABLE_LABEL => $label,
        TAG_VARIABLE_VALUE => $value,
      );
    }
  }
  
  if (isset($property['cellphone'])) {
    unset($property['cellphone']);
  }
  
  if (isset($property['fax'])) {
    unset($property['fax']);
  }
  
  if (isset($property['email'])) {
    unset($property['email']);
  }
  
  if (isset($property['telephone'])) {
    unset($property['telephone']);
  }
  
  ///Obligatory Info
  if (!isset($property[TAG_HAS_PROCEEDING]) || $property[TAG_HAS_PROCEEDING] != 1) {
    $property[TAG_HAS_PROCEEDING] = '';
  }
  
  if (!isset($property['planning_permission']) || $property['planning_permission'] != 1) {
    $property['planning_permission'] = '';
  }
  

  if (!isset($property['subdivision_permit']) || $property['subdivision_permit'] != 1) {
    $property['subdivision_permit'] = '';
  }
  

  if (!isset($property['most_recent_destination']) || $property['most_recent_destination'] != 1) {
    $property['most_recent_destination'] = '';
  }
  
  $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
  
  //-----------------------------------------  Getting Type if empty  -----------------------------------------//
  //Obligatory Info
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_FR]));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_FR]));
  }
  
  //-----------------------------------------  Getting Status if empty  -----------------------------------------//
  //Obligatory Info
  if (empty($property[TAG_STATUS])) {
    $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($parser->extract_xpath("head/title"));
  }
  if (empty($property[TAG_STATUS])) {
    $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($property[TAG_TEXT_DESC_FR]);
  }
  
  debug($property);
  exit;
  //-----------------------------------------  Writing item data to output.xml file -----------------------------------------//
  CrawlerTool::saveProperty($property);
}

/*
 *
 *
 *
/* ============================= START AREA FOR FUNCTIONS ============================= */
/**
 * Function to print array  
 */
function debug($obj, $e = false) {
  echo "<pre>";
  print_r($obj);
  echo "</pre>";
  
  if ($e) {
    exit;
  }
}

/**
 * Function to echo text
 */
function debugx($obj, $e = false) {
  echo "<br />************************<br/>";
  echo $obj;
  echo "<br/>************************<br/>";
  
  if ($e) {
    exit;
  }
}

/**
 * Getting Exact Attribute Value for XML
*/
function GetExactAttrib($key, $val) {
  
  $a = array();
  
  switch ($key) {
    case TAG_CONSTRUCTION_YEAR:
    return toYear($val);
    break;

    case TAG_RENOVATION_YEAR:
    return toYear($val);
    break;

    case TAG_FREE_FROM_DATE:
    return toUnixTimestamp($val);
    break;

    
    case TAG_EPC_VALUE:
    return toEpc($val);
    break;

    case TAG_GARDEN_AVAILABLE:
    return(strtolower($val) == 'ja') ? 1 : 0;
    break;

    
    case TAG_CONNECTION_TO_WATER:
    return(strtolower($val) == 'ja') ? 1 : 0;
    break;

    
    case TAG_OPEN_FIRE:
    return(strtolower($val) == 'ja') ? 1 : 0;
    break;

    
    case TAG_TERRACES:
    return $a[] = toNumber($val);
    break;

    
    default:
    
    $val = trim($val);
    
    if (stripos($key, "_permission") !== false) {
      return(strtolower($val) == 'ja') ? 1 : '';
    }
    
    if (stripos($key, "_visible") !== false) {
      return(strtolower($val) == 'ja') ? 1 : 0;
    }
    
    if (strtolower($val) == 'ja' || strtolower($val) == 'nee' || strtolower($val) == 'neen') {
      return(strtolower($val) == 'ja') ? 1 : 0;
    }
    
    else {
      
      if (stripos($key, "_nl") !== false) {
        return $val;
      }
      
      if (stripos($key, "_fr") !== false) {
        return $val;
      }
      
      if (stripos($key, "_en") !== false) {
        return $val;
      }
      else {
        return toNumber($val);
      }
    }
    
    break;
  }
}

/**
 * Basic Fixing for array
*/
function clearForLowerCase($str = '') {
  $str = strtolower(str_replace(' ', '_', $str));
  $str = trim(strip_tags($str));
  $str = trim(preg_replace('!ja,!', '', $str));
  $str = trim(normalize_str($str));
  return $str;
}

/**
 * Returning Number
*/
function toNumber($str) {
  
  $value = 0;
  $str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
  $str = preg_replace("/,(\d{3})|\.(\d{3})/", "$1$2", $str);
  if (preg_match("/(-?\d+)/", $str, $match)) {
    $value = intval($match[1]);
  }
  
  if (empty($value)) {
    return 0;
  }
  else {
    return $value;
  }
}

/**
 * Returning Timestamp
*/
function toUnixTimestamp($str) {
  return strtotime($str);
}

/**
 * Returning EPC Value
*/
function toEpc($str) {
  $epc = toNumber($str);
  if ($epc > 0 && $epc <= 999) {
    return $epc;
  }
}

/**
 * Returning Year format
*/
function toYear($str) {
  $year = toNumber($str);
  if ($year > 0 && strlen($year) == 4) {
    return $year;
  }
}

/**
 * Normalizing Special Characters
*/
function normalize_str($str) {
  $invalid = array(
    'Š' => 'S',
    'š' => 's',
    'Đ' => 'Dj',
    'đ' => 'dj',
    'Ž' => 'Z',
    'ž' => 'z',
    'Č' => 'C',
    'č' => 'c',
    'Ć' => 'C',
    'ć' => 'c',
    'À' => 'A',
    'Á' => 'A',
    'Â' => 'A',
    'Ã' => 'A',
    'Ä' => 'A',
    'Å' => 'A',
    'Æ' => 'A',
    'Ç' => 'C',
    'È' => 'E',
    'É' => 'E',
    'Ê' => 'E',
    'Ë' => 'E',
    'Ì' => 'I',
    'Í' => 'I',
    'Î' => 'I',
    'Ï' => 'I',
    'Ñ' => 'N',
    'Ò' => 'O',
    'Ó' => 'O',
    'Ô' => 'O',
    'Õ' => 'O',
    'Ö' => 'O',
    'Ø' => 'O',
    'Ù' => 'U',
    'Ú' => 'U',
    'Û' => 'U',
    'Ü' => 'U',
    'Ý' => 'Y',
    'Þ' => 'B',
    'ß' => 'Ss',
    'à' => 'a',
    'á' => 'a',
    'â' => 'a',
    'ã' => 'a',
    'ä' => 'a',
    'å' => 'a',
    'æ' => 'a',
    'ç' => 'c',
    'è' => 'e',
    'é' => 'e',
    'ê' => 'e',
    'ë' => 'e',
    'ì' => 'i',
    'í' => 'i',
    'î' => 'i',
    'ï' => 'i',
    'ð' => 'o',
    'ñ' => 'n',
    'ò' => 'o',
    'ó' => 'o',
    'ô' => 'o',
    'õ' => 'o',
    'ö' => 'o',
    'ø' => 'o',
    'ù' => 'u',
    'ú' => 'u',
    'û' => 'u',
    'ý' => 'y',
    'ý' => 'y',
    'þ' => 'b',
    'ÿ' => 'y',
    'Ŕ' => 'R',
    'ŕ' => 'r',
    "`" => "'",
    "´" => "'",
    "„" => ",",
    "`" => "'",
    "´" => "'",
    "“" => "\"",
    "”" => "\"",
    "´" => "'",
    "&acirc;€™" => "'",
    "{" => "",
    "~" => "",
    "–" => "-",
    "’" => "'",
  );
  foreach ($invalid as $k => $v) {
    $str = str_replace($k, $v, $str);
  }
  
  return $str;
}

/**
 * Get a Lat Long format other wise It will give XSD invalid
*/
function getLatLong($str) {
  return floatval(substr($str, 0, 8));
}

/**
 * Fixing Special Charachter Issue
 */
function fixSpecialChr($str) {
  $str = CrawlerTool::strip(CrawlerTool::fixUTF8(strip_tags(trim($str))));
  //toUTF8
  return $str;
}

/**
 * Getting Exact Attribute Key for XML
*/
function getAttributes($key, $language = 'nl') {
  //String Function always return string
  $attributeTagsArray = array(
    'en' => array(
      'pric' => TAG_PRICE,
      'constr' => TAG_CONSTRUCTION_YEAR,
      'ground' => TAG_SURFACE_GROUND,
      'living' => TAG_SURFACE_LIVING_AREA,
      'bath' => TAG_BATHROOMS_TOTAL,
      'warm' => TAG_HEATING_EN,
      'heat' => TAG_HEATING_EN,
      'sewer' => TAG_CONNECTION_TO_SEWER,
      'telep' => TAG_TELEPHONE_CONNECTION,
      'intern' => TAG_INTERNET_CONNECTION,
      'permission' => TAG_PLANNING_PERMISSION,
      'subdivision' => TAG_SUBDIVISION_PERMIT,
      'electri' => TAG_METER_FOR_ELECTRICITY,
      'hall' => TAG_HALLS,
      'dining' => TAG_DININGS,
      'kitch' => TAG_KITCHENS,
      'laundr' => TAG_LAUNDRY_ROOMS,
      'dress' => TAG_DRESSING,
      'bed' => TAG_BEDROOMS_TOTAL,
      'room' => TAG_BEDROOMS_TOTAL,
      'park' => TAG_PARKINGS,
      'garage' => TAG_GARAGES_TOTAL,
      'type' => TAG_TYPE,
      'garden' => TAG_GARDEN_AVAILABLE,
      'floor' => TAG_AMOUNT_OF_FLOORS,
      'winter' => TAG_WINTERGARDENS,
      'furnish' => TAG_FURNISHED,
      'water' => TAG_CONNECTION_TO_WATER,
      'lift' => TAG_LIFT,
      'glaz' => TAG_DOUBLE_GLAZING,
      'terrac' => TAG_TERRACES,
      'fronts' => TAG_AMOUNT_OF_FACADES,
      'category' => TAG_TYPE,
      'free' => TAG_FREE_FROM_DATE,
      'habit' => TAG_SURFACE_LIVING_AREA,
      'plot' => TAG_SURFACE_GROUND,
      'shops' => TAG_DISTANCE_SHOPS,
      'schools' => TAG_DISTANCE_SCHOOL,
      'transport' => TAG_DISTANCE_PUBLIC_TRANSPORT,
      'shower' => TAG_SHOWERS_TOTAL,
      'stor' => TAG_STOREROOMS,
      'gas' => TAG_GAS_CONNECTION,
      'alarm' => TAG_ALARM,
      'security' => TAG_SECURITY_DOOR,
      'parlo' => TAG_PARLOPHONE,
      'video' => TAG_VIDEOPHONE,
      'elevat' => TAG_LIFT,
      'blind' => TAG_SUN_BLINDS,
      'renova' => TAG_RENOVATION_YEAR,
      'control' => TAG_ACCESS_SEMIVALID,
    ),
    //Function written by Team
    'nl' => array(
      "prij" => TAG_PRICE,
      "type" => TAG_TYPE,
      "adres" => TAG_ADDRESS_VISIBLE,
      "bouwjaar" => TAG_CONSTRUCTION_YEAR,
      "grondopp" => TAG_SURFACE_GROUND,
      "bewoonbare" => TAG_SURFACE_LIVING_AREA,
      "antal_kamer" => TAG_BEDROOMS_TOTAL,
      "slaapkamer" => TAG_BEDROOMS_TOTAL,
      "antal_badkam" => TAG_BATHROOMS_TOTAL,
      "badkam" => TAG_BATHROOMS_TOTAL,
      "epc_certi" => TAG_EPC_CERTIFICATE_NUMBER,
      "certificaatnr" => TAG_EPC_CERTIFICATE_NUMBER,
      "epc_ind" => TAG_EPC_VALUE,
      "epc_waa" => TAG_EPC_VALUE,
      "epc" => TAG_EPC_VALUE,
      "adastraal_inkomen" => TAG_KI,
      "adastraal" => TAG_KI,
      "inkomen" => TAG_KI,
      "ki" => TAG_KI,
      "adastrale_numme" => TAG_KI_INDEX,
      "verdieping" => TAG_AMOUNT_OF_FLOORS,
      "living" => TAG_SURFACE_LIVING_AREA,
      "renovatie" => TAG_RENOVATION_YEAR,
      "kadaster_sectie" => TAG_CADASTRAL_SECTION,
      "beschikbaar" => TAG_FREE_FROM,
      "fax" => TAG_FAX,
      "tel" => TAG_CELLPHONE,
      "mail" => TAG_EMAIL,
      "winkels" => TAG_DISTANCE_SHOPS,
      "vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
      "overstromings" => TAG_FLOOD_INFORMATION_NL,
      "garage" => TAG_GARAGES_TOTAL,
      "toilet" => TAG_TOILETS_TOTAL,
      "parking" => TAG_PARKINGS_TOTAL,
      "gevels" => TAG_AMOUNT_OF_FACADES,
      "lasten" => TAG_COMMON_COSTS,
      "gas" => TAG_GAS_CONNECTION,
      "water" => TAG_CONNECTION_TO_WATER,
      "telefoon" => TAG_TELEPHONE,
      "lift" => TAG_LIFT,
      "gemeubeld" => TAG_FURNISHED,
      "tuin" => TAG_GARDEN_AVAILABLE,
      "haard" => TAG_OPEN_FIRE,
      "alarm" => TAG_ALARM,
      "parlofoon" => TAG_PARLOPHONE,
      "videofoon" => TAG_VIDEOPHONE,
      "breedte" => TAG_LOT_WIDTH,
      "diepte" => TAG_LOT_DEPTH,
      "constructie" => TAG_CONSTRUCTION_TYPE,
      "gevelbreedte" => TAG_FRONTAGE_WIDTH,
      "winkel" => TAG_HEATING_NL,
      "douche" => TAG_SHOWERS_TOTAL,
      "keuken" => TAG_KITCHEN_TYPE_NL,
      "ligging" => TAG_SUBDIVISION_PERMIT,
      "stedenbouwkundige" => TAG_PLANNING_PERMISSION,
      "terras" => TAG_TERRACES,
      "terrein" => TAG_SURFACE_GROUND,
      "scholen" => TAG_DISTANCE_SCHOOL,
      "oppervlakte" => TAG_SURFACE_LIVING_AREA,
      "eetkamer" => TAG_DININGS,
      "dressing" => TAG_DRESSINGS,
      "kelder" => TAG_CELLARS,
      "beroep" => TAG_FREE_PROFESSIONS,
      "berging" => TAG_STOREROOMS,
      "wasplaats" => TAG_LAUNDRY_ROOMS,
      "elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
      "beglazing" => TAG_DOUBLE_GLAZING,
      "verwarming" => TAG_HEATING_NL,
      "riolering" => TAG_CONNECTION_TO_SEWER,
      "olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
      "waterput" => TAG_WELL,
      "telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
      "toegangscontrole" => TAG_ACCESS_SEMIVALID,
      "computer" => TAG_INTERNET_CONNECTION,
      "nroerende_voorhef" => TAG_PROPERTY_TAX,
    ),
    'fr' => array(
      "prij" => TAG_PRICE,
      "Meuble" => TAG_FURNISHED,
      "facades" => TAG_AMOUNT_OF_FACADES,
      "nombre_de_chambre" => TAG_BEDROOMS_TOTAL,
      "chambres" => TAG_BEDROOMS_TOTAL,
      "chambre" => TAG_BEDROOMS_TOTAL,
      "nombre_de_salle_de_bain" => TAG_BATHROOMS_TOTAL,
      "jardin" => TAG_GARDEN_AVAILABLE,
      "garage" => TAG_GARAGES_TOTAL,
      "terras" => TAG_TERRACES,
      "parking" => TAG_PARKINGS_TOTAL,
      "habita" => TAG_SURFACE_LIVING_AREA,
      "surface" => TAG_SURFACE_LIVING_AREA,
      "terrain" => TAG_SURFACE_GROUND,
      "disponible" => TAG_FREE_FROM,
      "magasins" => TAG_DISTANCE_SHOPS,
      "transport" => TAG_DISTANCE_PUBLIC_TRANSPORT,
      "toilet" => TAG_TOILETS_TOTAL,
      "construction_annee" => TAG_CONSTRUCTION_YEAR,
      "renovation_annee" => TAG_RENOVATION_YEAR,
      "tages" => TAG_AMOUNT_OF_FLOORS,
      "alarm" => TAG_ALARM,
      "gaz" => TAG_GAS_CONNECTION,
      "eau" => TAG_CONNECTION_TO_WATER,
      "parlophone" => TAG_PARLOPHONE,
      "vitrage" => TAG_DOUBLE_GLAZING,
      "network" => TAG_INTERNET_CONNECTION,
      "douche" => TAG_SHOWERS_TOTAL,
      "caves" => TAG_CELLARS,
      "dressing" => TAG_DRESSINGS,
      "telephone" => TAG_TELEPHONE,
      "videophone" => TAG_VIDEOPHONE,
      "manger" => TAG_DININGS,
      "ecoles" => TAG_DISTANCE_SCHOOL,
      "sejour" => TAG_SURFACE_LIVING_AREA,
      "ascenseur" => TAG_LIFT,
      "largeur_du_lot" => TAG_LOT_WIDTH,
      "mazout" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
      "citerne" => TAG_WELL,
      "chauffage" => TAG_HEATING_FR,
      "electricite" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
      "fax" => TAG_FAX,
      "tel" => TAG_CELLPHONE,
      "inondation" => TAG_FLOOD_INFORMATION_FR,
      "egouts" => TAG_CONNECTION_TO_SEWER,
      "cuisine" => TAG_KITCHEN_TYPE_FR,
      "construction_type" => TAG_CONSTRUCTION_TYPE,
      "chauffage" => TAG_HEATING_FR,
      "debarras" => TAG_STOREROOMS,
      "telephoniques" => TAG_TELEPHONE_CONNECTION,
      "dacces" => TAG_ACCESS_SEMIVALID,
      "lotissement" => TAG_SUBDIVISION_PERMIT,
      "batir" => TAG_PLANNING_PERMISSION,
      "cadastrales" => TAG_CADASTRAL_SECTION,
      "prix" => TAG_PRICE,
      "epc" => TAG_EPC_VALUE,
      "ki" => TAG_KI,
      "mail" => TAG_EMAIL,
      "commun" => TAG_COMMON_COSTS,
      "feu" => TAG_OPEN_FIRE,
      "beaucoup_de_profondeur" => TAG_LOT_DEPTH,
      "facade_largeur" => TAG_FRONTAGE_WIDTH,
      "emission_co2" => TAG_CO2_EMISSION,
    ),
  );
  
  $keys = array_keys($attributeTagsArray[$language]);
  // Returning Keys
  $key = clearForLowerCase($key);
  // Converting to lower case and trim
  foreach ($keys as $k) {
    $check = stripos("X$key", "$k");
    if (!empty($check)) {
      return $attributeTagsArray[$language][$k];
    }
  }
  
  return '';
}

/**
 * Get a list of next pages
 */
function getPages($html) {
  $parser = new PageParser($html);
  
  $pages = array();
  $nodes = $parser->getNodes("a[@class = 'Link PaginationLink']");
  
  if (!empty($nodes)) {
    foreach ($nodes as $node) {
      $pages[] = "http://www.bkgroup.be".$parser->getAttr($node, "href");
    }
  }
  
  return array_unique($pages);
}

/**
 * Get a list of next pages
 */
function getNextPages($html) {
  $parser = new PageParser($html);
  $pages = array();
  $nodes = $parser->getNodes("div[@class = 'pages']/a");
  $page = 1;
  $uri = $xtext = '';
  
  if ($nodes->length > 1) {
    foreach ($nodes as $node) {
      $uri = $parser->getAttr($node, "href");
      $page = $parser->regex("/page=(\d+)/", $uri);
      //debugx($page);
    }
  }
  
  for ($i = 1;$i <= $page;$i++) {
    $pages[] = (strstr($uri, 'jaarverhuur')) ? $uri = 'http://jaarverhuur.sissau.be/nl/jaarverhuur?page='.$i : $uri = 'http://verkoop.sissau.be/nl/verkoop?page='.$i.'&view=list&goal=0';
  }
  
  return array_unique($pages);
}

/* ============================= END AREA FOR FUNCTIONS ============================= */
