<?php

/* ============================= CONFIG ============================= */

// Crawler ID 555

require_once("./../crawler_classes.php");

CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.immodot.be/"
    )
);

$startPages[STATUS_FORSALE] = array
(
    
    TYPE_NONE        =>  array
    (
        "http://www.immodot.be/nl/te-koop"
    ) 
    
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immodot.be/nl/te-huur"
    ),
);
 
/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

//Saving Office
$propertyCount = 0; 
$properties = array();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Kantoor Oostende";
$office[TAG_OFFICE_URL] = "http://www.immodot.be/";
$office[TAG_STREET] = "Aartshertoginnestraat";
$office[TAG_NUMBER] = "50";
$office[TAG_ZIP] = "8400";
$office[TAG_CITY] = "Oostende";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "+32 (0)59 80 34 38";
$office[TAG_FAX] = "+32 (0)59 70 84 54";
$office[TAG_EMAIL] = "info@immodot.be";

CrawlerTool::saveOffice($office);

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            
            //Debuging Page detail
            debugx($status.'->'.$type.'->'.'Page: -> '.$page);

            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
            
            //Next pages
            $parser = new PageParser($html);
	    $nodes = $parser->getNodes("div[@class ='pagination ']/ul/li/a");
	    $nextPage = '';
	    foreach($nodes as $node)
	    {
		
		$nextPage = "http://www.immodot.be". $parser->getAttr($node, "href");
		debugx('---'.$nextPage);
		processPage($crawler, $status, $type, $html);
	    }
        
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);
     
    //$nodes = $parser->getNodes("a[img[contains(@src, 'Filestore.Dat')]]");
    $nodes = $parser->getNodes("div[@class ='image']/a");
   
    $items = array();
    foreach($nodes as $node)
    {
        //Style of link with node
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        
        $property[TAG_UNIQUE_URL_NL] =  'http://www.immodot.be/'.$parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]); ///Getting Unique ID
      
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
    }   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));
	
    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("div[@style = 'text-align: justify;']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@id= 'PropertyRegion']", RETURN_TYPE_TEXT_ALL);
    
    //Getting Pictures
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'colorBoxImg']", RETURN_TYPE_ARRAY, function($pics)
	{
		$picUrls = array();
		foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL =>   $pic);
		return $picUrls;
	});
	
	$address = $parser->extract_xpath("h3[@class = 'pull-left leftside']", RETURN_TYPE_TEXT_ALL);
	
	$addr = explode(' ',$address);
	$property[TAG_ZIP] =  $parser->regex("/(\d{4})/", $address );  
	$property[TAG_CITY] = trim($addr[count($addr)-2]);

    $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL] );
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_PLAIN_TEXT_ALL_NL] );
    $property[TAG_IS_INVESTMENT_PROPERTY] = CrawlerTool::isInvestmentProperty($property[TAG_PLAIN_TEXT_ALL_NL]);
    
    ///Getting Price
    $property[TAG_PRICE] = $parser->extract_xpath("h3[@class='pull-right rightside']", RETURN_TYPE_NUMBER);
    
    //$property[TAG_PRICE] = $parser->extract_regex("/(Prijsklasse.*)/", RETURN_TYPE_NUMBER);
    
    $property[TAG_ORIGINAL_REFERENCE] = $parser->regex("/(\d+)/", $parser->extract_xpath("b[contains(text(), 'referentienummer:')]/following-sibling::text()"));
    $property[TAG_CONSTRUCTION_TYPE] = CrawlerTool::getConstructionType(preg_replace("/hob/i", "half open", $parser->extract_xpath("head/title")));

    $parser->setQueryTemplate("b[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::text()[1]");

    $property[TAG_KI] = $parser->extract_xpath("KI:", RETURN_TYPE_NUMBER);
    $property[TAG_EPC_VALUE] = $parser->extract_regex("/(\d)\skWh/i", RETURN_TYPE_EPC);
    $property[TAG_EPC_CERTIFICATE_NUMBER] = $parser->regex("/\(([\d-]+)/", $parser->extract_regex("/EPC(.*)/i"));
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("bouwjaar:", RETURN_TYPE_YEAR);
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("renovatiejaar:", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("grondopp:", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("bewoonbare opp:", RETURN_TYPE_NUMBER);
    
    $bed = GetBetween($html,'Aantal slaapkamers','<div class="clear" >');
    $property[TAG_BEDROOMS_TOTAL] = CrawlerTool::toNumber(trim($bed));
    
    $bath = GetBetween($html,'Aantal badkamers','<div class="clear" >');
    $property[TAG_BATHROOMS_TOTAL] = CrawlerTool::toNumber(trim($bath));
    
    $property[TAG_GARDEN_AVAILABLE] = $parser->extract_regex("/(tuin)/") === "tuin"? 1:0;
    $property[TAG_DOUBLE_GLAZING] = $parser->extract_regex("/( Dubbele beglazing)/") === " Dubbele beglazing"? 1:0;

    //Unmatched Veriables
    $unmatched_variables = array();
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	}
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
        
	if(!isset($property[TAG_HAS_PROCEEDING]) || $property[TAG_HAS_PROCEEDING] !=1 )
	$property[TAG_HAS_PROCEEDING] = '';
	
	if(!isset($property['planning_permission']) || $property['planning_permission'] !=1)
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || $property['subdivision_permit'] !=1)
	$property['subdivision_permit'] = '';
	
	
	if(!isset($property['most_recent_destination']) || $property['most_recent_destination'] !=1)
	$property['most_recent_destination'] = '';

	debug($property);
	
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
    
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////
///Clear Empity index
function removeEmptyIndex($property){
 foreach($property as $k=>$v){
		if(empty($v))
		unset($property[$k]);
		
			if(is_array($v)){ 
				foreach($v as $kx=>$vx){ 
					if(empty($vx)){ 
						unset($v[$kx]);
						unset($property[$k]);
					}
				}
			}	
	}
	return $property;

}
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////

 //function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

///0514437586 President Line...

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}

function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
} 

function removeBrackets($str){
	$str = str_replace('–','',$str);
	$str = str_replace('(','',$str);
	$str = str_replace(')','',$str);
	$str = str_replace('-','',$str);
	return $str;
}

//Function for Handle Attributes 
function setAtributesX($key='',$lan='nl'){ 
    
    $attrib['nl'] = array('Gemeubeld'=>BEBOUWING, 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Badkamer'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'keuken'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Aantal_slaapkamers'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'Bouwjaar'=>TAG_CONSTRUCTION_YEAR, 'Bewoonb_opp.'=>TAG_SURFACE_GROUND,
			'Parkings'=>TAG_PARKINGS,'Garages'=>TAG_GARAGES_TOTAL, 'Aantal_garages'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'Bewoonbare_oppervlakte'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Tuin'=>TAG_WINTERGARDENS,
			'Gemeubeld'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terras'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE
			
			);
    
    $attrib['fr'] = array('Gemeubeld'=>BEBOUWING, 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Nombre_de_salle_de_bain'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'cuisine'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Slaapkamers'=>TAG_BEDROOMS_TOTAL,
			'année_de_construction_année'=>TAG_CONSTRUCTION_YEAR, 'Taille_terrain_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'surface_nette_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Jardin'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER, 'Type'=>TAG_TYPE,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrasse'=>TAG_TERRACES,'Facades'=>TAG_AMOUNT_OF_FACADES,
			'Catégorie'=>TAG_TYPE
			);
    
    $attrib['en'] = array('Gemeubeld'=>BEBOUWING, 'Aantal_badkamers' =>TAG_BATHROOMS_TOTAL,
			'Number_of_bathrooms'=>TAG_BATHROOMS_TOTAL, 'verwarming_type'=>TAG_HEATING_NL,'Badkamers'=>TAG_BATHROOMS_TOTAL,
			'Verwarming'=>TAG_HEATING_NL, 'Vloerverwarming'=>TAG_HEATING_NL,
			'riolering'=>TAG_CONNECTION_TO_SEWER, 'Aansluiting_riolering'=>TAG_CONNECTION_TO_SEWER,
			'Aansluiting_telefoon'=>TAG_TELEPHONE_CONNECTION, 'Aansluiting_internet'=>TAG_INTERNET_CONNECTION,
			'Stedebouwkundige_vergunningen'=>TAG_PLANNING_PERMISSION, 'Verkavelingsvergunning'=>TAG_SUBDIVISION_PERMIT,
			'Meter_elektriciteit'=>TAG_METER_FOR_ELECTRICITY,'electricity_certificate'=>TAG_METER_FOR_ELECTRICITY,
			'electricity'=>TAG_METER_FOR_ELECTRICITY, 'Inkomhal'=>TAG_HALLS,
			'Eetkamer'=>TAG_DININGS, 'kitchen'=>TAG_KITCHENS,'wasplaats'=>TAG_LAUNDRY_ROOMS,
			'dressoir'=>TAG_DRESSING, 'Nombre_de_chambres'=>TAG_BEDROOMS_TOTAL,'Number_of_rooms'=>TAG_BEDROOMS_TOTAL,
			'construction_year_year'=>TAG_CONSTRUCTION_YEAR, 'Plot_size_(min.)'=>TAG_SURFACE_GROUND,
			'Parking'=>TAG_PARKINGS,'Garage'=>TAG_GARAGES_TOTAL, 'Type'=>TAG_TYPE,
			'Orientatie_woning'=>TAG_GARDEN_ORIENTATION, 'habitable_-_surface_-_surface'=>TAG_SURFACE_LIVING_AREA,
			'Aantal_verdiepingen'=>TAG_AMOUNT_OF_FLOORS, 'Garden'=>TAG_WINTERGARDENS,
			'Meublé'=>TAG_FURNISHED,'water'=>TAG_CONNECTION_TO_WATER,
			'lift'=>TAG_LIFT, 'Lift'=>TAG_LIFT, 'Beglazing'=>TAG_DOUBLE_GLAZING, 'Terrace'=>TAG_TERRACES,'Fronts'=>TAG_AMOUNT_OF_FACADES,
			'Category'=>TAG_TYPE
			);
    
    if(!empty($key)){
	
	if( array_key_exists($key, $attrib[$lan]) ){
	    return $attrib[$lan][$key];
	}
	else
	    return '';
    }else
	return '';
	
}