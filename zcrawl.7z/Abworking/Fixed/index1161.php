<?php
require_once("../crawler_classes.php");

define('SITE_URL','http://www.huyzentruyt.be/');

$office[TAG_OFFICE_ID]   = "1";
$office[TAG_OFFICE_URL]  = "www.huyzentruyt.be";
$office[TAG_OFFICE_NAME] = "Woningbouw Huyzentruyt";
$office[TAG_STREET]      = "Wagenaarstraat";
$office[TAG_NUMBER]      = "33";
$office[TAG_BOX_NUMBER]  = "";
$office[TAG_ZIP]         = "8791";
$office[TAG_CITY]        = "Waregem";
$office[TAG_COUNTRY]     = "Belgium";

$office[TAG_TELEPHONE]   = "056736736";
$office[TAG_FAX]         = "056718517";
$office[TAG_EMAIL]       = "info@huyzentruyt.be";

CrawlerTool::startXML();
CrawlerTool::saveOffice($office);

$projects = array();
 
$html   = $crawler->request('http://www.huyzentruyt.be/nieuwbouwprojecten/zoekresultaat/');
preg_match_all('!<a href="/nieuwbouwprojecten/verkaveling/([^"]+)" class="btn-color2 is-bottom-aligned">Meer info</a>!s',$html,$res);
foreach ($res[1] as $v)
{
	$project                         = array();
	$project[TAG_PROJECT_ID]         = trim($v,'/');
	$project[TAG_UNIQUE_URL_NL]      = SITE_URL . 'nieuwbouwprojecten/verkaveling/' . $v;
	$projects[] = $project;
}


$html   = $crawler->request('http://www.huyzentruyt.be/bouwenopmaat/bouwgronden/');
preg_match_all('!<a href="/bouwenopmaat/overzichtbouwgronden/([^"]+/)" class="btn-color2 is-halfwidth">Meer info</a>!s',$html,$res);
foreach ($res[1] as $v)
{
	$project                         = array();
	$project[TAG_PROJECT_ID]         = trim($v,'/');
	$project[TAG_UNIQUE_URL_NL]      = SITE_URL . 'bouwenopmaat/overzichtbouwgronden/' . $v;
	$projects[] = $project;
}
 
//Added by Ashfaq
$html   = $crawler->request('http://www.huyzentruyt.be/nieuwbouwprojecten/verkaveling/adinkerke-noordhoekstraat/');
$parser = new PageParser($html);
$nodes = $parser->getNodes("a[@class='btn-color2 is-halfwidth']");
 
foreach($nodes as $node)
{
	$project                         = array();
	 //trim($v,'/');
	$project[TAG_UNIQUE_URL_NL]      = 'http://www.huyzentruyt.be' .$parser->getAttr($node, "href");
	$project[TAG_PROJECT_ID]         = CrawlerTool::generateId($project[TAG_UNIQUE_URL_NL])  ; //	$parser->regex("/propertyid=(\d+)/", $property[TAG_UNIQUE_URL_NL] );  ; 
	//if(!empty($project[TAG_PROJECT_ID]))
	$projects[] = $project;
}

$html   = $crawler->request('http://www.huyzentruyt.be/nieuwbouwprojecten/verkaveling/adinkerke-noordhoekstraat/overzicht/');
$parser = new PageParser($html);
$nodes = $parser->getNodes("a[@class='btn-color2 is-halfwidth']");
 
foreach($nodes as $node)
{
	$project                         = array();
	 //trim($v,'/');
	$project[TAG_UNIQUE_URL_NL]      = 'http://www.huyzentruyt.be' .$parser->getAttr($node, "href");
	$project[TAG_PROJECT_ID]         = CrawlerTool::generateId($project[TAG_UNIQUE_URL_NL]) ; 
	//if(!empty($project[TAG_PROJECT_ID]))
	$projects[] = $project;
}

debug($projects);  

//procces projects
$done_cnt  = 0;
$total_cnt = count($projects);
echo "start proccesing projects\r\n<br>Total projects:$total_cnt\r\n<br>";
foreach ($projects as $project)
{
	extract_info_project($crawler,$project);
	$done_cnt++;
	$z = round(($done_cnt/$total_cnt)*100,2);
	echo "Done:$done_cnt/$total_cnt ($z% completed)\r\n<br>";
}

CrawlerTool::endXML();

echo "<br /><b>Completed!</b>";

function extract_info_project($crawler,$project)
{
	$html   = $crawler->request($project[TAG_UNIQUE_URL_NL]);
	$parser = new PageParser($html,true);

	if (CrawlerTool::skipWordFound($html))	{echo "project skipped<br>\r\n";return ;}

	if (!preg_match('!<h2>(.*?)</h2>(.*?)</article>!s',$html,$res))
	{
		preg_match('!<article class="l-fatmodule-last has-spaceleft" role="">\s+<h2 class="has-nmt is-green">(.*?)</h2>(.*?)</article>!s',$html,$res);
	}
	$project[TAG_TEXT_TITLE_NL]            = trim(strip_tags($res[1]));
	$project[TAG_TEXT_DESC_NL]             = trim(strip_tags($res[2]));

	$arr                                   = $parser->regex_all("!<div><img class='' src='/(site/assets/files/[^']+)' alt='[^<>]*' /></div>!", $html);
	$project[TAG_PICTURES]                 = CrawlerTool::addTextToPicUrls($arr,'http://www.huyzentruyt.be/');

	if (preg_match('!<a target="_blank" href="/(site/assets/files/[^"]+)" class="btn-color2">Download de (brochure)</a>!',$html,$res))
	{
		$project[TAG_FILES][] = array(TAG_FILE_URL_NL => SITE_URL . $res[1], TAG_FILE_TITLE_NL => $res[2]);
	}

	preg_match('!<p class="project-adres"><strong>([^<>]+)<br />(\d{4}) ([^<>]+)</strong>!',$html,$res);
	CrawlerTool::parseAddress(trim($res[1]),$project);
	$project[TAG_ZIP]  = trim($res[2]);
	$project[TAG_CITY] = trim($res[3]);

	if(empty($project[TAG_CITY])){
		
		$address = $parser->extract_xpath("h1", RETURN_TYPE_TEXT); 
		$addr = explode(' ',$address);
		$project[TAG_CITY] = trim($addr[0]);
		$project[TAG_STREET] =  trim($addr[count($addr)-1]);
		
	}


		$vars = array();
		preg_match_all('!>([^<>]+): <strong>([^<>]+)</strong>!',$html,$res1,PREG_SET_ORDER);
		foreach ($res1 as $arr)
		{
			$arr[1] = strtolower($arr[1]);
			$arr[1] = trim($arr[1]);
			$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
			$vars[$arr[1]] = trim($arr[2]);
		}
		 
	 
	 foreach ($vars as $label => $value)
	{ 
		$attribute = getAttributes(clearForLowerCase($label));
		if(!empty($attribute) ){
		    if(empty($project[$attribute]))
		    $project[$attribute] = GetExactAttrib($attribute,$value);
		}
		else
		    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
		
	}
	
	$project[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
	
	// Most Important 
	if(!isset($project['planning_proceeding']) || empty($project['planning_proceeding']))
	$project['planning_proceeding'] = 0;
	
	
	if(!isset($project['planning_permission']) || empty($project['planning_permission']))
	$project['planning_permission'] = 0;
	
	
	if(!isset($project['subdivision_permit']) || empty($project['subdivision_permit']))
	$project['subdivision_permit'] = 0;
	 
	if(!isset($project['most_recent_destination']) || empty($project['most_recent_destination']))
	$project['most_recent_destination'] = 0;
	 
	preg_match('!<table class="table">(.*?)</table>!s',$html,$res);
	if (isset($res[1]))
	{
		$project[TAG_TYPE] = TYPE_PLOT;

		$property_base = $project;
		$property_base[TAG_PROJECT_ID]         = $project[TAG_PROJECT_ID];
		$property_base[TAG_UNIQUE_URL_NL]      = $project[TAG_UNIQUE_URL_NL];
		$property_base[TAG_STATUS]             = STATUS_FORSALE;
		$property_base[TAG_CITY]             = $project[TAG_CITY];
		$property_base[TAG_STREET]             = $project[TAG_STREET];
		  
		$sold = $total = 0;

		$table = $res[1];
		preg_match_all('!<tr class="">(.*?)</tr>!s',$table,$res1);

		foreach ($res1[1] as $tr)
		{
			$total++;

			if (stripos($tr,'verkocht')!==false)
			{
				$sold++;
				continue;
			}

			$property = $property_base;

			preg_match_all('!<td[^<>]*>(.*?)</td>!s',$tr,$res2);

			$property[TAG_UNIQUE_ID] = trim($res2[1][0]) . '_' . $project[TAG_PROJECT_ID];

			if (preg_match('!(\d+) m!',$res2[1][1],$res))
			{
				$property[TAG_SURFACE_GROUND] = $res[1];
			}

			$property[TAG_CONSTRUCTION_TYPE]       = CrawlerTool::getConstructionType($res2[1][2]);

			if (preg_match('![^<>0-9]*([0-9.]+)!',$res2[1][5],$res))
			{
				$property[TAG_PRICE] = str_replace('.','',$res[1]);
			}

			if (preg_match('!<a href="/(site/assets/files/[^"]+)" target = "_blank" title="([^"]*)">!',$res2[1][6],$res))
			{
				$property[TAG_FILES][] = array(TAG_FILE_URL_NL => SITE_URL . $res[1], TAG_FILE_TITLE_NL => $res[2]);
			}

			if (preg_match('!<a href="/(site/assets/files/[^"]+)" target = "_blank" title="([^"]*)">!',$res2[1][7],$res))
			{
				$property[TAG_FILES][] = array(TAG_FILE_URL_NL => SITE_URL . $res[1], TAG_FILE_TITLE_NL => $res[2]);
			}
				debug($property); 
			CrawlerTool::saveProperty($property);
		}

		if ($total > 0)
		{
			$project[TAG_SOLD_PERCENTAGE_MAX]   = $total;
			$project[TAG_SOLD_PERCENTAGE_VALUE] = $sold;
		}
	}





	//if have other page
	if (preg_match('!<a href="/(nieuwbouwprojecten/verkaveling/[^"<>]+/overzicht/)" class="btn-color2 is-halfwidth">Bekijk deze([^<>]+)</a>!',$html,$res))
	{
		$next_page_url = SITE_URL . $res[1];
		$type = $res[2];
		
		preg_match('!<title>(.*?)</title>!s',$html,$res);
		$prev_title = $res[1];
		
		$html   = $crawler->request($next_page_url);

		preg_match('!<title>(.*?)</title>!s',$html,$res);
		
		$project[TAG_TYPE] = CrawlerTool::getPropertyType($res[1]);

		if (empty($project[TAG_TYPE])) 
		{
			$project[TAG_TYPE] = CrawlerTool::getPropertyType($prev_title);
		}

		if (empty($project[TAG_TYPE])) 
		{
			$project[TAG_TYPE] = CrawlerTool::getPropertyType($type);
		}
		
		if (empty($project[TAG_TYPE])) 
		{
			$project[TAG_TYPE] = CrawlerTool::getPropertyType($project[TAG_TEXT_TITLE_NL] );
		}
		
		
		if (preg_match("!<img id='printImg' class='photo' src='/(site/assets/files/[^']+)'!",$html,$res))
		{
			$project[TAG_PICTURES][] = array(TAG_PICTURE_URL => SITE_URL . $res[1]);
		}

		$property_base = $project;
		$property_base[TAG_PROJECT_ID]         = $project[TAG_PROJECT_ID];
		$property_base[TAG_UNIQUE_URL_NL]      = $project[TAG_UNIQUE_URL_NL];
		$property_base[TAG_STATUS]             = STATUS_FORSALE;

		$vars = array();
		preg_match_all('!>([^<>]+): <strong>([^<>]+)</strong>!',$html,$res1,PREG_SET_ORDER);
		foreach ($res1 as $arr)
		{
			$arr[1] = strtolower($arr[1]);
			$arr[1] = trim($arr[1]);
			$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
			$vars[$arr[1]] = trim($arr[2]);
		}

		
	 foreach ($vars as $label => $value)
	{ 
		$attribute = getAttributes(clearForLowerCase($label));
		if(!empty($attribute) ){
		    if(empty($project[$attribute]))
		    $project[$attribute] = GetExactAttrib($attribute,$value);
		}
		else
		    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
		
	}
	
	$project[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
	
	// Most Important 
	if(!isset($project['planning_proceeding']) || empty($project['planning_proceeding']))
	$project['planning_proceeding'] = 0;
	
	
	if(!isset($project['planning_permission']) || empty($project['planning_permission']))
	$project['planning_permission'] = 0;
	
	
	if(!isset($project['subdivision_permit']) || empty($project['subdivision_permit']))
	$project['subdivision_permit'] = 0;
	 
	if(!isset($project['most_recent_destination']) || empty($project['most_recent_destination']))
	$project['most_recent_destination'] = 0;
	 
	 
		$x = get_var($vars,'overstromingsgevoeligheid');
		if ($x == 'Niet overstromingsgevoelig') {

			$property_base[TAG_FLOOD_EFFECTIVELY_VULNERABLE] = 0;
			$property_base[TAG_FLOOD_POSSIBLY_VULNERABLE] = 0;
			$property_base[TAG_FLOOD_DEFINED_FLOODPLAIN] = 0;
			$property_base[TAG_FLOOD_DEFINED_BANK_AREA] = 0;
			$property_base[TAG_FLOOD_RISK_ZONE] = 0;
		}
		elseif ($x == 'Mogelijk overstromingsgevoelig')
		{
			$property_base[TAG_FLOOD_POSSIBLY_VULNERABLE] = 1;
		}

		$x = get_var($vars,'bouwvergunning');
		if ($x == 'ja')
		{
			$property_base[TAG_PLANNING_PERMISSION] = 1;
		}
		else 
		{
			$property_base[TAG_PLANNING_PERMISSION] = 0;
		}

		$x = get_var($vars,'recht van voorkoop');
		if ($x == 'ja')
		{
			$property_base[TAG_PRIORITY_PURCHASE] = 1;
		}
		else 
		{
			$property_base[TAG_PRIORITY_PURCHASE] = 0;
		}

		$x = get_var($vars,'dagvaarding');
		if ($x == 'ja')
		{
			$property_base[TAG_HAS_PROCEEDING] = 1;
		}
		else 
		{
			$property_base[TAG_HAS_PROCEEDING] = 0;
		}

		$x = get_var($vars,'verkavelingsvergunning');
		if ($x == 'ja')
		{
			$property_base[TAG_SUBDIVISION_PERMIT] = 1;
		}
		else
		{
			$property_base[TAG_SUBDIVISION_PERMIT] = 0;
		}

		$property_base[TAG_MOST_RECENT_DESTINATION] = get_var($vars,'stedenbouwkundige bestemming');


		preg_match('!<table class="table">(.*?)</table>!s',$html,$res);
		if (isset($res[1]))
		{
			$sold = $total = 0;

			$table = $res[1];
			preg_match_all('!<tr class="">(.*?)</tr>!s',$table,$res1);

			foreach ($res1[1] as $tr)
			{
				$total++;

				if (stripos($tr,'verkocht')!==false)
				{
					$sold++;
					continue;
				}

				$property = $property_base;

				preg_match_all('!<td[^<>]*>(.*?)</td>!s',$tr,$res2);

				$property[TAG_UNIQUE_ID] = trim($res2[1][0]) . '_' . $project[TAG_PROJECT_ID];

				if (preg_match('!(\d+) m!',$res2[1][1],$res))
				{
					$property[TAG_SURFACE_CONSTRUCTION] = $res[1];
				}

				$property[TAG_CONSTRUCTION_TYPE]       = CrawlerTool::getConstructionType($res2[1][2]);

				if (preg_match('![^<>0-9]*([0-9.]+)!',$res2[1][5],$res))
				{
					$property[TAG_PRICE] = str_replace('.','',$res[1]);
				}

				if (preg_match('!<a href="/(site/assets/files/[^"]+)" target = "_blank" title="([^"]*)">!',$res2[1][6],$res))
				{
					$property[TAG_FILES][] = array(TAG_FILE_URL_NL => SITE_URL . $res[1], TAG_FILE_TITLE_NL => $res[2]);
				}

				CrawlerTool::saveProperty($property);
			}

			if ($total > 0)
			{
				$project[TAG_SOLD_PERCENTAGE_MAX]   = $total;
				$project[TAG_SOLD_PERCENTAGE_VALUE] = $sold;
			}
		}

	}
debug($project); 
	CrawlerTool::saveProject($project);
}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
			return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}


//function for print array
function debug($obj)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}
 
    
    
	
function getAttributes($key, $language='nl'){ //String Function always return string

	$attributeTagsArray	= array('en' => array(	'pric' 			=>  TAG_PRICE,
							'constr'		=> TAG_CONSTRUCTION_YEAR,
							'ground'		=> TAG_SURFACE_GROUND,
							'living' 		=> TAG_SURFACE_LIVING_AREA,
							'bath'			=> TAG_BATHROOMS_TOTAL,
							'warm'			=> TAG_HEATING_EN,
							'heat'			=> TAG_HEATING_EN,
							'sewer'			=> TAG_CONNECTION_TO_SEWER,
							'telep'			=> TAG_TELEPHONE_CONNECTION,
							'intern'		=> TAG_INTERNET_CONNECTION,
							'permission'		=> TAG_PLANNING_PERMISSION,
							'subdivision'		=> TAG_SUBDIVISION_PERMIT,
							'electri'		=> TAG_METER_FOR_ELECTRICITY,
							'hall'			=> TAG_HALLS,
							'dining'		=> TAG_DININGS,
							'kitch'			=> TAG_KITCHENS,
							'laundr'		=> TAG_LAUNDRY_ROOMS,
							'dress'			=> TAG_DRESSING,
							'bed'			=> TAG_BEDROOMS_TOTAL,
							'room'			=> TAG_BEDROOMS_TOTAL,
							'park'			=> TAG_PARKINGS,
							'garage'		=> TAG_GARAGES_TOTAL,
							'type'			=> TAG_TYPE,
							'garden'		=> TAG_GARDEN_AVAILABLE,
							'floor'			=> TAG_AMOUNT_OF_FLOORS,
							'winter'		=> TAG_WINTERGARDENS,
							'furnish'		=> TAG_FURNISHED,
							'water'			=> TAG_CONNECTION_TO_WATER,
							'lift'			=> TAG_LIFT,
							'glaz'			=> TAG_DOUBLE_GLAZING,
							'terrac'		=> TAG_TERRACES,
							'fronts'		=> TAG_AMOUNT_OF_FACADES,
							'category'		=> TAG_TYPE,
							'free'			=> TAG_FREE_FROM_DATE,
							'habit'			=> TAG_SURFACE_LIVING_AREA,
							'plot'			=> TAG_SURFACE_GROUND,
							'shops'			=> TAG_DISTANCE_SHOPS,
							'schools'		=> TAG_DISTANCE_SCHOOL,
							'transport'		=> TAG_DISTANCE_PUBLIC_TRANSPORT,
							'shower'		=> TAG_SHOWERS_TOTAL,
							'stor'			=> TAG_STOREROOMS,
							'gas'			=> TAG_GAS_CONNECTION,
							'alarm'			=> TAG_ALARM,
							'security'		=> TAG_SECURITY_DOOR,
							'parlo'			=> TAG_PARLOPHONE,
							'video'			=> TAG_VIDEOPHONE,
							'elevat'		=> TAG_LIFT,
							'blind'			=> TAG_SUN_BLINDS,
							'renova'		=> TAG_RENOVATION_YEAR,
							'control'		=> TAG_ACCESS_SEMIVALID,
								),
					'nl' => array(	"prij" =>  TAG_PRICE,
							"type" =>  TAG_TYPE,
							"adres" =>  TAG_ADDRESS_VISIBLE,
							"bouwjaar" => TAG_CONSTRUCTION_YEAR,
							"grondopp" => TAG_SURFACE_GROUND, 
							"bewoonbare" => TAG_SURFACE_LIVING_AREA,
							"antal_kamer"=> TAG_BEDROOMS_TOTAL,
							"slaapkamer"=> TAG_BEDROOMS_TOTAL,
							"antal_badkam"=> TAG_BATHROOMS_TOTAL,
							"badkam"=> TAG_BATHROOMS_TOTAL,
							"epc_certi" => TAG_EPC_CERTIFICATE_NUMBER,
							"certificaatnr" => TAG_EPC_CERTIFICATE_NUMBER,
							"epc_ind" => TAG_EPC_VALUE,
							"epc_waa" => TAG_EPC_VALUE,
							"epc" => TAG_EPC_VALUE,
							"adastraal_inkomen" => TAG_KI,
							"adastraal" => TAG_KI,
							"inkomen" => TAG_KI,
							"ki" => TAG_KI,
							"adastrale_numme" => TAG_KI_INDEX,
							"verdieping" => TAG_AMOUNT_OF_FLOORS,
							"living" => TAG_SURFACE_LIVING_AREA,
							"renovatie" => TAG_RENOVATION_YEAR,
							"kadaster_sectie" => TAG_CADASTRAL_SECTION,
							"beschikbaar" => TAG_FREE_FROM,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"mail" => TAG_EMAIL,
							"winkels" => TAG_DISTANCE_SHOPS,
							"vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"overstromings" => TAG_FLOOD_INFORMATION_NL,
							"garage" => TAG_GARAGES_TOTAL,
							"toilet" => TAG_TOILETS_TOTAL,
							"parking" => TAG_PARKINGS_TOTAL,
							"gevels" => TAG_AMOUNT_OF_FACADES,
							"lasten" => TAG_COMMON_COSTS,
							"gas" => TAG_GAS_CONNECTION,
							"water" => TAG_CONNECTION_TO_WATER,
							"telefoon" => TAG_TELEPHONE,
							"lift" => TAG_LIFT,
							"gemeubeld" => TAG_FURNISHED,
							"tuin" => TAG_GARDEN_AVAILABLE,
							"haard" => TAG_OPEN_FIRE,
							"alarm" => TAG_ALARM,
							"parlofoon" => TAG_PARLOPHONE,
							"videofoon" => TAG_VIDEOPHONE,
							"breedte" => TAG_LOT_WIDTH,
							"diepte" => TAG_LOT_DEPTH,
							"constructie" => TAG_CONSTRUCTION_TYPE,
							"gevelbreedte" => TAG_FRONTAGE_WIDTH,
							"winkel" => TAG_HEATING_NL,
							"douche" => TAG_SHOWERS_TOTAL,
							"keuken" => TAG_KITCHEN_TYPE_NL,
							"ligging" => TAG_SUBDIVISION_PERMIT,
							"stedenbouwkundige" => TAG_PLANNING_PERMISSION,
							"terras" => TAG_TERRACES,
							"terrein" => TAG_SURFACE_GROUND,
							"scholen" => TAG_DISTANCE_SCHOOL,
							"oppervlakte" => TAG_SURFACE_LIVING_AREA,
							"eetkamer" => TAG_DININGS,
							"dressing" => TAG_DRESSINGS,
							"kelder" => TAG_CELLARS,
							"beroep" => TAG_FREE_PROFESSIONS,
							"berging" => TAG_STOREROOMS,
							"wasplaats" => TAG_LAUNDRY_ROOMS,
							"elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"beglazing" => TAG_DOUBLE_GLAZING,
							"verwarming" => TAG_HEATING_NL,
							"riolering" => TAG_CONNECTION_TO_SEWER,
							"olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"waterput" => TAG_WELL,
							"telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
							"toegangscontrole" => TAG_ACCESS_SEMIVALID,
							"computer" => TAG_INTERNET_CONNECTION,
							"nroerende_voorhef" => TAG_PROPERTY_TAX,
								),
                                        'fr' => array(	"prij" =>  TAG_PRICE,
							"Meuble" => TAG_FURNISHED,
							"facades" => TAG_AMOUNT_OF_FACADES,
							"nombre_de_chambre"=> TAG_BEDROOMS_TOTAL,
							"nombre_de_salle_de_bain"=> TAG_BATHROOMS_TOTAL,
							"jardin" => TAG_GARDEN_AVAILABLE,
							"garage" => TAG_GARAGES_TOTAL,
							"terras" => TAG_TERRACES,
							"parking" => TAG_PARKINGS_TOTAL,
							"habita" => TAG_SURFACE_LIVING_AREA,
							"terrain" => TAG_SURFACE_GROUND,
							"disponible" => TAG_FREE_FROM,
							"magasins" => TAG_DISTANCE_SHOPS,
							"transport" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"toilet" => TAG_TOILETS_TOTAL,
							"construction_annee" => TAG_CONSTRUCTION_YEAR,
							"renovation_annee" => TAG_RENOVATION_YEAR,
							"tages" => TAG_AMOUNT_OF_FLOORS,
							"alarm" => TAG_ALARM,
							"gaz" => TAG_GAS_CONNECTION,
							"eau" => TAG_CONNECTION_TO_WATER,
							"parlophone" => TAG_PARLOPHONE,
							"vitrage" => TAG_DOUBLE_GLAZING,
							"network" => TAG_INTERNET_CONNECTION,
							"douche" => TAG_SHOWERS_TOTAL,
							"caves" => TAG_CELLARS,
							"dressing" => TAG_DRESSINGS,
							"telephone" => TAG_TELEPHONE,
							"videophone" => TAG_VIDEOPHONE,
							"manger" => TAG_DININGS,
							"ecoles" => TAG_DISTANCE_SCHOOL,
							"sejour" => TAG_SURFACE_LIVING_AREA,
							"ascenseur" => TAG_LIFT,
							"largeur_du_lot" => TAG_LOT_WIDTH,
							"mazout" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"citerne" => TAG_WELL,
							"chauffage" => TAG_HEATING_FR,
							"electricite " => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"inondation" => TAG_FLOOD_INFORMATION_FR,
							"egouts" => TAG_CONNECTION_TO_SEWER,
							"cuisine" => TAG_KITCHEN_TYPE_FR,
							"construction_type" => TAG_CONSTRUCTION_TYPE,
							"chauffage" => TAG_HEATING_FR,
							"debarras" => TAG_STOREROOMS,
							"telephoniques" => TAG_TELEPHONE_CONNECTION,
							"dacces" => TAG_ACCESS_SEMIVALID,
							"lotissement" => TAG_SUBDIVISION_PERMIT,
							"batir" => TAG_PLANNING_PERMISSION,
							"cadastrales" => TAG_CADASTRAL_SECTION,
							"prix" => TAG_PRICE, 
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"mail" => TAG_EMAIL,
							"commun" => TAG_COMMON_COSTS,
							"feu" => TAG_OPEN_FIRE,
							"beaucoup_de_profondeur" => TAG_LOT_DEPTH,
							"facade_largeur" => TAG_FRONTAGE_WIDTH,
							"emission_co2" => TAG_CO2_EMISSION,
                                                     ),
				);
	
	$keys = array_keys($attributeTagsArray[$language]); // Returning Keys
	$key = clearForLowerCase($key); // Converting to lower case
	
	foreach($keys as $k){
	    
		   $check = stripos("X$key","$k");
		   if(!empty($check))
		   return $attributeTagsArray[$language][$k];
	    }
	 
	return '';	 
}

function GetExactAttrib($key,$val){
 
    $a = array();
    
    switch($key){
    case TAG_PROPERTY_TAX:
        return toNumber($val);
        break;	
    case TAG_PRICE:
        return toNumber($val);
        break;
    case TAG_CONSTRUCTION_YEAR:
        return toYear($val);
        break;
    case TAG_RENOVATION_YEAR:
        return toYear($val);
        break;
     case TAG_FREE_FROM_DATE:
        return toUnixTimestamp($val);
        break;
    case TAG_KI:
        return toNumber($val);
        break;
    case TAG_EPC_VALUE:
        return toEpc($val);
        break;
    case TAG_EPC_CERTIFICATE_NUMBER:
        return toNumber($val);
        break;
    case TAG_SURFACE_LIVING_AREA:
       return toNumber($val);
       break;
    case TAG_SURFACE_GROUND:
       return toNumber($val);
       break;

    case TAG_GARDEN_AVAILABLE:
       return ($val=='Ja') ? 1 : 0;
    break;
    
    case TAG_TERRACES:
       return $a[] = toNumber($val); 
    break;
    
    default:
	
	$val = trim($val);
	if($val=='Ja' || $val=='Nee' || $val=='Neen')
        return ($val=='Ja') ? 1 : 0;

	else{

		if(stripos($key,"_permission") !== false)
	    return ($val=='Ja') ? 1 : 0;
		
		if(stripos($key,"_visible") !== false)
	    return ($val=='Ja') ? 1 : 0;

	    if(stripos($key,"_nl") !== false)
	    return $val;
	    
	    if(stripos($key,"_fr") !== false)
	    return $val;
	
	    if(stripos($key,"_en") !== false)
	    return $val;
	    else
	    return toNumber($val);
	    
	}
	
    break;
     
    }
}


/// Basic checking for 
function clearForLowerCase($str = ''){ 
    $str = strtolower(str_replace(' ','_',$str)); 
    $str = trim(strip_tags($str)); 
    //$str = preg_replace('![^a-z0-9_\-\. ]!','',$str); 
    // $str = trim(preg_replace('!nbsp!','',$str)); 
    $str = trim(preg_replace('!ja,!','',$str));
    //$str = trim(preg_replace('!,!','',$str));
    $str = trim(normalize_str($str));
    return $str ;
 
}

function toNumber($str)
{
    ///return $str;
	$value = 0;
    $str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
    $str = preg_replace("/,(\d{3})|\.(\d{3})/",  "$1$2", $str);
    if(preg_match("/(-?\d+)/", $str, $match)) $value = intval($match[1]);
    
    if(empty($value))
    return 0;
    else
    return $value;
}

function toUnixTimestamp($str)
{
	return strtotime($str);
}

function toEpc($str){
	$epc = toNumber($str);
	if($epc > 0 && $epc <= 999) return $epc;
}

function toYear($str){
	$year = toNumber($str);
	if($year > 0 && strlen($year) == 4) return $year;
}

function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");
        foreach($invalid as $k => $v){
            $str = str_replace($k, $v, $str); //array_values($invalid)
        }

        return $str;
    }

    