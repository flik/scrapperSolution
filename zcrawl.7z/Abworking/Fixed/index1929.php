<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1929

require_once("./../crawler_classes.php");

CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.sea-coast.be/"
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.sea-coast.be/nl/nieuwbouw"
    )
);

/* ============================= END CONFIG ============================= */



/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/

/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/

/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Immo Sea Coast NV";
$office[TAG_OFFICE_URL] = "http://www.sea-coast.be/";
$office[TAG_STREET] = "Albert I Laan";
$office[TAG_NUMBER] = "98";
$office[TAG_ZIP] = "8620";
$office[TAG_CITY] = "Nieuwpoort";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "+32(0)58 24 24 84";
$office[TAG_FAX] = "+32(0)58 24 24 85";
$office[TAG_EMAIL] = "verkoop@sea-coast.be";
CrawlerTool::saveOffice($office);


$propertyCount = 0;
$properties = array();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
    global $propertyCount;
    global $properties;

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[@class = 'cellfix'][img]");

    $items = array();
    foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_NL] = "http://www.sea-coast.be" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]) ; //$parser->regex("@/(\d+)/@", $property[TAG_UNIQUE_URL_NL]);
        $property[TAG_UNIQUE_URL_FR] = str_replace('/nl/','/fr/',$property[TAG_UNIQUE_URL_NL]);
        $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $parser->extract_xpath("following-sibling::div[@class = 'location']", RETURN_TYPE_TEXT, null, $node)));
        echo "city " . $property[TAG_CITY] . "\n";
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
    }   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    // check for project, if this is a project page then go processing the project
   
 
    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("div[@id = 'algemeen']/text()[1]");
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("div[@class = 'column-2']/h3"));
    
     $node = $parser->getNode("table[@class = 'table']");
    if($node)
    {
        processProject($crawler, $parser, $property);
        return;
    }
    //if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("span[@id = 'status']"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_PLAIN_TEXT_ALL_NL]);

    $property[TAG_PICTURES] = $parser->extract_xpath("a[@class = 'fancybox'][div]", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL =>   $pic);

        return $picUrls;
    });

    $getPics = $parser->extract_xpath("div[@id = 'downloads']/div/a[contains(@href, '.jpg')]", RETURN_TYPE_ARRAY, function($pics)
    {
        $morepicUrls = array();
        foreach($pics as $pic) $morepicUrls[] = array(TAG_PICTURE_URL=> $pic);

        return $morepicUrls;
    });

    $node = $parser->getNode("div[@id = 'downloads']/div/a[contains(@href, '.jpg')]");
    if($node)
    {
        $property[TAG_PICTURES] = array_merge($property[TAG_PICTURES], $getPics);
    }

    // get document files
    $files = array();
    $nodes = $parser->getNodes("div[@id = 'downloads']/div/a[contains(@href, '.pdf')] | div[@id = 'downloads']/div/a[contains(@href, '.doc')]");
    foreach($nodes as $node)
    {
        $fileUrl =  $parser->getAttr($node, "href");
        $fileTitle = $parser->getText($node);
        $files[] = array(TAG_FILE_URL_NL => $fileUrl, TAG_FILE_TITLE_NL => $fileTitle);
    }
    if(!empty($files)) $property[TAG_FILES] = $files;

    $property[TAG_IS_NEW_CONSTRUCTION] = 1;
    $property[TAG_PRICE] = $parser->extract_regex("/(Prijsklasse.*)/", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("span[contains(text(), 'Slaapkamers')]/following-sibling::text()[1]", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("span[contains(text(), 'Badkamers')]/following-sibling::text()[1]", RETURN_TYPE_NUMBER);
    $property[TAG_FLOOR] = $parser->extract_xpath("span[contains(text(), 'Verdieping:')]/following-sibling::text()[1]", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] = $parser->extract_regex("/Garage: <b>(ja)/") === "ja"? 1:0;
    $property[TAG_PARKINGS_TOTAL] = $parser->extract_regex("/Parking: <b>(ja)/") === "ja"? 1:0;
    //CrawlerTool::test($property);
    
        if(!isset($property[TAG_HAS_PROCEEDING]) || empty($property[TAG_HAS_PROCEEDING]))
	$property[TAG_HAS_PROCEEDING] = '';
	
	
	if(!isset($property['planning_permission']) || empty($property['planning_permission']))
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
	$property['subdivision_permit'] = '';
	
	
	if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
	$property['most_recent_destination'] = '';


        $html = $crawler->request($property[TAG_UNIQUE_URL_FR]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	
	$property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("div[@id = 'algemeen']/text()[1]");
        $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL);
    
	$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode($property[TAG_TEXT_DESC_FR])); 
	$property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode(CrawlerTool::encode($property[TAG_PLAIN_TEXT_ALL_FR])); 
	if(empty($property[TAG_TEXT_DESC_FR])){
		
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res); 
		$res[1] = str_replace(chr(11),'',$res[1]); 
		$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode(strip_tags($res[1]))); 
	}
        
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}

function processProject($crawler, $parser, $property)
{
    global $propertyCount;
    global $properties;

    $project = array();
    $project[TAG_PROJECT_ID] = $property[TAG_UNIQUE_ID];
    $project[TAG_UNIQUE_URL_NL] = $property[TAG_UNIQUE_URL_NL];
    $project[TAG_CITY] = $property[TAG_CITY];
    $project[TAG_TEXT_DESC_NL] = $parser->extract_xpath("div[@class = 'hoofding'] | div[@id = 'algemeen']/text()", RETURN_TYPE_TEXT_ALL);
    $project[TAG_PICTURES] = $parser->extract_xpath("a[@class = 'fancybox']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL =>   $pic);

        return $picUrls;
    });


    $nodes = $parser->getNodes("table/descendant::a[.= 'meer info']");
    //$project[TAG_SOLD_PERCENTAGE_MAX] = $nodes->length;
    //$project[TAG_SOLD_PERCENTAGE_VALUE] =  0;
    $innerNodes = $parser->getNodes("div[contains(@id, 'subnav')]/a");
    if($innerNodes->length > 0)
    {
        $project[TAG_SOLD_PERCENTAGE_MAX] = 0;
        $project[TAG_SOLD_PERCENTAGE_VALUE] =  0;
    }
    else
    {
        $project[TAG_SOLD_PERCENTAGE_MAX] = $nodes->length;
        $project[TAG_SOLD_PERCENTAGE_VALUE] =  0;
    }

    $count = 0;
    foreach($nodes as $node)
    {
        $innerProperty = array();
        $innerProperty[TAG_PROJECT_ID] = $project[TAG_PROJECT_ID];
        $innerProperty[TAG_STATUS] = STATUS_FORSALE;
        $innerProperty[TAG_CITY] = $project[TAG_CITY];

        $innerProperty[TAG_UNIQUE_URL_NL] = "http://www.sea-coast.be" . $parser->getAttr($node, "href");
        $innerProperty[TAG_UNIQUE_ID] =  $parser->regex("@/(\d+)/@", $innerProperty[TAG_UNIQUE_URL_NL]);
        $innerProperty[TAG_PRICE] = $parser->extract_xpath("parent::td[1]/preceding-sibling::td[2]", RETURN_TYPE_NUMBER, null, $node);

        if(in_array($innerProperty[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $innerProperty[TAG_UNIQUE_ID];

        $count += 1;

        // process item to obtain detail information
        if($count > 1) echo "--------- Processing property #$propertyCount ...";

        processInnerItem($crawler, $innerProperty, $crawler->request($innerProperty[TAG_UNIQUE_URL_NL]));

        if($count < $nodes->length) echo "--------- Completed<br />";

        $propertyCount += 1;
    }


    $nodes = $parser->getNodes("div[contains(@id, 'subnav')]/a"); // properties on each floor

    foreach($nodes as $node)
    {
        $url_temp = "http://www.sea-coast.be" . $parser->getAttr($node, "href");
        $html = $crawler->request($url_temp);
        $parser = new PageParser($html);

        $innerNodes = $parser->getNodes("table/descendant::a[.= 'meer info']");
        $project[TAG_SOLD_PERCENTAGE_MAX] +=  $innerNodes->length;

        foreach($innerNodes as $index=>$innerNode)
        {
            $innerProperty = array();
            $innerProperty[TAG_PROJECT_ID] = $project[TAG_PROJECT_ID];
            $innerProperty[TAG_STATUS] = STATUS_FORSALE;
            $innerProperty[TAG_CITY] = $project[TAG_CITY];
            $innerProperty[TAG_CITY] = $project[TAG_TEXT_DESC_NL];
            
            $innerProperty[TAG_UNIQUE_URL_NL] = "http://www.sea-coast.be" . $parser->getAttr($innerNode, "href");
            $innerProperty[TAG_UNIQUE_ID] =  $parser->regex("@/(\d+)/@", $innerProperty[TAG_UNIQUE_URL_NL]);

            if(in_array($innerProperty[TAG_UNIQUE_ID], $properties)) continue;
            $properties[] = $innerProperty[TAG_UNIQUE_ID];

            $index += 1;

            // process item to obtain detail information
            if($index > 1) echo "--------- Processing property #$propertyCount ...";

            processInnerItem($crawler, $innerProperty, $crawler->request($innerProperty[TAG_UNIQUE_URL_NL]));

            if($index < $innerNodes->length) echo "--------- Completed<br />";

            $propertyCount += 1;
        }

    }

    if($count > 0) CrawlerTool::saveProject($project);
}

function processInnerItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    if(empty($property[TAG_TEXT_DESC_NL])) $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("div[@id = 'algemeen']/text()[1]");
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("div[@class = 'column-2']/h3"));
    //if (empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("span[@id = 'status']"));
    if (empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_PLAIN_TEXT_ALL_NL]);

    $property[TAG_PICTURES] = $parser->extract_xpath("a[@class = 'fancybox']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL =>   $pic);

        return $picUrls;
    });

    $getPics = $parser->extract_xpath("div[@id = 'downloads']/div/a[contains(@href, '.jpg')]", RETURN_TYPE_ARRAY, function($pics)
    {
        $morepicUrls = array();
        foreach($pics as $pic) $morepicUrls[] = array(TAG_PICTURE_URL=> $pic);

        return $morepicUrls;
    });

    $node = $parser->getNode("div[@id = 'downloads']/div/a[contains(@href, '.jpg')]");
    if($node)
    {
        $property[TAG_PICTURES] = array_merge($property[TAG_PICTURES], $getPics);
    }

    //$property[TAG_CITY] = preg_replace("/.*,\s/", "", $parser->extract_xpath("div[@class = 'column-2']/h1"));
    // get document files
    $files = array();
    $nodes = $parser->getNodes("div[@id = 'downloads']/div/a[contains(@href, '.pdf')] | div[@id = 'downloads']/div/a[contains(@href, '.doc')]");
    foreach($nodes as $node)
    {
        $fileUrl =  $parser->getAttr($node, "href");
        $fileTitle = $parser->getText($node);
        $files[] = array(TAG_FILE_URL_NL => $fileUrl, TAG_FILE_TITLE_NL => $fileTitle);
    }
    if(!empty($files)) $property[TAG_FILES] = $files;

    $property[TAG_IS_NEW_CONSTRUCTION] = 1;
    $property[TAG_PRICE] = $parser->extract_regex("/(Prijsklasse.*)/", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("span[contains(text(), 'Slaapkamers')]/following-sibling::text()[1]", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("span[contains(text(), 'Badkamers')]/following-sibling::text()[1]", RETURN_TYPE_NUMBER);
    $property[TAG_FLOOR] = $parser->extract_xpath("span[contains(text(), 'Verdieping')]/following-sibling::text()[1]", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] = $parser->extract_regex("/Garage: <b>(ja)/") === "ja"? 1:0;
    $property[TAG_PARKINGS_TOTAL] = $parser->extract_regex("/Parking: <b>(ja)/") === "ja"? 1:0;
    
        if(!isset($property[TAG_HAS_PROCEEDING]) || empty($property[TAG_HAS_PROCEEDING]))
	$property[TAG_HAS_PROCEEDING] = '';
	
	
	if(!isset($property['planning_permission']) || empty($property['planning_permission']))
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
	$property['subdivision_permit'] = '';
	
	
	if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
	$property['most_recent_destination'] = '';
		
 
    //CrawlerTool::test($property);
    
    debug($property);
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////

 //function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

///0514437586 President Line...

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}

function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
} 

function removeBrackets($str){
	$str = str_replace('–','',$str);
	$str = str_replace('(','',$str);
	$str = str_replace(')','',$str);
	$str = str_replace('-','',$str);
	return $str;
}

