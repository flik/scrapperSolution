<?php

require_once("../../crawler_classes.php");
$crawler->set_script_dir(realpath(dirname(__FILE__)).'/');

//$crawler->enable_delay_between_requests(5,15);
//$crawler->use_cookies(true);
//$crawler->clean_cookies();
//$crawler->use_gzip(false);

$startPages[STATUS_TORENT] = array
(
"http://www.eurimas.be/nl/Jaarbasis/Index/169/villas-huizen" => TYPE_HOUSE,
"http://www.eurimas.be/nl/Jaarbasis/Index/173/garages" => TYPE_GARAGE,
"http://www.eurimas.be/nl/Jaarbasis/Index/167/appartementen" => TYPE_APARTMENT,


);

$startPages[STATUS_FORSELL] = array
(
 "http://www.eurimas.be/nl/Verkoop/Index/217/villas-huizen" => TYPE_HOUSE,
 "http://www.eurimas.be/nl/Verkoop/Index/3680/nieuwbouw" => "new",
 "http://www.eurimas.be/nl/Verkoop/Index/214/appartementen" => TYPE_APARTMENT,
 "http://www.eurimas.be/nl/Verkoop/Index/3059/bouwgrond" => TYPE_PLOT,
 "http://www.eurimas.be/nl/Verkoop/Index/3064/handelspand" => TYPE_COMMERCIAL,
 "http://www.eurimas.be/nl/Verkoop/Index/3069/garages" => TYPE_GARAGE,
 "http://www.eurimas.be/nl/Verkoop/Index/6233/cote-dazur" => ""

);

CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
		debug($page_url);
	    $html = $crawler->request($page_url);
	    processPage($crawler, $status, $type, $html);
	}
}

CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    if($type=="new") $property[TAG_IS_NEW_CONSTRUCTION]=1;
    static $properties = array();
    $count=0;
    $parser = new PageParser($html);
    if($status=="forsale"){
	    $pattern = '<a href="(\/nl\/Verkoop\/[^"]+)" class="overzichtitem[^"]*">.*?<\/a>';
	}
    if($status=="torent"){
	    $pattern = '<div rel="(\/nl\/[^"]+)" class="[^"]*">\s+<div class="overzichtimg">.*?<div class="overzichtstatus">([^<>]*)';
	}
	preg_match_all("/" . $pattern . "/is", $html, $res, PREG_SET_ORDER);
 
	foreach ($res as $v)
	{
		$property[TAG_STATUS]=$status;
		$property[TAG_TYPE]=$type;

		/*
		if(!empty($v[2]) && (strpos($html,"VERHUURD") || strpos($html,"verhuurd"))){
			$property[TAG_STATUS] = "rented";
		}
		if(!empty($v[0]) && strpos($v[0],"VERKOCHT") || strpos($v[0],"verkocht")){
			$property[TAG_STATUS] = "sold";
		}
		*/
		if(!empty($v[2]) && (trim($v[2]) == "VERHUURD" || trim($v[2]) == "verhuurd")){
			$property[TAG_STATUS] = "rented";
		}
		if(!empty($v[2]) && (trim($v[2]) == "VERKOCHT" || trim($v[2]) == "verkocht")){
			$property[TAG_STATUS] = "sold";
		}

		echo $property[TAG_UNIQUE_URL_NL] = 'http://www.eurimas.be'.$v[1];
		$property[TAG_UNIQUE_ID] = getUniqueId($property[TAG_UNIQUE_URL_NL]);

		if($status=="forsale"){
			$bedrooms = (preg_match('!(\d+) (?:kamer|SLAAPKAMER)!i',$v[0],$res)) ? $res[1] : '';
		}
		if($status=="torent"){
			$bedrooms = (preg_match('!(\d+) kamers!',$v[2],$res)) ? $res[1] : '';
		}
		
        if(!empty($bedrooms)) $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT]=$bedrooms;

		$property[TAG_PRICE]    = (preg_match('!&euro; ([0-9.]+)!',$v[0],$res)) ? str_replace('.','',$res[1]) : '';

		$count=$count+1;
		$propertyCount += 1;
		flush();
		ob_flush();
		// process item to obtain detail information
		echo "--------- Processing property #$propertyCount ...";
		//debug($property);
		processItem($crawler,$property,$type,$status);
		echo "--------- Completed<br />";

    }

}

function getUniqueId($url) {
	preg_match("/Details\/(\d+)\//", $url, $match);
	if($match) return $match[1];
}

function processItem($crawler, $property ,$type)
{
	
	if($property[TAG_STATUS]==STATUS_SOLD)	 return ;
	if($property[TAG_STATUS]==STATUS_RENTED) return ;
	
	
    $r = $crawler->request($property[TAG_UNIQUE_URL_NL]);
    $parser = new PageParser($r,true);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode($parser->extract_xpath("div[@class = 'overzicht']"));
    $property[TAG_TEXT_TITLE_NL] = utf8_decode($parser->extract_xpath("h1"));

    /*
	if (empty($info['type']))
	{
		preg_match('!<span class="ref">([^<>]+)!',$r,$res);
		$property[TAG_TYPE]          = CrawlerTool::getPropertyType($res[1]);

	}
	*/
    
    if(empty($property[TAG_PRICE])) $property[TAG_PRICE]    = (preg_match('!&euro; ([0-9.]+)!',$r,$res)) ? str_replace('.','',$res[1]) : '';

	$address = $parser->extract_xpath("div[@class = 'detailsadres']", RETURN_TYPE_TEXT_ALL); 
	CrawlerTool::parseAddress(preg_replace("/,|\//", "", utf8_decode($address)), $property);
	
	$addr = explode(' ',$address);
	$property[TAG_CITY] = trim($addr[count($addr)-1]);
	$xcity = explode('-',$property[TAG_CITY]);
	
	if(isset($xcity[1])) 
	  $property[TAG_CITY] = $xcity[0]; 
	  $property[TAG_ZIP] =  $parser->regex("/(\d{4})/", $address ); 
	
	if(strlen($property[TAG_ZIP]) < 4){
		$address = str_replace($property[TAG_ZIP],'',$address );
		$property[TAG_BOX_NUMBER] = $property[TAG_ZIP];
		$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
	}
	
	$property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
	$property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
	
	$property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
	$property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
	
	if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
	
	if(strlen($property[TAG_BOX_NUMBER]) < 3 || strlen($property[TAG_BOX_NUMBER]) > 3 )
	unset($property[TAG_BOX_NUMBER]);
	
	if(empty($property[TAG_CITY])){ 
	
		preg_match('!<span class="ref">[^<>]*</span><br />[^<>]+<br />([^<>]+)<br />([^<>]+)<br />!',$r,$res);
		$property[TAG_CITY]          = trim(utf8_decode($res[2]));
		 $adres  = trim($res[1]);
		 debugx($adres );
	    if($adres){
		if(preg_match('!(.*?)\d+|\d[A-Za-z]|$!',$adres,$res2)){
		    if(!empty($res2[1])) $property[TAG_STREET]=trim($res2[1]);
		}
	
		preg_match('!\d+\-\d+|\d+[A-Za-z]|\d+|$!',$adres,$res2);
		$property[TAG_NUMBER]=trim($res2[0]);
	
	    }
    
		if(empty($property[TAG_STREET])) $property[TAG_STREET]=utf8_decode($adres);
		$property[TAG_CITY] = str_replace('-Bad','',$property[TAG_CITY]);
	
		if (stripos($property[TAG_CITY],'Nieuwpoort')!==false) {$property[TAG_CITY] = 'Nieuwpoort';}
	}	

		 
		
	//$info['city'] = preg_replace('!\(.*?\)!s','',$info['city']);

	if (preg_match('!EPC:\s*(\d+)!i',$r,$res))
	{
		$property[TAG_EPC_VALUE] = $res[1];
	}

	//images
	$pic_urls = array();
	if (preg_match('!<div class="fotos">.*?</div>!s',$r,$res))
	{
		preg_match_all('!<img src="(/cms_pictures/[^"]+)" />!',$res[0],$res1);
		foreach ($res1[1] as $v) {$pic_urls[] = array(TAG_PICTURE_URL =>'http://www.eurimas.be'.$v);}
		$property[TAG_PICTURES]  = $pic_urls;
	}

	if(empty( $property[TAG_PICTURES] )){
		
		$property[TAG_PICTURES] =  $parser->extract_xpath("div[@class = 'fotos']/img/@src", RETURN_TYPE_ARRAY, function($pics)
		{
		    $picUrls = array();
		    foreach($pics as $pic) {
	    
			$picUrls[] = array(TAG_PICTURE_URL => 'http://www.eurimas.be'.$pic);
		    }
		    return $picUrls;
		});
		
	}
	//shortdescr
	preg_match('!<div class="detailstekst">(.*?)</div>!s',$r,$res);
	$property[TAG_TEXT_SHORT_DESC_NL]    =  trim(strip_tags($res[1]));
    
     if(empty($property[TAG_TYPE]) || $property[TAG_TYPE]=='new') $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_SHORT_DESC_NL], 999); 
     if(empty($property[TAG_TYPE]) || $property[TAG_TYPE]=='new') $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_PLAIN_TEXT_ALL_NL], 999); 
    
     $property[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
     {
         $fileUrls = array();
         foreach($files as $file)
         {
         echo $file;
             if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => 'http://www.eurimas.be'.$file);
         }
         return $fileUrls;
    });
		//1000 en 9999
	$property[TAG_ZIP] = intval($property[TAG_ZIP]); 
	if( $property[TAG_ZIP] < 1000 && $property[TAG_ZIP] > 9999)
	unset($property[TAG_ZIP]);
	
	if(strlen($property[TAG_ZIP]) < 4)
	unset($property[TAG_ZIP]);
	
	if( $property[TAG_TYPE] == '12681' )
	$property[TAG_TYPE] = 'apartment';
	
	$property[TAG_STREET] = str_replace('x'.$property[TAG_TEXT_TITLE_NL], '', $property[TAG_STREET]);
	
	//////
	if(stripos('x'.$property[TAG_STREET],'Henri')!==false) { $property[TAG_CITY] = 'Gent'; $property[TAG_ZIP] = 9051; }
	if(stripos('x'.$property[TAG_CITY],'Panne')!==false) { $property[TAG_CITY] = 'De Panne'; }
	
	$property[TAG_CITY] = removeBrackets($property[TAG_CITY]); 
	 
	debug($property); 
	CrawlerTool::saveProperty($property);

}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}

function removeBrackets($str){
	$str = str_replace('–','',$str);
	$str = str_replace('(','',$str);
	$str = str_replace(')','',$str);
	$str = str_replace('-','',$str);
	return $str;
}

?>