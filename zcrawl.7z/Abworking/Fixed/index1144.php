<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1144

require_once("../crawler_classes.php");



CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.immoblomme.be/"
    )
);


$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immoblomme.be/Web.mvc/fr-fr/List1"
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immoblomme.be/Web.mvc/fr-fr/List2"
    ),
);


/* ============================= END CONFIG ============================= */


// START writing data to output.xml file
CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);

            $nextPages = getPages($html);
            foreach($nextPages as $nextPage)
            {
                $html = $crawler->request($nextPage);
                processPage($crawler, $status, $type, $html);
            }
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);


    $nodes = $parser->getNodes("a[contains(@href, '/Detail/')][img]");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_FR] = "http://www.immoblomme.be" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  $parser->regex("/(\d+)$/", $property[TAG_UNIQUE_URL_FR]);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_FR]);
	}

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Get a list of next pages
 */
function getPages($html)
{
    $parser = new PageParser($html);

	$pages = array();
	$nodes = $parser->getNodes("a[@class = 'Link PaginationLink']");

    if(!empty($nodes))
    {
		foreach($nodes as $node)
        {
			$pages[] = "http://www.immoblomme.be" . $parser->getAttr($node, "href");
		}
	}

	return array_unique($pages);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
	
	//Out of Belgium
	if($property[TAG_UNIQUE_ID] == '1761342' )
	return;
	
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]");
    $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);
    
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.immoblomme.be" . $pic);

        return $picUrls;
    });

    $files = array();
   
    $property[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
         {
             $fileUrls = array();
             foreach($files as $file)
             {
                 if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => "http://www.immoblomme.be/".str_replace('../','',$file));
             }
             return $fileUrls;
    });

    CrawlerTool::parseAddress($parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[1]"), $property);
    $parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[2]", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(\d{4,})(.*)/", $text, $match))
        {
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
        if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $text));
    });

    $property[TAG_PRICE] = $parser->extract_xpath("td[contains(text(), 'Prix')]", RETURN_TYPE_NUMBER);


    $labels = $values = $vars = array();
    $nodes = $parser->getNodes("table[@cellpadding = '1']/tr/td");
    foreach($nodes as $node)
    {
        $labelText = $parser->getText($node);
        $labelText = normalize_str($labelText);
        $ignoreArray = array("Terrain & Envir.","Contact","General","Communications","Interieur","Aspects Financiers","Exterieur","Documents");
        if(!empty($labelText) && !in_array($labelText,$ignoreArray)){
            $labels[] = $parser->getText($node);
        }
    }
    $count = 0;
    foreach($labels as $label)
    {
        $count2 = $count+1;
        $key = $labels[$count];
        $val = $labels[$count2];
         $vars[$key] = $val;
    }
    
    //----------------------------------------------------------------------------------//
         $unmatched_variables = array();
	
	// Most Important 
	if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
	$property['planning_proceeding'] = '';
	
	
	if(!isset($property['planning_permission']) || empty($property['planning_permission']))
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
	$property['subdivision_permit'] = '';
	 
	if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
	$property['most_recent_destination'] = '';
	
	 
	 foreach ($vars as $label => $value)
	{ 
		$attribute = getAttributes(clearForLowerCase($label), 'fr'); 
		if(!empty($attribute) ){ 
		    if(empty($property[$attribute])) 
		    $property[$attribute] = GetExactAttrib($attribute,$value); 
		}
		else
		    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
		
	}
	
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
	    
    //debug($labels);
 
    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("Catégorie"));
    $property[TAG_EPC_VALUE] = $parser->extract_xpath("PEB", RETURN_TYPE_EPC);
    $property[TAG_KI] = $parser->extract_xpath("revenu cadastral", RETURN_TYPE_NUMBER);
    if(empty($property[TAG_KI]))  $property[TAG_KI] = $parser->extract_regex("/RC\s?:\s(\d+)/", RETURN_TYPE_NUMBER);

    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("surface brute surface", RETURN_TYPE_NUMBER);
    if(empty($property[TAG_SURFACE_GROUND])) $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("surface brute - surface", RETURN_TYPE_NUMBER);

    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("surface nette surface", RETURN_TYPE_NUMBER);
    if(empty($property[TAG_SURFACE_LIVING_AREA])) $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("surface nette - surface", RETURN_TYPE_NUMBER);

    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Facades", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Nombre de chambres", RETURN_TYPE_NUMBER);
    if(empty($property[TAG_BEDROOMS_TOTAL])) $property[TAG_BEDROOMS_TOTAL] = $parser->extract_regex("/(\d)\s(chambres|chambre|grandes chambres)/", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_regex("/(\d)\s(sdb|s d bain|salle de bain)/i", RETURN_TYPE_NUMBER);
    $property[TAG_FLOOR] = $parser->extract_xpath("étages nombre", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toilettes nombre", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] =  CrawlerTool::contains($parser->extract_xpath("Garage"), "Oui");
    if(empty($property[TAG_GARAGES_TOTAL]))   $property[TAG_GARAGES_TOTAL] =  $parser->extract_regex("/(\d)\sgarages/", RETURN_TYPE_NUMBER);
    $property[TAG_PARKINGS_TOTAL] = CrawlerTool::contains($parser->extract_xpath("Parking"), "Oui");
    if(empty($property[TAG_PARKINGS_TOTAL])) $property[TAG_PARKINGS_TOTAL] = $parser->extract_regex("/(\d)\sparkings/", RETURN_TYPE_NUMBER);
    $property[TAG_HEATING_FR] = $parser->extract_xpath("chauffage type");
    $property[TAG_DOUBLE_GLAZING] = CrawlerTool::contains($parser->extract_regex("/(double vitrage)/i"), "double vitrage");
    $property[TAG_GARDEN_AVAILABLE] = CrawlerTool::contains($parser->extract_xpath("Jardin"), "Oui");
    $property[TAG_CONNECTION_TO_WATER] = CrawlerTool::contains($parser->extract_xpath("eau"), "Oui");
    $property[TAG_GAS_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("gaz"), "Oui");
    $property[TAG_TELEPHONE_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("téléphone"), "Oui");
    $property[TAG_ALARM] = CrawlerTool::contains($parser->extract_xpath("alarme"), "Oui");
    $property[TAG_PARLOPHONE] = CrawlerTool::contains($parser->extract_xpath("parlophone"), "Oui");
    $property[TAG_VIDEOPHONE] = CrawlerTool::contains($parser->extract_xpath("vidéophone"), "Oui");
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Disponible de", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM] = $parser->extract_xpath("Disponible de");

    $property[TAG_DISTANCE_PUBLIC_TRANSPORT] = $parser->extract_xpath("transports en commun distance", RETURN_TYPE_NUMBER);
    $property[TAG_DISTANCE_SHOPS] = $parser->extract_xpath("magasins distance", RETURN_TYPE_NUMBER);

    $kitchenSurf = $parser->extract_xpath("cuisine surface", RETURN_TYPE_NUMBER);
    if($kitchenSurf > 0) $property[TAG_KITCHENS][] = array(TAG_KITCHEN_SURFACE => $kitchenSurf);

    //debug($property);

	$property[TAG_UNIQUE_URL_NL] = str_replace('fr-fr','nl-be',$property[TAG_UNIQUE_URL_FR]);
	$property[TAG_UNIQUE_URL_EN] = str_replace('fr-fr','en-gb',$property[TAG_UNIQUE_URL_FR]);
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_NL]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	
	$property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]");
	$property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);
    
	$property[TAG_TEXT_DESC_NL] = utf8_decode(CrawlerTool::encode($property[TAG_TEXT_DESC_NL])); 
	$property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode(CrawlerTool::encode($property[TAG_PLAIN_TEXT_ALL_NL])); 
	if(empty($property[TAG_TEXT_DESC_NL])){
		
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res); 
		$res[1] = str_replace(chr(11),'',$res[1]); 
		$property[TAG_TEXT_DESC_NL] = utf8_decode(CrawlerTool::encode(strip_tags($res[1]))); 
	}
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_EN]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	
	$property[TAG_TEXT_DESC_EN] = $parser->extract_xpath("table[@border = '1' and not(@cellpadding)]");
	$property[TAG_PLAIN_TEXT_ALL_EN] = $parser->extract_xpath("table[@border = '1'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);
    
	$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode($property[TAG_TEXT_DESC_EN])); 
	$property[TAG_PLAIN_TEXT_ALL_EN] = utf8_decode(CrawlerTool::encode($property[TAG_PLAIN_TEXT_ALL_EN])); 
		
	if(empty($property[TAG_TEXT_DESC_EN])){
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
		$res[1] = str_replace(chr(11),'',$res[1]);
		$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode(strip_tags($res[1])));
	}
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}

	
function getAttributes($key, $language='nl'){ //String Function always return string

	$attributeTagsArray	= array('en' => array(	'pric' 			=>  TAG_PRICE,
							'constr'		=> TAG_CONSTRUCTION_YEAR,
							'ground'		=> TAG_SURFACE_GROUND,
							'living' 		=> TAG_SURFACE_LIVING_AREA,
							'bath'			=> TAG_BATHROOMS_TOTAL,
							'warm'			=> TAG_HEATING_EN,
							'heat'			=> TAG_HEATING_EN,
							'sewer'			=> TAG_CONNECTION_TO_SEWER,
							'telep'			=> TAG_TELEPHONE_CONNECTION,
							'intern'		=> TAG_INTERNET_CONNECTION,
							'permission'		=> TAG_PLANNING_PERMISSION,
							'subdivision'		=> TAG_SUBDIVISION_PERMIT,
							'electri'		=> TAG_METER_FOR_ELECTRICITY,
							'hall'			=> TAG_HALLS,
							'dining'		=> TAG_DININGS,
							'kitch'			=> TAG_KITCHENS,
							'laundr'		=> TAG_LAUNDRY_ROOMS,
							'dress'			=> TAG_DRESSING,
							'bed'			=> TAG_BEDROOMS_TOTAL,
							'room'			=> TAG_BEDROOMS_TOTAL,
							'park'			=> TAG_PARKINGS,
							'garage'		=> TAG_GARAGES_TOTAL,
							'type'			=> TAG_TYPE,
							'garden'		=> TAG_GARDEN_AVAILABLE,
							'floor'			=> TAG_AMOUNT_OF_FLOORS,
							'winter'		=> TAG_WINTERGARDENS,
							'furnish'		=> TAG_FURNISHED,
							'water'			=> TAG_CONNECTION_TO_WATER,
							'lift'			=> TAG_LIFT,
							'glaz'			=> TAG_DOUBLE_GLAZING,
							'terrac'		=> TAG_TERRACES,
							'fronts'		=> TAG_AMOUNT_OF_FACADES,
							'category'		=> TAG_TYPE,
							'free'			=> TAG_FREE_FROM_DATE,
							'habit'			=> TAG_SURFACE_LIVING_AREA,
							'plot'			=> TAG_SURFACE_GROUND,
							'shops'			=> TAG_DISTANCE_SHOPS,
							'schools'		=> TAG_DISTANCE_SCHOOL,
							'transport'		=> TAG_DISTANCE_PUBLIC_TRANSPORT,
							'shower'		=> TAG_SHOWERS_TOTAL,
							'stor'			=> TAG_STOREROOMS,
							'gas'			=> TAG_GAS_CONNECTION,
							'alarm'			=> TAG_ALARM,
							'security'		=> TAG_SECURITY_DOOR,
							'parlo'			=> TAG_PARLOPHONE,
							'video'			=> TAG_VIDEOPHONE,
							'elevat'		=> TAG_LIFT,
							'blind'			=> TAG_SUN_BLINDS,
							'renova'		=> TAG_RENOVATION_YEAR,
							'control'		=> TAG_ACCESS_SEMIVALID,
								),
					'nl' => array(	"prij" =>  TAG_PRICE,
							"bouwjaar" => TAG_CONSTRUCTION_YEAR,
							"grondopp" => TAG_SURFACE_GROUND, 
							"bewoonbare" => TAG_SURFACE_LIVING_AREA,
							"antal_kamer"=> TAG_BEDROOMS_TOTAL,
							"slaapkamer"=> TAG_BEDROOMS_TOTAL,
							"antal_badkam"=> TAG_BATHROOMS_TOTAL,
							"badkam"=> TAG_BATHROOMS_TOTAL,
							"certificaatnr" => TAG_EPC_CERTIFICATE_NUMBER,
							"epc_waa" => TAG_EPC_VALUE,
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"verdieping" => TAG_AMOUNT_OF_FLOORS,
							"living" => TAG_SURFACE_LIVING_AREA,
							"renovatie" => TAG_RENOVATION_YEAR,
							"kadaster_sectie" => TAG_CADASTRAL_SECTION,
							"beschikbaar" => TAG_FREE_FROM,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"mail" => TAG_EMAIL,
							"winkels" => TAG_DISTANCE_SHOPS,
							"vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"overstromings" => TAG_FLOOD_INFORMATION_NL,
							"garage" => TAG_GARAGES_TOTAL,
							"toilet" => TAG_TOILETS_TOTAL,
							"parking" => TAG_PARKINGS_TOTAL,
							"gevels" => TAG_AMOUNT_OF_FACADES,
							"lasten" => TAG_COMMON_COSTS,
							"gas" => TAG_GAS_CONNECTION,
							"water" => TAG_CONNECTION_TO_WATER,
							"telefoon" => TAG_TELEPHONE,
							"lift" => TAG_LIFT,
							"gemeubeld" => TAG_FURNISHED,
							"tuin" => TAG_GARDEN_AVAILABLE,
							"haard" => TAG_OPEN_FIRE,
							"alarm" => TAG_ALARM,
							"parlofoon" => TAG_PARLOPHONE,
							"videofoon" => TAG_VIDEOPHONE,
							"breedte" => TAG_LOT_WIDTH,
							"diepte" => TAG_LOT_DEPTH,
							"constructie" => TAG_CONSTRUCTION_TYPE,
							"gevelbreedte" => TAG_FRONTAGE_WIDTH,
							"winkel" => TAG_HEATING_NL,
							"douche" => TAG_SHOWERS_TOTAL,
							"keuken" => TAG_KITCHEN_TYPE_NL,
							"ligging" => TAG_SUBDIVISION_PERMIT,
							"stedenbouwkundige" => TAG_PLANNING_PERMISSION,
							"terras" => TAG_TERRACES,
							"terrein" => TAG_SURFACE_GROUND,
							"scholen" => TAG_DISTANCE_SCHOOL,
							"oppervlakte" => TAG_SURFACE_LIVING_AREA,
							"eetkamer" => TAG_DININGS,
							"dressing" => TAG_DRESSINGS,
							"kelder" => TAG_CELLARS,
							"beroep" => TAG_FREE_PROFESSIONS,
							"berging" => TAG_STOREROOMS,
							"wasplaats" => TAG_LAUNDRY_ROOMS,
							"elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"beglazing" => TAG_DOUBLE_GLAZING,
							"verwarming" => TAG_HEATING_NL,
							"riolering" => TAG_CONNECTION_TO_SEWER,
							"olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"waterput" => TAG_WELL,
							"telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
							"toegangscontrole" => TAG_ACCESS_SEMIVALID,
							"computer" => TAG_INTERNET_CONNECTION,
							"nroerende_voorhef" => TAG_PROPERTY_TAX,
								),
                                        'fr' => array(	"prij" =>  TAG_PRICE,
							"Meuble" => TAG_FURNISHED,
							"facades" => TAG_AMOUNT_OF_FACADES,
							"nombre_de_chambre"=> TAG_BEDROOMS_TOTAL,
							"nombre_de_salle_de_bain"=> TAG_BATHROOMS_TOTAL,
							"jardin" => TAG_GARDEN_AVAILABLE,
							"garage" => TAG_GARAGES_TOTAL,
							"terras" => TAG_TERRACES,
							"parking" => TAG_PARKINGS_TOTAL,
							"habita" => TAG_SURFACE_LIVING_AREA,
							"terrain" => TAG_SURFACE_GROUND,
							"disponible" => TAG_FREE_FROM,
							"magasins" => TAG_DISTANCE_SHOPS,
							"transport" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"toilet" => TAG_TOILETS_TOTAL,
							"construction_annee" => TAG_CONSTRUCTION_YEAR,
							"renovation_annee" => TAG_RENOVATION_YEAR,
							"tages" => TAG_AMOUNT_OF_FLOORS,
							"alarm" => TAG_ALARM,
							"gaz" => TAG_GAS_CONNECTION,
							"eau" => TAG_CONNECTION_TO_WATER,
							"parlophone" => TAG_PARLOPHONE,
							"vitrage" => TAG_DOUBLE_GLAZING,
							"network" => TAG_INTERNET_CONNECTION,
							"douche" => TAG_SHOWERS_TOTAL,
							"caves" => TAG_CELLARS,
							"dressing" => TAG_DRESSINGS,
							"telephone" => TAG_TELEPHONE,
							"videophone" => TAG_VIDEOPHONE,
							"manger" => TAG_DININGS,
							"ecoles" => TAG_DISTANCE_SCHOOL,
							"sejour" => TAG_SURFACE_LIVING_AREA,
							"ascenseur" => TAG_LIFT,
							"largeur_du_lot" => TAG_LOT_WIDTH,
							"mazout" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"citerne" => TAG_WELL,
							"chauffage" => TAG_HEATING_FR,
							"electricite " => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"inondation" => TAG_FLOOD_INFORMATION_FR,
							"egouts" => TAG_CONNECTION_TO_SEWER,
							"cuisine" => TAG_KITCHEN_TYPE_FR,
							"construction_type" => TAG_CONSTRUCTION_TYPE,
							"chauffage" => TAG_HEATING_FR,
							"debarras" => TAG_STOREROOMS,
							"telephoniques" => TAG_TELEPHONE_CONNECTION,
							"dacces" => TAG_ACCESS_SEMIVALID,
							"lotissement" => TAG_SUBDIVISION_PERMIT,
							"batir" => TAG_PLANNING_PERMISSION,
							"cadastrales" => TAG_CADASTRAL_SECTION,
							"prix" => TAG_PRICE, 
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"mail" => TAG_EMAIL,
							"commun" => TAG_COMMON_COSTS,
							"feu" => TAG_OPEN_FIRE,
							"beaucoup_de_profondeur" => TAG_LOT_DEPTH,
							"facade_largeur" => TAG_FRONTAGE_WIDTH,
							"emission_co2" => TAG_CO2_EMISSION,
                                                     ),
				);
	
	$keys = array_keys($attributeTagsArray[$language]); // Returning Keys
	$key = clearForLowerCase($key); // Converting to lower case
	
	foreach($keys as $k){
	    
		   $check = stripos("X$key","$k");
		   if(!empty($check))
		   return $attributeTagsArray[$language][$k];
	    }
	 
	return '';	 
}

function GetExactAttrib($key,$val){
 
    $a = array();
    
    switch($key){
    case TAG_PROPERTY_TAX:
        return toNumber($val);
        break;	
    case TAG_PRICE:
        return toNumber($val);
        break;
    case TAG_CONSTRUCTION_YEAR:
        return toYear($val);
        break;
    case TAG_RENOVATION_YEAR:
        return toYear($val);
        break;
     case TAG_FREE_FROM_DATE:
        return toUnixTimestamp($val);
        break;
    case TAG_KI:
        return toNumber($val);
        break;
    case TAG_EPC_VALUE:
        return toEpc($val);
        break;
    case TAG_EPC_CERTIFICATE_NUMBER:
        return toNumber($val);
        break;
    case TAG_SURFACE_LIVING_AREA:
       return toNumber($val);
       break;
    case TAG_SURFACE_GROUND:
       return toNumber($val);
       break;
    case TAG_MOST_RECENT_DESTINATION:
       return trim($val);
       break;
    case TAG_PLANNING_PERMISSION:
       return $val;
       break;
    case TAG_SUBDIVISION_PERMIT:
       return toNumber($val); 
    break;

    case TAG_GARDEN_AVAILABLE:
       return ($val=='Ja') ? 1 : 0;
    break;
    
    case TAG_TERRACES:
       return $a[] = toNumber($val); 
    break;
    
    default:
	$val = trim($val);
	if($val=='Ja' || $val=='Nee' || $val=='Neen')
        return ($val=='Ja') ? 1 : 0;
	else{

		if(stripos($key,"permission") !== false)
	    return ($val=='Ja') ? 1 : 0;
	
	    if(stripos($key,"_nl") !== false)
	    return $val;
	    
	    if(stripos($key,"_fr") !== false)
	    return $val;
	
	    if(stripos($key,"_en") !== false)
	    return $val;
	    else
	    return toNumber($val);
	    
	}
	
    break;
     
    }
}

/// Basic checking for 
function clearForLowerCase($str = ''){ 
    $str = strtolower(str_replace(' ','_',$str)); 
    $str = trim(strip_tags($str)); 
    //$str = preg_replace('![^a-z0-9_\-\. ]!','',$str); 
    // $str = trim(preg_replace('!nbsp!','',$str)); 
    $str = trim(preg_replace('!ja,!','',$str));
    //$str = trim(preg_replace('!,!','',$str));
    $str = trim(normalize_str($str));
    return $str ;
 
}

function toNumber($str)
{
    ///return $str;
	$value = 0;
    $str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
    $str = preg_replace("/,(\d{3})|\.(\d{3})/",  "$1$2", $str);
    if(preg_match("/(-?\d+)/", $str, $match)) $value = intval($match[1]);
    
    if(empty($value))
    return 0;
    else
    return $value;
}

function toUnixTimestamp($str)
{
	return strtotime($str);
}

function toEpc($str){
	$epc = toNumber($str);
	if($epc > 0 && $epc <= 999) return $epc;
}

function toYear($str){
	$year = toNumber($str);
	if($year > 0 && strlen($year) == 4) return $year;
}

function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");
        foreach($invalid as $k => $v){
            $str = str_replace($k, $v, $str); //array_values($invalid)
        }

        return $str;
    }

/**
 * Get a Lat Long format other wise It will give XSD invalid
*/
function getLatLong($str)
{
	$str = floatval($str);
	return substr($str, 0, 8) ;
}

//function for print array
function debug($obj)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}  