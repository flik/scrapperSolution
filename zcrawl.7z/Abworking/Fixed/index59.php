<?php
require_once("../crawler_classes.php");
$crawler->use_cookies(true);

//$crawler->enable_delay_between_requests(5,15);
//$crawler->use_cookies(true);
$crawler->clean_cookies();
//$crawler->use_gzip(false);

$startPages[STATUS_TORENT] = array
(
'http://www.ccimmo.be/showlist.aspx?pageId=12835&goal=1&cmMenu=4' => TYPE_NONE,
);

$startPages[STATUS_FORSELL] = array
(
'http://www.ccimmo.be/showlist.aspx?pageId=12694&goal=0&cds=n&cdsv=-&Marquee=1,2,3&StatusList=1,6&cmMenu=2' => TYPE_NONE,
'www.ccimmo.be/ConstructionList.aspx?ProjectType=&Language=1'=>"project",
);




CrawlerTool::startXML();

//Office Detail Updated by Ashfaq
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "CC IMMO bvba";
$office[TAG_OFFICE_URL] = "http://www.concept-bvba.be/";
$office[TAG_STREET] = "Nationalestraat";
$office[TAG_NUMBER] = "90";
$office[TAG_ZIP] = "2000";
$office[TAG_CITY] = "Antwerpen";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "+32 (0)3/257.55.55";
$office[TAG_FAX] = "+32 (0)3/257.11.01";
$office[TAG_EMAIL] = " info@ccimmo.be";
CrawlerTool::saveOffice($office);


foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
           $html = $crawler->request($page_url);
     	   processPage($crawler, $status, $type, $html);

    }
}

CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $projectCount = 0;

    static $properties = array();
    static $project = array();

    $parser = new PageParser($html);
	if($type=="project" ){
		$project = array();
		$project[TAG_STATUS] = $status;
		$nodes = $parser->getNodes("td[contains(@class, 'Listimages')]/a");
		$items = array();
		foreach($nodes as $node)
		{

			 echo $project[TAG_UNIQUE_URL_NL]  =  'http://www.ccimmo.be/'.$parser->getattr($node,"href");
			 $project[TAG_PROJECT_ID] = $parser->regex("/PrjId=(\d+)/", $project[TAG_UNIQUE_URL_NL]);

			 $projectCount += 1;
			 echo "--------- Processing project #$projectCount ...";
			 processProject($crawler,$project,$type,$status);
			 echo "--------- Completed<br />";
		}
	}else{
		$nodes = $parser->getNodes("div[contains(@onclick, 'objectid=')]");
		$items = array();
		foreach($nodes as $node)
		{
			$property = array();
			$property[TAG_STATUS] = $status;

			$property[TAG_UNIQUE_ID] = getUniqueId($parser,$node);
			echo $property[TAG_UNIQUE_URL_NL] = "http://www.ccimmo.be/showobject.aspx?objectid=".$property[TAG_UNIQUE_ID];
			$n = $parser->getNode("div[2]", $node);
			if($n) $property[TAG_TYPE]=CrawlerTool::getPropertyType($parser->getText($n));
			$n = $parser->getNode("div[3]", $node);
			if($n) {
				$rooms = CrawlerTool::toNumber($parser->getText($n));
				if($rooms > 0) echo $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT] = $rooms;
			}

			$propertyCount += 1;
			flush();
			ob_flush();
			// process item to obtain detail information
			echo "--------- Processing property #$propertyCount ...";
			processItem($crawler, $property);
			echo "--------- Completed<br />";
		}
	}
}
function getUniqueId($parser, $node) {
	preg_match("/objectid=(\d+)/", $parser->getAttr($node, "onclick"), $match);
	if($match) return $match[1];
}

function processItem($crawler, $property)
{
	$html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
	$parser = new PageParser($html);
	$parser->deleteTags(array("script", "style"));
    $property[TAG_TEXT_SHORT_DESC_NL]= $parser->extract_xpath("div[descendant::*[contains(text(), 'KORTE BESCHRIJVING')]]/following-sibling::table[1]");
    $property[TAG_PLAIN_TEXT_ALL_NL]= $parser->extract_xpath("table[@width = '950']/tr[2]");

	$node = $parser->getNode("div[@id = 'caption']/strong");
	if($node) {
		$price = CrawlerTool::toNumber($node->nodeValue);
		if($price > 0) $property[TAG_PRICE]= $price;
	}
    $property[TAG_PICTURES] = $parser->extract_xpath("img[contains(@onmouseover, 'showfoto')]", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic)
        {
            if(!empty($pic)) $picUrls[] = array(TAG_PICTURE_URL => "http://www.ccimmo.be/" . str_replace("S.jpg", "L.jpg", $pic));
        }
        return $picUrls;
    });

	$node = $parser->getNode("td[contains(text(), 'Opp. Bewoonbaar')]");
	if($node) {
		$surf = CrawlerTool::toNumber($node->nodeValue);
		if($surf > 0) $property[TAG_SURFACE_GROUND] = $surf;
	}
	if (preg_match('!GoogleX=([0-9.]+)&GoogleY=([0-9.]+)&!',$html,$res))
	{
		#$property[TAG_LATITUDE] = $res[1];
		#$property[TAG_LONGITUDE] = $res[2];
	}
	preg_match_all('!<td width="35%" nowrap="">\s+([^<>]+)</td>\s+<td width="65%">\s+([^<>]+)</td>!',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('!&nbsp;!','',$arr[1]);
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$vars[$arr[1]] = str_replace('&nbsp;','',$arr[2]);
		#echo "<br>";
	}
	preg_match_all('!<td width="35%" nowrap="">([^<>]+)</td>\s+<td width="65%">([^<>]+)</td>!',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('!&nbsp;!','',$arr[1]);
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$vars[$arr[1]] = str_replace('&nbsp;','',$arr[2]);
		#echo "<br>";
	}
	if (isset($vars['status'])) {unset($vars['status']);}
	$property[TAG_CONSTRUCTION_TYPE]       = CrawlerTool::getConstructionType(get_var($vars,'type bebouwing'));
    $property[TAG_HEATING_NL] = get_var($vars,'verwarming');
    $property[TAG_PRICE]                   =  CrawlerTool::toNumber(get_var($vars,'prijs'));
/*	if(stripos($text, "/m") !== false)
	{
		$property[TAG_PRICE_PER_M2] = CrawlerTool::toNumber($text);
		$property[TAG_PRICE]="";

	}
	else
	{
		$property[TAG_PRICE] = CrawlerTool::toNumber($text);
	}
*/
    $property[TAG_EPC_VALUE]                   = CrawlerTool::toNumber(get_var($vars,'epc'));
    $property[TAG_COMMON_COSTS] = get_var($vars,'lasten','!(\d+)!');
    $property[TAG_GAS_CONNECTION]          = (get_var($vars,'aansluiting aardgas') === "Ja" ? 1 : 0);
    $property[TAG_CONNECTION_TO_WATER]=get_var($vars,'aansluiting waterleiding') === 'Ja' ? 1 : '';
    #$property[TAG_SURFACE_GROUND] = get_var($vars,"opp\. terrein",'!(\d+)!');
    $property[TAG_RENOVATION_YEAR] = get_var($vars,'renovatiejaar','!(\d{4})!');
    $property[TAG_DOUBLE_GLAZING]=CrawlerTool::contains(get_var($vars,'beglazing') ,"Dubbel");
    $property[TAG_KI]                      = str_replace('.','',get_var($vars,'ki','![^<>0-9]*([0-9.]+)!'));
    $property[TAG_LIFT]                    = CrawlerTool::contains(get_var($vars,'lift'),'Ja');
    $property[TAG_CONSTRUCTION_YEAR]       = get_var($vars,'bouwjaar','!(\d{4})!');
    $property[TAG_FRONTAGE_WIDTH] =get_var($vars,'voorgevelbreedte');
    $property[TAG_LOT_WIDTH] = get_var($vars,'perceelbreedte');
    $property[TAG_FREE_FROM_DATE] = CrawlerTool::toUnixTimestamp(get_var($vars,'vrij op'));



    $adres=get_var($vars,'adres');

	$adres = trim(str_replace('&nbsp;','',$adres));

	if (strpos($adres,','))
	{
		list($info['address_full'],$info['city']) = explode(',',$adres,2);
		$property[TAG_CITY]  = trim(preg_replace('!\d!','',$info['city']));
		$property[TAG_ZIP]  = (preg_match('!\d{4}!',$adres,$res2)) ? $res2[0] : '' ;
	}
	else
	{
		preg_match('!(.*?)\d{4}(.*)!',$adres,$res2);
		$info['address_full'] = trim($res2[1]);
		$property[TAG_CITY] = trim($res2[2]);
	}

	if(!empty($info['address_full'])){
		if(preg_match("/(.*)\s(\d+[A-Za-z]|[A-Za-z]\s\d+|\d+\/\d+[A-Za-z]*|\d+-\d+|\d+)/", $info['address_full'], $match))
		{
			$property[TAG_NUMBER] = $match[2];
		}

		 #$property[TAG_NUMBER] = trim(preg_replace("/[a-zA-Z\/\.\>\- ]/", "", $info['address_full']));
		 $property[TAG_STREET]=(preg_match('/(.*?)\d/s',$info['address_full'],$res)) ? trim(strip_tags(($res[1]))) : '';
	}

	$unmatched_variables = array();
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	}
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_SHORT_DESC_NL], 999);
    $property[TAG_PRIORITY_PURCHASE] =(preg_match('/<td>Voorkooprecht op dit goed: (.*?)</s',$html,$res)) ? trim(strip_tags(($res[1] )))=== 'Ja' ? 1 : '' : '';
    $property[TAG_PLANNING_PERMISSION] =(preg_match('/<td>Stedenbouwkundige vergunning verkregen: (.*?)</s',$html,$res)) ? trim(strip_tags(($res[1] )))=== 'Ja' ? 1 : '' : '';
    $property[TAG_HAS_PROCEEDING] =(preg_match('/<td>Dagvaardingen uitgebracht: (.*?)</s',$html,$res)) ? trim(strip_tags(($res[1] )))=== 'Ja' ? 1 : '' : '';
    $property[TAG_SUBDIVISION_PERMIT] =(preg_match('/<td>Verkavelingsvergunning verkregen: (.*?)</s',$html,$res)) ? trim(strip_tags(($res[1] )))=== 'Ja' ? 1 : '' : '';
    $property[TAG_MOST_RECENT_DESTINATION] =(preg_match('/<td>Bestemming: (.*?)</s',$html,$res)) ? trim(strip_tags(($res[1] ))) : '';

    
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));
	if(empty($property[TAG_CITY]))
	return;
    CrawlerTool::saveProperty($property);
}

function processProject($crawler, $project)
{
	$html = $crawler->request($project[TAG_UNIQUE_URL_NL]);
	$parser = new PageParser($html);
	$parser->deleteTags(array("script", "style"));

    $project[TAG_TEXT_DESC_NL]= $parser->extract_xpath("td[@class= 'ProjectDescription']");
    $project[TAG_PLAIN_TEXT_ALL_NL]= $parser->extract_xpath("table[@width = '100%']");


	$html = $crawler->request('http://www.ccimmo.be/Constructionfoto.aspx?PrjId='. $project[TAG_PROJECT_ID]);
	$parser = new PageParser($html);
    $project[TAG_PICTURES] = $parser->extract_xpath("input[@class = 'large-photo']/@value", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic)
        {
            if(!empty($pic)) $picUrls[] = array(TAG_PICTURE_URL => 'http://www.ccimmo.be/'.$pic);
        }
        return $picUrls;
    });

	$html = $crawler->request('http://www.ccimmo.be/Constructionfoto.aspx?PrjId='. $project[TAG_PROJECT_ID]);
	$parser = new PageParser($html);
    $project[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
	 {
		 $fileUrls = array();
		 foreach($files as $file)
		 {
			 if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => str_replace('../','',$file));
		 }
		 return $fileUrls;
    });

	$html = $crawler->request('http://www.ccimmo.be/ViewConstructionMap.aspx?PrjId='. $project[TAG_PROJECT_ID]);
	$parser = new PageParser($html);
	if (preg_match('!googleX =(.*?) ;!',$html,$res))
	{
		$long  = $res[1];
	}
	if (preg_match('!googleY =(.*?) ;!',$html,$res))
	{
		$lat  = $res[1];
	}

/*	if (preg_match('!GLatLng\(([0-9.]+),([0-9.]+)\)!',$html,$res))
	{
		$long  = $res[1];
		$lat  = $res[2];
	}
*/
    $html=$crawler->request('http://maps.googleapis.com/maps/api/geocode/json?latlng='.$long.','.$lat.'&sensor=true');
    $text=(preg_match('/"formatted_address"(.*?)",/s',$html,$res)) ? preg_replace("/,/",".",trim(strip_tags(($res[1])))) : '';
    preg_match("/(.*)(\d{4})\s(.*)/", $text, $match);
	if($match) {
		$adres = trim($match[1]);
		$project[TAG_ZIP] = $match[2];
		$project[TAG_CITY] = preg_match('/(.*?)\./',trim(preg_replace("/\(.*\)|\d/", "", $match[3])),$res) ? $res[1]: '';
		$project[TAG_STREET]=(preg_match('/(.*?)\d/s',$adres,$res)) ? trim(strip_tags((str_replace(': "','',$res[1])))) : '';
		preg_match("/bus (\d+|\d+[.]\d+)$/", $adres, $match);
		if($match) {

				$project[TAG_BOX_NUMBER]=trim(preg_replace("/[a-zA-Z,]/", "", $match[1]));
		}

		preg_match("/ (\d+) bus/", $adres, $match);
		if($match) {

			$project[TAG_NUMBER]=trim(preg_replace("/[a-zA-Z]/", "", $match[1]));
		}

		if(empty($project[TAG_NUMBER])) $project[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);

	}

	$html = $crawler->request('http://www.ccimmo.be/ConstructionPlanning.aspx?PrjId='. $project[TAG_PROJECT_ID].'&new=1');
	$parser = new PageParser($html);

    $nodes = $parser->getNodes("table[@class = 'display']/descendant::a[contains(@href, 'objectid=')]");
	$SoldNodes = $parser->getNodes("table[@class = 'display']/descendant::td[@align= 'center' and contains(.,'Verkocht')]");
    $project[TAG_SOLD_PERCENTAGE_MAX]=$nodes->length+$SoldNodes->length;
	$project[TAG_SOLD_PERCENTAGE_VALUE] =$SoldNodes->length;
    if($project[TAG_SOLD_PERCENTAGE_MAX]<=0){
	unset($project[TAG_SOLD_PERCENTAGE_MAX]);
	unset($project[TAG_SOLD_PERCENTAGE_VALUE]);
		}

		   
if(empty($project[TAG_TYPE])) $project[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
if(empty($project[TAG_TYPE])) $project[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
if(empty($project[TAG_TYPE])) $project[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($project[TAG_TEXT_SHORT_DESC_NL]));
if(empty($project[TAG_TYPE])) $project[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($project[TAG_TEXT_DESC_NL]));
if(empty($project[TAG_TYPE])) $project[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($project[TAG_PLAIN_TEXT_ALL_NL]));

if(empty($project[TAG_CITY]))
	return;
    CrawlerTool::saveProject($project);

	$nodes = $parser->getNodes("a[contains(@href, 'objectid=')]");
	$items = array();
	foreach($nodes as $node)
	{
	    static $innerpropertyCount = 0;

		$property = array();
		$property[TAG_STATUS] = $project[TAG_STATUS];
		$property[TAG_PROJECT_ID]=$project[TAG_PROJECT_ID];
		$property[TAG_UNIQUE_URL_NL] = "http://www.ccimmo.be/".$parser->getAttr($node,"href");
		$property[TAG_UNIQUE_ID] = $parser->regex("/objectid=(\d+)/", $property[TAG_UNIQUE_URL_NL]);
		$innerpropertyCount += 1;
		flush();
		ob_flush();
		// process item to obtain detail information
		echo "--------- Processing property #$innerpropertyCount ...";
		processItem($crawler, $property);
		echo "--------- Completed<br />";
	}
}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function getvalue($parser,$start,$follow) {
    $nodes = $parser->getNodes("h1[contains(text(), $start)]/following-sibling::p/text()");
    foreach($nodes as $node) {
        $text = $parser->GetText($node);
        if(stripos($text, $follow) !== false) {
            $n = $parser->getNodes("following-sibling::strong[1]",$node);
            if($n) return $parser->GetText($n);
        }
    }
}

?>
