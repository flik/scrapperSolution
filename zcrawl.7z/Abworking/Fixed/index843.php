<?php
require_once("../crawler_classes.php");
$crawler->set_script_dir(realpath(dirname(__FILE__)).'/');


//$crawler->enable_delay_between_requests(5,15);
//$crawler->use_cookies(true);
//$crawler->clean_cookies();
//$crawler->use_gzip(false);


$startPages[STATUS_TORENT] = array
(
#'http://www.vabra.be/te_huur.asp' => '',
'http://www.vabra.be/appartement-te-huur.asp' =>'',
'http://www.vabra.be/projecten-overzicht.asp?t=Projecten%20in%20uitvoering' => 'project1',
'http://www.vabra.be/projecten-overzicht.asp?t=projekten%20in%20voorbereiding' => 'project2',
);

$startPages[STATUS_FORSELL] = array
(
'http://www.vabra.be/te_koop.asp' => '',
);



CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "VA BRA";
$office[TAG_OFFICE_URL] = "http://www.concept-bvba.be/";
$office[TAG_STREET] = "Leopoldlaan";
$office[TAG_NUMBER] = "85";
$office[TAG_ZIP] = "8430";
$office[TAG_CITY] = "Middelkerke";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "+32 (0)59 300 703";
$office[TAG_FAX] = "+32(0)59 300 315 ";
$office[TAG_EMAIL] = "info@vabra.be";
CrawlerTool::saveOffice($office);


foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
	    $html = $crawler->request($page_url);
		processPage($crawler, $status, $type, $html);

	}
}

CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';

function processProject($crawler, $property)
{
	#$html = $crawler->request('http://www.jemar.be/nl/te-koop?view=details&id=14');
	$html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
 
	$parser = new PageParser($html);
	$parser->deleteTags(array("script", "style"));
	
	$property[TAG_PICTURES] =  $parser->extract_xpath("img[@width = '150']/@src", RETURN_TYPE_ARRAY, function($pics)
	{
	    $picUrls = array();
	    foreach($pics as $pic) {
		$picUrls[] = array(TAG_PICTURE_URL => str_replace('resize2.asp?w=150&p=','http://www.vabra.be/popup.asp?p=',$pic));
	    }
    
	    return $picUrls;
	});
    
	$property[TAG_TEXT_DESC_NL] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("td[@class = 'style1']", RETURN_TYPE_TEXT_ALL))); 
	$property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("td[@bgcolor = '#A9C7DC']", RETURN_TYPE_TEXT_ALL)));
	
	$property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));

	$property[TAG_TYPE] = STATUS_TORENT;
	$address = utf8_decode(CrawlerTool::encode($parser->extract_xpath("td[@class = 'style1']/p[1]", RETURN_TYPE_TEXT))); 
	CrawlerTool::parseAddress($address,$property);
	    
	$addr = explode(' ',$address);
	$property[TAG_CITY] = trim($addr[count($addr)-1]);
	$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
	
	if(strlen($property[TAG_ZIP]) < 4){
		$address = str_replace($property[TAG_ZIP],'',$address );
		$property[TAG_BOX_NUMBER] = $property[TAG_ZIP];
		$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
	}
	
	$property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
	$property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
	
	$property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
	$property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
	
	if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
	
	if(strlen($property[TAG_BOX_NUMBER]) < 3 || strlen($property[TAG_BOX_NUMBER]) > 3 )
	unset($property[TAG_BOX_NUMBER]);

	$property[TAG_STREET] = rtrim($property[TAG_STREET], '-');

	if(empty($property[TAG_ZIP]) || strlen($property[TAG_ZIP]) < 3){
		if(strtolower($property[TAG_CITY]) == "middelkerke")
			$property[TAG_ZIP] = "8430";
		elseif(strtolower($property[TAG_CITY]) == "gistel")
			$property[TAG_ZIP] = "8470";
		else
			unset($property[TAG_ZIP]);
	}

	if(empty($property[TAG_NUMBER]))
		unset($property[TAG_NUMBER]);

    unset($property[TAG_STREET]);
	
    debug($property);  
    CrawlerTool::saveProject($property);
}


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();
    
    
    
    if( $type=='project1' || $type=='project2'){
	
	$parser = new PageParser($html); 
	$parser->deleteTags(array("script", "style")); 
    	$nodes = $parser->getNodes("td[@class = 'style1']"); 
	//debug($nodes); exit;
	$projects = $project = array();
	foreach ($nodes as $node){
		//style1 style5
		 $link = $parser->extract_xpath("a[@class = 'style1 style5']/@href", RETURN_TYPE_TEXT, null, $node);
		 if(!empty($link)){
		 
			$project[TAG_UNIQUE_URL_NL] 	= 	'http://www.vabra.be/'.$link;
			$project[TAG_UNIQUE_ID]     	=  	CrawlerTool::generateId($project[TAG_UNIQUE_URL_NL]) ;
			$project[TAG_STATUS]		= 	$status;
			
			if(in_array($project[TAG_UNIQUE_ID], $projects)) continue; 
			$projects[] = $project[TAG_UNIQUE_ID];


            if($project[TAG_UNIQUE_ID] == "2020684256" || $project[TAG_UNIQUE_ID] == "2433914069" || $project[TAG_UNIQUE_ID] == "3860177987" || $project[TAG_UNIQUE_ID] == "2132604409"){
                return;
            }

			processProject($crawler, $project); 
			
		 }
		 
	}
	
    }
    
    $count=0;
    
    
    $pattern  = "<TR>\s+?<TD width=\"250\".+?href=\"(.+?)\".+?<\/TR>";
	preg_match_all ( "/" . $pattern . "/is", $html, $items_matches, PREG_SET_ORDER);

	$item = array();
    //print $html;
    foreach ($items_matches as $match) {
	    $property[TAG_STATUS]=$status;
        $property[TAG_TYPE] = CrawlerTool::getPropertyType($type);

        if (stristr ($match[0], 'verkocht')) {
            $property[TAG_STATUS]="sold";
        }
        if (stristr ($match[0], 'verhuurd')) {
            $property[TAG_STATUS]="rented";
        }
		$property[TAG_UNIQUE_URL_NL] 	= 'http://www.vabra.be/'.html_entity_decode( str_replace(' ', '%20', $match[1]));
		$property[TAG_UNIQUE_ID]     =  preg_replace("/^.+?ID=(.+)$/is", "\$1", $match[1]);
		if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
		$properties[] = $property[TAG_UNIQUE_ID];

		$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);

    }

    $pattern = "<A href=\"(te_huur2\.asp\?.+?)\"";
    preg_match_all ( "/" . $pattern . "/is", $html, $items_matches, PREG_SET_ORDER);
    foreach ($items_matches as $match) {
        if (stristr ($match[0], 'verkocht')) {
            $property[TAG_STATUS]="sold";
        }
        if (stristr ($match[0], 'verhuurd')) {
            $property[TAG_STATUS]="rented";
        }
        $property[TAG_TYPE] = CrawlerTool::getPropertyType($type);
		$property[TAG_UNIQUE_URL_NL] 	= 'http://www.vabra.be/'.html_entity_decode( str_replace(' ', '%20', $match[1]));
		$property[TAG_UNIQUE_ID]     = preg_replace("/^.+?ID=(.+)$/is", "\$1", $match[1]);
		if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
		$properties[] = $property[TAG_UNIQUE_ID];


        if($property[TAG_UNIQUE_ID] == "2020684256" || $property[TAG_UNIQUE_ID] == "2433914069" || $property[TAG_UNIQUE_ID] == "3860177987" || $property[TAG_UNIQUE_ID] == "2132604409"){
                return;
        }

		$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);


    }
	foreach($items as $item)
	{
		// keep track of number of properties processed
		$propertyCount += 1;

			// process item to obtain detail information
			echo "--------- Processing property #$propertyCount ...";
			//if($item["itemUrl"] == "http://www.vabra.be/te_koop_detail.asp?id=80"){
				echo $item["itemUrl"]."<br>";
				processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
				echo "--------- Completed<br />";
			//}
		 
	}
}
function getUniqueId($url) {
	preg_match("/bien=(\d+)/", $url, $match);
	if($match) return $match[1];
}


function processItem($crawler, $property ,$type)
{
	if($property[TAG_UNIQUE_URL_NL] == "http://www.vabra.be/te_koop_detail.asp?id=80"){
		return;
	}
#    $html = $crawler->request('http://www.vabra.be/te_koop_detail.asp?id=84');
    $html = $crawler->request($property[TAG_UNIQUE_URL_NL]);

    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

	$pattern = "LIGGING:<\/TD>.*?class=\"style1\">(.+?)<br \/>";
	$data=preg_match ( "/" . $pattern . "/is", $html, $ligging) ? $ligging[1] : '';
    if(empty($data)) echo $data=preg_match ( "/<strong>LIGGING:.*?class=\"style1\">(.*?)<\/span>/is", $html, $ligging) ? $ligging[1] : '';
	$arr=explode(',',$data);
    if(!empty( $arr[2])){
        $adres=$arr[1];
        $d=$arr[2];
    }else{
        $adres=$arr[0];
        $d=$arr[1];
    }
	$property[TAG_CITY]=preg_replace('/[0-9,.]/','',$d);
	$property[TAG_ZIP] = preg_replace("/[^0-9]/", '',$d);
	if(preg_match("/(.*)\s(\d+[A-Za-z]|[A-Za-z]\s\d+|\d+\/\d+[A-Za-z]*|\d+-\d+|\d+)/", $adres, $match2))
	{
		$property[TAG_NUMBER] = $match2[2];
	}
	$property[TAG_STREET]=(preg_match('/(.*?)\d/s',$adres,$res)) ? trim(strip_tags(($res[1]))) : '';

	$property[TAG_STREET] = rtrim($property[TAG_STREET], '-');

	if(empty($property[TAG_NUMBER])) $property[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);
	if(empty($property[TAG_NUMBER])) $property[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);

	if(empty($property[TAG_NUMBER]))
		unset($property[TAG_NUMBER]);

	// Raheel Fix 
	$cityText = $parser->extract_xpath("p[@class = 'style3']", RETURN_TYPE_TEXT);
	$cityArr = explode("-",$cityText);
	if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim($cityArr[0]);
	if(empty($property[TAG_ZIP]) || strlen($property[TAG_ZIP]) < 3){
		if(strtolower($property[TAG_CITY]) == "middelkerke")
			$property[TAG_ZIP] = "8430";
		elseif(strtolower($property[TAG_CITY]) == "gistel")
			$property[TAG_ZIP] = "8470";
		else
			unset($property[TAG_ZIP]);
	}
	// Raheel Fix End

	preg_match("/EPC-WAARDE:.*?\"style1\">(.*?)</si", $html, $match);
	if($match) {
		$epc = CrawlerTool::toNumber($match[1]);
		if($epc > 0) echo $property[TAG_EPC_VALUE] = $epc;
	}

	preg_match("/EPC-CERTIFICAAT:.*?\"style1\">(.*?)</si", $html, $match);
	if($match) {
		echo $property[TAG_EPC_CERTIFICATE_NUMBER]=$match[1];
		#$epc = CrawlerTool::toNumber($match[1]);
		#if($epc > 0) echo $property[TAG_EPC_CERTIFICATE_NUMBER] = $epc;
	}


	$vars = array();
	preg_match_all('!<TD bgcolor="#FFFFFF" class="style1">([^<>]+):</TD>\s+<TD bgcolor="#FFFFFF" class="style1">([^<>]+)</TD>!',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('!&nbsp;!','',$arr[1]);
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$vars[$arr[1]] = str_replace('&nbsp;','',$arr[2]);
		#echo "<br>";
	}
	preg_match_all('!<TD width="20%" bgcolor="#FFFFFF" class="style1">([^<>]+):</TD>\s+<TD width="20%" bgcolor="#FFFFFF" class="style1">([^<>]+)</TD>!',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('!&nbsp;!','',$arr[1]);
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$vars[$arr[1]] = str_replace('&nbsp;','',$arr[2]);
		#echo "<br>";
	}
	if (isset($vars['type'])) {unset($vars['type']);}
	$property[TAG_CONSTRUCTION_TYPE]       = CrawlerTool::getConstructionType(get_var($vars,'type bebouwing'));
    $property[TAG_HEATING_NL] = get_var($vars,'verwarming');
    $property[TAG_PRICE]                   =  CrawlerTool::toNumber(get_var($vars,'prijs'));
/*	if(stripos($text, "/m") !== false)
	{
		$property[TAG_PRICE_PER_M2] = CrawlerTool::toNumber($text);
		$property[TAG_PRICE]="";

	}
	else
	{
		$property[TAG_PRICE] = CrawlerTool::toNumber($text);
	}
*/
    $floor                   = get_var($vars,'verdieping','!(\d+)!');
    if(!empty($floor)) $property[TAG_FLOOR]=$floor;
    $property[TAG_COMMON_COSTS] = get_var($vars,'lasten','!(\d+)!');
    $property[TAG_GAS_CONNECTION]          = (get_var($vars,'aansluiting aardgas') === "Ja" ? 1 : 0);
    $property[TAG_CONNECTION_TO_WATER]=get_var($vars,'aansluiting waterleiding') === 'Ja' ? 1 : '';
    $property[TAG_SURFACE_GROUND] = get_var($vars,"opp\. terrein",'!(\d+)!');
    $property[TAG_DOUBLE_GLAZING]=CrawlerTool::contains(get_var($vars,'beglazing') ,"Dubbel");
    $property[TAG_KI]                      = str_replace('.','',get_var($vars,'ki','![^<>0-9]*([0-9.]+)!'));
    $property[TAG_LIFT]                    = CrawlerTool::contains(get_var($vars,'lift'),'Ja');
    $property[TAG_CONSTRUCTION_YEAR]       = get_var($vars,'bouwjaar','!(\d{4})!');
    $property[TAG_SURFACE_LIVING_AREA]     = get_var($vars,'bewoonbare opp','!(\d+)!');
    $property[TAG_FRONTAGE_WIDTH] =get_var($vars,'voorgevelbreedte');
    $property[TAG_LOT_WIDTH] = get_var($vars,'perceelbreedte');
    $property[TAG_FREE_FROM_DATE] = CrawlerTool::toUnixTimestamp(get_var($vars,'vrij op'));

	$pattern = "<FONT size=2>(.+?)<\/FONT>";
	preg_match ( "/" . $pattern . "/is", $html, $shortdescr);
	if (isset($shortdescr[1])) {
		$property[TAG_TEXT_SHORT_DESC_NL] = trim(substr (trim (preg_replace("/(&nbsp;|\n|\r|\s+)/s", " ", ( strip_tags ($shortdescr[1])))), 0, 255));
	} else {
		$pattern = "OMSCHRIJVING:.*?<span class=\"style1\">(.+?)<\/span><\/TD>";
        preg_match ( "/" . $pattern . "/is", $html, $shortdescr);
	    if (isset($shortdescr[1])) {
	    	$property[TAG_TEXT_SHORT_DESC_NL] = trim(substr (trim (preg_replace("/(&nbsp;|\n|\r|\s+)/s", " ", ( strip_tags ($shortdescr[1])))), 0, 255));
	    }
	}
	$totalbedrooms                  = get_var($vars,'aantal slaapkamers','!(\d+)!');
	if(!empty($totalbedrooms)) $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT] = $totalbedrooms;
    $pic_urls=array();
	preg_match_all("!<IMG src=\"resize.+?p=(.+?)\"!si",$html,$res1);
	foreach ($res1[1] as $v) { if(!preg_match('/logo_vabra/',$v,$res))$pic_urls[] = array(TAG_PICTURE_URL => 'http://www.vabra.be/images/'.$v);}
	$property[TAG_PICTURES] = $pic_urls;

	$unmatched_variables = array();
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	}
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_SHORT_DESC_NL], 999);

    // Most Important 
	if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
	$property['planning_proceeding'] = '';
	
	
	if(!isset($property['planning_permission']) || empty($property['planning_permission']))
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
	$property['subdivision_permit'] = '';
	 
	if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
	$property['most_recent_destination'] = '';
	
	
	
	
    $property[TAG_CITY] = trim($property[TAG_CITY]);

    unset($property[TAG_STREET]);

    debug($property);

    CrawlerTool::saveProperty($property);

}

function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

?>