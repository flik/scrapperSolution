<?php

error_reporting(E_ALL);
ini_set('display_errors', '1'); 

require_once("../crawler_classes.php");

$startPages[STATUS_TORENT] = array
(
TYPE_NONE        =>  array
(
"http://www.expertissimo.be/index.php?option=com_content&view=article&id=3&Itemid=104"
),
);
$startPages[STATUS_FORSELL] = array
(
TYPE_NONE        =>  array
(
"http://www.expertissimo.be/index.php?option=com_content&view=article&id=2&Itemid=103",
),
);


CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
	foreach($types as $type => $pages)
	{
		foreach($pages as $page)
		{
			debugx($page);
			$html = $crawler->request($page);
			processPage($crawler, $status, $type, $html);

		}
	}
}


CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
	global $propertyCount;
	global $properties;
	if(empty($propertyCount)) $propertyCount = 0;
	if(empty($properties)) $properties = array();

	$parser = new PageParser($html);

	$nodes = $parser->getNodes("div[@class = 'es-list_image_wrapper']/a");
	
	 //debug($nodes);  exit;
	$items = array();
	foreach($nodes as $node)
	{
		$property = array();
		$property[TAG_STATUS] = $status;
		$property[TAG_TYPE] = $type;
		flush();
		ob_flush();
		$property[TAG_UNIQUE_URL_NL] = "http://www.expertissimo.be" . $parser->getAttr($node, "href");
		$property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]) ;
		
		if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
		$properties[] = $property[TAG_UNIQUE_ID];

		$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}

	foreach($items as $item)
	{
		// keep track of number of properties processed
		$propertyCount += 1;

		// process item to obtain detail information
        
        //if($item["item"][TAG_UNIQUE_ID] == "1904571"){
    		echo "--------- Processing property #$propertyCount ...";
    		echo $item["itemUrl"]."<br>";
    		processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
    		echo "--------- Completed<br />";
        //}
	}

	return sizeof($items);
}


function getPages($html)
{
	//debugx($html); exit;
	$parser = new PageParser($html);
	

	$pages = array();
	$nodes = $parser->getNodes("div[span = 'Pagina']/a");

	if(!empty($nodes))
	{
		foreach($nodes as $node)
		{
			$pages[] = "http://www.op.be" . $parser->getAttr($node, "href");
		}
	}

	return array_unique($pages);
}

function processItem($crawler, $property, $html1)
{
	$parser = new PageParser($html1);
	$html =$html1;
	if(empty($property[TAG_STATUS])) $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($parser->extract_xpath("table[@border = '1']"));

	$property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("div[@class = 'es-description_content'", RETURN_TYPE_TEXT_ALL);
	$property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@class = 'item-page'] | table[@cellpadding = '1']", RETURN_TYPE_TEXT_ALL);

	if(empty($property[TAG_TEXT_DESC_NL])){
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
		$res[1] = str_replace(chr(11),'',$res[1]);
		$property[TAG_TEXT_DESC_NL] = utf8_decode(CrawlerTool::encode(strip_tags($res[1])));
	}
	
	$property[TAG_PICTURES] = $parser->extract_xpath("img[@class = 'es-imagetn']", RETURN_TYPE_ARRAY, function($pics)
	{
		$picUrls = array();
		foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.expertissimo.be" . $pic);

		return $picUrls;
	});

	$street= $parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[1]");
	if($street!=''){
		if(preg_match("/(.*)\s(\d+[A-Za-z]|[A-Za-z]\s\d+|\d+\/\d+[A-Za-z]*|\d+-\d+|\d+)/", $street, $match))
		{
			$property[TAG_NUMBER] = $match[2];
		}

		 $property[TAG_STREET]=(preg_match('/(.*?)\d/s',$street,$res)) ? trim(strip_tags(($res[1]))) : '';
	}
	$parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[2]", RETURN_TYPE_TEXT, function($text) use(&$property)
	{
		if(preg_match("/(\d{4})(.*)/", $text, $match))
		{
			$property[TAG_ZIP] = $match[1];
			$property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
		}
	});

	
	$property[TAG_PRICE] = $parser->extract_xpath("td[contains(text(), 'Prijs:')]", RETURN_TYPE_NUMBER);
	$property[TAG_HEATING_NL] = $parser->extract_xpath("td[. = 'verwarming type']/following-sibling::td[1]");

	$parser->extract_xpath("td[contains(text(), 'slaapkamer') and contains(text(), 'oppervlakte')]/following-sibling::td[1]", RETURN_TYPE_ARRAY, function($arr) use(&$property)
	{
		$bedrooms = array();
		foreach($arr as $count=>$surface)
		{
			$surface = CrawlerTool::toNumber($surface);
			$bedroom = array(TAG_BEDROOM_SURFACE => $surface, TAG_BEDROOM_DESC_NL => "slaapkamer " . ($count + 1) . " oppervlakte (m�)");
			$bedrooms[] = $bedroom;
		}

		if(!empty($bedrooms)) $property[TAG_BEDROOMS] = $bedrooms;
	});

	$parser->extract_xpath("td[contains(text(), 'badkamer') and contains(text(), 'oppervlakte')]/following-sibling::td[1]", RETURN_TYPE_ARRAY, function($arr) use(&$property)
	{
		$bathrooms = array();
		foreach($arr as $count=>$surface)
		{
			$surface = CrawlerTool::toNumber($surface);
			$bathroom = array(TAG_BATHROOM_SURFACE => $surface, TAG_BATHROOM_DESC_NL => "badkamer(s) oppervlakte (bdk" . ($count + 1) . ")");
			$bathrooms[] = $bathroom;
		}

		if(!empty($bathrooms)) $property[TAG_BATHROOMS] = $bathrooms;
	});

	$parser->extract_xpath("td[contains(text(), 'terras') and contains(text(), 'oppervlakte')]/following-sibling::td[1]", RETURN_TYPE_ARRAY, function($arr) use(&$property)
	{
		$terraces = array();
		foreach($arr as $count=>$surface)
		{
			$surface = CrawlerTool::toNumber($surface);
			$terrace = array(TAG_TERRACE_SURFACE => $surface, TAG_TERRACE_DESC_NL => "terras " . ($count + 1) . " oppervlakte (m�)");
			$terraces[] = $terrace;
		}

		if(!empty($terraces)) $property[TAG_TERRACES] = $terraces;
	});

	$parser->extract_xpath("td[contains(text(), 'garage oppervlakte')]/following-sibling::td[1]", RETURN_TYPE_ARRAY, function($arr) use(&$property)
	{
		$garages = array();
		foreach($arr as $count=>$surface)
		{
			$surface = CrawlerTool::toNumber($surface);
			$garage = array(TAG_GARAGE_SURFACE => $surface);
			$garages[] = $garage;
		}

		if(!empty($garages)) $property[TAG_GARAGES] = $garages;
	});

	// get document files
	$files = array();
	$nodes = $parser->getNodes("a[contains(@href, 'GetFile.ashx?path=Documents')]");
	foreach($nodes as $node)
	{
		$fileUrl = "http://www.op.be/" . $parser->regex("/path=(.*)&/", $parser->getAttr($node, "href"));
		$fileTitle = $parser->getText($node);
		$files[] = array(TAG_FILE_URL => $fileUrl, TAG_FILE_TITLE_NL => $fileTitle);
	}
	if(!empty($files)) $property[TAG_FILES] = $files;

	//parse fields
	$html = str_replace('<sup>2</sup>','',$html);
	$vars = array();
	
	$nodes = $parser->getNodes("table[@class='es-estate_details']/tbody/tr");
	debug($nodes);
	foreach ($nodes as $node)
	{
		$key = utf8_decode(CrawlerTool::encode($parser->extract_xpath("th[1]",  RETURN_TYPE_TEXT, null, $node))); 
		$val = $parser->extract_xpath("td[1]", RETURN_TYPE_TEXT, null, $node);
		$key = clearForLowerCase($key);
		
		if($key=='gemeente')
		$property[TAG_CITY] = trim($val);
		
		if($key=='postcode')
		$property[TAG_ZIP] = trim($val);
		 
		if($key=='straat')
		$property[TAG_STREET] = trim($val);
		 
		 
		if($key=='nr.')
		$property[TAG_NUMBER] = trim($val);
		
		if((strpos($key,"oppervlakte")==false) || ($key=="bewoonbare oppervlakte")){
		   $vars[$key] = str_replace('&nbsp;','',$val);
		}
		$vars[$key] = str_replace('&nbsp;','',$val);

	}
	 
	if (isset($vars['tel'])) {unset($vars['tel']);}
	if (isset($vars['fax'])) {unset($vars['fax']);}
	if (isset($vars['email'])) {unset($vars['email']);}

	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(get_var($vars,"categorie"));
	if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = get_var($vars,"epc vlaanderen energiescore kwhm",'!(\d+)!');
	$property[TAG_EPC_CERTIFICATE_NUMBER] = get_var($vars,"epc vlaanderen unieke code",'!(\d+)!');
	$property[TAG_KI] = get_var($vars,'kadastraal inkomen  bedrag','!(\d+)!');
	$property[TAG_HEATING_NL] = get_var($vars,'verwarming type');
	$property[TAG_KI_INDEX] = get_var($vars,"kad.ink. gendexeerd bedrag",'!(\d+)!');
	$property[TAG_PROPERTY_TAX] = get_var($vars,'onroerende voorheffing bedrag','!(\d+)!');
	$property[TAG_CONSTRUCTION_YEAR] = get_var($vars,'bouwjaar jaar','!(\d{4})!');
	$property[TAG_RENOVATION_YEAR] = get_var($vars,'renovatie jaar','!(\d{4})!');
	$property[TAG_SURFACE_LIVING_AREA] = get_var($vars,'bewoonbare oppervlakte','!(\d+)!');
	$property[TAG_SURFACE_GROUND] = get_var($vars,'grootte terrein','!(\d+)!');
	$property[TAG_BEDROOMS_TOTAL] = get_var($vars,'aantal kamers','!(\d+)!');
	$property[TAG_BATHROOMS_TOTAL] = get_var($vars,'aantal badkamers','!(\d+)!');
	$property[TAG_TOILETS_TOTAL] = get_var($vars,'toiletten aantal','!(\d+)!');
	$property[TAG_GARAGES_TOTAL] = get_var($vars,'garage aantal','!(\d+)!');
	if(empty($property[TAG_GARAGES_TOTAL])) $property[TAG_GARAGES_TOTAL] = get_var($vars,'garage') == 'Ja' ? 1 : '';
	$property[TAG_TERRACES][TAG_TOTAL_AMOUNT] = get_var($vars,'terras') == 'Ja' ? 1 : '';

	$property[TAG_PARKINGS_TOTAL] = get_var($vars,'parking buiten aantal','!(\d+)!');
	if(empty($property[TAG_PARKINGS_TOTAL])) $property[TAG_PARKINGS_TOTAL]         = get_var($vars,'parking') == 'Ja' ? 1 : '';
	$gevels = get_var($vars,'Gevels','!(\d+)!') === "Ja" ? 1 : 0;
	$property[TAG_AMOUNT_OF_FACADES] = get_var($vars,'Gevels','!(\d+)!') === "Ja" ? 1 : 0;
	$property[TAG_AMOUNT_OF_FLOORS] = get_var($vars,'verdiepingen aantal','!(\d+)!');
	$freeFromDate = get_var($vars,'beschikbaar vanaf');
	$property[TAG_COMMON_COSTS] = get_var($vars,'lasten','!(\d+)!');
	$property[TAG_GAS_CONNECTION] = (get_var($vars,'gas') === "Ja" ? 1 : 0);
	$property[TAG_CONNECTION_TO_WATER] = (get_var($vars,'water') === "Ja" ? 1 : 0);
	$property[TAG_TELEPHONE_CONNECTION] = (get_var($vars,'telefoon') === "Ja" ? 1 : 0);
	$property[TAG_DOUBLE_GLAZING]=CrawlerTool::contains(get_var($vars,'dubbele beglazing') ,"Ja");
	$property[TAG_LIFT] = (get_var($vars,'lift') === "Ja" ? 1 : 0);
	$gemeubeld = get_var($vars,'Gemeubeld','!(\d+)!') === "Ja" ? 1 : 0;
	$property[TAG_FURNISHED] = (get_var($vars,'Gemeubeld') === "Ja" ? 1 : 0);
	$property[TAG_GARDEN_AVAILABLE] = (get_var($vars,'tuin') === "Ja" ? 1 : 0);
	$property[TAG_OPEN_FIRE] = (get_var($vars,'open haard aantal') === "Ja" ? 1 : 0);
	$property[TAG_ALARM] = (get_var($vars,'alarm') === "Ja" ? 1 : 0);
	$property[TAG_PARLOPHONE] = (get_var($vars,'parlofoon') === "Ja" ? 1 : 0);
	$property[TAG_VIDEOPHONE] = (get_var($vars,'videofoon') === "Ja" ? 1 : 0);
    $property[TAG_SUBDIVISION_PERMIT]=(get_var($vars,'verkavelingvergunning') === "Ja" ? 1 : '');
    $property[TAG_PRIORITY_PURCHASE]=(get_var($vars,'voorkooprecht') === "Ja" ? 1 : '');
    $property[TAG_MOST_RECENT_DESTINATION]=(get_var($vars,'terrein bestemming') === "Ja" ? 1 :'');
    $property[TAG_PLANNING_PERMISSION]=(get_var($vars,'bouwvergunning') === "Ja" ? 1 : '');
    $property[TAG_FRONTAGE_WIDTH] =get_var($vars,'gevelbreedte breedte');

	 
	
	//----------------------------------------------------------------------------------//
         $unmatched_variables = array();
	
	// Most Important 
	if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
	$property['planning_proceeding'] = '';
	
	
	if(!isset($property['planning_permission']) || empty($property['planning_permission']))
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
	$property['subdivision_permit'] = '';
	 
	if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
	$property['most_recent_destination'] = '';
 
	foreach ($vars as $label => $value)
	{ 
		$attribute = getAttributes(clearForLowerCase($label));
		if(!empty($attribute) ){
		    if(empty($property[$attribute]))
		    $property[$attribute] = GetExactAttrib($attribute,$value);
		}
		else
		    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
		
	}
	
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
	
    if($property[TAG_CITY] == 'Arrigas')
        return;
 
 
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));

	
    debug($property);  
    if(empty($property[TAG_CITY])) return;
	// WRITING item data to output.xml file
	CrawlerTool::saveProperty($property);
}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function debug($obj, $e = false)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
    if($e)
      exit;
    
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}    

function getAttributes($key, $language='nl'){ //String Function always return string

	$attributeTagsArray	= array('en' => array(	'pric' 			=>  TAG_PRICE,
							'constr'		=> TAG_CONSTRUCTION_YEAR,
							'ground'		=> TAG_SURFACE_GROUND,
							'living' 		=> TAG_SURFACE_LIVING_AREA,
							'bath'			=> TAG_BATHROOMS_TOTAL,
							'warm'			=> TAG_HEATING_EN,
							'heat'			=> TAG_HEATING_EN,
							'sewer'			=> TAG_CONNECTION_TO_SEWER,
							'telep'			=> TAG_TELEPHONE_CONNECTION,
							'intern'		=> TAG_INTERNET_CONNECTION,
							'permission'		=> TAG_PLANNING_PERMISSION,
							'subdivision'		=> TAG_SUBDIVISION_PERMIT,
							'electri'		=> TAG_METER_FOR_ELECTRICITY,
							'hall'			=> TAG_HALLS,
							'dining'		=> TAG_DININGS,
							'kitch'			=> TAG_KITCHENS,
							'laundr'		=> TAG_LAUNDRY_ROOMS,
							'dress'			=> TAG_DRESSING,
							'bed'			=> TAG_BEDROOMS_TOTAL,
							'room'			=> TAG_BEDROOMS_TOTAL,
							'park'			=> TAG_PARKINGS,
							'garage'		=> TAG_GARAGES_TOTAL,
							'type'			=> TAG_TYPE,
							'garden'		=> TAG_GARDEN_AVAILABLE,
							'floor'			=> TAG_AMOUNT_OF_FLOORS,
							'winter'		=> TAG_WINTERGARDENS,
							'furnish'		=> TAG_FURNISHED,
							'water'			=> TAG_CONNECTION_TO_WATER,
							'lift'			=> TAG_LIFT,
							'glaz'			=> TAG_DOUBLE_GLAZING,
							'terrac'		=> TAG_TERRACES,
							'fronts'		=> TAG_AMOUNT_OF_FACADES,
							'category'		=> TAG_TYPE,
							'free'			=> TAG_FREE_FROM_DATE,
							'habit'			=> TAG_SURFACE_LIVING_AREA,
							'plot'			=> TAG_SURFACE_GROUND,
							'shops'			=> TAG_DISTANCE_SHOPS,
							'schools'		=> TAG_DISTANCE_SCHOOL,
							'transport'		=> TAG_DISTANCE_PUBLIC_TRANSPORT,
							'shower'		=> TAG_SHOWERS_TOTAL,
							'stor'			=> TAG_STOREROOMS,
							'gas'			=> TAG_GAS_CONNECTION,
							'alarm'			=> TAG_ALARM,
							'security'		=> TAG_SECURITY_DOOR,
							'parlo'			=> TAG_PARLOPHONE,
							'video'			=> TAG_VIDEOPHONE,
							'elevat'		=> TAG_LIFT,
							'blind'			=> TAG_SUN_BLINDS,
							'renova'		=> TAG_RENOVATION_YEAR,
							'control'		=> TAG_ACCESS_SEMIVALID,
								),
					'nl' => array(	"prij" =>  TAG_PRICE,
							"type" =>  TAG_TYPE,
							"adres" =>  TAG_ADDRESS_VISIBLE,
							"bouwjaar" => TAG_CONSTRUCTION_YEAR,
							"grondopp" => TAG_SURFACE_GROUND, 
							"bewoonbare" => TAG_SURFACE_LIVING_AREA,
							"antal_kamer"=> TAG_BEDROOMS_TOTAL,
							"slaapkamer"=> TAG_BEDROOMS_TOTAL,
							"antal_badkam"=> TAG_BATHROOMS_TOTAL,
							"badkam"=> TAG_BATHROOMS_TOTAL,
							"epc_certi" => TAG_EPC_CERTIFICATE_NUMBER,
							"certificaatnr" => TAG_EPC_CERTIFICATE_NUMBER,
							"epc_ind" => TAG_EPC_VALUE,
							"epc_waa" => TAG_EPC_VALUE,
							"epc" => TAG_EPC_VALUE,
							"adastraal_inkomen" => TAG_KI,
							"adastraal" => TAG_KI,
							"inkomen" => TAG_KI,
							"ki" => TAG_KI,
							"adastrale_numme" => TAG_KI_INDEX,
							"verdieping" => TAG_AMOUNT_OF_FLOORS,
							"living" => TAG_SURFACE_LIVING_AREA,
							"renovatie" => TAG_RENOVATION_YEAR,
							"kadaster_sectie" => TAG_CADASTRAL_SECTION,
							"beschikbaar" => TAG_FREE_FROM,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"mail" => TAG_EMAIL,
							"winkels" => TAG_DISTANCE_SHOPS,
							"vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"overstromings" => TAG_FLOOD_INFORMATION_NL,
							"garage" => TAG_GARAGES_TOTAL,
							"toilet" => TAG_TOILETS_TOTAL,
							"parking" => TAG_PARKINGS_TOTAL,
							"gevels" => TAG_AMOUNT_OF_FACADES,
							"lasten" => TAG_COMMON_COSTS,
							"gas" => TAG_GAS_CONNECTION,
							"water" => TAG_CONNECTION_TO_WATER,
							"telefoon" => TAG_TELEPHONE,
							"lift" => TAG_LIFT,
							"gemeubeld" => TAG_FURNISHED,
							"tuin" => TAG_GARDEN_AVAILABLE,
							"haard" => TAG_OPEN_FIRE,
							"alarm" => TAG_ALARM,
							"parlofoon" => TAG_PARLOPHONE,
							"videofoon" => TAG_VIDEOPHONE,
							"breedte" => TAG_LOT_WIDTH,
							"diepte" => TAG_LOT_DEPTH,
							"constructie" => TAG_CONSTRUCTION_TYPE,
							"gevelbreedte" => TAG_FRONTAGE_WIDTH,
							"winkel" => TAG_HEATING_NL,
							"douche" => TAG_SHOWERS_TOTAL,
							"keuken" => TAG_KITCHEN_TYPE_NL,
							"ligging" => TAG_SUBDIVISION_PERMIT,
							"stedenbouwkundige" => TAG_PLANNING_PERMISSION,
							"terras" => TAG_TERRACES,
							"terrein" => TAG_SURFACE_GROUND,
							"scholen" => TAG_DISTANCE_SCHOOL,
							"oppervlakte" => TAG_SURFACE_LIVING_AREA,
							"eetkamer" => TAG_DININGS,
							"dressing" => TAG_DRESSINGS,
							"kelder" => TAG_CELLARS,
							"beroep" => TAG_FREE_PROFESSIONS,
							"berging" => TAG_STOREROOMS,
							"wasplaats" => TAG_LAUNDRY_ROOMS,
							"elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"beglazing" => TAG_DOUBLE_GLAZING,
							"verwarming" => TAG_HEATING_NL,
							"riolering" => TAG_CONNECTION_TO_SEWER,
							"olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"waterput" => TAG_WELL,
							"telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
							"toegangscontrole" => TAG_ACCESS_SEMIVALID,
							"computer" => TAG_INTERNET_CONNECTION,
							"nroerende_voorhef" => TAG_PROPERTY_TAX,
								),
                                        'fr' => array(	"prij" =>  TAG_PRICE,
							"Meuble" => TAG_FURNISHED,
							"facades" => TAG_AMOUNT_OF_FACADES,
							"nombre_de_chambre"=> TAG_BEDROOMS_TOTAL,
							"nombre_de_salle_de_bain"=> TAG_BATHROOMS_TOTAL,
							"jardin" => TAG_GARDEN_AVAILABLE,
							"garage" => TAG_GARAGES_TOTAL,
							"terras" => TAG_TERRACES,
							"parking" => TAG_PARKINGS_TOTAL,
							"habita" => TAG_SURFACE_LIVING_AREA,
							"terrain" => TAG_SURFACE_GROUND,
							"disponible" => TAG_FREE_FROM,
							"magasins" => TAG_DISTANCE_SHOPS,
							"transport" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"toilet" => TAG_TOILETS_TOTAL,
							"construction_annee" => TAG_CONSTRUCTION_YEAR,
							"renovation_annee" => TAG_RENOVATION_YEAR,
							"tages" => TAG_AMOUNT_OF_FLOORS,
							"alarm" => TAG_ALARM,
							"gaz" => TAG_GAS_CONNECTION,
							"eau" => TAG_CONNECTION_TO_WATER,
							"parlophone" => TAG_PARLOPHONE,
							"vitrage" => TAG_DOUBLE_GLAZING,
							"network" => TAG_INTERNET_CONNECTION,
							"douche" => TAG_SHOWERS_TOTAL,
							"caves" => TAG_CELLARS,
							"dressing" => TAG_DRESSINGS,
							"telephone" => TAG_TELEPHONE,
							"videophone" => TAG_VIDEOPHONE,
							"manger" => TAG_DININGS,
							"ecoles" => TAG_DISTANCE_SCHOOL,
							"sejour" => TAG_SURFACE_LIVING_AREA,
							"ascenseur" => TAG_LIFT,
							"largeur_du_lot" => TAG_LOT_WIDTH,
							"mazout" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"citerne" => TAG_WELL,
							"chauffage" => TAG_HEATING_FR,
							"electricite " => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"inondation" => TAG_FLOOD_INFORMATION_FR,
							"egouts" => TAG_CONNECTION_TO_SEWER,
							"cuisine" => TAG_KITCHEN_TYPE_FR,
							"construction_type" => TAG_CONSTRUCTION_TYPE,
							"chauffage" => TAG_HEATING_FR,
							"debarras" => TAG_STOREROOMS,
							"telephoniques" => TAG_TELEPHONE_CONNECTION,
							"dacces" => TAG_ACCESS_SEMIVALID,
							"lotissement" => TAG_SUBDIVISION_PERMIT,
							"batir" => TAG_PLANNING_PERMISSION,
							"cadastrales" => TAG_CADASTRAL_SECTION,
							"prix" => TAG_PRICE, 
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"mail" => TAG_EMAIL,
							"commun" => TAG_COMMON_COSTS,
							"feu" => TAG_OPEN_FIRE,
							"beaucoup_de_profondeur" => TAG_LOT_DEPTH,
							"facade_largeur" => TAG_FRONTAGE_WIDTH,
							"emission_co2" => TAG_CO2_EMISSION,
                                                     ),
				);
	
	$keys = array_keys($attributeTagsArray[$language]); // Returning Keys
	$key = clearForLowerCase($key); // Converting to lower case
	
	foreach($keys as $k){
	    
		   $check = stripos("X$key","$k");
		   if(!empty($check))
		   return $attributeTagsArray[$language][$k];
	    }
	 
	return '';	 
}

function GetExactAttrib($key,$val){
 
    $a = array();
    
    switch($key){
    case TAG_CONSTRUCTION_YEAR:
        return toYear($val);
        break;
    case TAG_RENOVATION_YEAR:
        return toYear($val);
        break;
     case TAG_FREE_FROM_DATE:
        return toUnixTimestamp($val);
        break;
    
    case TAG_EPC_VALUE:
        return toEpc($val);
        break;
    case TAG_GARDEN_AVAILABLE:
       return (strtolower($val)=='ja') ? 1 : 0;
    break;
    
    case TAG_CONNECTION_TO_WATER:
       return (strtolower($val)=='ja') ? 1 : 0;
    break;
  
    case TAG_TERRACES:
       return $a[] = toNumber($val); 
    break;
    
    default:
	
	$val = trim($val);
	if(strtolower($val)=='ja' || strtolower($val)=='nee' || strtolower($val)=='neen')
        return (strtolower($val)=='ja') ? 1 : '';

	else{

		if(stripos($key,"_permission") !== false)
	    return (strtolower($val)=='ja') ? 1 : '';
		
		if(stripos($key,"_visible") !== false)
	    return (strtolower($val)=='ja') ? 1 : '0';

	    if(stripos($key,"_nl") !== false)
	    return $val;
	    
	    if(stripos($key,"_fr") !== false)
	    return $val;
	
	    if(stripos($key,"_en") !== false)
	    return $val;
	    else
	    return toNumber($val);
	    
	}
	
    break;
     
    }
}


/// Basic checking for 
function clearForLowerCase($str = ''){ 
    $str = strtolower(str_replace(' ','_',$str)); 
    $str = trim(strip_tags($str)); 
    //$str = preg_replace('![^a-z0-9_\-\. ]!','',$str); 
    // $str = trim(preg_replace('!nbsp!','',$str)); 
    $str = trim(preg_replace('!ja,!','',$str));
    //$str = trim(preg_replace('!,!','',$str));
    $str = trim(normalize_str($str));
    return $str ;
 
}

function toNumber($str)
{
    ///return $str;
	$value = 0;
    $str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
    $str = preg_replace("/,(\d{3})|\.(\d{3})/",  "$1$2", $str);
    if(preg_match("/(-?\d+)/", $str, $match)) $value = intval($match[1]);
    
    if(empty($value))
    return 0;
    else
    return $value;
}

function toUnixTimestamp($str)
{
	return strtotime($str);
}

function toEpc($str){
	$epc = toNumber($str);
	if($epc > 0 && $epc <= 999) return $epc;
}

function toYear($str){
	$year = toNumber($str);
	if($year > 0 && strlen($year) == 4) return $year;
}

function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");
        foreach($invalid as $k => $v){
            $str = str_replace($k, $v, $str); //array_values($invalid)
        }

        return $str;
    }