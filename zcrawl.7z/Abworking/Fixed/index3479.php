<?php
require_once("../crawler_classes.php");

define('SITE_URL','http://www.huizejansen.eu/');

$office[TAG_OFFICE_ID]   = "1";
$office[TAG_OFFICE_URL]  = "www.huizejansen.eu";
$office[TAG_OFFICE_NAME] = "Huize Jansen";
$office[TAG_STREET]      = "Geelsebaan";
$office[TAG_NUMBER]      = "102A";
$office[TAG_BOX_NUMBER]  = "";
$office[TAG_ZIP]         = "2460";
$office[TAG_CITY]        = "Kasterlee";
$office[TAG_COUNTRY]     = "Belgium";
$office[TAG_TELEPHONE]   = "014/75.76.75 ";
$office[TAG_EMAIL]       = "info@dannyjansen.eu";

CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.huizejansen.eu/" 
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://huizejansen.eu/te-koop" 
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://hyboma.be/nieuwbouw" 
    ),
);


$start_links = array(
SITE_URL . 'pand_overzicht.aspx?transactie=1;3;5&id=2181' => STATUS_FORSELL,
SITE_URL . 'pand_overzicht.aspx?transactie=2;4;6&id=2180' => STATUS_TORENT ,
);

//set url here, if site have projects
$projects_url = SITE_URL . 'pand_overzicht.aspx?type=21;0&id=3072';

//$crawler->enable_delay_between_requests(5,15);
//$crawler->use_cookies(true);
//$crawler->clean_cookies();
//$crawler->use_gzip(false);

$properties = array();

//Projects
//some proprties, not a projects, so there TAG_PROJECT_ID and TAG_UNIQUE_ID
//we should procces projects, to get properties with linked with projects
if (!empty($projects_url))
{
	$html = $crawler->request($projects_url);
	preg_match_all('!<h5>\s+<a href="pand_detail\.aspx\?pandid=(\d+)&id=(\d+)" i!',$html,$res,PREG_SET_ORDER);
	debug($res); exit;
	foreach ($res as $v)
	{
		$project                         = array();
		$project[TAG_PROJECT_ID]         = $v[1];//$v[1].'.'.$v[2];
		$project[TAG_UNIQUE_ID]          = $project[TAG_PROJECT_ID];
		$project[TAG_UNIQUE_URL_NL]      = SITE_URL . 'pand_detail.aspx?pandid=' .$v[1] . '&id=' . $v[2];
		$project[TAG_STATUS]             = STATUS_FORSELL;
		$properties[$project[TAG_PROJECT_ID]] = $project;
	}
}

foreach ($start_links as  $tkth_url => $status)
{
	$html   = $crawler->request($tkth_url);

	for ($page = 2; $page <= 200; $page++)
	{
		//extract links to properties
		preg_match_all('!<h5>\s+<a href="pand_detail\.aspx\?pandid=(\d+)&id=(\d+)" i!',$html,$res,PREG_SET_ORDER);
		foreach ($res as $v)
		{
			$property                         = array();
			$property[TAG_UNIQUE_ID]          = $v[1];//$v[1].'.'.$v[2];
			$property[TAG_UNIQUE_URL_NL]      = SITE_URL . 'pand_detail.aspx?pandid=' .$v[1] . '&id=' . $v[2];
			$property[TAG_STATUS]             = $status;

			if (isset($properties[$property[TAG_UNIQUE_ID]])) {continue;}
			$properties[$property[TAG_UNIQUE_ID]] = $property;
		}

		//break if no next page link
		if (strpos($html,'__doPostBack(\'ctl00$ctl00$content$child_content$dpOverzichtTop$ctl01$ctl0'.($page-1).'\',\'\')">'.$page.'</a>')===false)
		{
			break;
		}

		//parse values for next page query
		$eventtarget = 'ctl00%24ctl00%24content%24child_content%24dpOverzichtTop%24ctl01%24ctl0'.($page-1);
		preg_match('!id="__VIEWSTATE" value="(.*?)"!',$html,$res);
		$viewstate  = urlencode($res[1]);
		$post = "__EVENTTARGET=$eventtarget&__EVENTARGUMENT=&__VIEWSTATE=$viewstate&__SCROLLPOSITIONX=0&__SCROLLPOSITIONY=0&ctl00%24ctl00%24content%24child_content%24Pand_zoeken1%24type=0&ctl00%24ctl00%24content%24child_content%24Pand_zoeken1%24city=0&ctl00%24ctl00%24content%24child_content%24Pand_zoeken1%24price_class=0&ctl00%24ctl00%24content%24txtNaam=&ctl00%24ctl00%24content%24txtVoorNaam=&ctl00%24ctl00%24content%24txtEmail=&ctl00_ctl00_content_HoneypotCap_Inschrijven=&ctl00%24ctl00%24hfVSFileName=";
		$html = $crawler->request($tkth_url,$post,$tkth_url);
	}
}

CrawlerTool::startXML();

CrawlerTool::saveOffice($office);

//procces projects/properties
$done_cnt  = 0;
$total_cnt = count($properties);
echo "start proccesing property/project pages\r\n<br>Total count:$total_cnt\r\n<br>";
foreach ($properties as $property)
{
	extract_info($crawler,$property);
	$done_cnt++;
	$z = round(($done_cnt/$total_cnt)*100,2);
	echo "Done:$done_cnt/$total_cnt ($z% completed)\r\n<br>";
}

CrawlerTool::endXML();

echo "<br /><b>Completed!</b>";

function extract_info($crawler,$property)
{
	static $already_saved = array();

	//properies from projects can appear at te koop too, so we should check id to prevent dublicates
	if (isset($already_saved[$property[TAG_UNIQUE_ID]]))
	{
		echo "property #{$property[TAG_UNIQUE_ID]} skipped, because already saved<br>\r\n";
		return ;
	}
	$already_saved[$property[TAG_UNIQUE_ID]] = 1;


	$html   = $crawler->request($property[TAG_UNIQUE_URL_NL]);

	if (CrawlerTool::skipWordFound($html))
	{
		echo "property skipped<br>\r\n";
		return ;
	}




	$parser = new PageParser($html);

	$parser->extract_xpath("li/span[contains(text(), 'Toilet')]", RETURN_TYPE_ARRAY, function($arr) use(&$property, $parser)
	{
		$surf_arr = array();
		foreach($arr as $text)
		{
			$surface = str_replace(',','.',$parser->regex("/([0-9][0-9,]*)\s*m/", $text));
			if(!empty($surface))
			{
				$surf_arr[] = array(TAG_TOILET_SURFACE => $surface, TAG_TOILET_DESC_NL => $text);
			}
		}
		if(count($surf_arr)>0) $property[TAG_TOILETS] = $surf_arr;
	});


	$parser->extract_xpath("li/span[contains(text(), 'Garage')]", RETURN_TYPE_ARRAY, function($arr) use(&$property, $parser)
	{
		$surf_arr = array();
		foreach($arr as $text)
		{
			$surface = str_replace(',','.',$parser->regex("/([0-9][0-9,]*)\s*m/", $text));
			if(!empty($surface))
			{
				$surf_arr[] = array(TAG_GARAGE_SURFACE => $surface, TAG_GARAGE_DESC_NL => $text);
			}
		}
		if(count($surf_arr)>0) $property[TAG_GARAGES] = $surf_arr;
	});



	$parser->extract_xpath("li/span[contains(text(), 'Terras')]", RETURN_TYPE_ARRAY, function($arr) use(&$property, $parser)
	{
		$surf_arr = array();
		foreach($arr as $text)
		{
			$surface = str_replace(',','.',$parser->regex("/([0-9][0-9,]*)\s*m/", $text));
			if(!empty($surface))
			{
				$surf_arr[] = array(TAG_TERRACE_SURFACE => $surface, TAG_TERRACE_DESC_NL => $text);
			}
		}
		if(count($surf_arr)>0) $property[TAG_TERRACES] = $surf_arr;
	});




	$parser->extract_xpath("li/span[contains(text(), 'Slaapkamer')]", RETURN_TYPE_ARRAY, function($arr) use(&$property, $parser)
	{
		$surf_arr = array();
		foreach($arr as $text)
		{
			$surface = str_replace(',','.',$parser->regex("/([0-9][0-9,]*)\s*m/", $text));
			if(!empty($surface))
			{
				$surf_arr[] = array(TAG_BEDROOM_SURFACE => $surface, TAG_BEDROOM_DESC_NL => $text);
			}
		}
		if(count($surf_arr)>0) $property[TAG_BEDROOMS] = $surf_arr;
	});




	// get bathroom surface info
	$parser->extract_xpath("li/span[contains(text(), 'Badkamer')]", RETURN_TYPE_ARRAY, function($arr) use(&$property, $parser)
	{
		$bathrooms = array();
		$property[TAG_BATHROOMS_TOTAL] = sizeof($arr);
		foreach($arr as $text)
		{
			$surface = str_replace(',','.',$parser->regex("/([0-9][0-9,]*)\s*m/", $text));
			if(!empty($surface))
			{
				$bathrooms[] = array(TAG_BATHROOM_SURFACE => $surface, TAG_BATHROOM_DESC_NL => $text);
			}
		}

		if(count($bathrooms)>0) $property[TAG_BATHROOMS] = $bathrooms;
	});


	// get kitchen surface info
	$parser->extract_xpath("li/span[contains(text(), 'Keuken')]", RETURN_TYPE_ARRAY, function($arr) use(&$property, $parser)
	{
		$kitchens = array();
		foreach($arr as $text)
		{
			$surface = str_replace(',','.',$parser->regex("/([0-9][0-9,]*)\s*m/", $text));
			if(!empty($surface))
			{
				$kitchens[] = array(TAG_KITCHEN_SURFACE => $surface, TAG_KITCHEN_DESC_NL => $text);
			}
		}
		if(count($kitchens)>0) $property[TAG_KITCHENS] = $kitchens;
	});

	// get store room surface info
	$parser->extract_xpath("li/span[contains(text(), 'Berging')]", RETURN_TYPE_ARRAY, function($arr) use(&$property, $parser)
	{
		$storerooms = array();
		foreach($arr as $text)
		{
			$surface = str_replace(',','.',$parser->regex("/([0-9][0-9,]*)\s*m/", $text));
			if(!empty($surface))
			{
				$storerooms[] = array(TAG_STOREROOM_SURFACE => $surface, TAG_STOREROOM_DESC_NL => $text);
			}
		}
		if(count($storerooms)>0) $property[TAG_STOREROOMS] = $storerooms;
	});

	// get dining rooms surface info
	$parser->extract_xpath("li/span[contains(text(), 'Eetkamer')]", RETURN_TYPE_ARRAY, function($arr) use(&$property, $parser)
	{
		$diningrooms = array();
		foreach($arr as $text)
		{
			$surface = str_replace(',','.',$parser->regex("/([0-9][0-9,]*)\s*m/", $text));
			if(!empty($surface))
			{
				$diningrooms[] = array(TAG_DINING_SURFACE => $surface, TAG_DINING_DESC_NL => $text);
			}
		}
		if(count($diningrooms)>0) $property[TAG_DININGS] = $diningrooms;
	});



	if (preg_match("!<div id='map_text' style='display:none;' lat='([0-9, ]+)'long='([0-9, ]+)'>!",$html,$res))
	{
		$property[TAG_LATITUDE] = trim(str_replace(',','.',$res[1]));
		$property[TAG_LONGITUDE] = trim(str_replace(',','.',$res[2]));
	}

	$arr                                   = $parser->regex_all('!rel="pand_detail_slider" href="([^"]+)"><img!', $html);
	$property[TAG_PICTURES]                = CrawlerTool::addTextToPicUrls($arr,SITE_URL);


	//parse fields
	$vars = array();
	preg_match_all('!class="tdTitel">([^<>]+)</td>\s+<td[^<>]+>(?:<a [^<>]+>|)(.+?)<!',$html,$res,PREG_SET_ORDER);

	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$vars[$arr[1]] = $arr[2];
	}

	//rename k.i. to ki
	if (isset($vars['k.i.'])){$vars['ki'] = $vars['k.i.'];unset($vars['k.i.']);}
	if (isset($vars['referentie nr.'])) {$vars['referentie'] = $vars['referentie nr.'];unset($vars['referentie nr.']);}


/*	if (isset($vars['omgeving'])) {unset($vars['omgeving']);}
	if (isset($vars['voorzieningen'])) {unset($vars['voorzieningen']);}
	if (isset($vars['energie-prestatie-certificaat'])) {unset($vars['energie-prestatie-certificaat']);}
	if (isset($vars['stedenbouwkundige overtreding'])) {unset($vars['stedenbouwkundige overtreding']);}
	if (isset($vars['algemene staat'])) {unset($vars['algemene staat']);}

*/

	//remove transactie (i.e. te koop or te huur) and others values
	if (isset($vars['transactie'])) {unset($vars['transactie']);}

	$original_reference = get_var($vars,'referentie');
	if (!empty($original_reference))
	{
		$property[TAG_ORIGINAL_REFERENCE]      = $original_reference;
	}

	$property[TAG_TYPE]                    = CrawlerTool::getPropertyType(get_var($vars,'type'));

	$property[TAG_CITY]                    = trim(preg_replace('!\(.*?\)!','',get_var($vars,'gemeente')));
	$property[TAG_ZIP]                     = get_var($vars,'postcode','!([1-9][0-9]{3})!');
	$property[TAG_PRICE]                   = str_replace('.','',get_var($vars,'prijs','![^<>0-9]*([0-9.]+)!'));
	$property[TAG_KI_INDEX]                = str_replace('.','',get_var($vars,'ki','![^<>0-9]*([0-9.]+)!'));
	$property[TAG_KI]                      = str_replace('.','',get_var($vars,'k.i. niet-gendexeerd','![^<>0-9]*([0-9.]+)!'));
	$property[TAG_STREET]                  = get_var($vars,'straat');
	$property[TAG_NUMBER]                  = get_var($vars,'nr.');
	$property[TAG_CONSTRUCTION_YEAR]       = get_var($vars,'bouwjaar','!(\d{4})!');
	$property[TAG_RENOVATION_YEAR]         = get_var($vars,'renovatie jaar','!(\d{4})!');
	$property[TAG_SURFACE_LIVING_AREA]     = get_var($vars,'oppervlakte bewoonbaar','!(\d+)!');
	$property[TAG_SURFACE_GROUND]          = get_var($vars,'oppervlakte grond','!(\d+)!');
	$property[TAG_SURFACE_CONSTRUCTION]    = get_var($vars,'oppervlakte bebouwd','!(\d+)!');
	$property[TAG_LOT_WIDTH]               = get_var($vars,'breedte grond','!(\d+)!');
	$property[TAG_LOT_DEPTH]               = get_var($vars,'diepte grond','!(\d+)!');
	$property[TAG_BEDROOMS_TOTAL]          = get_var($vars,'slaapkamers','!(\d+)!');
	$property[TAG_FLOOR]                   = trim(get_var($vars,'verdieping','!(\d+)!'));
	$property[TAG_K_LEVEL]                 = get_var($vars,'k peil','!(\d+)!');
	$property[TAG_EPC_VALUE]               = get_var($vars,'epc waarde','!(\d+)!');
	$property[TAG_EPC_CERTIFICATE_NUMBER]  = get_var($vars,'epc referentie','!(\d+)!');
	$property[TAG_CONSTRUCTION_TYPE]       = CrawlerTool::getConstructionType(get_var($vars,'bebouwing'));
	$property[TAG_FRONTAGE_WIDTH]          = str_replace(',','.',get_var($vars,'breedte huis','!([0-9,]+)!'));
	$property[TAG_DEPTH_GROUND_FLOOR]      = str_replace(',','.',get_var($vars,'diepte huis','!([0-9,]+)!'));
	$property[TAG_MOST_RECENT_DESTINATION] = get_var($vars,'stedenbouwkundige bestemming');
	$property[TAG_DOMESTIC_ANIMALS_ALLOWED]= get_var($vars,'huisdieren toegelaten') == 'Ja' ? 1 : '';
	$property[TAG_FREE_FROM]               = get_var($vars,'beschikbaar');
	$property[TAG_PRIORITY_PURCHASE]       = get_var($vars,'voorkooprecht') == 'Ja' ? 1 : '';
	$property[TAG_IS_NEW_CONSTRUCTION]     = get_var($vars,'nieuwbouw') == 'Ja' ? 1 : '';
	$property[TAG_LIFT]                    = get_var($vars,'lift') == 'Ja' ? 1 : '';
	$property[TAG_PLANNING_PERMISSION]     = get_var($vars,'bouwvergunning') == 'Ja' ? 1 : '';
	$property[TAG_SUBDIVISION_PERMIT]      = get_var($vars,'verkavelings vergunning') == 'Ja' ? 1 : '';
	$property[TAG_FURNISHED]               = get_var($vars,'bemeubeld') == 'Ja' ? 1 : '';
	$property[TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE] = get_var($vars,'keuringsattest elektriciteit') == 'Ja' ? 1 : '';


	preg_match('!<p>\s+<h2>(.*?)</h2>\s+</p>\s+<p>(.*?)</p>!s',$html,$res);
	$property[TAG_TEXT_TITLE_NL]           = trim(strip_tags($res[1]));
	$property[TAG_TEXT_DESC_NL]            = trim(strip_tags($res[2]));

	if ($property[TAG_TYPE] == '' || (is_array($property[TAG_TYPE]) && count($property[TAG_TYPE])==0))	{$property[TAG_TYPE]     =  CrawlerTool::getPropertyType($property[TAG_TEXT_TITLE_NL],300);}
	if ($property[TAG_TYPE] == '' || (is_array($property[TAG_TYPE]) && count($property[TAG_TYPE])==0))	{$property[TAG_TYPE]     =  CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL],300);}

	$tuin = get_var($vars,'orientatie tuin');
	if (!empty($tuin))
	{
		$property[TAG_GARDEN_AVAILABLE] = 1;

		$raw = trim(strtolower($tuin));
		$raw = str_replace('-','',$raw);

		if ($raw=='noordwest')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'NW';
		}
		elseif ($raw=='zuidwest')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'SW';
		}
		elseif ($raw=='zuidoost')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'SE';
		}
		elseif ($raw=='noordoost')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'NE';
		}
		elseif ($raw=='noordoost')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'NE';
		}
		elseif ($raw=='noord')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'N';
		}
		elseif ($raw=='oost')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'E';
		}
		elseif ($raw=='west')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'W';
		}
		elseif ($raw=='zuid')
		{
			$property[TAG_GARDEN_ORIENTATION] = 'S';
		}
	}

	$unmatched_variables = array();
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	}
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;


	//if page have table with rptPanden_ct rows, this is project page
	$sold_max = substr_count($html,'rptPanden_ct');
	if ($sold_max > 0)
	{
		$property[TAG_PROJECT_ID] = $property[TAG_UNIQUE_ID];

		preg_match_all('!window\.location=\'/pand_detail\.aspx\?pandid=(\d+)\';" onmouseover="this\.style\.cursor=\'pointer\';!',$html,$res1);
		$property[TAG_SOLD_PERCENTAGE_MAX]   = $sold_max;
		$property[TAG_SOLD_PERCENTAGE_VALUE] = $sold_max - count($res1[1]);
		CrawlerTool::saveProject($property);
		foreach ($res1[1] as $pandid)
		{
			$property2                         = array();
			$property2[TAG_UNIQUE_ID]          = $pandid;
			$property2[TAG_PROJECT_ID]         = $property[TAG_PROJECT_ID];
			$property2[TAG_UNIQUE_URL_NL]      = SITE_URL . 'pand_detail.aspx?pandid=' .$pandid;
			$property2[TAG_STATUS]             = $property[TAG_STATUS];
			echo "Extracting project item info\r\n<br>";
			extract_info($crawler,$property2);
		}
	}
	else
	{
		CrawlerTool::saveProperty($property);
	}


}

function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
			return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

//function for print array
function debug($obj)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}
