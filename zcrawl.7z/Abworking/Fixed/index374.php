<?php
require_once("./../crawler_classes.php");


//$crawler->enable_delay_between_requests(5,15);
$crawler->use_cookies(true);
//$crawler->clean_cookies();
//$crawler->use_gzip(false);

$crawler->request('http://www.anitavandevoort.be/home.php?idioma=Nederlands');
$startPages[STATUS_TORENT] = array
(
"http://www.anitavandevoort.be/alouer.php" => '',
);

$startPages[STATUS_FORSELL] = array
(
"http://www.anitavandevoort.be/avendre.php"=>'',
);

CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Anita Vandevoort BVBA";
$office[TAG_OFFICE_URL] = "www.anitavandevoort.be";
$office[TAG_STREET] = "Tegelrijstraat";
$office[TAG_NUMBER] = "40";
$office[TAG_ZIP] = "3850";
$office[TAG_CITY] = "Nieuwerkerken";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "+32 (0)11 69 23 57";
$office[TAG_FAX] = "+32 (0)11 69 23 58";
$office[TAG_EMAIL] = "info@anitavandevoort.be";
CrawlerTool::saveOffice($office);

foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
		
//Debuging Page detail
debugx($status.'->'.$type.'->'.'Page: -> '.$page_url);
	
	    $html = $crawler->request($page_url);
	    processPage($crawler, $status, $type, $html);
	    
        while(1){
		//print $html;
			$pattern = ".+class=\"numero_pagina_selec\">\d{1,}<\/span>&nbsp;<a href=\"(.+?)\" class=\"numero_pagina_link\"";
			preg_match ( "/" . $pattern . "/is", $html, $next_match);
			//print_r ($next_match);
			if (isset($next_match[1])) {
			   	$p = 'http://www.anitavandevoort.be/'.trim(str_replace('&amp;', '&', $next_match[1]));
//Debuging Page detail
debugx($status.'->'.$type.'->'.'Page: -> '.$p);

			   $html = $crawler->request($p);
			   processPage($crawler, $status, $type, $html);
			} else {
				break;
			}
		}
	}
}


CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';

/**
 *  Get next page
 */
function getNextPage($html) {

	$nextPage = "";
    $parser = new PageParser($html);
	$node = $parser->getNode("a[img[contains(@src, 'Filestore.Dat')]]");
	if($node) $nextPage = "http://webdata.skarabee.net/flexplus/websites/live/Solvas/" . $parser->getAttr($node, "href");
	return $nextPage;
}



function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;

    static $properties = array();
    $count=0;
    $parser = new PageParser($html);
    
    //$pattern  = "<br \/>\s+?<a href=\"((detail|details|details_louer)\.php.+?)\"";
    //preg_match_all ( "/" . $pattern . "/is", $html, $items_matches, PREG_SET_ORDER);
   
    $nodes = $parser->getNodes("div[@class = 'info']/h2/a");
 
    foreach($nodes as $node) {

        $property[TAG_STATUS]=$status;
        if (stristr ($match[0], 'Verkocht.gif')) {
            $property[TAG_STATUS]="sold";
        }

		$property[TAG_UNIQUE_URL_NL] = 'http://www.anitavandevoort.be'.trim($parser->getAttr($node, "href"));
		
		$property[TAG_UNIQUE_ID]     = $parser->regex("/detail\/(\d+)/", $property[TAG_UNIQUE_URL_NL] ); 
		
		$property[TAG_UNIQUE_URL_NL] = 'http://www.anitavandevoort.be/nl/detail/'.$property[TAG_UNIQUE_ID].'/';
		
		$count=$count+1;
		$propertyCount += 1;
		  
		flush();
		ob_flush();

		//if($property[TAG_UNIQUE_ID] == "116" || $property[TAG_UNIQUE_ID] == "100" || $property[TAG_UNIQUE_ID] == "69"){
			// process item to obtain detail information
			echo "--------- Processing property #$propertyCount ...";
			processItem($crawler,$property,$type,$status);
			echo "--------- Completed<br />";
		//}

    }

}

function getUniqueId($url) {
	preg_match("/id=(\d+)\&/", $url, $match);
	if($match) return $match[1];
}


function processItem($crawler, $property ,$type)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_NL].'?idioma=Nederlands');
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    $html=preg_replace('/<strong>|<\/strong>|vAlign="top" |valign="top" /','',$html);
    $html=preg_replace('/TD/','td',$html);
    $html=preg_replace('/TR/','tr',$html);
    $html=preg_replace('/KenmerkLabel/','kenmerklabel',$html);

    $picUrls = array();
	$nodes = $parser->getNodes( "a[contains(@class, 'detail')]/@href");
	foreach($nodes as $node) {
		$picUrls[] = array(TAG_PICTURE_URL => 'http://www.anitavandevoort.be/'.$parser->getText($node));
	}
    $property[TAG_PICTURES] = $picUrls;

	$property[TAG_TEXT_TITLE_NL] = trim($parser->extract_xpath("h3[@class = 'title-property']", RETURN_TYPE_TEXT_ALL));
	$property[TAG_PRICE] = $parser->extract_xpath("h4[@class = 'price']",RETURN_TYPE_NUMBER);
	$property[TAG_TEXT_DESC_NL] = trim($parser->extract_xpath("div[@class = 'description']", RETURN_TYPE_TEXT_ALL));
	$property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@class= 'container']", RETURN_TYPE_TEXT_ALL);
	
	$property[TAG_TYPE] = CrawlerTool::getpropertyType( $property[TAG_TEXT_TITLE_NL]);
	$address = $parser->extract_xpath("span[@class= 'subheading']", RETURN_TYPE_TEXT);
	    CrawlerTool::parseAddress($address,$property);
	    
	$addr = explode(' ',$address);
	$property[TAG_CITY] = trim($addr[count($addr)-1]);
	$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
	
	if(strlen($property[TAG_ZIP]) < 4){
		$address = str_replace($property[TAG_ZIP],'',$address );
		$property[TAG_BOX_NUMBER] = $property[TAG_ZIP];
		
		unset($property[TAG_ZIP]) ;
	}
	
	$property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
	$property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
	
	$property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
	$property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
	
	if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
	
	if(strlen($property[TAG_BOX_NUMBER]) < 3 || strlen($property[TAG_BOX_NUMBER]) > 3 )
	unset($property[TAG_BOX_NUMBER]);
	
	$property[TAG_CONSTRUCTION_YEAR]       =  $parser->regex("/(\d{4})/", $parser->extract_xpath("div[@class = 'span2']/div/span[2]", RETURN_TYPE_TEXT_ALL));
	$property[TAG_SURFACE_GROUND]         = CrawlerTool::toNumber(get_var($vars,"land"));
	$property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("span[@class = 'bed']", RETURN_TYPE_NUMBER);
	$property[TAG_BATHROOMS][TAG_TOTAL_AMOUNT] = $parser->extract_xpath("span[@class = 'bath']", RETURN_TYPE_NUMBER);
	$property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("span[@class = 'car']", RETURN_TYPE_NUMBER);
	 
	$garagetotal                = get_var($vars,'garages','!(\d+)!');

	if(!isset($property[TAG_HAS_PROCEEDING]) || $property[TAG_HAS_PROCEEDING] !=1 )
	$property[TAG_HAS_PROCEEDING] = '';
	
	if(!isset($property['planning_permission']) || $property['planning_permission'] !=1)
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || $property['subdivision_permit'] !=1)
	$property['subdivision_permit'] = '';
	
	
	if(!isset($property['most_recent_destination']) || $property['most_recent_destination'] !=1)
	$property['most_recent_destination'] = '';
	
	
	debug($property);
	CrawlerTool::saveProperty($property);

}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function getmapinfo($text){
   preg_match('/MapView\.LonLat\((.*?)\)/',$text,$res);
   $ret=explode(",", $res[1]);
   return $ret;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////

 //function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

///0514437586 President Line...

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}


?>