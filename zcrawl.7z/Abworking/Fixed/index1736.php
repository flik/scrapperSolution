<?php

// Crawler ID 1736  http://www.immofinco.be/

require_once("../crawler_classes.php");

$startPages[STATUS_FORSELL] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immofinco.be/index.php?option=com_hotproperty&task=viewtype&id=2&Itemid=26",
		"http://www.immofinco.be/index.php?option=com_hotproperty&task=viewtype&id=1&Itemid=26",
		"http://www.immofinco.be/index.php?option=com_hotproperty&task=viewtype&id=5&Itemid=69",
		"http://www.immofinco.be/index.php?option=com_hotproperty&task=viewtype&id=4&Itemid=66"
    ),
);

$startPages[STATUS_TORENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immofinco.be/index.php?option=com_hotproperty&task=viewtype&id=3&Itemid=26"
    ),
);

CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = " N.V. Immo Finco ";
$office[TAG_OFFICE_URL] = "http://www.concept-bvba.be/";
$office[TAG_STREET] = "St. Petrus- en Paulusstraat";
$office[TAG_NUMBER] = "24/6";
$office[TAG_ZIP] = "8800";
$office[TAG_CITY] = "West-Vlaanderen ";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "051/20.82.44 ";
$office[TAG_FAX] = "051/22.96.22 ";
$office[TAG_EMAIL] = "		immofinco@skynet.be";
CrawlerTool::saveOffice($office);


foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        { 
		    $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
        }
    }
}

CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount=0;
    static $properties=array();
    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[@class = 'hp_title']");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_NL] = $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  $parser->regex("/(\d+)/", $property[TAG_UNIQUE_URL_NL]);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
		processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}



function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
        $parser->deleteTags(array("script", "style"));
	if(CrawlerTool::skipWordFound($html)){echo 'property Skipped <br>'; return;}
    
    $property[TAG_TEXT_TITLE_NL] = $parser->extract_regex("@<title>ImmoFinco -([^<>]+)</title>@");
    
    $property[TAG_TEXT_DESC_NL] = preg_replace('@----------[^<>]+@','',implode(' ',$parser->extract_xpath("div[@class ='hp_view_details']/p",RETURN_TYPE_ARRAY)));
     $property[TAG_TYPE]=CrawlerTool::getPropertyType($property[TAG_TEXT_TITLE_NL].$property[TAG_TEXT_DESC_NL] ); 
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@id = 'con_hp1']", RETURN_TYPE_TEXT_ALL);
    
    $property[TAG_PICTURES] = $parser->extract_xpath("ul[@class = 'thumb']//img", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => preg_replace('@thb@','std',$pic));

        return $picUrls;
    });

    if(empty($property[TAG_PICTURES])){
	
	$property[TAG_PICTURES] = $parser->extract_xpath("img[contains(@src, 'JPG')]", RETURN_TYPE_ARRAY, function($files)
	     {
		     $fileUrls = array();
		     foreach($files as $file)
		     {
			     if(!empty($file)) $fileUrls[] = array(TAG_PICTURE_URL => $file);
		     }
		     return $fileUrls;
	});
	
    
    }
    
        $street= $parser->extract_xpath("div[@id = 'hp_view_addr']");
		if(!empty($street)){
		if(strstr($street,'SPANJE')){echo 'property skipped : outside belgium'; return;}	
		$street=preg_replace('@,.+\Z@','',$street);
	    $property[TAG_STREET] = trim(preg_replace("/([^\d,]+).*?$/", "$1", strip_tags($street)));
        $property[TAG_NUMBER]  = trim(preg_replace("/^[^\d,]+([^\s,]*).*$/", "$1", strip_tags($street)));
		}
    $parser->extract_xpath("div[@id = 'hp_view_addr']", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("@\d+([^<>]+),\s+(\d{4})@", $text, $match))
        {
            $property[TAG_ZIP] = $match[2];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[1]));
        }
    });
if(empty($property[TAG_CITY])){
	unset($property[TAG_STREET]);
	unset($property[TAG_NUMBER]);
	$property[TAG_CITY]=$parser->extract_xpath("div[@id = 'hp_view_addr']");
	
	}
    $property[TAG_IS_NEW_CONSTRUCTION] = CrawlerTool::isNewConstruction($parser->extract_regex("@Type: </span>([^<>]+)<br />@"));
	$property[TAG_PRICE] = CrawlerTool::toNumber($parser->extract_xpath("span[@class='hp_price']"));
    $property[TAG_EPC_VALUE] = CrawlerTool::toNumber($parser->extract_regex("@<p>EPC([^<>]+)kwh</p@"));
	 
	if(strpos(strtolower(str_replace(' ','_',$html)),"verhuurd")){
	    $property[TAG_STATUS] = "rented"; return;
	}
	if(strpos(strtolower(str_replace(' ','_',$html)),"vrkocht")){
	    $property[TAG_STATUS] = "sold"; return;
	}
	
	if($property[TAG_STATUS]==STATUS_SOLD)	 return ;
	if($property[TAG_STATUS]==STATUS_RENTED) return ;
	
	if(!isset($property[TAG_HAS_PROCEEDING]) || empty($property[TAG_HAS_PROCEEDING]))
	$property[TAG_HAS_PROCEEDING] = '';
	
	
	if(!isset($property['planning_permission']) || empty($property['planning_permission']))
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
	$property['subdivision_permit'] = '';
	
	
	if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
	$property['most_recent_destination'] = '';
		
 

	 CrawlerTool::saveProperty($property);
	
}

