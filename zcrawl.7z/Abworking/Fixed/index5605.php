<?php

// Crawler ID 425 http://www.depreterteurfs.be/
require_once("./../crawler_classes.php");

$startPages[STATUS_FORSELL] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.depreterteurfs.be/Web.mvc/nl-be/List1",
        "http://www.depreterteurfs.be/Web.mvc/nl-be/List3"
    ),
);

$startPages[STATUS_TORENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.depreterteurfs.be/Web.mvc/nl-be/List2"
    ),
);

CrawlerTool::startXML();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "DEPRETERTEURFS";
$office[TAG_OFFICE_URL] = "http://www.depreterteurfs.be/";
$office[TAG_STREET] = "E. Woutersstraat ";
$office[TAG_NUMBER] = "59";
$office[TAG_ZIP] = "2220";
$office[TAG_CITY] = "Heist-op-den-Berg";
$office[TAG_TELEPHONE] = "015 33 05 01";
$office[TAG_EMAIL] = "info@depreterteurfs.be";
CrawlerTool::saveOffice($office);

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
	    debugx($page);
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);        
            $nextPages = getPages($html);
	   
            foreach($nextPages as $nextPage)
            {
		debugx($nextPage);
                $html = $crawler->request($nextPage);
                processPage($crawler, $status, $type, $html);
            }
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


/**
 */
function processPage($crawler, $status, $type, $html)
{
    global $propertyCount;
    global $properties;
    if(empty($propertyCount)) $propertyCount = 0;
    if(empty($properties)) $properties = array();

    $parser = new PageParser($html, true);

    $nodes = $parser->getNodes("a[. = 'Meer details']");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_NL] = "http://www.depreterteurfs.be/" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_URL_FR]=preg_replace("/nl\-be/", "fr-fr",$property[TAG_UNIQUE_URL_NL]);
        $property[TAG_UNIQUE_URL_EN]=preg_replace("/nl\-be/", "en-gb",$property[TAG_UNIQUE_URL_NL]);
        $property[TAG_UNIQUE_ID] =  $parser->regex("/(\d+)$/", $property[TAG_UNIQUE_URL_NL]);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}
    //debug($items);exit;

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;
        // process item to obtain detail information
        // if($item["item"][TAG_UNIQUE_ID] == "1966320"){
            echo "--------- Processing property #$propertyCount ...";
            processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
            echo "--------- Completed<br />";
        // }
    }

    return sizeof($items);
}

/**
 * Get a list of next pages
 */
function getPages($html)
{
    $parser = new PageParser($html);

	$pages = array();
	$nodes = $parser->getNodes("a[@class = 'Link PaginationLink']");

    if(!empty($nodes))
    {
		foreach($nodes as $node)
        {
			$pages[] = "http://www.depreterteurfs.be" . $parser->getAttr($node, "href");
		}
	}

	return array_unique($pages);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    //$html = $crawler->request("http://www.depreterteurfs.be//Web.mvc/nl-be/Detail/1965338");
    //$html = str_replace('?', '&euro;',$html);
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));
    $status = CrawlerTool::getPropertyStatus($parser->extract_xpath("table[@border = '1']"));
	
	if($status)$property[TAG_STATUS]=$status;
	
	//Return in case of sold or rented
	if($property[TAG_STATUS]==STATUS_SOLD)	 return ;
	if($property[TAG_STATUS]==STATUS_RENTED) return ;
	
    $property[TAG_TEXT_DESC_NL] = utf8_decode($parser->extract_xpath("table[@border = '1' and not(@cellpadding)]"));
    $property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode($parser->extract_xpath("table[@style = 'width: 100%; margin-top: 10px;']", RETURN_TYPE_TEXT_ALL));
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.depreterteurfs.be" . $pic);

        return $picUrls;
    });

        $street= $parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[1]");
		if($street!=''){
	    $street=preg_replace('@,.+\Z@','',$street);
	    $property[TAG_STREET] = trim(preg_replace("/([^\d,]+).*?$/", "$1", strip_tags($street)));
        $property[TAG_NUMBER]  = trim(preg_replace("/^[^\d,]+([^\s,]*).*$/", "$1", strip_tags($street)));
		$property[TAG_BOX_NUMBER] = trim(strip_tags(preg_replace('/[^<>]*'.$property[TAG_NUMBER].'([^<>]*)$/','$1',$street)));
		}
    $parser->extract_xpath("table[@border = '1']/tr/td/table/tr[last()]/td[2]", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(\d{4})(.*)/", $text, $match))
        {
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }else{
		$property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $text));	
			
			}
    });
    $property[TAG_PRICE] = $parser->extract_regex("@Prijs:\s+<strong>([^<>]+?)</strong>@", RETURN_TYPE_NUMBER);
    $property[TAG_EPC_VALUE] = $parser->extract_regex("/EPC\s*(\d+)/", RETURN_TYPE_EPC);

    $nodes = $parser->getNodes("div[@class='print-detail']/table/tr[3]/td/table/tr");
    foreach($nodes as $node)
    {
        $key = $parser->extract_xpath("td[1]", RETURN_TYPE_TEXT, null, $node);
        $val = $parser->extract_xpath("td[2]", RETURN_TYPE_TEXT, null, $node);
        if(!empty($val) && $key != 'Kantoor'){
            $att = getAttributes(str_replace(' ','_',$key), 'nl');
            
            if(isset($att) && !empty($att)){
                $property[$att] = GetExactAttrib($att, $val);
            }else{
                $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $key, TAG_VARIABLE_VALUE => $val);
            }   
            unset($att);
        }
    }
    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
    /*
    $property[TAG_HEATING_NL] = $parser->extract_xpath("td[. = 'verwarming type']/following-sibling::td[1]");

    $parser->extract_xpath("td[contains(text(), 'slaapkamer') and contains(text(), 'oppervlakte')]/following-sibling::td[1]", RETURN_TYPE_ARRAY, function($arr) use(&$property)
    {
        $bedrooms = array();
        foreach($arr as $count=>$surface)
        {
            $surface = CrawlerTool::toNumber($surface);
            $bedroom = array(TAG_BEDROOM_SURFACE => $surface, TAG_BEDROOM_DESC_NL => "slaapkamer " . ($count + 1) . " oppervlakte (m²)");
            $bedrooms[] = $bedroom;
        }

        if(!empty($bedrooms)) $property[TAG_BEDROOMS] = $bedrooms;
    });

    $parser->extract_xpath("td[contains(text(), 'badkamer') and contains(text(), 'oppervlakte')]/following-sibling::td[1]", RETURN_TYPE_ARRAY, function($arr) use(&$property)
    {
        $bathrooms = array();
        foreach($arr as $count=>$surface)
        {
            $surface = CrawlerTool::toNumber($surface);
            $bathroom = array(TAG_BATHROOM_SURFACE => $surface, TAG_BATHROOM_DESC_NL => "badkamer(s) oppervlakte (bdk" . ($count + 1) . ")");
            $bathrooms[] = $bathroom;
        }

        if(!empty($bathrooms)) $property[TAG_BATHROOMS] = $bathrooms;
    });

    $parser->extract_xpath("td[contains(text(), 'terras') and contains(text(), 'oppervlakte')]/following-sibling::td[1]", RETURN_TYPE_ARRAY, function($arr) use(&$property)
    {
        $terraces = array();
        foreach($arr as $count=>$surface)
        {
            $surface = CrawlerTool::toNumber($surface);
            $terrace = array(TAG_TERRACE_SURFACE => $surface, TAG_TERRACE_DESC_NL => "terras " . ($count + 1) . " oppervlakte (m²)");
            $terraces[] = $terrace;
        }

        if(!empty($terraces)) $property[TAG_TERRACES] = $terraces;
    });

    $parser->extract_xpath("td[contains(text(), 'garage oppervlakte')]/following-sibling::td[1]", RETURN_TYPE_ARRAY, function($arr) use(&$property)
    {
        $garages = array();
        foreach($arr as $count=>$surface)
        {
            $surface = CrawlerTool::toNumber($surface);
            $garage = array(TAG_GARAGE_SURFACE => $surface);
            $garages[] = $garage;
        }

        if(!empty($garages)) $property[TAG_GARAGES] = $garages;
    });

    // get document files
    $files = array();
    $nodes = $parser->getNodes("a[contains(@href, 'GetFile.ashx?path=Documents')]");
    foreach($nodes as $node)
    {
        $fileUrl = "http://www.depreterteurfs.be" . $parser->regex("/path=(.*)&/", $parser->getAttr($node, "href"));
        $fileTitle = $parser->getText($node);
        $files[] = array(TAG_FILE_URL => $fileUrl, TAG_FILE_TITLE_NL => $fileTitle);
    }
    if(!empty($files)) $property[TAG_FILES] = $files;

   
     
    $nodes = $parser->getNodes("table[@cellpadding=1][@border=0][@style='width: 100%;']/tr");
    foreach($nodes as $node)
    {
    $key = $parser->extract_xpath("td[1]",  RETURN_TYPE_TEXT, null, $node); 
    $val = $parser->extract_xpath("td[2]", RETURN_TYPE_TEXT, null, $node); 
    $k = getAttributes($key);
    if(!empty($k))
        $property[$k] = GetExactAttrib($key,$val);
    else
        $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $key, TAG_VARIABLE_VALUE => $val);
    }

    $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
   
    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("Categorie"));
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC score (kwh/m²)", RETURN_TYPE_EPC);
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC score (kwh/mÃ‚Â²)", RETURN_TYPE_EPC);
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC score", RETURN_TYPE_EPC);
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC Index:", RETURN_TYPE_EPC);
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("kwh/m", RETURN_TYPE_EPC);

    if(empty($property[TAG_EPC_CERTIFICATE_NUMBER])) $property[TAG_EPC_CERTIFICATE_NUMBER] = $parser->extract_xpath("EPC (Vlaanderen) unieke code", RETURN_TYPE_NUMBER);
    
    
    $property[TAG_KI] = $parser->extract_xpath("kadastraal inkomen", RETURN_TYPE_NUMBER);
    
    $property[TAG_METER_FOR_ELECTRICITY] = ($parser->extract_xpath("elektriciteitskeuring ja/nee") === "Ja" ? 1 : 0);
    $property[TAG_HEATING_NL] = $parser->extract_xpath("verwarming type (ind/coll)");
    
    $property[TAG_KI_INDEX] = $parser->extract_xpath("kad.ink.", RETURN_TYPE_NUMBER);

    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("bouwjaar", RETURN_TYPE_YEAR);
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("renovatie jaar", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Bewoonbare oppervlakte", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Grootte terrein", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Aantal kamers", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toiletten aantal", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("garage aantal", RETURN_TYPE_NUMBER);
    $property[TAG_PARKINGS_TOTAL] = $parser->extract_xpath("parking buiten aantal", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FLOORS] = $parser->extract_xpath("verdiepingen aantal", RETURN_TYPE_NUMBER);
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Beschikbaar vanaf", RETURN_TYPE_UNIX_TIMESTAMP);
    $property[TAG_COMMON_COSTS] = $parser->extract_xpath("lasten", RETURN_TYPE_NUMBER);
    $property[TAG_GAS_CONNECTION] = ($parser->extract_xpath("gas") === "Ja" ? 1 : 0);
    $property[TAG_CONNECTION_TO_WATER] = ($parser->extract_xpath("water") === "Ja" ? 1 : 0);
    $property[TAG_TELEPHONE_CONNECTION] = ($parser->extract_xpath("telefoon") === "Ja" ? 1 : 0);
    $property[TAG_LIFT] = ($parser->extract_xpath("lift") === "Ja" ? 1 : 0);
    $property[TAG_FURNISHED] = ($parser->extract_xpath("Gemeubeld") === "Ja" ? 1 : 0);
    $property[TAG_GARDEN_AVAILABLE] = ($parser->extract_xpath("Tuin") === "Ja" ? 1 : 0);
    $property[TAG_OPEN_FIRE] = ($parser->extract_xpath("open haard aantal") ? 1 : 0);
    $property[TAG_ALARM] = ($parser->extract_xpath("alarm") ? 1 : 0);
    $property[TAG_PARLOPHONE] = ($parser->extract_xpath("parlofoon") ? 1 : 0);
    $property[TAG_VIDEOPHONE] = ($parser->extract_xpath("videofoon") === "Ja" ? 1 : 0);

 
    */
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("Categorie"));
    $html = $crawler->request($property[TAG_UNIQUE_URL_FR]);
    $html = str_replace('?', '&euro;',$html); 
    $parser = new PageParser($html, true); 
    $parser->deleteTags(array("script", "style"));
    $property[TAG_TEXT_DESC_FR] = utf8_decode($parser->extract_xpath("table[@border = '1' and not(@cellpadding)]")); 
    $property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode($parser->extract_xpath("table[@style = 'width: 100%; margin-top: 10px;']", RETURN_TYPE_TEXT_ALL));
    if(empty($property[TAG_TEXT_DESC_FR])){
        preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
        $res[1] = str_replace(chr(11),'',$res[1]);
        $property[TAG_TEXT_DESC_FR] = utf8_decode(strip_tags($res[1]));
    }
    
    $html = $crawler->request($property[TAG_UNIQUE_URL_EN]); 
    $html = str_replace('?', '&euro;',$html);
    $parser = new PageParser($html, true); 
    $parser->deleteTags(array("script", "style")); 
    $property[TAG_TEXT_DESC_EN] = utf8_decode($parser->extract_xpath("table[@border = '1' and not(@cellpadding)]")); 
    $property[TAG_PLAIN_TEXT_ALL_EN] = utf8_decode($parser->extract_xpath("table[@style = 'width: 100%; margin-top: 10px;']", RETURN_TYPE_TEXT_ALL)); 
    
    if(empty($property[TAG_TEXT_DESC_EN])){
        preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
        $res[1] = str_replace(chr(11),'',$res[1]);
        $property[TAG_TEXT_DESC_EN] = utf8_decode(strip_tags($res[1]));
    }

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_EN]));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_EN]));

    // Most Important 
    if(!isset($property[TAG_HAS_PROCEEDING]) || $property[TAG_HAS_PROCEEDING] !=1 )
	$property[TAG_HAS_PROCEEDING] = '';
	
	if(!isset($property['planning_permission']) || $property['planning_permission'] !=1)
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || $property['subdivision_permit'] !=1)
	$property['subdivision_permit'] = '';
	
	
	if(!isset($property['most_recent_destination']) || $property['most_recent_destination'] !=1)
	$property['most_recent_destination'] = '';
	
    // WRITING item data to output.xml file
    debug($property); 
    CrawlerTool::saveProperty($property);
}


function getAttributes($key, $language='nl'){ //String Function always return string

    $attributeTagsArray = array('en' => array(  'pric'          =>  TAG_PRICE,
                            'constr'        => TAG_CONSTRUCTION_YEAR,
                            'ground'        => TAG_SURFACE_GROUND,
                            'living'        => TAG_SURFACE_LIVING_AREA,
                            'bath'          => TAG_BATHROOMS_TOTAL,
                            'warm'          => TAG_HEATING_EN,
                            'heat'          => TAG_HEATING_EN,
                            'sewer'         => TAG_CONNECTION_TO_SEWER,
                            'telep'         => TAG_TELEPHONE_CONNECTION,
                            'intern'        => TAG_INTERNET_CONNECTION,
                            'permission'        => TAG_PLANNING_PERMISSION,
                            'subdivision'       => TAG_SUBDIVISION_PERMIT,
                            'electri'       => TAG_METER_FOR_ELECTRICITY,
                            'hall'          => TAG_HALLS,
                            'dining'        => TAG_DININGS,
                            'kitch'         => TAG_KITCHENS,
                            'laundr'        => TAG_LAUNDRY_ROOMS,
                            'dress'         => TAG_DRESSING,
                            'bed'           => TAG_BEDROOMS_TOTAL,
                            'room'          => TAG_BEDROOMS_TOTAL,
                            'park'          => TAG_PARKINGS,
                            'garage'        => TAG_GARAGES_TOTAL,
                            'Categorie'     => TAG_TYPE,
                            'type'          => TAG_TYPE,
                            'garden'        => TAG_GARDEN_AVAILABLE,
                            'floor'         => TAG_AMOUNT_OF_FLOORS,
                            'winter'        => TAG_WINTERGARDENS,
                            'furnish'       => TAG_FURNISHED,
                            'water'         => TAG_CONNECTION_TO_WATER,
                            'lift'          => TAG_LIFT,
                            'glaz'          => TAG_DOUBLE_GLAZING,
                            'terrac'        => TAG_TERRACES,
                            'fronts'        => TAG_AMOUNT_OF_FACADES,
                            'category'      => TAG_TYPE,
                            'free'          => TAG_FREE_FROM_DATE,
                            'habit'         => TAG_SURFACE_LIVING_AREA,
                            'plot'          => TAG_SURFACE_GROUND,
                            'shops'         => TAG_DISTANCE_SHOPS,
                            'schools'       => TAG_DISTANCE_SCHOOL,
                            'transport'     => TAG_DISTANCE_PUBLIC_TRANSPORT,
                            'shower'        => TAG_SHOWERS_TOTAL,
                            'stor'          => TAG_STOREROOMS,
                            'gas'           => TAG_GAS_CONNECTION,
                            'alarm'         => TAG_ALARM,
                            'security'      => TAG_SECURITY_DOOR,
                            'parlo'         => TAG_PARLOPHONE,
                            'video'         => TAG_VIDEOPHONE,
                            'elevat'        => TAG_LIFT,
                            'blind'         => TAG_SUN_BLINDS,
                            'renova'        => TAG_RENOVATION_YEAR,
                            'control'       => TAG_ACCESS_SEMIVALID,
                                ),
                    'nl' => array(  "prij" =>  TAG_PRICE,
                            "bouwjaar" => TAG_CONSTRUCTION_YEAR,
                            "carport" => TAG_CARPORTS, 
                            "grondopp" => TAG_SURFACE_GROUND, 
                            "bewoonbare" => TAG_SURFACE_LIVING_AREA,
                            "antal_kamer"=> TAG_BEDROOMS_TOTAL,
                            "slaapkamer_1_oppervlakt" => TAG_BEDROOM_SURFACE,
                            "Aantal_kamers"=> TAG_BEDROOMS_TOTAL,
                            
                            "antal_badkam"=> TAG_BATHROOMS_TOTAL,
                            "badkam"=> TAG_BATHROOMS_TOTAL,
                            "certificaatnr" => TAG_EPC_CERTIFICATE_NUMBER,
                            "epc_waa" => TAG_EPC_VALUE,
                            "epc" => TAG_EPC_VALUE,
                            "kadastraal" => TAG_KI,
                            'Categorie'     => TAG_TYPE,
                            "ki" => TAG_KI,
                            "verdieping" => TAG_AMOUNT_OF_FLOORS,
                            "living" => TAG_SURFACE_LIVING_AREA,
                            "renovatie" => TAG_RENOVATION_YEAR,
                            "kadaster_sectie" => TAG_CADASTRAL_SECTION,
                            "beschikbaar" => TAG_FREE_FROM,
                            "fax" => TAG_FAX,
                            "tel" => TAG_CELLPHONE,
                            "mail" => TAG_EMAIL,
                            "winkels" => TAG_DISTANCE_SHOPS,
                            "vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
                            "overstromings" => TAG_FLOOD_INFORMATION_NL,
                            "garage" => TAG_GARAGES_TOTAL,
                            "toilet" => TAG_TOILETS_TOTAL,
                            "parking" => TAG_PARKINGS_TOTAL,
                            "gevels" => TAG_AMOUNT_OF_FACADES,
                            "lasten" => TAG_COMMON_COSTS,
                            "gas" => TAG_GAS_CONNECTION,
                            "water" => TAG_CONNECTION_TO_WATER,
                            "telefoon" => TAG_TELEPHONE,
                            "lift" => TAG_LIFT,
                            "gemeubeld" => TAG_FURNISHED,
                            "tuin" => TAG_GARDEN_AVAILABLE,
                            "haard" => TAG_OPEN_FIRE,
                            "alarm" => TAG_ALARM,
                            "parlofoon" => TAG_PARLOPHONE,
                            "videofoon" => TAG_VIDEOPHONE,
                            "breedte" => TAG_LOT_WIDTH,
                            "diepte" => TAG_LOT_DEPTH,
                            "constructie" => TAG_CONSTRUCTION_TYPE,
                            "gevelbreedte" => TAG_FRONTAGE_WIDTH,
                            "winkel" => TAG_HEATING_NL,
                            "douche" => TAG_SHOWERS_TOTAL,
                            "keuken" => TAG_KITCHEN_TYPE_NL,
                            "ligging" => TAG_SUBDIVISION_PERMIT,
                            "stedenbouwkundige" => TAG_PLANNING_PERMISSION,
                            "terras" => TAG_TERRACES,
                            "terrein bestemming" => TAG_SURFACE_GROUND,
                            "scholen" => TAG_DISTANCE_SCHOOL,
                            "oppervlakte" => TAG_SURFACE_LIVING_AREA,
                            "eetkamer" => TAG_DININGS,
                            "dressing" => TAG_DRESSINGS,
                            "kelder" => TAG_CELLARS,
                            "beroep" => TAG_FREE_PROFESSIONS,
                            "berging" => TAG_STOREROOMS,
                            "wasplaats" => TAG_LAUNDRY_ROOMS,
                            "elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
                            "beglazing" => TAG_DOUBLE_GLAZING,
                            "verwarming" => TAG_HEATING_NL,
                            "riolering" => TAG_CONNECTION_TO_SEWER,
                            "olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
                            "waterput" => TAG_WELL,
                            "telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
                            "toegangscontrole" => TAG_ACCESS_SEMIVALID,
                            "computer" => TAG_INTERNET_CONNECTION,
                            "nroerende_voorhef" => TAG_PROPERTY_TAX,
                                ),
                                        'fr' => array(  "prij" =>  TAG_PRICE,
                            "Meuble" => TAG_FURNISHED,
                            "facades" => TAG_AMOUNT_OF_FACADES,
                            "nombre_de_chambre"=> TAG_BEDROOMS_TOTAL,
                            "nombre_de_salle_de_bain"=> TAG_BATHROOMS_TOTAL,
                            "jardin" => TAG_GARDEN_AVAILABLE,
                            "garage" => TAG_GARAGES_TOTAL,
                            "terras" => TAG_TERRACES,
                            "parking" => TAG_PARKINGS_TOTAL,
                            "habita" => TAG_SURFACE_LIVING_AREA,
                            "terrain" => TAG_SURFACE_GROUND,
                            "disponible" => TAG_FREE_FROM,
                            "magasins" => TAG_DISTANCE_SHOPS,
                            "transport" => TAG_DISTANCE_PUBLIC_TRANSPORT,
                            "toilet" => TAG_TOILETS_TOTAL,
                            "construction_annee" => TAG_CONSTRUCTION_YEAR,
                            "renovation_annee" => TAG_RENOVATION_YEAR,
                            "tages" => TAG_AMOUNT_OF_FLOORS,
                            "alarm" => TAG_ALARM,
                            "gaz" => TAG_GAS_CONNECTION,
                            "eau" => TAG_CONNECTION_TO_WATER,
                            "parlophone" => TAG_PARLOPHONE,
                            "vitrage" => TAG_DOUBLE_GLAZING,
                            "network" => TAG_INTERNET_CONNECTION,
                            "douche" => TAG_SHOWERS_TOTAL,
                            "caves" => TAG_CELLARS,
                            "dressing" => TAG_DRESSINGS,
                            "telephone" => TAG_TELEPHONE,
                            "videophone" => TAG_VIDEOPHONE,
                            "manger" => TAG_DININGS,
                            "ecoles" => TAG_DISTANCE_SCHOOL,
                            "sejour" => TAG_SURFACE_LIVING_AREA,
                            "ascenseur" => TAG_LIFT,
                            "largeur_du_lot" => TAG_LOT_WIDTH,
                            "mazout" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
                            "citerne" => TAG_WELL,
                            "chauffage" => TAG_HEATING_FR,
                            "electricite " => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
                            "fax" => TAG_FAX,
                            "tel" => TAG_CELLPHONE,
                            "inondation" => TAG_FLOOD_INFORMATION_FR,
                            "egouts" => TAG_CONNECTION_TO_SEWER,
                            "cuisine" => TAG_KITCHEN_TYPE_FR,
                            "construction_type" => TAG_CONSTRUCTION_TYPE,
                            "chauffage" => TAG_HEATING_FR,
                            "debarras" => TAG_STOREROOMS,
                            "telephoniques" => TAG_TELEPHONE_CONNECTION,
                            "dacces" => TAG_ACCESS_SEMIVALID,
                            "lotissement" => TAG_SUBDIVISION_PERMIT,
                            "batir" => TAG_PLANNING_PERMISSION,
                            "cadastrales" => TAG_CADASTRAL_SECTION,
                            "prix" => TAG_PRICE, 
                            "epc" => TAG_EPC_VALUE,
                            "ki" => TAG_KI,
                            "mail" => TAG_EMAIL,
                            "commun" => TAG_COMMON_COSTS,
                            "feu" => TAG_OPEN_FIRE,
                            "beaucoup_de_profondeur" => TAG_LOT_DEPTH,
                            "facade_largeur" => TAG_FRONTAGE_WIDTH,
                            "emission_co2" => TAG_CO2_EMISSION,
                                                     ),
                );
    
    $keys = array_keys($attributeTagsArray[$language]); // Returning Keys
    $key = clearForLowerCase($key); // Converting to lower case
    
    foreach($keys as $k){
        
           $check = stripos("X$key","$k");
           if(!empty($check))
           return $attributeTagsArray[$language][$k];
        }
     
    return '';   
}

function GetExactAttrib($key,$val){
 
    $a = array();
    
    switch($key){
    case TAG_PROPERTY_TAX:
        return toNumber($val);
        break;  
    case TAG_PRICE:
        return toNumber($val);
        break;
    case TAG_CONSTRUCTION_YEAR:
        return toYear($val);
        break;
    case TAG_RENOVATION_YEAR:
        return toYear($val);
        break;
     case TAG_FREE_FROM_DATE:
        return toUnixTimestamp($val);
        break;
    case TAG_KI:
        return toNumber($val);
        break;
    case TAG_EPC_VALUE:
        return toEpc($val);
        break;
    case TAG_EPC_CERTIFICATE_NUMBER:
        return toNumber($val);
        break;
    case TAG_SURFACE_LIVING_AREA:
       return toNumber($val);
       break;
    case TAG_SURFACE_GROUND:
       return toNumber($val);
       break;
    case TAG_MOST_RECENT_DESTINATION:
       return trim($val);
       break;
    case TAG_PLANNING_PERMISSION:
       return $val;
       break;
    case TAG_SUBDIVISION_PERMIT:
       return toNumber($val); 
    break;

    case TAG_GARDEN_AVAILABLE:
       return 1; 
    break;
    
    case TAG_TERRACES:
       return $a[] = toNumber($val); 
    break;
    
    default:
    $val = trim($val);
    if($val=='Ja' || $val=='Nee' || $val=='Neen')
        return ($val=='Ja') ? 1 : 0;
    else{

        if(stripos($key,"available") !== false)
        return ($val=='Ja') ? 1 : 0;
    
        if(stripos($key,"_nl") !== false)
        return $val;
        
        if(stripos($key,"_fr") !== false)
        return $val;
    
        if(stripos($key,"_en") !== false)
        return $val;
        else
        return toNumber($val);
        
    }
    
    break;
     
    }
}

/// Basic checking for 
function clearForLowerCase($str = ''){ 
    $str = strtolower(str_replace(' ','_',$str)); 
    $str = trim(strip_tags($str)); 
    //$str = preg_replace('![^a-z0-9_\-\. ]!','',$str); 
    // $str = trim(preg_replace('!nbsp!','',$str)); 
    $str = trim(preg_replace('!ja,!','',$str));
    //$str = trim(preg_replace('!,!','',$str));
    $str = trim(normalize_str($str));
    return $str ;
 
}

function toNumber($str)
{
    ///return $str;
    $value = 0;
    $str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
    $str = preg_replace("/,(\d{3})|\.(\d{3})/",  "$1$2", $str);
    if(preg_match("/(-?\d+)/", $str, $match)) $value = intval($match[1]);
    
    if(empty($value))
    return 0;
    else
    return $value;
}

function toUnixTimestamp($str)
{
    return strtotime($str);
}

function toEpc($str){
    $epc = toNumber($str);
    if($epc > 0 && $epc <= 999) return $epc;
}

function toYear($str){
    $year = toNumber($str);
    if($year > 0 && strlen($year) == 4) return $year;
}

function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");
        foreach($invalid as $k => $v){
            $str = str_replace($k, $v, $str); //array_values($invalid)
        }

        return $str;
    }

/**
 * Get a Lat Long format other wise It will give XSD invalid
*/
function getLatLong($str)
{
    $str = floatval($str);
    return substr($str, 0, 8) ;
}

//function for print array
function debug($obj)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
    
    
}

//function for print string
function debugx($obj, $e = false)
{
    echo "<br />************************<br/>";
    echo $obj;
    echo "<br/>************************<br/>";
    if($e)
      exit;
}    