<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1674

require_once("./../crawler_classes.php");

$startPages[STATUS_FORSALE] = array
(
'http://www.immo-particulier.be/fr/vente-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-bruxelles-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/vente-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-brabant-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/vente-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-hainaut-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/vente-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-liege-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/vente-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-luxembourg-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/vente-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-namur-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/vente-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-anvers-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/vente-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-flandre-occidentale-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/vente-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-flandre-orientale-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/vente-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-Limbourg-1.html'=>TYPE_NONE,

    );

$startPages[STATUS_FORRENT] = array
(

'http://www.immo-particulier.be/fr/location-meuble-ou-non-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-bruxelles-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/location-meuble-ou-non-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-brabant-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/location-meuble-ou-non-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-hainaut-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/location-meuble-ou-non-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-liege-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/location-meuble-ou-non-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-luxembourg-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/location-meuble-ou-non-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-namur-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/location-meuble-ou-non-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-anvers-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/location-meuble-ou-non-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-flandre-occidentale-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/location-meuble-ou-non-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-flandre-orientale-1.html'=>TYPE_NONE,
'http://www.immo-particulier.be/fr/location-meuble-ou-non-studio-chambre-appartement-3chambres-loft-maison-surfaces-terrain-bureaux-commerces-parking-Limbourg-1.html'=>TYPE_NONE,

);


/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/
 
/*$html = file_get_contents("p-1.htm");
echo getNextPage($html);
exit;*/

/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "immoParticulier";
$office[TAG_OFFICE_URL] = "http://www.immo-particulier.be/";
$office[TAG_STREET] = "Vleurgatsesteenweg";
$office[TAG_NUMBER] = "184";
$office[TAG_ZIP] = "1000";
$office[TAG_CITY] = "Brussel";
$office[TAG_TELEPHONE] = "02.655.04.65";
$office[TAG_FAX] = "02.655.04.60";
$office[TAG_EMAIL] = "info@immo-particulier.be";
CrawlerTool::saveOffice($office);

foreach($startPages as $status => $types)
{
	foreach($types as $page => $type)
	{
		debugx($page); 
		$html = $crawler->request($page);
		processPage($crawler, $status, $type, $html);
		echo "Complete processing page ..." . "<br /><br />";

		$nextPage = getNextPage($html);
		unset($html);

		while(strlen($nextPage) > 0) {
			echo "Downloading page content..." . "<br />";
			debugx($nextPage); 
			$html = $crawler->request($nextPage);
			echo "Complete downloading page content..." . "<br />";

			// process page content
			echo "Processing page ..." . "<br />";
			processPage($crawler, $status, $type, $html);
			echo "Complete processing page ..." . "<br /><br />";

			$nextPage = getNextPage($html);
			unset($html);
		}
	}

}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function getUniqueId($url) {
	preg_match("/_(\d+)/", $url, $match);
	if($match) return $match[1];
}
/**
 *  Get next page
 */
function getNextPage($html) {
	$nextPage = "";
	$dom = new DOMDocument();
	$dom->preserveWhiteSpace = false;
	@$dom->loadHTML($html);
	$xpath = new DOMXPath($dom);
    $parser = new PageParser($html);

	$node = $parser->getNode("a[contains(text(), 'Page suivante')]");
	if($node) $nextPage = "http://www.immo-particulier.be" . $parser->getAttr($node, "href");

	// free memory used
	unset($dom);
	unset($xpath);

	return $nextPage;
}

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("div[contains(@id, 'annonce')]");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
		$n = $parser->getNode("h2/a", $node);
		if($n) $property[TAG_UNIQUE_URL_NL] = "http://www.immo-particulier.be" . $parser->getAttr($n, "href");
        $property[TAG_UNIQUE_ID] =  getUniqueId($property[TAG_UNIQUE_URL_NL]);
		$n = $parser->getNode("p[contains(@class, 'texte')]", $node);
		if($n) $property[TAG_TEXT_DESC_NL] = $parser->getText($n);
        if(empty($property[TAG_TEXT_DESC_NL])) {
		    $n = $parser->getNode("table/tr/td[1]", $node);
		    if($n) return $parser->getText($n);
        }
		$n = $parser->getNode("h2/a/span", $node);
		if($n) {
			$text = str_replace(".", "", $parser->getText($n));
			preg_match("/(.*)\//", $text, $match);
			if($match) {
				$price = CrawlerTool::toNumber($match[1]);
				if($price > 0) $property[TAG_PRICE] = $price;
			}
		}
		
		$n = $parser->getNode("h2/a/span", $node);
		if($n) {
			$text = $parser->getText($n);
			preg_match("/(\d+)\sm/", $text, $match);
			if($match) {
				$surf = CrawlerTool::toNumber($match[1]);
				if($surf > 0) $property[TAG_SURFACE_GROUND] = $surf;
			}
		}
		$n = $parser->getNode("h2/a/text()[1]", $node);
		if($n) {
			$text = $parser->getText($n);
			preg_match("/(.*)\s\((\d+)\)/", $text, $match);
			if($match) {
				$property[TAG_ZIP] = $match[2];
				$property[TAG_CITY] = trim(preg_replace("/\(.*\)/", "", $match[1]));
			}
		}
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...".$item["itemUrl"];
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("td[@id = 'contenu']");
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL]);
    $property[TAG_PICTURES] = $parser->extract_xpath("div[@class = 'photos-top']/img/@src | div[@class = 'photos-right']/img/@src", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) {
            $picUrls[] = array(TAG_PICTURE_URL => "http://www.immo-particulier.be".$pic);
        }

        return $picUrls;
    });

    $price = $parser->extract_xpath("div[@class = 'annonce detail panier-off']/h2/span"); 
	$pricex = explode('â‚¬', $price );
	if(empty($property[TAG_PRICE])) $property[TAG_PRICE] = intval(str_replace('.','',$pricex[0]));
	 
	 if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));

    if(empty($property[TAG_CITY])) return;
    debug($property);  
    $property[TAG_CITY] = removeBrackets($property[TAG_CITY]);
    // WRITING item data to output.xml file
    // Most Important 
    if($property[TAG_HAS_PROCEEDING] != '1')
        $property[TAG_HAS_PROCEEDING] = '';
          
    if($property['planning_permission'] != '1')
        $property['planning_permission'] = '';
            
    if($property['subdivision_permit'] != '1')
        $property['subdivision_permit'] = '';
            
    if($property['most_recent_destination'] != '1')
        $property['most_recent_destination'] = '';

    if($property[TAG_PRIORITY_PURCHASE] != '1')
        $property[TAG_PRIORITY_PURCHASE] = '';
    
    CrawlerTool::saveProperty($property);
}

function removeBrackets($str){
	$str = str_replace('–','',$str);
	$str = str_replace('(','',$str);
	$str = str_replace(')','',$str);
	$str = str_replace('-','',$str);
	return $str;
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}


function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
} 
