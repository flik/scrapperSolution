<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1122

require_once("../crawler_classes.php");


$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immo-wauters.be/Web.mvc/fr-fr/List1"
    )
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.immo-wauters.be/Web.mvc/fr-fr/List2"
    )
);


/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/




/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Immo WAUTERS";
$office[TAG_OFFICE_URL] = "http://www.immo-wauters.be";
$office[TAG_STREET] = "Rue des Champles";
$office[TAG_NUMBER] = "54";
$office[TAG_ZIP] = "1301";
$office[TAG_CITY] = "Bierges";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "010/22.21.00";
$office[TAG_FAX] = "010/22.24.02";
$office[TAG_EMAIL] = "info@immo-wauters.be";

CrawlerTool::saveOffice($office);

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);

            $parser = new PageParser($html);
            $numOfPages = $parser->regex("/pageNumber=(\d+)/", $parser->extract_xpath("a[@class = 'Link PaginationLink'][last()]/@href"));
            for($pageNum = 1; $pageNum <= $numOfPages; $pageNum++)
            {
                $html = $crawler->request($page . "?pageNumber=$pageNum");
                $numOfProperty = processPage($crawler, $status, $type, $html);
            }
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[contains(@href, 'Web.mvc/fr-fr/Detail')][img]");

    $items = array();
    foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_FR] = "http://www.immo-wauters.be" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_FR]);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_FR]);
    }   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    $propertyStatus = CrawlerTool::getPropertyStatus($parser->extract_xpath("title"));
    if(!empty($propertyStatus)) $property[TAG_STATUS] = $propertyStatus;
    $property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("div[@class = 'flash-description Text']/p[1]");
    $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("div[@id = 'details']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PICTURES] = $parser->extract_regex("/attr\('src', '(.*?)'/i", RETURN_TYPE_ARRAY, function($match)
    {
        $pics = $match[1];
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.immo-wauters.be" . $pic);

        return $picUrls;
    });

    $parser->extract_xpath("*[@class = 'SubtitleSmall4']", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(\d{4,})(.*)/", $text, $match))
        {
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
    });

    $parser->extract_xpath("p[@class = 'TitleSmall4']", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(\d{4,})(.*)/", $text, $match))
        {
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
        else
        {
            if(empty($property[TAG_CITY]))
            {
                $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $text));
            }
            else
            {
                CrawlerTool::parseAddress($text, $property);
            }
        }
    });

    // get bedroom surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'chambre') and contains(text(), 'surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_BEDROOMS][] = array(TAG_BEDROOM_SURFACE => $surf, TAG_BEDROOM_DESC_FR => $desc);
    }

    // get living room surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'salle de séjour') and contains(text(), 'surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_LIVINGS][] = array(TAG_LIVING_SURFACE => $surf, TAG_LIVING_DESC_FR => $desc);
    }

    // get bathroom surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'salle de bains') and contains(text(), 'surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_BATHROOMS][] = array(TAG_BATHROOM_SURFACE => $surf, TAG_BATHROOM_DESC_FR => $desc);
    }

    // get terrace surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'terrasse') and contains(text(), 'surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_TERRACES][] = array(TAG_TERRACE_SURFACE => $surf, TAG_TERRACE_DESC_FR => $desc);
    }

    // get garage surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'garage') and contains(text(), 'surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_GARAGES][] = array(TAG_GARAGE_SURFACE => $surf, TAG_GARAGE_DESC_FR => $desc);
    }

    // get kitchen surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'cuisine') and contains(text(), 'surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_KITCHENS][] = array(TAG_KITCHEN_SURFACE => $surf, TAG_KITCHEN_DESC_FR => $desc);
    }

    // get hall surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'hall') and contains(text(), 'surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_HALLS][] = array(TAG_HALL_SURFACE => $surf, TAG_HALL_DESC_FR => $desc);
    }

    // get dining surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'salle à manger surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_DININGS][] = array(TAG_DINING_SURFACE => $surf, TAG_DINING_DESC_FR => $desc);
    }

    // get attic surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'grenier surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_ATTICS][] = array(TAG_ATTIC_SURFACE => $surf, TAG_ATTIC_DESC_FR => $desc);
    }

    // get cellar surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'caves surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_CELLARS][] = array(TAG_CELLAR_SURFACE => $surf, TAG_CELLAR_DESC_FR => $desc);
    }

    // get laundry surface info
    $nodes = $parser->getNodes("div[@id = 'otherDetailsContent']/table/tr[td[contains(text(), 'buanderie surface')]]");
    foreach($nodes as $node)
    {
        $desc = $parser->getText($parser->getNode("td[1]", $node));
        $surf = CrawlerTool::toNumber($parser->getText($parser->getNode("td[2]", $node)));
        if($surf > 0) $property[TAG_LAUNDRY_ROOMS][] = array(TAG_LAUNDRY_ROOM_SURFACE => $surf, TAG_LAUNDRY_ROOM_DESC_FR => $desc);
    }

    $property[TAG_PRICE] = $parser->extract_xpath("div[contains(@class, 'detail-comment-price')]/p[2]", RETURN_TYPE_NUMBER);
    if(!empty($property[TAG_PRICE]) && $property[TAG_PRICE] < 5000) $property[TAG_STATUS] = STATUS_TORENT;

    $property[TAG_HEATING_FR] = $parser->extract_xpath("td[contains(text(), 'chauffage type') and not(contains(text(), '(ind/coll)'))]/following-sibling::td[1]");

    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    $property[TAG_COMMON_COSTS] = $parser->extract_xpath("charges (€) montant", RETURN_TYPE_NUMBER);
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("Catégorie"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_FR]);
    $property[TAG_EPC_VALUE] = $parser->extract_xpath("PEB (Br. - Wall.) consommation énergétique (kwh/m²)", RETURN_TYPE_EPC);
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("année de construction année", RETURN_TYPE_NUMBER);
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("rénovation annee", RETURN_TYPE_YEAR);
    $property[TAG_KI] = $parser->extract_xpath("revenu cadastral (€) montant", RETURN_TYPE_NUMBER);
    $property[TAG_KI_INDEX] = $parser->extract_xpath("rev. cad. indexé montant", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Facades", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Nombre de chambres", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Nombre de salle de bain", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toilettes nombre", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FLOORS] = $parser->extract_xpath("étages nombre", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("garage nombre", RETURN_TYPE_NUMBER);
    $property[TAG_PARKINGS_TOTAL] = $parser->extract_xpath("parking extérieur nombre", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Surface habitable", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Taille terrain (min.)", RETURN_TYPE_NUMBER);
    $property[TAG_FRONTAGE_WIDTH] = $parser->extract_xpath("largeur façade largeur", RETURN_TYPE_NUMBER);
    $property[TAG_DISTANCE_SHOPS] = $parser->extract_xpath("environs - magasins distance (m)", RETURN_TYPE_NUMBER);
    $property[TAG_DISTANCE_SCHOOL] = $parser->extract_xpath("environs - écoles distance (m)", RETURN_TYPE_NUMBER);
    $property[TAG_DISTANCE_PUBLIC_TRANSPORT] = $parser->extract_xpath("environs - transports en commun distance (m)", RETURN_TYPE_NUMBER);
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Disponible de", RETURN_TYPE_UNIX_TIMESTAMP);

    $surf = $parser->extract_xpath("cuisine - surface", RETURN_TYPE_NUMBER);
    if($surf > 0) $property[TAG_KITCHENS][] = array(TAG_KITCHEN_SURFACE => $surf);

    $surf = $parser->extract_xpath("grenier - surface (m²)", RETURN_TYPE_NUMBER);
    if($surf > 0) $property[TAG_ATTICS][] = array(TAG_ATTIC_SURFACE => $surf);

    $property[TAG_FURNISHED] = CrawlerTool::contains($parser->extract_xpath("Meublé"), "oui");
    $property[TAG_GARDEN_AVAILABLE] = CrawlerTool::contains($parser->extract_xpath("Jardin"), "oui");
    $property[TAG_ALARM] = CrawlerTool::contains($parser->extract_xpath("alarme"), "oui");
    $property[TAG_LIFT] = CrawlerTool::contains($parser->extract_xpath("ascenseur"), "oui");
    $property[TAG_DOUBLE_GLAZING] = CrawlerTool::contains($parser->extract_xpath("double vitrage"), "oui");
    $property[TAG_CONNECTION_TO_WATER] = CrawlerTool::contains($parser->extract_xpath("eau"), "oui");
    $property[TAG_GAS_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("gaz"), "oui");
    $property[TAG_TELEPHONE_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("téléphone"), "oui");
    $property[TAG_PARLOPHONE] = CrawlerTool::contains($parser->extract_xpath("parlophone"), "oui");
    $property[TAG_VIDEOPHONE] = CrawlerTool::contains($parser->extract_xpath("vidéophone"), "oui");

    
	// Most Important 
	if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
	$property['planning_proceeding'] = 0;
	
	
	if(!isset($property['planning_permission']) || empty($property['planning_permission']))
	$property['planning_permission'] = 0;
	
	
	if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
	$property['subdivision_permit'] = 0;
	 
	if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
	$property['most_recent_destination'] = 0;
	

    $property[TAG_UNIQUE_URL_NL] = str_replace('fr-fr','nl-be',$property[TAG_UNIQUE_URL_FR]);
    $property[TAG_UNIQUE_URL_EN] = str_replace('fr-fr','en-gb',$property[TAG_UNIQUE_URL_FR]);
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_NL]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	
        $property[TAG_TEXT_DESC_NL] = utf8_decode(CrawlerTool::encode(strip_tags($parser->extract_xpath("div[@class = 'flash-description Text']/p[1]"))));
        $property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode(CrawlerTool::encode(strip_tags($parser->extract_xpath("div[@id = 'details']", RETURN_TYPE_TEXT_ALL))));
   
	if(empty($property[TAG_TEXT_DESC_NL])){
		
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res); 
		$res[1] = str_replace(chr(11),'',$res[1]); 
		$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode(strip_tags($res[1]))); 
	}
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_EN]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 

        $property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode(strip_tags($parser->extract_xpath("div[@class = 'flash-description Text']/p[1]"))));
        $property[TAG_PLAIN_TEXT_ALL_EN] = utf8_decode(CrawlerTool::encode(strip_tags($parser->extract_xpath("div[@id = 'details']", RETURN_TYPE_TEXT_ALL))));
   	
	if(empty($property[TAG_TEXT_DESC_EN])){
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
		$res[1] = str_replace(chr(11),'',$res[1]);
		$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode(strip_tags($res[1])));
	}
        
 
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));


    //    CrawlerTool::test($property);
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}


//function for print array
function debug($obj)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}    
    
