<?php
/* ============================= CONFIG ============================= */
// Crawler ID 426
require_once("../crawler_classes.php");

CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.zkr.be/",
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.zkr.be/nl/te-koop.aspx",
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.zkr.be/nl/te-huur.aspx",
    ),
);
  
/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/



/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Zakenkantoor Robijns";
$office[TAG_OFFICE_URL] = "http://www.zkr.be";
$office[TAG_STREET] = "Grote Markt";
$office[TAG_NUMBER] = "7";
$office[TAG_ZIP] = "3440";
$office[TAG_CITY] = "Zoutleeuw";
$office[TAG_TELEPHONE] = "+32 (0)11/78.03.04";
$office[TAG_FAX] = "+32 (0)11/78.50.05";
CrawlerTool::saveOffice($office);

for($i=0; $i<10;$i++)
{
	$pageUrl1  = "http://www.zkr.be/Modules/ZoekModule/RESTService/SearchService.svc/GetPropertiesCount/3/0/0/1/0/0/0/0/0/0/0/0/0/0/0/20/".$i."/false/11625/NL/23/0/0/1/VURPJOEEANUDGXHJCFBICQTSMPUFCIPREFOVRWJMFDPXBLNZFG/10600713/0/0/1/0/11625/0/false/0/false/0/0/0?_=1416835946388";
    $html1 = $crawler->request($pageUrl1);
    processXML($crawler, STATUS_FORSALE, $type, $html1);
}


for($j=0; $j<10;$j++)
{
	$pageUrl2  = "http://www.zkr.be/Modules/ZoekModule/RESTService/SearchService.svc/GetPropertiesCount/3/0/0/2/0/0/0/0/0/0/0/0/0/0/0/20/".$j."/false/11626/NL/23/0/0/1/VURPJOEEANUDGXHJCFBICQTSMPUFCIPREFOVRWJMFDPXBLNZFG/0/0/0/1/0/11626/0/false/0/false/0/0/0?_=1416837094046";
    $html2 = $crawler->request($pageUrl2);
    processXML($crawler, STATUS_FORRENT, $type, $html2);
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


/**
 * Get a list of next pages
 */

function processXML($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $xml = simplexml_load_string($html);
    $xml = xml2array($xml);
    $items = array();
    
	foreach($xml as $node)
    {
    	$nodes = xml2array($node);
	
    	foreach($nodes as $n){
    		//debug($n);exit;
    		$property = array();
        	$property[TAG_STATUS] = $status;
        	$property[TAG_TYPE] = CrawlerTool::getPropertyType($n["Property_Type_Value"]);
        	$link = $n["Property_URL"];
	
        	$property[TAG_UNIQUE_URL_NL] =  'http://www.zkr.be/nl'.$link ;
        	$property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);

        	$property[TAG_TEXT_TITLE_NL] = $n["Property_Title"];
        	
        	$price = CrawlerTool::toNumber($n["Property_Price"]);
        	$property[TAG_PRICE] = $price;

        	if(!empty($n["Property_City_Value"])){
        		$city = $n["Property_City_Value"];
        		$property[TAG_CITY] = $city;
        	}

        	if(!empty($n["Property_Zip"])){
        		$zip = $n["Property_Zip"];
        		$property[TAG_ZIP] = $zip;
        	}

        	if(!empty($n["Property_Street"])){
        		$street = $n["Property_Street"];
        		$property[TAG_STREET] = $street;
        	}

        	if(!empty($n["Property_Number"])){
        		$property[TAG_NUMBER] = $n["Property_Number"];
        	}

        	if(!empty($n["Property_Description"])){
        		$description = $n["Property_Description"];
        		$property[TAG_TEXT_DESC_NL] = utf8_decode($description);
			}

			if(!empty($n["Property_Area_Ground"])){
        		$surface_ground = $n["Property_Area_Ground"];
        		$surface_ground = preg_replace("/[^0-9]/", "",$surface_ground);
        		$property[TAG_SURFACE_GROUND] = $surface_ground;
        	}

        	if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        	$properties[] = $property[TAG_UNIQUE_ID];

        	$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL],"itemId" => $n["FortissimmoID"]);
    	}
	}

	if(count($items) > 0){
		foreach($items as $item){
			$itemUrl = "http://www.zkr.be/Modules/DataModule/RESTService/DataService.svc/GetDetailManagement/VURPJOEEANUDGXHJCFBICQTSMPUFCIPREFOVRWJMFDPXBLNZFG/NL/".$item["itemId"];
			echo "--------- Processing property #$propertyCount ... ".$itemUrl;
			processItem($crawler, $item["item"], $crawler->request($itemUrl));
			echo "--------- Completed<br />";
		}
	}

}

/**
 * Download and extract item detail information http://www.av-vastgoed.be/images/panden/1366631738.jpg
 */
function processItem($crawler, $property, $html)
{
    $xml = simplexml_load_string($html);
    $xml = xml2array($xml);
    if(is_array($xml)){
		foreach($xml as $node){
			if(is_array($node["Pictures"]["PropertyPictures"])){
				$picUrls = array();	
				$picturesArr = xml2array($node["Pictures"]["PropertyPictures"]);
				if(is_array($picturesArr[0])){
					foreach($picturesArr as $pic){
						$picUrls[] = array(TAG_PICTURE_URL => "http://www.zkr.be/fortissimmo/zkr.be/images/".$pic["picture_file"]); 
					}
				}
				else{
					$picUrls[] = array(TAG_PICTURE_URL => "http://www.zkr.be/fortissimmo/zkr.be/images/".$picturesArr["picture_file"]); 
				}
				$property[TAG_PICTURES] = $picUrls;
			}
	 
			if(isset($node["Detail"]["bedrooms"])) $property[TAG_BEDROOMS_TOTAL] = $node["Detail"]["bedrooms"];
			if(isset($node["Detail"]["floors_total"])) $property[TAG_AMOUNT_OF_FLOORS] = $node["Detail"]["floors_total"];

			if(isset($node["Detail"]["latitude"])) $property[TAG_LATITUDE] = getLatLong(str_replace(',', '.', $node["Detail"]["latitude"]));
			if(isset($node["Detail"]["longitude"])) $property[TAG_LONGITUDE] = getLatLong(str_replace(',', '.', $node["Detail"]["longitude"]));
			$unmatched_variables = array();
			if(is_array($node["Layout"]["PropertyLayout"])){
				$layoutArr = xml2array($node["Layout"]["PropertyLayout"]);
				if(isset($layoutArr[0]["value"])){
					foreach($layoutArr as $lay){
						$count = CrawlerTool::toNumber($lay["count"]);
						if($lay["value"] == "Badkamer"){
							$property[TAG_BATHROOMS_TOTAL] = $count;
						}
						else if($lay["value"] == "Eetkamer"){
							$property[TAG_DININGS] = $count;
						}
						else if($lay["value"] == "Woonkamer"){
							$property[TAG_LIVINGS] = $count;
						}
						else if($lay["value"] == "Toilet"){
							$property[TAG_TOILETS_TOTAL] = $count;
						}
						else if($lay["value"] == "Keuken"){
							$property[TAG_KITCHENS] = $count;
						}
						else if($lay["value"] == "Slaapkamer"){
							$property[TAG_BEDROOMS_TOTAL] = $count;
						}
						else if($lay["value"] == "Zolder"){
							$property[TAG_ATTICS] = $count;
						}
						else if($lay["value"] == "Garage"){
							$property[TAG_GARAGES_TOTAL] = $count;
						}
						else if($lay["value"] == "Wasplaats"){
							$property[TAG_LAUNDRY_ROOMS] = $count;
						}
						else if($lay["value"] == "Berging"){
							$property[TAG_STOREROOMS] = $count;
						}
						else if($lay["value"] == "Tuin"){
							$property[TAG_GARDEN_AVAILABLE] = $count;
						}
						else if($lay["value"] == "Terras"){
							$property[TAG_TERRACES] = $count;
						}
						else if($lay["value"] == "Inkomhal"){
							$property[TAG_HALLS] = $count;
						}
						else{
							$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $lay["value"], TAG_VARIABLE_VALUE =>$lay["count"]);
						}
					}
				}
				else{
					$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $layoutArr["value"], TAG_VARIABLE_VALUE =>$layoutArr["count"]);	
				}
			}
		}
	}
	
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;

    $property[TAG_PLAIN_TEXT_ALL_NL] = $property[TAG_TEXT_DESC_NL]; 
     
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
      
    // Most Important 
    if(!isset($property['priority_purchase']) || empty($property['priority_purchase']) || $property['priority_purchase'] != "1")
    $property['priority_purchase'] = "";

    if(!isset($property['has_proceeding']) || empty($property['has_proceeding']) || $property['has_proceeding'] != "1")
    $property['has_proceeding'] = "";
    
    
    if(!isset($property['planning_permission']) || empty($property['planning_permission']) || $property['planning_permission'] != "1")
    $property['planning_permission'] = "";
    
    
    if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']) || $property['subdivision_permit'] != "1")
    $property['subdivision_permit'] = "";

    if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']) || $property['most_recent_destination'] != "1")
    $property['most_recent_destination'] = "";

	// if(empty($property[TAG_CITY]) || $property[TAG_CITY]=='u' || $property[TAG_CITY]==1 || empty($property[TAG_TYPE])){
	// 	return;
	// }
   if(strlen($property[TAG_ZIP]) < 4){
        $property[TAG_BOX_NUMBER]   = $property[TAG_ZIP];
        unset($property[TAG_ZIP]) ;
    }
    debug($property);
 
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
     

}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}
function xml2array ( $xmlObject, $out = array () )
{
    foreach ( (array) $xmlObject as $index => $node )
        $out[$index] = ( is_object ( $node ) ) ? xml2array ( $node ) : $node;

    return $out;
}


/**
 * Get a Lat Long format other wise It will give XSD invalid
*/
function getLatLong($str)
{
    return floatval(substr($str, 0, 8));
}
