<?php
require_once("./../crawler_classes.php");

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE    =>  array    (	"http://www.actavastgoed.be/Web.mvc/nl-be/List1"),
);

$startPages[STATUS_TORENT] = array
(
    TYPE_NONE    =>  array    ("http://www.actavastgoed.be/Web.mvc/nl-be/List2"),
);

CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
        }
	
	$nextPages = getNextPage($html);
	foreach($nextPages as $nextPage)
	{
	    $html = $crawler->request($nextPage);
	    processPage($crawler, $status, $type, $html);
	}		
    }
}

CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
  	static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);
    $nodes = $parser->getNodes("a[@target='_self'][img]");
    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
		$property_url = "http://www.actavastgoed.be/" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_URL_NL] = $property_url;
		if(preg_match('(\d+)', $property_url,$match)){
	   	   $property[TAG_UNIQUE_ID] =  $match[0];
		}
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}//CrawlerTool::test($items);
    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;
        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...<br />";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}


/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html,true);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_SHORT_DESC_NL] = utf8_decode($parser->extract_xpath("td[@class='Text'][@style='padding: 5px;']")); 
    $property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode($parser->extract_xpath("table[@id='details']", RETURN_TYPE_TEXT_ALL)); 

    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel='lightbox']/@href", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.actavastgoed.be".$pic);
        return $picUrls;
    });
    
    $parser->extract_xpath("td[@style='padding: 5px 5px 5px 5px;']//table//tr[last()]//td[2]", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
		//CrawlerTool::parseAddress($text, $property);

        if(preg_match("/(\d+)\s(.*)/", $text, $match))
        {
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
    });
  
	$rent_price = $parser->extract_xpath("td[contains(text(),'Prijs')]//strong", RETURN_TYPE_NUMBER);
	if($rent_price){
		$property[TAG_PRICE] = $rent_price;
	}
	
 	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
 
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_SHORT_DESC_NL]));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));
   
	$nodes = $parser->getNodes("table[@class='project-building']/tr/td[2]");
	 $project = 0;
	foreach($nodes as $node)
	{
		
		
		$link = $parser->extract_xpath("a[@class = 'Link']/@href", RETURN_TYPE_TEXT, null, $node);
		
		if(!empty($link)){
			
			$project = 1 ;
			$xproperty_url = "http://www.actavastgoed.be/" . $link;
			$xproperty[TAG_UNIQUE_URL_NL] = $property_url;
			$xproperty[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]) ;
			
			echo "--------- Processing inner property # ...<br />";
			
			$xhtml = $crawler->request( $property_url );
			
			$xparser = new PageParser($xhtml,true);
			$xparser->deleteTags(array("script", "style"));
		    
			$xproperty[TAG_TEXT_SHORT_DESC_NL] = utf8_decode($xparser->extract_xpath("td[@class='Text'][@style='padding: 5px;']")); 
			$xproperty[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode($xparser->extract_xpath("table[@id='details']", RETURN_TYPE_TEXT_ALL)); 
		    
			$xproperty[TAG_PICTURES] = $xparser->extract_xpath("a[@rel='lightbox']/@href", RETURN_TYPE_ARRAY, function($pics)
			{
			    $picUrls = array();
			    foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.actavastgoed.be".$pic);
			    return $picUrls;
			});
			
			$xparser->extract_xpath("td[@style='padding: 5px 5px 5px 5px;']//table//tr[last()]//td[2]", RETURN_TYPE_TEXT, function($text) use(&$property)
			{
				    //CrawlerTool::parseAddress($text, $property);
		    
			    if(preg_match("/(\d+)\s(.*)/", $text, $match))
			    {
				$xproperty[TAG_ZIP] = $match[1];
				$xproperty[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
			    }
			});
		      
			    $rent_price = $xparser->extract_xpath("td[contains(text(),'Prijs')]//strong", RETURN_TYPE_NUMBER);
			    if($rent_price){
				    $xproperty[TAG_PRICE] = $rent_price;
			    }
			    
			    if(empty($xproperty[TAG_TYPE])) $xproperty[TAG_TYPE] = CrawlerTool::getPropertyType($xparser->extract_xpath("head/title"));
		     
			    if(empty($xproperty[TAG_TYPE])) $xproperty[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($xproperty[TAG_TEXT_SHORT_DESC_NL]));
			    if(empty($xproperty[TAG_TYPE])) $xproperty[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($xproperty[TAG_PLAIN_TEXT_ALL_NL]));
					
					 // START using XPath query template
			    $xparser->setQueryTemplate("table[@cellpadding=1][@border=0][@style='width: 100%;']//td[contains(text(),'" .XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");
				
				$type = $xparser->extract_xpath("Categorie",RETURN_TYPE_TEXT);
				$tag_type = CrawlerTool::getPropertyType($type);
			    
				if(empty($xproperty[TAG_TYPE])) $xproperty[TAG_TYPE] = $tag_type;
			     
				$tag_bedrooms_total = $xparser->extract_xpath("Aantal kamers", RETURN_TYPE_NUMBER);
				if($tag_bedrooms_total)
					$xproperty[TAG_BEDROOMS_TOTAL] = $tag_bedrooms_total;	
				
			
			    $tag_bathrooms_total = $xparser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
				if($tag_bathrooms_total)
					$xproperty[TAG_BATHROOMS_TOTAL] = $tag_bathrooms_total;
					
						
				$tag_parking_total = $xparser->extract_xpath("Parking", RETURN_TYPE_TEXT)=="Ja"?1:0;
				if($tag_parking_total)
					$xproperty[TAG_PARKINGS_TOTAL]=$tag_parking_total;
			
				$tag_terrace_desc = $xparser->extract_xpath("Terras", RETURN_TYPE_TEXT);
				if($tag_terrace_desc)
					$xproperty[TAG_TERRACE_DESC_NL]=$tag_terrace_desc;
			
			
			    $tag_surface_area = $xparser->extract_xpath("oppervlakte oppervlakte", RETURN_TYPE_NUMBER);
				if(!empty($tag_surface_area)){
					$xproperty[TAG_SURFACE_GROUND] = $tag_surface_area;
			    }
			
			    $tag_surface_living_area = $xparser->extract_xpath("Bewoonbare oppervlakte", RETURN_TYPE_NUMBER);
				if(!empty($tag_surface_living_area)){
					$xproperty[TAG_SURFACE_LIVING_AREA] = $tag_surface_living_area;
			    }
			
				$TAG_KITCHEN_SURFACE = $xparser->extract_xpath("keuken oppervlakte", RETURN_TYPE_NUMBER);
				if(!empty($TAG_KITCHEN_SURFACE)){
					$xproperty[TAG_KITCHEN_SURFACE] = $TAG_KITCHEN_SURFACE;
			    }
				
				$TAG_DINING_SURFACE	 = $xparser->extract_xpath("eetkamer oppervlakte", RETURN_TYPE_NUMBER);
				if(!empty($TAG_DINING_SURFACE)){
					$xproperty[TAG_DINING_SURFACE] = $TAG_DINING_SURFACE;
			    }
				
				
				$tag_toilets = $xparser->extract_xpath("toiletten aantal", RETURN_TYPE_NUMBER);
				if($tag_toilets)
					$xproperty[TAG_TOILETS_TOTAL]=$tag_toilets;
			
			
				$tag_epc = $xparser->extract_xpath("EPC score (kwh", RETURN_TYPE_EPC);
				if($tag_epc)
					$xproperty[TAG_EPC_VALUE]=$tag_epc;
			
				$tag_epc_certificate = $xparser->extract_xpath("EPC (Br. - Wall.) CO2 uitstoot",RETURN_TYPE_TEXT_ALL);
				if($tag_epc_certificate)
					$xproperty[TAG_EPC_CERTIFICATE_NUMBER]=$tag_epc_certificate;
				
				$tag_construction_year = $xparser->extract_xpath("bouwjaar jaar", RETURN_TYPE_YEAR);
				if($tag_construction_year)
					$xproperty[TAG_CONSTRUCTION_YEAR]=$tag_construction_year;
				
				$tag_renovation_year = $xparser->extract_xpath("renovatie jaar", RETURN_TYPE_YEAR);
				if($tag_renovation_year)
					$xproperty[TAG_RENOVATION_YEAR]=$tag_renovation_year;
			
				$TAG_GAS_CONNECTION = $xparser->extract_xpath("gas", RETURN_TYPE_TEXT) == 'Ja'?1:0; 
				if($TAG_GAS_CONNECTION)
					$xproperty[TAG_GAS_CONNECTION]=$TAG_GAS_CONNECTION;
			
				$tag_heating_nl = $xparser->extract_xpath("verwarming type",RETURN_TYPE_TEXT);
				if($tag_heating_nl)
					$xproperty[TAG_HEATING_NL] = $tag_heating_nl;
					
		      CrawlerTool::saveProperty($xproperty); 
		       echo "--------- Completed<br />";
			
		       
		}  
	}
       
    $keys = $skips = $vals = $vars = array();
    
    $nodes = $parser->getNodes("table[@cellpadding=1][@border=0][@style='width: 100%;']/tr/td[1]");
   //debug($nodes);
   $skips = array('Contact', 'Algemeen', 'Bereikbaarheid', 'Terrein En/Of Omgeving', 'Binnenkant Gebouw', 'Buitenkant Gebouw', 'Financiele Aspecten', 'Documenten', 'Plan en prijzen 5de verdieping');
    
    foreach($nodes as $node)
    {
	 $v = str_replace('ë','e',(trim($parser->getText($node))));
	if(empty($v))
	 $keys[] = '-';
	 else{
	    if(!in_array($v,$skips))
		$keys[] = $v;
	 }
	 
     }
    //debug( $keys );
    $nodes = $parser->getNodes("table[@cellpadding=1][@border=0][@style='width: 100%;']/tr/td[2]");
    //debug($nodes);
    foreach($nodes as $node)
    {
	$v = utf8_decode(trim($parser->getText($node)));
	//debugx($v);
	if(empty($v))
	 $vals[] = '-';
	 else
	 $vals[] = $v;
	
    }
   // debug( $vals);
    foreach($vals as $k=>$x){
	
	 
	if($x=="Ja" || $x=="Nee")
	$vars[str_replace(' ','_',$keys[$k])] = ($x=="Ja"?1:0);
	else
	$vars[str_replace(' ','_',$keys[$k])] = $x;
    }
     
    
    // START using XPath query template
    $parser->setQueryTemplate("table[@cellpadding=1][@border=0][@style='width: 100%;']//td[contains(text(),'" .XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");
	
	$type = $parser->extract_xpath("Categorie",RETURN_TYPE_TEXT);
	$tag_type = CrawlerTool::getPropertyType($type);
    
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = $tag_type;
     
	$tag_bedrooms_total = $parser->extract_xpath("Aantal kamers", RETURN_TYPE_NUMBER);
	if($tag_bedrooms_total)
		$property[TAG_BEDROOMS_TOTAL] = $tag_bedrooms_total;	
	

    $tag_bathrooms_total = $parser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
	if($tag_bathrooms_total)
		$property[TAG_BATHROOMS_TOTAL] = $tag_bathrooms_total;
		
			
	$tag_parking_total = $parser->extract_xpath("Parking", RETURN_TYPE_TEXT)=="Ja"?1:0;
	if($tag_parking_total)
		$property[TAG_PARKINGS_TOTAL]=$tag_parking_total;

	$tag_terrace_desc = $parser->extract_xpath("Terras", RETURN_TYPE_TEXT);
	if($tag_terrace_desc)
		$property[TAG_TERRACE_DESC_NL]=$tag_terrace_desc;


    $tag_surface_area = $parser->extract_xpath("oppervlakte oppervlakte", RETURN_TYPE_NUMBER);
	if(!empty($tag_surface_area)){
		$property[TAG_SURFACE_GROUND] = $tag_surface_area;
    }

    $tag_surface_living_area = $parser->extract_xpath("Bewoonbare oppervlakte", RETURN_TYPE_NUMBER);
	if(!empty($tag_surface_living_area)){
		$property[TAG_SURFACE_LIVING_AREA] = $tag_surface_living_area;
    }

	$TAG_KITCHEN_SURFACE = $parser->extract_xpath("keuken oppervlakte", RETURN_TYPE_NUMBER);
	if(!empty($TAG_KITCHEN_SURFACE)){
		$property[TAG_KITCHEN_SURFACE] = $TAG_KITCHEN_SURFACE;
    }
	
	$TAG_DINING_SURFACE	 = $parser->extract_xpath("eetkamer oppervlakte", RETURN_TYPE_NUMBER);
	if(!empty($TAG_DINING_SURFACE)){
		$property[TAG_DINING_SURFACE] = $TAG_DINING_SURFACE;
    }
	
	
	$tag_toilets = $parser->extract_xpath("toiletten aantal", RETURN_TYPE_NUMBER);
	if($tag_toilets)
		$property[TAG_TOILETS_TOTAL]=$tag_toilets;


	$tag_epc = $parser->extract_xpath("EPC score (kwh", RETURN_TYPE_EPC);
	if($tag_epc)
		$property[TAG_EPC_VALUE]=$tag_epc;

	$tag_epc_certificate = $parser->extract_xpath("EPC (Br. - Wall.) CO2 uitstoot",RETURN_TYPE_TEXT_ALL);
	if($tag_epc_certificate)
		$property[TAG_EPC_CERTIFICATE_NUMBER]=$tag_epc_certificate;
	
	$tag_construction_year = $parser->extract_xpath("bouwjaar jaar", RETURN_TYPE_YEAR);
	if($tag_construction_year)
		$property[TAG_CONSTRUCTION_YEAR]=$tag_construction_year;
	
	$tag_renovation_year = $parser->extract_xpath("renovatie jaar", RETURN_TYPE_YEAR);
	if($tag_renovation_year)
		$property[TAG_RENOVATION_YEAR]=$tag_renovation_year;

	$TAG_GAS_CONNECTION = $parser->extract_xpath("gas", RETURN_TYPE_TEXT) == 'Ja'?1:0; 
	if($TAG_GAS_CONNECTION)
		$property[TAG_GAS_CONNECTION]=$TAG_GAS_CONNECTION;

	$tag_heating_nl = $parser->extract_xpath("verwarming type",RETURN_TYPE_TEXT);
	if($tag_heating_nl)
		$property[TAG_HEATING_NL] = $tag_heating_nl;

	/*
	$unmatched_var_arr = array('Beschikbaar vanaf','Grootte terrein','keuken type','Tuin','buurt type','vloerbedekking type','vloerbedekking type','riolering','olietank','dubbele beglazing','schrijnwerkerij type','wasplaats');
	foreach($unmatched_var_arr as $var){
		$tag_unmatched_var = $parser->extract_xpath($var, RETURN_TYPE_TEXT);
		if($tag_unmatched_var){
			if($tag_unmatched_var=="Ja" || $tag_unmatched_var=="Nee")
				$property[TAG_UNMATCHED_VARIABLES][]=array(TAG_VARIABLE_LABEL=>$var,TAG_VARIABLE_VALUE=>$tag_unmatched_var=="Ja"?1:0);
			else
				$property[TAG_UNMATCHED_VARIABLES][]=array(TAG_VARIABLE_LABEL=>$var,TAG_VARIABLE_VALUE=>$tag_unmatched_var);
		}		
	}
	*/
		
	$tag_free_from_date = $parser->extract_xpath("Beschikbaar vanaf", RETURN_TYPE_NUMBER);
	if($tag_free_from_date)
	    $property[TAG_FREE_FROM_DATE] = $tag_free_from_date;

	$unmatched_variables = array(); 
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	}
	
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
    
	// Most Important 
	if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
	$property['planning_proceeding'] = 0;
	
	
	if(!isset($property['planning_permission']) || empty($property['planning_permission']))
	$property['planning_permission'] = 0;
	
	
	if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
	$property['subdivision_permit'] = 0;
	 
	if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
	$property['most_recent_destination'] = 0;
	
	 
	if(empty($property[TAG_CITY]))
	return;
    
	if($project==1){
		
			debug($property);
        CrawlerTool::saveProject($property);
	}
	else
	CrawlerTool::saveProperty($property);
		// WRITING item data to output.xml file
    
}


/**
 * Get a list of next pages
 */
function getNextPage($html)
{
	$parser = new PageParser($html);
	$pages = array();
	$nodes = $parser->getNodes("a[@class='Link PaginationLink'][last()]");
		if($nodes)
		{
			foreach($nodes as $node)
			{
				$link_found = $parser->getAttr($node, "href");
				$link_found = str_replace("isAjaxRequest=True","isAjaxRequest=False",$link_found);
				$pages[] = "http://www.actavastgoed.be" . $link_found;
			}
		}
	return array_unique($pages);
}


/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}