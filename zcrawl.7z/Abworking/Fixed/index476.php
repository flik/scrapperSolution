<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

/* ============================= CONFIG ============================= */

// Crawler ID 476
require_once("./../crawler_classes.php");

CrawlerTool::setDefault(array(TAG_OFFICE_URL => "http://www.hetimmohuis.be"));

$startPages[STATUS_FORSALE] = array(
  TYPE_NONE => array(
    "http://www.hetimmohuis.be/nl/te-koop",
  ),
);


$startPages[STATUS_FORRENT] = array(
  TYPE_NONE => array(
    "http://www.hetimmohuis.be/nl/te-huur",
  ),
);

/* ============================= END CONFIG ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Het Immohuis";
$office[TAG_OFFICE_URL] = "http://www.hetimmohuis.be/";
$office[TAG_STREET] = "Abeelplein";
$office[TAG_NUMBER] = "15";
$office[TAG_ZIP] = "3840";
$office[TAG_CITY] = "Borgloon";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "+32 (0)12 26 22 05";
$office[TAG_FAX] = "+32 (0)12 26 28 91";
$office[TAG_EMAIL] = "info@hetimmohuis.be";
CrawlerTool::saveOffice($office);

foreach ($startPages as $status => $types) {
  foreach ($types as $type => $pages) {
    foreach ($pages as $page) {
      $html = $crawler->request($page);
      //processPage($crawler, $status, $type, $html);
      $nextPages = getPages($html);
      
      foreach ($nextPages as $nextPage) {
        debugx($nextPage);
        $html = $crawler->request($nextPage);
        processPage($crawler, $status, $type, $html);
      }
    }
  }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html) {
  static $propertyCount = 0;
  static $properties = array();
  
  $parser = new PageParser($html);
  
  $nodes = $parser->getNodes("div[@class='image']/a");
  
  $items = array();
  foreach ($nodes as $node) {
    $property = array();
    $property[TAG_STATUS] = $status;
    $property[TAG_TYPE] = $type;
    $property[TAG_UNIQUE_URL_NL] = "http://www.hetimmohuis.be".$parser->getAttr($node, "href");
    $property[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
    
    if (in_array($property[TAG_UNIQUE_ID], $properties)) {
      continue;
    }
    $properties[] = $property[TAG_UNIQUE_ID];
    
    $items[] = array(
      "item" => $property,
      "itemUrl" => $property[TAG_UNIQUE_URL_NL],
    );
  }
  // CrawlerTool::test($items);
  foreach ($items as $item) {
    // keep track of number of properties processed
    $propertyCount += 1;
    
    // process item to obtain detail information
    echo "--------- Processing property #$propertyCount ...";
    processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
    echo "--------- Completed<br />";
  }
  
  return sizeof($items);
}

/**
 * Get a list of next pages
 */
function getPages($html) {
  $parser = new PageParser($html);
  
  $pages = array();
  
  $nodes = $parser->getNodes("div[@class = 'pagination ']/ul/li/a");
  
  if (!empty($nodes)) {
    foreach ($nodes as $node) {
      if (strstr("http://www.hetimmohuis.be".$parser->getAttr($node, "href"), '/nl/')) {
        $pages[] = "http://www.hetimmohuis.be".$parser->getAttr($node, "href");
      }
    }
  }
  
  return array_unique($pages);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html) {
  $parser = new PageParser($html, true);
  $parser->deleteTags(array("script", "style"));
  
  $property[TAG_TEXT_DESC_NL] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@class = 'group']", RETURN_TYPE_TEXT_ALL)));
  $property[TAG_PLAIN_TEXT_ALL_NL] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@id = 'PropertyRegion']", RETURN_TYPE_TEXT_ALL)));
  
  $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'colorBoxImg']", RETURN_TYPE_ARRAY,

  function($pics) {
    $picUrls = array();
    foreach ($pics as $pic) {
      $picUrls[] = array(
        TAG_PICTURE_URL => $pic,
      );
    }
    return $picUrls;
  });
  
  $property[TAG_PRICE] = $parser->extract_regex("h3[@class='pull-right rightside']", RETURN_TYPE_NUMBER);
  
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));
  }
  
  $property[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY,

  function($files) {
    $fileUrls = array();
    foreach ($files as $file) {
      if (!empty($file)) {
        $fileUrls[] = array(
          TAG_FILE_URL_NL => "http://www.hetimmohuis.be/".str_replace('../',
          '',
          $file),
        );
      }
    }
    return $fileUrls;
  });
  
  $vars = $arr = array();
  
  $nodes = $parser->getNodes("div[@class = 'field']");
  
  foreach ($nodes as $node) {
    $arr[1] = $parser->extract_xpath("div[@class= 'name']", RETURN_TYPE_TEXT, null, $node);
    $arr[2] = $parser->extract_xpath("div[@class= 'value']", RETURN_TYPE_TEXT, null, $node);
    $arr[1] = strtolower($arr[1]);
    $arr[1] = trim(strip_tags($arr[1]));
    $arr[1] = preg_replace('![^a-z0-9_\-\. ]!', '', $arr[1]);
    $arr[1] = trim(preg_replace('!nbsp!', '', $arr[1]));
    
    if ($arr[2] == 'prijs') {
      if (empty($property[TAG_PRICE])) {
        $property[TAG_PRICE] = toNumber(trim($arr[2]));
      }
    }
    

    if (!empty($arr[1])) {
      $vars[str_replace(' ', '_', $arr[1])] = trim(utf8_decode($arr[2]));
    }
  }
  
  //----------------------------------------------------------------------------------//
  $unmatched_variables = array();
  $address = '';
  foreach ($vars as $label => $value) {
    
    if ($label == 'adres') {
      $address = $value;
    }
    
    $attribute = getAttributes($label);
    
    if (!empty($attribute)) {
      if (empty($property[$attribute])) {
        $property[$attribute] = GetExactAttrib($attribute, $value);
      }
    }
    else {
      $unmatched_variables[] = array(
        TAG_VARIABLE_LABEL => $label,
        TAG_VARIABLE_VALUE => $value,
      );
    }
  }
  ///Obligatory Attrib Info
  if (!isset($property[TAG_HAS_PROCEEDING]) || $property[TAG_HAS_PROCEEDING] != 1) {
    $property[TAG_HAS_PROCEEDING] = '';
  }
  
  if (!isset($property['planning_permission']) || $property['planning_permission'] != 1) {
    $property['planning_permission'] = '';
  }
  

  if (!isset($property['subdivision_permit']) || $property['subdivision_permit'] != 1) {
    $property['subdivision_permit'] = '';
  }
  

  if (!isset($property['most_recent_destination']) || $property['most_recent_destination'] != 1) {
    $property['most_recent_destination'] = '';
  }
  
  $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
  
  if (!empty($address)) {
    
    CrawlerTool::parseAddress(preg_replace("/,|\//", "", $address), $property);
    
    $addr = explode(' ', $address);
    $property[TAG_CITY] = trim($addr[count($addr) - 1]);
    $property[TAG_ZIP] = $parser->regex("/(\d{4})/", $address);
    
    $property[TAG_STREET] = str_replace($property[TAG_CITY], '', $property[TAG_STREET]);
    $property[TAG_STREET] = str_replace($property[TAG_ZIP], '', $property[TAG_STREET]);
    
    $property[TAG_NUMBER] = str_replace($property[TAG_CITY], '', $property[TAG_NUMBER]);
    $property[TAG_NUMBER] = str_replace($property[TAG_ZIP], '', $property[TAG_NUMBER]);
    
    if (empty($property[TAG_CITY])) {
      $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER]));
    }
    
    unset($property[TAG_BOX_NUMBER]);
  }
  da($property);
  //CrawlerTool::test($property);
  // WRITING item data to output.xml file
  CrawlerTool::saveProperty($property);
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array and exit debug exit = de
function de($obj, $e = false) {
  echo "<pre>";
  print_r($obj);
  echo "</pre>";
  
  exit;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array debug all = da
function da($obj, $e = false) {
  echo "<pre>";
  print_r($obj);
  echo "</pre>";
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false) {
  echo "<pre>";
  print_r($obj);
  echo "</pre>";
  if ($e) {
    exit;
  }
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false) {
  echo "<br />************************<br/>";
  echo $obj;
  echo "<br/>************************<br/>";
  if ($e) {
    exit;
  }
}

function getAttributes($key, $language = 'nl') {
  //String Function always return string
  $attributeTagsArray = array(
    'en' => array(
      'pric' => TAG_PRICE,
      'constr' => TAG_CONSTRUCTION_YEAR,
      'ground' => TAG_SURFACE_GROUND,
      'living' => TAG_SURFACE_LIVING_AREA,
      'bath' => TAG_BATHROOMS_TOTAL,
      'warm' => TAG_HEATING_EN,
      'heat' => TAG_HEATING_EN,
      'sewer' => TAG_CONNECTION_TO_SEWER,
      'telep' => TAG_TELEPHONE_CONNECTION,
      'intern' => TAG_INTERNET_CONNECTION,
      'permission' => TAG_PLANNING_PERMISSION,
      'subdivision' => TAG_SUBDIVISION_PERMIT,
      'electri' => TAG_METER_FOR_ELECTRICITY,
      'hall' => TAG_HALLS,
      'dining' => TAG_DININGS,
      'kitch' => TAG_KITCHENS,
      'laundr' => TAG_LAUNDRY_ROOMS,
      'dress' => TAG_DRESSING,
      'bed' => TAG_BEDROOMS_TOTAL,
      'room' => TAG_BEDROOMS_TOTAL,
      'park' => TAG_PARKINGS,
      'garage' => TAG_GARAGES_TOTAL,
      'type' => TAG_TYPE,
      'garden' => TAG_GARDEN_AVAILABLE,
      'floor' => TAG_AMOUNT_OF_FLOORS,
      'winter' => TAG_WINTERGARDENS,
      'furnish' => TAG_FURNISHED,
      'water' => TAG_CONNECTION_TO_WATER,
      'lift' => TAG_LIFT,
      'glaz' => TAG_DOUBLE_GLAZING,
      'terrac' => TAG_TERRACES,
      'fronts' => TAG_AMOUNT_OF_FACADES,
      'category' => TAG_TYPE,
      'free' => TAG_FREE_FROM_DATE,
      'habit' => TAG_SURFACE_LIVING_AREA,
      'plot' => TAG_SURFACE_GROUND,
      'shops' => TAG_DISTANCE_SHOPS,
      'schools' => TAG_DISTANCE_SCHOOL,
      'transport' => TAG_DISTANCE_PUBLIC_TRANSPORT,
      'shower' => TAG_SHOWERS_TOTAL,
      'stor' => TAG_STOREROOMS,
      'gas' => TAG_GAS_CONNECTION,
      'alarm' => TAG_ALARM,
      'security' => TAG_SECURITY_DOOR,
      'parlo' => TAG_PARLOPHONE,
      'video' => TAG_VIDEOPHONE,
      'elevat' => TAG_LIFT,
      'blind' => TAG_SUN_BLINDS,
      'renova' => TAG_RENOVATION_YEAR,
      'control' => TAG_ACCESS_SEMIVALID,
    ),
    'nl' => array(
      "prij" => TAG_PRICE,
      "bouwjaar" => TAG_CONSTRUCTION_YEAR,
      "grondopp" => TAG_SURFACE_GROUND,
      "bewoonbare" => TAG_SURFACE_LIVING_AREA,
      "slaapkamer" => TAG_BEDROOMS_TOTAL,
      "badkam" => TAG_BATHROOMS_TOTAL,
      "epc" => TAG_EPC_VALUE,
      "ki" => TAG_KI,
      "verdieping" => TAG_AMOUNT_OF_FLOORS,
      "living" => TAG_SURFACE_LIVING_AREA,
      "renovatie" => TAG_RENOVATION_YEAR,
      "kadaster sectie" => TAG_CADASTRAL_SECTION,
      "beschikbaar" => TAG_FREE_FROM,
      "fax" => TAG_FAX,
      "tel" => TAG_CELLPHONE,
      "mail" => TAG_EMAIL,
      "winkels" => TAG_DISTANCE_SHOPS,
      "vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
      "overstromings" => TAG_FLOOD_INFORMATION_NL,
      "garage" => TAG_GARAGES_TOTAL,
      "toilet" => TAG_TOILETS_TOTAL,
      "parking" => TAG_PARKINGS_TOTAL,
      "gevels" => TAG_AMOUNT_OF_FACADES,
      "lasten" => TAG_COMMON_COSTS,
      "gas" => TAG_GAS_CONNECTION,
      "water" => TAG_CONNECTION_TO_WATER,
      "telefoon" => TAG_TELEPHONE,
      "lift" => TAG_LIFT,
      "gemeubeld" => TAG_FURNISHED,
      "tuin" => TAG_GARDEN_AVAILABLE,
      "haard" => TAG_OPEN_FIRE,
      "alarm" => TAG_ALARM,
      "parlofoon" => TAG_PARLOPHONE,
      "videofoon" => TAG_VIDEOPHONE,
      "breedte" => TAG_LOT_WIDTH,
      "diepte" => TAG_LOT_DEPTH,
      "constructie" => TAG_CONSTRUCTION_TYPE,
      "gevelbreedte" => TAG_FRONTAGE_WIDTH,
      "winkel" => TAG_HEATING_NL,
      "douche" => TAG_SHOWERS_TOTAL,
      "keuken" => TAG_KITCHEN_TYPE_NL,
      "ligging" => TAG_SUBDIVISION_PERMIT,
      "stedenbouwkundige" => TAG_PLANNING_PERMISSION,
      "terras" => TAG_TERRACES,
      "terrein" => TAG_SURFACE_GROUND,
      "scholen" => TAG_DISTANCE_SCHOOL,
      "oppervlakte" => TAG_SURFACE_LIVING_AREA,
      "eetkamer" => TAG_DININGS,
      "dressing" => TAG_DRESSINGS,
      "kelder" => TAG_CELLARS,
      "beroep" => TAG_FREE_PROFESSIONS,
      "berging" => TAG_STOREROOMS,
      "wasplaats" => TAG_LAUNDRY_ROOMS,
      "elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
      "beglazing" => TAG_DOUBLE_GLAZING,
      "verwarming" => TAG_HEATING_NL,
      "riolering" => TAG_CONNECTION_TO_SEWER,
      "olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
      "waterput" => TAG_WELL,
      "telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
      "toegangscontrole" => TAG_ACCESS_SEMIVALID,
      "computer" => TAG_INTERNET_CONNECTION,
    ),
    'fr' => array(
      "prij" => TAG_PRICE,
    ),
  );
  
  $keys = array_keys($attributeTagsArray[$language]);
  // Returning Keys
  $key = clearForLowerCase($key);
  // Converting to lower case
  foreach ($keys as $k) {
    
    $check = stripos("X$key", "$k");
    if (!empty($check)) {
      return $attributeTagsArray[$language][$k];
    }
  }
  
  return '';
}


/// Basic checking for
function clearForLowerCase($str = '') {
  $str = strtolower($str);
  $str = trim(strip_tags($str));
  // $str = preg_replace('![^a-z0-9_\-\. ]!','',$str);
  // $str = trim(preg_replace('!nbsp!','',$str));
  // $str = trim(preg_replace('!m!','',$str));
  //   $str = trim(preg_replace('!ja,!','',$str));
  return trim(utf8_decode($str));
}

function GetExactAttrib($key, $val) {
  //debugx($key.'~'.$val);
  switch ($key) {
    case TAG_PRICE:
    return toNumber($val);
    break;

    
    case TAG_BATHROOMS_TOTAL:
    return toNumber($val);
    break;

    
    case TAG_BEDROOMS_TOTAL:
    return toNumber($val);
    break;

    
    case TAG_GARAGES_TOTAL:
    return toNumber($val);
    break;

    
    case TAG_TOILETS_TOTAL:
    return toNumber($val);
    break;

    
    case TAG_CONSTRUCTION_YEAR:
    return toNumber($val);
    break;

    
    case TAG_RENOVATION_YEAR:
    return toNumber($val);
    break;

    
    case TAG_FREE_FROM_DATE:
    return toNumber($val);
    break;

    
    case TAG_KI:
    return toNumber($val);
    break;

    
    case TAG_EPC_VALUE:
    return toNumber($val);
    break;

    
    case TAG_EPC_CERTIFICATE_NUMBER:
    return toNumber($val);
    break;

    
    case TAG_SURFACE_LIVING_AREA:
    return toNumber($val);
    break;

    
    case TAG_SURFACE_GROUND:
    return toNumber($val);
    break;

    
    case TAG_MOST_RECENT_DESTINATION:
    return trim($val);
    break;

    
    case TAG_PLANNING_PERMISSION:
    return 1;
    break;

    
    case TAG_SUBDIVISION_PERMIT:
    return toNumber($val);
    break;

    
    default:
    $val = trim($val);
    if ($val == 'Ja' || $val == 'Nee') {
      return($val == 'Ja') ? 1 : 0;
    }
    break;
  }
}

function toNumber($str) {
  ///return $str;
  $value = 0;
  $str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
  $str = preg_replace("/,(\d{3})|\.(\d{3})/", "$1$2", $str);
  if (preg_match("/(-?\d+)/", $str, $match)) {
    $value = intval($match[1]);
  }
  return $value;
}

