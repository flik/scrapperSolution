<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1096

require_once("../crawler_classes.php");


CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.vergimmo.be/"
    )
);


$startPages[STATUS_FORSALE] = array
(
    
    TYPE_HOUSE        =>  array
    (
        "http://www.vergimmo.be/woningen-te-koop/"
    ),
    TYPE_APARTMENT    =>  array
    (
        "http://www.vergimmo.be/appartementen-te-koop/"
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_HOUSE        =>  array
    (
        "http://www.vergimmo.be/woningen-te-huur/"
    ),
    TYPE_APARTMENT    =>  array
    (
        "http://www.vergimmo.be/appartementen-te-huur/"
    ),
);


/* ============================= END CONFIG ============================= */
/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


// START writing data to output.xml file
CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1; 
$office[TAG_OFFICE_NAME] = "Vergimmo"; 
$office[TAG_OFFICE_URL] = "http://www.vergimmo.be/"; 
$office[TAG_STREET] = "Antwerpsesteenweg"; 
$office[TAG_NUMBER] = "174"; 
$office[TAG_ZIP] = "2950"; 
$office[TAG_CITY] = "Kapellen"; 
$office[TAG_COUNTRY] = "Belgium"; 
$office[TAG_TELEPHONE] = "03 354 45 10"; 
$office[TAG_FAX] = "03 354 45 13"; 
$office[TAG_EMAIL] = "info@vergimmo.be"; 
CrawlerTool::saveOffice($office);


foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[. = 'Lees meer']");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_NL] = "http://www.vergimmo.be/" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
        $property[TAG_PRICE] = $parser->extract_xpath("parent::div[1]/preceding-sibling::span[@class = 'price']", RETURN_TYPE_NUMBER, null, $node);
        $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $parser->extract_xpath("parent::div[1]/preceding-sibling::h2[@class = 'header-info']", RETURN_TYPE_TEXT, null, $node)));
        CrawlerTool::parseAddress($parser->extract_xpath("parent::div[1]/preceding-sibling::p[@class = 'description font2']/a/text()[1]", RETURN_TYPE_TEXT, null, $node), $property);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}


/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("div[@class = 'font2 description']/p[1] | div[@class = 'font2 description']/ul[1]", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@id = 'content']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@class = 'lightbox']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "" . $pic);

        return $picUrls;
    });

    $parser->extract_xpath("div[@class= 'col-right detail']/p", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(.*)(\d{4,})/", $text, $match))
        {
            $property[TAG_ZIP] = $match[2];
        }
    });

    $property[TAG_EPC_VALUE] = $parser->extract_regex("/([\d,\d]+)\skwh/i", RETURN_TYPE_EPC);
    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_regex("/(\d+)\skwh/i", RETURN_TYPE_EPC);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_regex("/(\d)&nbsp;(ruime slaapkamer|slaapkamers)/", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_regex("/(\d)\ssBadkamer/i", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("li[contains(text(), 'Oppervlakte grond')]", RETURN_TYPE_NUMBER);
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("p[contains(text(), 'Beschikbaar vanaf')]/strong", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM_DATE] = $parser->extract_regex("/vanaf\s(.*?)</", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM] = $parser->extract_regex("/vanaf\s(.*?)\./");
    $property[TAG_LIFT] = CrawlerTool::contains($parser->extract_regex("/(Lift)/i"), "Lift");

    if(!isset($property[TAG_HAS_PROCEEDING]) || $property[TAG_HAS_PROCEEDING] !=1 )
	$property[TAG_HAS_PROCEEDING] = '';
	
	if(!isset($property['planning_permission']) || $property['planning_permission'] !=1)
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || $property['subdivision_permit'] !=1)
	$property['subdivision_permit'] = '';
	
	
	if(!isset($property['most_recent_destination']) || $property['most_recent_destination'] !=1)
	$property['most_recent_destination'] = '';
		
	debug($property);
	//CrawlerTool::test($property);
	// WRITING item data to output.xml file
	CrawlerTool::saveProperty($property);
}


//function for print array
function debug($obj)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}    
    
    