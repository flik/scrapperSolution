<?php

// Crawler ID 720   http://www.sissau.be/

require_once("../crawler_classes.php");

$startPages[STATUS_FORSELL] = array
(
    TYPE_NONE        =>  array
    (
        "http://verkoop.sissau.be/nl/verkoop?view=list&page=1&goal=0",
	"http://www.sissau.be/nieuwbouw/index.asp?T=NL",
	"http://verkoop.sissau.be/nl/verkoop",
	
		
    ),
);

$startPages[STATUS_TORENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://jaarverhuur.sissau.be/nl/jaarverhuur",
    ),
);

CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "AGENCE SISSAU";
$office[TAG_OFFICE_URL] = "http://jaarverhuur.sissau.be/";
$office[TAG_STREET] = "Zeedijk";
$office[TAG_NUMBER] = "127-128";
$office[TAG_ZIP] = "8430";
$office[TAG_CITY] = "Middelkerke";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = " 059 301991, 059 302260";
$office[TAG_FAX] = "059 305623";
$office[TAG_EMAIL] = "info@sissau.be";
CrawlerTool::saveOffice($office);

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        { 
		    $html = $crawler->request($page);
		    debugx($page);
		    processPage($crawler, $status, $type, $html);
			 $nextPages = getPages($html);
            foreach($nextPages as $nextPage)
            {
		debugx($nextPage);
                $html = $crawler->request($nextPage);
                processPage($crawler, $status, $type, $html);
            }
        }
    }
}

CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount=0;
    static $properties=array();
    $parser = new PageParser($html);
	
	$uri = ($status==STATUS_FORSELL) ? 'http://verkoop.sissau.be' : 'http://jaarverhuur.sissau.be';
	
    $nodes = $parser->getNodes("div[@class='image']/a");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
		$property[TAG_PRICE]=CrawlerTool::toNumber($parser->regex('@<div class="price-item">([^<>]+)</div>@',$parser->getHTML($parser->parentNode($node,"3"))));
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_NL] = $uri . $parser->getAttr($node, "href");
		$property[TAG_UNIQUE_URL_FR] =preg_replace('@/nl/@','/fr/',$property[TAG_UNIQUE_URL_NL]);
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]) ; //$parser->regex("/(\d+)/", $property[TAG_UNIQUE_URL_NL]);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
		processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Get a list of next pages
 */
function getPages($html)
{
    $parser = new PageParser($html);

	$pages = array();
	$nodes = $parser->getNodes("div[@class = 'pages']/a");
	$page = 1;
	$uri = $xtext = '';
	 
    if($nodes->length > 1)
    {
        foreach($nodes as $node)
        {
	    $uri = $parser->getAttr($node, "href");
	     
	    $page = $parser->regex("/page=(\d+)/", $uri );
	    //debugx($page);
        }
    }
 
    for($i=1; $i <= $page; $i++){
	
	$pages[] = (strstr($uri,'jaarverhuur'))?$uri='http://jaarverhuur.sissau.be/nl/jaarverhuur?page='.$i:$uri='http://verkoop.sissau.be/nl/verkoop?page='.$i.'&view=list&goal=0';
    }
 
    return array_unique($pages);
}



function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));
	if(CrawlerTool::skipWordFound($html)){echo 'property Skipped <br>'; return;}
	
	
    $property[TAG_TEXT_TITLE_NL] = $parser->extract_xpath("div[@class='fleft']");
	$property[TAG_TYPE]=CrawlerTool::getPropertyType($property[TAG_TEXT_TITLE_NL]);
	
    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("div[@class = 'content']");
    $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@id = 'PropertyRegion']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PICTURES] = $parser->extract_xpath("li[@class = 'last page-1']/a", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "" . $pic);

        return $picUrls;
    });

    $property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/",  $property[TAG_TEXT_TITLE_NL] ));
    
        $street= $parser->extract_xpath("div[@class='fleft']/div[3]");
		if(!empty($street) and !preg_match('@\d{4} @',$street) ){
			
	$street=preg_replace('@,.+\Z@','',$street); 
	$property[TAG_STREET] = trim(preg_replace("/([^\d,]+).*?$/", "$1", strip_tags($street))); 
        $property[TAG_NUMBER]  = trim(preg_replace("/^[^\d,]+([^\s,]*).*$/", "$1", strip_tags($street)));
		$property[TAG_BOX_NUMBER] = trim(strip_tags(preg_replace('/[^<>]*'.$property[TAG_NUMBER].'([^<>]*)$/','$1',$street)));
		}
		
		
    $parser->extract_xpath("div[@class='fleft']", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
	$address = $text;
	debugx($address);
        if(preg_match("/(\d{4}) ([^\d]*)\Z/", $text, $match))
        {
            if(empty($property[TAG_ZIP])) $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
        }
    });
      
	    
	if($property[TAG_ZIP]=='8430')
	$property[TAG_CITY] = 'Middelkerke';

	// get all the labels and there values 
	$Labels=$parser->extract_regex('@<div class="name">([^<>]+)</div>@',RETURN_TYPE_ARRAY);
	$Values=$parser->extract_regex('@<div class="value">([^<>]+)</div>@',RETURN_TYPE_ARRAY);
	if(count($Labels)<>count($Values)){
	echo 'matching values skipped';
	
	//CrawlerTool::saveProperty($property);
	//return;		
	}
	 
	foreach ($Labels as $index=>$label){
		switch(trim($label)){
		  case 'Bouwjaar':
		  $property[TAG_CONSTRUCTION_YEAR] = CrawlerTool::toNumber($Values[$index]);
		  break;
		  case 'EPC':
		  $property[TAG_EPC_VALUE] = CrawlerTool::toNumber($Values[$index]);
		  break;
		  case 'Bewoonbare opp.': 
		  $property[TAG_SURFACE_LIVING_AREA] = CrawlerTool::toNumber($Values[$index]);
		  break;
		  case 'Unieke code':
		  $property[TAG_EPC_CERTIFICATE_NUMBER] = $Values[$index];
		  break;
		  case 'Slaapkamers': 
		  $property[TAG_BEDROOMS_TOTAL] =CrawlerTool::toNumber( $Values[$index]);
   
		  break;
		  
		  case 'Bestemming': 
		  $property[TAG_MOST_RECENT_DESTINATION] = trim($Values[$index]); 
		  break;
		  case 'Badkamers': 
		  $property[TAG_BATHROOMS_TOTAL] =CrawlerTool::toNumber( $Values[$index]);
   
		  break;
		  case 'Garage': 
		  $property[TAG_GARAGES_TOTAL] =CrawlerTool::toNumber( $Values[$index]);
   
		  break;
		  case 'Grondoppervlakte':
		  $property[TAG_SURFACE_GROUND] = CrawlerTool::toNumber($Values[$index]);
          break;
		  
		  default:
		  $property[TAG_UNMATCHED_VARIABLES][]=array(TAG_VARIABLE_LABEL=>$label,TAG_VARIABLE_VALUE=>$Values[$index]);
		 
		  break;	
		
			}
		}
	
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));

	// Most Important 
    if(!isset($property['priority_purchase']) || empty($property['priority_purchase']) || $property['priority_purchase'] != "1")
    $property['priority_purchase'] = "";

    if(!isset($property['has_proceeding']) || empty($property['has_proceeding']) || $property['has_proceeding'] != "1")
    $property['has_proceeding'] = "";
    
    
    if(!isset($property['planning_permission']) || empty($property['planning_permission']) || $property['planning_permission'] != "1")
    $property['planning_permission'] = "";
    
    
    if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']) || $property['subdivision_permit'] != "1")
    $property['subdivision_permit'] = "";

    if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']) || $property['most_recent_destination'] != "1")
    $property['most_recent_destination'] = "";

	
	$html = $crawler->request($property[TAG_UNIQUE_URL_FR]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	
	$property[TAG_TEXT_TITLE_FR] = $parser->extract_xpath("div[@class='fleft']");
	$property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("div[@class = 'content']");
	//$property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("body", RETURN_TYPE_TEXT_ALL);
	$property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("div[@id = 'PropertyRegion']", RETURN_TYPE_TEXT_ALL);
    
	$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode($property[TAG_TEXT_DESC_FR])); 
	$property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode(CrawlerTool::encode($property[TAG_PLAIN_TEXT_ALL_FR])); 
	if(empty($property[TAG_TEXT_DESC_FR])){
		
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res); 
		$res[1] = str_replace(chr(11),'',$res[1]); 
		$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode(strip_tags($res[1]))); 
	}
/**/

if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));


	if(strtolower($property[TAG_CITY]) == "middelkerke"){
		$property[TAG_ZIP] = "8430";
	}

	debug($property);  
	CrawlerTool::saveProperty($property);
	
}
 
 
//function for print array
function debug($obj)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}    
    
    

