<?php

/* ============================= CONFIG ============================= */

// Crawler ID 1079

require_once("../crawler_classes.php");


CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.brabimo.be"
    )
);


$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.brabimo.be/SNWebBuilder.php?page=/ventes"
    ),

);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.brabimo.be/SNWebBuilder.php?page=/locations"
    ),
);


/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/



/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Brabimo";
$office[TAG_OFFICE_URL] = "http://www.brabimo.be/";
$office[TAG_STREET] = "Rue du Moulin";
$office[TAG_NUMBER] = "7";
$office[TAG_ZIP] = "1340";
$office[TAG_CITY] = "Ottignies";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = " 010.41.50.50";
$office[TAG_FAX] = " 010.41.14.89";
$office[TAG_EMAIL] = "info@brabimo.be";
CrawlerTool::saveOffice($office);


foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->getNodes("a[contains(@href, 'context=offerid;')][img]");

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_FR] = "http://www.brabimo.be/" . $parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] =  $parser->regex("/(\d+)$/", $property[TAG_UNIQUE_URL_FR]);

        // check for sold or rented properties
        $parser->extract_xpath("parent::div[1]/following-sibling::div[1]/div[@class = 'Description']/img/@src", RETURN_TYPE_TEXT, function($text) use(&$property)
        {
            $propertyStatus = CrawlerTool::getPropertyStatus($text);
            if(STATUS_SOLD === $propertyStatus || STATUS_RENTED === $propertyStatus)
            {
                $property[TAG_STATUS] = $propertyStatus;
            }
        }, $node);

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_FR]);
	}   //CrawlerTool::test($items);

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

    $property[TAG_TEXT_DESC_FR] = $parser->extract_xpath("div[@class = 'Description']/span[2]");
    $property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("div[@class = 'Content']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PICTURES] = $parser->extract_xpath("div[@class = 'galthumbcontainer']/img", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.brabimo.be/" . str_replace("144x108", "550x412", $pic));

        return $picUrls;
    });

    $parser->extract_xpath("div[@class = 'TopCommune']", RETURN_TYPE_TEXT, function($text) use(&$property)
    {
        if(preg_match("/(.*)(\d{4,})/", $text, $match))
        {
            $property[TAG_ZIP] = $match[2];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[1]));
        }
    });
    $property[TAG_PRICE] = $parser->extract_xpath("div[@class = 'TopPrix']", RETURN_TYPE_NUMBER);
    $property[TAG_ORIGINAL_REFERENCE] = $parser->extract_xpath("div[@class = 'TopRef']/span");
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_PLAIN_TEXT_ALL_FR], 999);

    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("Année de construction", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Surface habitable", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Surface du terrain", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Chambre", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Salles de bain", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_regex("/(\d)\swc/", RETURN_TYPE_NUMBER);
    $property[TAG_HEATING_FR] = $parser->extract_xpath("Type de chauffage");
    $property[TAG_FREE_FROM_DATE] = $parser->extract_regex("/Libre.*(\d+\/\d+\/\d+)/", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM_DATE] = $parser->extract_regex("/Disponible.*(\d+\/\d+\/\d+)/", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM] = $parser->extract_regex("/Libre (.*\d+)\./");
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Nombre de façades", RETURN_TYPE_NUMBER);

    $livingSurf = $parser->extract_xpath("Surface séjour", RETURN_TYPE_NUMBER);
    if ($livingSurf > 0)
    {
        $property[TAG_LIVINGS][] = array(TAG_LIVING_SURFACE=>$livingSurf);
    }

    if(!isset($property[TAG_HAS_PROCEEDING]) || $property[TAG_HAS_PROCEEDING] !=1 )
	$property[TAG_HAS_PROCEEDING] = '';
	
	if(!isset($property['planning_permission']) || $property['planning_permission'] !=1)
	$property['planning_permission'] = '';
	
	
	if(!isset($property['subdivision_permit']) || $property['subdivision_permit'] !=1)
	$property['subdivision_permit'] = '';
	
	
	if(!isset($property['most_recent_destination']) || $property['most_recent_destination'] !=1)
	$property['most_recent_destination'] = '';


    //CrawlerTool::test($property);
	debug($property); 
    // WRITING item data to output.xml file
    CrawlerTool::saveProperty($property);
}

//function for print array
function debug($obj)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	
	
}

//function for print string
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
}    
    