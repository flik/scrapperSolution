<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');

/* ============================= CONFIG ============================= */

// Crawler ID 1049
require_once("../crawler_classes.php");


CrawlerTool::setDefault(array(TAG_OFFICE_URL => "http://www.trentimmo.net/"));


$startPages[STATUS_FORSALE] = array(
  TYPE_NONE => array(
    "http://www.trentimmo.be/index_bestanden/Lijsttekoop1.htm",
  ),
);

$startPages[STATUS_FORRENT] = array(
  TYPE_NONE => array(
    "http://www.trentimmo.be/index_bestanden/LijstTeHuur.htm",
  ),
);

/* ============================= END CONFIG ============================= */
/* ============================= TEST AREA ============================= */
/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/
/*$html = file_get_contents("d-1.htm");
processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/
/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Erkend Vastgoedmakelaar";
$office[TAG_OFFICE_URL] = "http://www.trentimmo.be/";
$office[TAG_STREET] = "Elisabethlaan";
$office[TAG_NUMBER] = "108";
$office[TAG_ZIP] = "2600";
$office[TAG_CITY] = "Berchem";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = " 03/237 07 09";
$office[TAG_FAX] = "03/237 07 59";
$office[TAG_EMAIL] = "info@trentimmo.be";
CrawlerTool::saveOffice($office);

foreach ($startPages as $status => $types) {
  foreach ($types as $type => $pages) {
    foreach ($pages as $page) {
      $html = file_get_contents($page);
      
      processPage($crawler, $status, $type, $html);
    }
  }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html) {
  static $propertyCount = 0;
  static $properties = array();
  
  $parser = new PageParser($html);
  
  $nodes = $parser->getNodes("span/a[contains(@href, 'htm')][img]");
  
  $items = array();
  foreach ($nodes as $node) {
    $property = array();
    $property[TAG_STATUS] = $status;
    $property[TAG_TYPE] = $type;
    $property[TAG_UNIQUE_URL_NL] = "http://www.trentimmo.net/index_bestanden/".$parser->getAttr($node, "href");
    $property[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
    
    $parser->extract_xpath("parent::span[1]/preceding-sibling::span[2]", RETURN_TYPE_TEXT,

    function($text)use(&$property) {
      if (preg_match("/\ste\s(\d{4,})(.*)/i", $text, $match)) {
        $property[TAG_ZIP] = $match[1];
        $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[2]));
      }

      /*elseif(preg_match("/centrum\s(.*)/", $text, $match))
      {
          $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[1]));
      }*/
      elseif (preg_match("/\ste\s(.*)/", $text, $match)) {
        $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[1]));
      }
    }, $node);
    if (empty($property[TAG_CITY])) {
      $parser->extract_xpath("parent::span[1]/following-sibling::span[3]", RETURN_TYPE_TEXT,

      function($text)use(&$property) {
        //$text = str_replace("2de verdieping", "", $text);
        if (preg_match("/\s-\s(\d{4,})(.*)/i", $text, $match)) {
          $property[TAG_ZIP] = $match[1];
          $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[2]));
        }
        elseif (preg_match("/(.*)\ste\s(\d{4,})(.*)/", $text, $match)) {
          CrawlerTool::parseAddress($match[1], $property);
          $property[TAG_ZIP] = $match[2];
          $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[3]));
        }
        elseif (preg_match("/(.*)(\d{4,})(.*)/", $text, $match)) {
          CrawlerTool::parseAddress($match[1], $property);
          $property[TAG_ZIP] = $match[2];
          $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[3]));
        }
      }, $node);
    }
    
    if (empty($property[TAG_CITY])) {
      $parser->extract_xpath("parent::span[1]/preceding-sibling::span[3]", RETURN_TYPE_TEXT,

      function($text)use(&$property) {
        if (preg_match("/\s-\s(.*)/i", $text, $match)) {
          $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[1]));
        }
      }, $node);
    }
    
    if (empty($property[TAG_CITY])) {
      $parser->extract_xpath("parent::span[1]/preceding-sibling::span[2]/descendant::span", RETURN_TYPE_TEXT,

      function($text)use(&$property) {
        if (preg_match("/\s-\s(\d{4,})(.*)/", $text, $match)) {
          $property[TAG_ZIP] = $match[1];
          $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[2]));
        }
      }, $node);
    }
    $property[TAG_PRICE] = $parser->extract_xpath("parent::span[1]/following-sibling::span[1]", RETURN_TYPE_NUMBER, null, $node);
    if ($property[TAG_PRICE] < 5000) {
      $property[TAG_PRICE] = $parser->extract_xpath("parent::span[1]/following-sibling::span[4]", RETURN_TYPE_NUMBER, null, $node);
    }
    if ($property[TAG_PRICE] < 5000) {
      $property[TAG_PRICE] = "";
    }
    if ($property[TAG_STATUS] === STATUS_FORRENT) {
      $parser->extract_xpath("parent::span[1]/following-sibling::span[1]/descendant::span", RETURN_TYPE_TEXT,

      function($text)use(&$property) {
        if (preg_match("/Van\s(.*)(\d{4,})(.*)/i", $text, $match)) {
          CrawlerTool::parseAddress($match[1], $property);
          $property[TAG_ZIP] = $match[2];
          $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[3]));
        }
        elseif (preg_match("/te\s(.*)(\d{4,})(.*)/", $text, $match)) {
          CrawlerTool::parseAddress($match[1], $property);
          $property[TAG_ZIP] = $match[2];
          $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[3]));
        }
        elseif (preg_match("/-\s(\d{4,})(.*)/", $text, $match)) {
          $property[TAG_ZIP] = $match[1];
          $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[2]));
        }
      }, $node);
      if (empty($property[TAG_CITY])) {
        $parser->extract_xpath("parent::span[1]/preceding-sibling::span[2]/descendant::span", RETURN_TYPE_TEXT,

        function($text)use(&$property) {
          if (preg_match("/\s-\s(\d{4,})(.*)/", $text, $match)) {
            $property[TAG_ZIP] = $match[1];
            $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d|,|\-/", "", $match[2]));
          }
        }, $node);
      }
      
      $property[TAG_PRICE] = $parser->extract_xpath("parent::span[1]/following-sibling::span[3]", RETURN_TYPE_NUMBER, null, $node);
      if ($property[TAG_PRICE] < 100) {
        $property[TAG_PRICE] = "";
      }
      if (empty($property[TAG_PRICE])) {
        $property[TAG_PRICE] = $parser->extract_xpath("parent::span[1]/preceding-sibling::span[1]", RETURN_TYPE_NUMBER, null, $node);
      }
      if ($property[TAG_PRICE] < 100) {
        $property[TAG_PRICE] = "";
      }
      if (empty($property[TAG_PRICE])) {
        $property[TAG_PRICE] = $parser->extract_xpath("parent::span[1]/following-sibling::span[1]", RETURN_TYPE_NUMBER, null, $node);
      }
      if (empty($property[TAG_PRICE])) {
        if ($property[TAG_UNIQUE_ID] === "642537949") {
          $property[TAG_PRICE] = $parser->extract_xpath("parent::span[1]/following-sibling::span[contains(@style, '251658665')]", RETURN_TYPE_NUMBER, null, $node);
        }
        if ($property[TAG_UNIQUE_ID] === "3447664824") {
          $property[TAG_PRICE] = $parser->extract_xpath("parent::span[1]/following-sibling::span[contains(@style, '251658678')]", RETURN_TYPE_NUMBER, null, $node);
        }
        if ($property[TAG_UNIQUE_ID] === "2697550353") {
          $property[TAG_PRICE] = $parser->extract_xpath("parent::span[1]/following-sibling::span[contains(@style, '251658677')]", RETURN_TYPE_NUMBER, null, $node);
        }
      }
    }
    

    if (in_array($property[TAG_UNIQUE_ID], $properties)) {
      continue;
    }
    $properties[] = $property[TAG_UNIQUE_ID];
    
    $items[] = array(
      "item" => $property,
      "itemUrl" => $property[TAG_UNIQUE_URL_NL],
    );
  }
  // CrawlerTool::test($items);
  foreach ($items as $item) {
    // keep track of number of properties processed
    $propertyCount += 1;
    
    // process item to obtain detail information
    echo "--------- Processing property #$propertyCount ...";
    processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
    echo "--------- Completed<br />";
  }
  
  return sizeof($items);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html) {
  $html = preg_replace("/file.*?image5741.jpg|file.*?image5201.jpg|image295.jpg/", "", $html);
  $parser = new PageParser($html);
  $parser->deleteTags(array("script", "style"));
  
  $property[TAG_TEXT_DESC_NL] = str_replace(array("+32 (0)3 237 07 09 Powered by TRENT E-mail: info@trentimmo.be", "Powered by TRENT"), array("", ""), $parser->extract_xpath("td[@width = '576'] | div[@class = 'shape']/p[@class = 'MsoNormal'] | div[@class = 'shape']/p[@class = 'MsoBodyText3']", RETURN_TYPE_TEXT_ALL));
  $property[TAG_TEXT_TITLE_NL] = $parser->extract_xpath("p[@class = 'MsoAccentText']");
  if (empty($property[TAG_TEXT_TITLE_NL])) {
    $property[TAG_TEXT_TITLE_NL] = $parser->extract_xpath("p[@class = 'MsoTitle3']");
  }
  $property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("body[@link = 'maroon']", RETURN_TYPE_TEXT_ALL);
  $property[TAG_PICTURES] = $parser->extract_xpath("span/img[contains(@src, 'jpg')]", RETURN_TYPE_ARRAY,

  function($pics) {
    $picUrls = array();
    foreach ($pics as $pic) {
      $picUrls[] = array(
        TAG_PICTURE_URL => "http://www.trentimmo.net/index_bestanden/".$pic,
      );
    }
    
    return $picUrls;
  });
  
  if (empty($property[TAG_CITY])) {
    $parser->extract_xpath("p[@class = 'MsoAccentText']", RETURN_TYPE_TEXT,

    function($text)use(&$property) {
      if (preg_match("/\s—\s(.*)/", $text, $match)) {
        $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[1]));
      }
    });
  }
  if (empty($property[TAG_CITY])) {
    $parser->extract_xpath("p[@class = 'MsoBodyText3']", RETURN_TYPE_TEXT,

    function($text)use(&$property) {
      if (preg_match("/(.*)(\d{4,})(.*)/", $text, $match)) {
        CrawlerTool::parseAddress($match[1], $property);
        $property[TAG_ZIP] = $match[2];
        $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));
      }
    });
  }
  
  if (empty($property[TAG_CITY])) {
    $parser->extract_xpath("span[img[contains(@src, 'image516')]]/following-sibling::span[1]/descendant::div/p[1]", RETURN_TYPE_TEXT,

    function($text)use(&$property) {
      if (preg_match("/(.*)(\d{4,})(.*)/", $text, $match)) {
        CrawlerTool::parseAddress(str_replace(" te ", "", $match[1]), $property);
        $property[TAG_ZIP] = $match[2];
        $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));
      }
      elseif (preg_match("/centrum\s(.*)/", $text, $match)) {
        $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[1]));
      }
    });
  }
  
  if (empty($property[TAG_CITY])) {
    return;
  }
  $property[TAG_TYPE] = CrawlerTool::getPropertyType(str_replace("Burgerwoning", "Burger woning", $parser->extract_xpath("p[@class = 'MsoAccentText']")));
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(str_replace("Burgerwoning", "Burger woning", $parser->extract_xpath("p[@class = 'MsoTitle3']")));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_PLAIN_TEXT_ALL_NL]);
  }
  if (stripos($property[TAG_PLAIN_TEXT_ALL_NL], "nieuwbouw") !== false) {
    $property[TAG_IS_NEW_CONSTRUCTION] = 1;
  }
  
  $parser->setQueryTemplate("td[p[span[contains(text(), '".XPATH_QUERY_TEMPLATE."')]]]/following-sibling::td[1]");
  
  $property[TAG_KI] = $parser->extract_xpath("KI", RETURN_TYPE_NUMBER);
  if (empty($property[TAG_KI])) {
    $property[TAG_KI] = $parser->extract_regex("/KI\s?:\s(\d+)/", RETURN_TYPE_NUMBER);
  }
  $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC", RETURN_TYPE_EPC);
  $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("Bouwjaar", RETURN_TYPE_YEAR);
  if (empty($property[TAG_CONSTRUCTION_YEAR])) {
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_regex("/Bouwjaar :\s(\d+)/", RETURN_TYPE_YEAR);
  }
  $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Perceeloppervlakte", RETURN_TYPE_NUMBER);
  if (empty($property[TAG_SURFACE_GROUND])) {
    $property[TAG_SURFACE_GROUND] = $parser->extract_regex("/totale opp.*?\s(\d+)/", RETURN_TYPE_NUMBER);
  }
  if (empty($property[TAG_SURFACE_GROUND])) {
    $property[TAG_SURFACE_GROUND] = $parser->extract_regex("/Totale.*?oppervlakte\s(\d+)/", RETURN_TYPE_NUMBER);
  }
  $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Bewoonbare", RETURN_TYPE_NUMBER);
  if (empty($property[TAG_SURFACE_LIVING_AREA])) {
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_regex("/Bewoonbare opp.*?\s(\d+)/", RETURN_TYPE_NUMBER);
  }
  $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Aantal slaapkamers", RETURN_TYPE_NUMBER);
  if (empty($property[TAG_BEDROOMS_TOTAL])) {
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_regex("/(\d)\s(slaapkamers|ruime slaapkamers|slaapkamer)/", RETURN_TYPE_NUMBER);
  }
  $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
  $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("Aantal toiletten", RETURN_TYPE_NUMBER);
  
  $property[TAG_COMMON_COSTS] = $parser->extract_regex("/kosten.*?\s(\d+)/i", RETURN_TYPE_NUMBER);
  $property[TAG_DOUBLE_GLAZING] = CrawlerTool::contains($parser->extract_regex("/(dubbele belglazing)/"), "dubbele belglazing");
  $property[TAG_LIFT] = CrawlerTool::contains($parser->extract_xpath("Lift"), "Ja");
  $property[TAG_CONNECTION_TO_WATER] = CrawlerTool::contains($parser->extract_xpath("Water"), "Ja");
  $property[TAG_GAS_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("Gas"), "Ja");
  $property[TAG_GARDEN_AVAILABLE] = CrawlerTool::contains($parser->extract_xpath("tuin"), "Ja");
  $livingSurf = $parser->extract_xpath("Woonkamer", RETURN_TYPE_NUMBER);
  if ($livingSurf > 0) {
    $property[TAG_LIVINGS][] = array(
      TAG_LIVING_SURFACE => $livingSurf,
    );
  }
  $terrasSurf = $parser->extract_xpath("Terras", RETURN_TYPE_NUMBER);
  if ($terrasSurf > 0) {
    $property[TAG_TERRACES][] = array(
      TAG_TERRACE_SURFACE => $terrasSurf,
    );
  }
  

  //   CrawlerTool::test($property);
  // WRITING item data to output.xml file
  CrawlerTool::saveProperty($property);
}

/**
 * Function to print array  
 */
function debug($obj, $e = false) {
  echo "<pre>";
  print_r($obj);
  echo "</pre>";
  
  if ($e) {
    exit;
  }
}

/**
 * Function to echo text
 */
function debugx($obj, $e = false) {
  echo "<br />************************<br/>";
  echo $obj;
  echo "<br/>************************<br/>";
  
  if ($e) {
    exit;
  }
}
