<?php

require_once("./../crawler_classes.php");
$crawler->use_cookies(true);
$startPages[STATUS_TORENT] = array
(
	TYPE_NONE        =>  array
	(
		"http://www.keyimmo.be/te-huur",
	),

);

$startPages[STATUS_FORSELL] = array
(
	TYPE_NONE        =>  array
	(
		"http://www.keyimmo.be/te-koop",
	),
	
	"project"        =>  array
	(
		'http://www.keyimmo.be/nieuwbouw'
	),
);

CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
	foreach($types as $type => $pages)
	{
		foreach($pages as $page)
		{
			$html = $crawler->request($page);
			debugx($page);
			processPage($crawler, $status, $type, $html);
			$nextPage = getNextPage($html);
			unset($html);

			while(strlen($nextPage) > 0) {
				echo "Downloading page content..." .$nextPage. "<br />";
				$html = $crawler->request($nextPage);
				echo "Complete downloading page content..." . "<br />";

				// process page content
				echo "Processing page ..." . "<br />";
				processPage($crawler, $status, $type, $html);
				echo "Complete processing page ..." . "<br /><br />";

				$nextPage = getNextPage($html);
				unset($html);
			}
		}
	}
}

/**
 *  Get next page
 */
function getNextPage($html) {
	$nextPage = "";
    $parser = new PageParser($html);
	$node = $parser->getNode("a[contains(text(), 'volgende pagina')]");
	if($node) $nextPage = "http://www.keyimmo.be" . $parser->getAttr($node, "href");
	return $nextPage;
}

CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
	global $propertyCount;
	global $properties;
	if(empty($propertyCount)) $propertyCount = 0;
	if(empty($properties)) $properties = array();

	$parser = new PageParser($html);
	if($type==="project"){
		$nodes = $parser->getNodes("div[contains(@class, 'meerinfo')]");

		$items = array();
		foreach($nodes as $node)
		{
			$project = array();
			flush();
			ob_flush();
			$n= $parser->getNode("a",$node);
			$project[TAG_STATUS]=$status;
			$project[TAG_UNIQUE_URL_NL] = "http://www.keyimmo.be" . $parser->getAttr($n, "href");
			echo $project[TAG_CITY] = preg_match('/\((.*?)\)/',$parser->extract_xpath("span[contains(@class, 'upper')]",'', null, parentNode($node, 2)),$res) ? trim($res[1]) : '';
			$project[TAG_PROJECT_ID] =  $parser->regex("/\/(\d+)$/", $project[TAG_UNIQUE_URL_NL]);
			processProject($crawler,$project);

		}

	}else{

		//$nodes = $parser->getNodes("div[contains(@class, 'meerinfo')]/a");
		$nodes = $parser->getNodes("div[contains(@class, 'pand_kader')]");

		$items = array();
		foreach($nodes as $node)
		{
			$property = array();
			flush();
			ob_flush();
			$property[TAG_STATUS]=$status;
			$n= $parser->getNode("a",$node);
			
			$link = $parser->extract_xpath("div[@class = 'meerinfo']/a/@href", RETURN_TYPE_TEXT, null, $node); 

			$property[TAG_UNIQUE_URL_NL] = "http://www.keyimmo.be" . $link ;
			
			$property[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]);
			
			$property[TAG_PRICE] = CrawlerTool::toNumber($parser->extract_xpath("div[@class = 'tekst']/h2", RETURN_TYPE_TEXT, null, $node)); 
			
			if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
			$properties[] = $property[TAG_UNIQUE_ID];
			$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);

		}

		foreach($items as $item)
		{
			// keep track of number of properties processed
			$propertyCount += 1;

			// process item to obtain detail information
			echo "--------- Processing property #$propertyCount ...";
			echo $item["itemUrl"]."<br>";
			processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
			echo "--------- Completed<br />";
		}

		return sizeof($items);
	}
}

function parentNode($node, $n = 1) {
	$parentNode = $node;
	for($i = 1; $i <= $n; $i++) $parentNode = $parentNode->parentNode;

	return $parentNode;
}

function getPages($html)
{
	$parser = new PageParser($html);

	$pages = array();
	$nodes = $parser->getNodes("div[span = 'Pagina']/a");

	if(!empty($nodes))
	{
		foreach($nodes as $node)
		{
			$pages[] = "http://www.brasschaatsimmo.be" . $parser->getAttr($node, "href");
		}
	}

	return array_unique($pages);
}

function processProject($crawler, $project)
{
	$html = $crawler->request($project[TAG_UNIQUE_URL_NL]);
	$parser = new PageParser($html);
	$parser->deleteTags(array("script", "style"));

    $project[TAG_TEXT_SHORT_DESC_NL]= $parser->extract_xpath("div[contains(@class, 'links')]/p");
    
    $project[TAG_PICTURES] = $parser->extract_xpath("a[contains(@rel, 'lytebox')]", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.keyimmo.be/" . preg_replace("!(\.\./)|^/!", "", $pic));

        return $picUrls;
    });

	if (preg_match('!maps\.LatLng\(([0-9.]+),([0-9.]+)\)!',$html,$res))
	{
		$long  = $res[1];
		$lat  = $res[2];
	}
 
    $nodes = $parser->getNodes("table[@id = 'table_overzicht']/descendant::tr[contains(@class, 'project')]");
	$SoldNodes = $parser->getNodes("table[@id = 'table_overzicht']/descendant::tr[contains(@class, 'kavel_verkocht')]");
    $project[TAG_SOLD_PERCENTAGE_MAX]=$nodes->length+$SoldNodes->length;
	$project[TAG_SOLD_PERCENTAGE_VALUE] =$SoldNodes->length;
    if($project[TAG_SOLD_PERCENTAGE_MAX]<=0){
		unset($project[TAG_SOLD_PERCENTAGE_MAX]);
		unset($project[TAG_SOLD_PERCENTAGE_VALUE]);
	}

    CrawlerTool::saveProject($project);

	$nodes = $parser->getNodes("table[@id = 'table_overzicht']/descendant::tr[contains(@class, 'project')]");
	$items = array();
	$property = array();

	foreach($nodes as $node)
	{
        $property[TAG_STATUS]=$project[TAG_STATUS];
        $property[TAG_PROJECT_ID]=$project[TAG_PROJECT_ID];
        $property[TAG_UNIQUE_URL_NL]='http://www.keyimmo.be'.(preg_match('/document.location=\'(.*?)\'/',$parser->getAttr($node, "onclick"),$res) ? $res[1] : '');
        $property[TAG_UNIQUE_ID] =  $parser->regex("/details-pand\/(\d+)\?/", $property[TAG_UNIQUE_URL_NL]);
		// WRITING item data to output.xml file
		debugx($property[TAG_UNIQUE_URL_NL]);
		processItem($crawler, $property, $crawler->request($property[TAG_UNIQUE_URL_NL]));
	}

}
function processItem($crawler, $property, $html)
{
	$parser = new PageParser($html);

    $property[TAG_TEXT_TITLE_NL]           = $parser->extract_xpath("h2");
    $property[TAG_TEXT_SHORT_DESC_NL]= $parser->extract_xpath("div[contains(@class, 'links')]/p");
    $property[TAG_PLAIN_TEXT_ALL_NL]= $parser->extract_xpath("div[contains(@class, 'links')]");
    
    	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_TITLE_NL]));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_SHORT_DESC_NL]));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));

    
    $property[TAG_PICTURES] = $parser->extract_xpath("a[contains(@rel, 'prettyPhoto')]", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL => "http://www.keyimmo.be/" . preg_replace("!(\.\./)|^/!", "", $pic));

        return $picUrls;
    });
    
    
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
	if(empty($property[TAG_STATUS])) $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($parser->extract_xpath("head/title"));
    
	if(STATUS_SOLD === $property[TAG_STATUS] || STATUS_RENTED === $property[TAG_STATUS])
	{
		return ; 
	}
	
	//Getting Attributes
	    $attributes = $parser->getNodes("table[@class = 'infolijst']/tr");
	//In case of TD and get next td val
	$parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");
	
	$address = $parser->extract_xpath("Adres:", RETURN_TYPE_TEXT);
	
	if(empty($address))
	$address = GetBetween($html,  'Adres' , 'kenmerklabel');
	 
	 
	//debugx($address);
	$address = strip_tags($address);
	
	$addr = explode(' ', trim($address) ); 
	
	/*$property[TAG_ZIP] =  CrawlerTool::toNumber(trim($addr[count($addr)-2]));
	$property[TAG_CITY] = trim($addr[count($addr)-1]);*/
	CrawlerTool::parseAddress(preg_replace("/,|\//", "", $address), $property);
		
		$addr = explode(' ',$address);
		$property[TAG_CITY] = trim($addr[count($addr)-1]);
		$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
		
		if(strlen($property[TAG_ZIP]) < 4){
			$address = str_replace($property[TAG_ZIP],'',$address );
			$property[TAG_BOX_NUMBER] = $property[TAG_ZIP];
			$property[TAG_ZIP] =  intval($parser->regex("/(\d{4})/", $address ));
		}
		
		$property[TAG_STREET] = str_replace($property[TAG_CITY],'',$property[TAG_STREET]);
		$property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
		
		$property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
		$property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
		
		if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
		
		if(strlen($property[TAG_BOX_NUMBER]) < 3 || strlen($property[TAG_BOX_NUMBER]) > 3 )
		unset($property[TAG_BOX_NUMBER]);

    if(empty($property[TAG_EPC_VALUE])) $property[TAG_EPC_VALUE] = $parser->extract_xpath("EPC score", RETURN_TYPE_EPC);
    $property[TAG_KI] = $parser->extract_xpath("kadastraal inkomen", RETURN_TYPE_NUMBER);
    $property[TAG_KI_INDEX] = $parser->extract_xpath("kad.ink.", RETURN_TYPE_NUMBER);
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("bouwjaar", RETURN_TYPE_YEAR);
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("renovatie jaar", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Bewoonbare opp.:", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Oppervlakte terrein:", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Aantal slaapkamers:", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Aantal badkamers", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toiletten aantal", RETURN_TYPE_NUMBER);
    $property[TAG_GARAGES_TOTAL] = $parser->extract_xpath("garage aantal", RETURN_TYPE_NUMBER);
    $property[TAG_PARKINGS_TOTAL] = $parser->extract_xpath("parking buiten aantal", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FLOORS] = $parser->extract_xpath("verdiepingen aantal", RETURN_TYPE_NUMBER);
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Beschikbaar vanaf", RETURN_TYPE_UNIX_TIMESTAMP);
    $property[TAG_COMMON_COSTS] = $parser->extract_xpath("lasten", RETURN_TYPE_NUMBER);
    $property[TAG_GAS_CONNECTION] = ($parser->extract_xpath("gas") === "Ja" ? 1 : 0);
    $property[TAG_CONNECTION_TO_WATER] = ($parser->extract_xpath("water") === "Ja" ? 1 : 0);
    $property[TAG_TELEPHONE_CONNECTION] = ($parser->extract_xpath("telefoon") === "Ja" ? 1 : 0);
    $property[TAG_LIFT] = ($parser->extract_xpath("lift") === "Ja" ? 1 : 0);
    $property[TAG_FURNISHED] = ($parser->extract_xpath("Gemeubeld") === "Ja" ? 1 : 0);
    $property[TAG_GARDEN_AVAILABLE] = ($parser->extract_xpath("Tuin") === "Ja" ? 1 : 0);
    $property[TAG_OPEN_FIRE] = ($parser->extract_xpath("open haard aantal") ? 1 : 0);
    $property[TAG_ALARM] = ($parser->extract_xpath("alarm") ? 1 : 0);
    $property[TAG_PARLOPHONE] = ($parser->extract_xpath("parlofoon") ? 1 : 0);
    $property[TAG_VIDEOPHONE] = ($parser->extract_xpath("videofoon") === "Ja" ? 1 : 0);

    $unmatched_variables = array();
    


    foreach($attributes as $attr){
		$AttribDetail = explode(':',trim($attr->nodeValue));
		$key = clearForLowerCase($AttribDetail[0]);
		$val = trim($AttribDetail[1]);
		$attribute = getAttributes($key);
		if(!empty($attribute)){
		    if(empty($property[$attribute]))
		    $property[$attribute] = GetExactAttrib($attribute,$val);
		}
		else
		    $unmatched_variables[] = array(TAG_VARIABLE_LABEL => $key, TAG_VARIABLE_VALUE => $val);
		
    }
    
    // Most Important 
    if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
    $property['planning_proceeding'] = 0;
    
    
    if(!isset($property['planning_permission']) || empty($property['planning_permission']))
    $property['planning_permission'] = 0;
    
    
    if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
    $property['subdivision_permit'] = 0;
    
    
    if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
    $property['planning_proceeding'] = 0;
    
    
    if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
    $property['most_recent_destination'] = 0;
	
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
	  
	if(empty($property[TAG_CITY]))
	return;
	
	$property[TAG_ZIP] = intval($property[TAG_ZIP]);
	
	if(strlen($property[TAG_ZIP]) < 4)
	return;
	
	if(intval($property[TAG_ZIP]) < 1000)
	return;

	debug($property);
	
    CrawlerTool::saveProperty($property);

}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}


function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
}

function getAttributes($key, $language='nl'){ //String Function always return string

	$attributeTagsArray	= array('en' => array(	'pric' 			=>  TAG_PRICE,
							'constr'		=> TAG_CONSTRUCTION_YEAR,
							'ground'		=> TAG_SURFACE_GROUND,
							'living' 		=> TAG_SURFACE_LIVING_AREA,
							'bath'			=> TAG_BATHROOMS_TOTAL,
							'warm'			=> TAG_HEATING_EN,
							'heat'			=> TAG_HEATING_EN,
							'sewer'			=> TAG_CONNECTION_TO_SEWER,
							'telep'			=> TAG_TELEPHONE_CONNECTION,
							'intern'		=> TAG_INTERNET_CONNECTION,
							'permission'		=> TAG_PLANNING_PERMISSION,
							'subdivision'		=> TAG_SUBDIVISION_PERMIT,
							'electri'		=> TAG_METER_FOR_ELECTRICITY,
							'hall'			=> TAG_HALLS,
							'dining'		=> TAG_DININGS,
							'kitch'			=> TAG_KITCHENS,
							'laundr'		=> TAG_LAUNDRY_ROOMS,
							'dress'			=> TAG_DRESSING,
							'bed'			=> TAG_BEDROOMS_TOTAL,
							'room'			=> TAG_BEDROOMS_TOTAL,
							'park'			=> TAG_PARKINGS,
							'garage'		=> TAG_GARAGES_TOTAL,
							'type'			=> TAG_TYPE,
							'garden'		=> TAG_GARDEN_AVAILABLE,
							'floor'			=> TAG_AMOUNT_OF_FLOORS,
							'winter'		=> TAG_WINTERGARDENS,
							'furnish'		=> TAG_FURNISHED,
							'water'			=> TAG_CONNECTION_TO_WATER,
							'lift'			=> TAG_LIFT,
							'glaz'			=> TAG_DOUBLE_GLAZING,
							'terrac'		=> TAG_TERRACES,
							'fronts'		=> TAG_AMOUNT_OF_FACADES,
							'category'		=> TAG_TYPE,
							'free'			=> TAG_FREE_FROM_DATE,
							'habit'			=> TAG_SURFACE_LIVING_AREA,
							'plot'			=> TAG_SURFACE_GROUND,
							'shops'			=> TAG_DISTANCE_SHOPS,
							'schools'		=> TAG_DISTANCE_SCHOOL,
							'transport'		=> TAG_DISTANCE_PUBLIC_TRANSPORT,
							'shower'		=> TAG_SHOWERS_TOTAL,
							'stor'			=> TAG_STOREROOMS,
							'gas'			=> TAG_GAS_CONNECTION,
							'alarm'			=> TAG_ALARM,
							'security'		=> TAG_SECURITY_DOOR,
							'parlo'			=> TAG_PARLOPHONE,
							'video'			=> TAG_VIDEOPHONE,
							'elevat'		=> TAG_LIFT,
							'blind'			=> TAG_SUN_BLINDS,
							'renova'		=> TAG_RENOVATION_YEAR,
							'control'		=> TAG_ACCESS_SEMIVALID,
								),
					'nl' => array(	"prij" =>  TAG_PRICE,
							"bouwjaar" => TAG_CONSTRUCTION_YEAR,
							"grondopp" => TAG_SURFACE_GROUND, 
							"bewoonbare" => TAG_SURFACE_LIVING_AREA,
							"antal_kamer"=> TAG_BEDROOMS_TOTAL,
							"slaapkamer"=> TAG_BEDROOMS_TOTAL,
							"antal_badkam"=> TAG_BATHROOMS_TOTAL,
							"badkam"=> TAG_BATHROOMS_TOTAL,
							"certificaatnr" => TAG_EPC_CERTIFICATE_NUMBER,
							"epc_waa" => TAG_EPC_VALUE,
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"verdieping" => TAG_AMOUNT_OF_FLOORS,
							"living" => TAG_SURFACE_LIVING_AREA,
							"renovatie" => TAG_RENOVATION_YEAR,
							"kadaster_sectie" => TAG_CADASTRAL_SECTION,
							"beschikbaar" => TAG_FREE_FROM,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"mail" => TAG_EMAIL,
							"winkels" => TAG_DISTANCE_SHOPS,
							"vervoer" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"overstromings" => TAG_FLOOD_INFORMATION_NL,
							"garage" => TAG_GARAGES_TOTAL,
							"toilet" => TAG_TOILETS_TOTAL,
							"parking" => TAG_PARKINGS_TOTAL,
							"gevels" => TAG_AMOUNT_OF_FACADES,
							"lasten" => TAG_COMMON_COSTS,
							"gas" => TAG_GAS_CONNECTION,
							"water" => TAG_CONNECTION_TO_WATER,
							"telefoon" => TAG_TELEPHONE,
							"lift" => TAG_LIFT,
							"gemeubeld" => TAG_FURNISHED,
							"tuin" => TAG_GARDEN_AVAILABLE,
							"haard" => TAG_OPEN_FIRE,
							"alarm" => TAG_ALARM,
							"parlofoon" => TAG_PARLOPHONE,
							"videofoon" => TAG_VIDEOPHONE,
							"breedte" => TAG_LOT_WIDTH,
							"diepte" => TAG_LOT_DEPTH,
							"constructie" => TAG_CONSTRUCTION_TYPE,
							"gevelbreedte" => TAG_FRONTAGE_WIDTH,
							"winkel" => TAG_HEATING_NL,
							"douche" => TAG_SHOWERS_TOTAL,
							"keuken" => TAG_KITCHEN_TYPE_NL,
							"ligging" => TAG_SUBDIVISION_PERMIT,
							"stedenbouwkundige" => TAG_PLANNING_PERMISSION,
							"terras" => TAG_TERRACES,
							"terrein" => TAG_SURFACE_GROUND,
							"scholen" => TAG_DISTANCE_SCHOOL,
							"oppervlakte" => TAG_SURFACE_LIVING_AREA,
							"eetkamer" => TAG_DININGS,
							"dressing" => TAG_DRESSINGS,
							"kelder" => TAG_CELLARS,
							"beroep" => TAG_FREE_PROFESSIONS,
							"berging" => TAG_STOREROOMS,
							"wasplaats" => TAG_LAUNDRY_ROOMS,
							"elektric" => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"beglazing" => TAG_DOUBLE_GLAZING,
							"verwarming" => TAG_HEATING_NL,
							"riolering" => TAG_CONNECTION_TO_SEWER,
							"olietank" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"waterput" => TAG_WELL,
							"telefoonbekabeling" => TAG_TELEPHONE_CONNECTION,
							"toegangscontrole" => TAG_ACCESS_SEMIVALID,
							"computer" => TAG_INTERNET_CONNECTION,
							"nroerende_voorhef" => TAG_PROPERTY_TAX,
								),
                                        'fr' => array(	"prij" =>  TAG_PRICE,
							"Meuble" => TAG_FURNISHED,
							"facades" => TAG_AMOUNT_OF_FACADES,
							"nombre_de_chambre"=> TAG_BEDROOMS_TOTAL,
							"nombre_de_salle_de_bain"=> TAG_BATHROOMS_TOTAL,
							"jardin" => TAG_GARDEN_AVAILABLE,
							"garage" => TAG_GARAGES_TOTAL,
							"terras" => TAG_TERRACES,
							"parking" => TAG_PARKINGS_TOTAL,
							"habita" => TAG_SURFACE_LIVING_AREA,
							"terrain" => TAG_SURFACE_GROUND,
							"disponible" => TAG_FREE_FROM,
							"magasins" => TAG_DISTANCE_SHOPS,
							"transport" => TAG_DISTANCE_PUBLIC_TRANSPORT,
							"toilet" => TAG_TOILETS_TOTAL,
							"construction_annee" => TAG_CONSTRUCTION_YEAR,
							"renovation_annee" => TAG_RENOVATION_YEAR,
							"tages" => TAG_AMOUNT_OF_FLOORS,
							"alarm" => TAG_ALARM,
							"gaz" => TAG_GAS_CONNECTION,
							"eau" => TAG_CONNECTION_TO_WATER,
							"parlophone" => TAG_PARLOPHONE,
							"vitrage" => TAG_DOUBLE_GLAZING,
							"network" => TAG_INTERNET_CONNECTION,
							"douche" => TAG_SHOWERS_TOTAL,
							"caves" => TAG_CELLARS,
							"dressing" => TAG_DRESSINGS,
							"telephone" => TAG_TELEPHONE,
							"videophone" => TAG_VIDEOPHONE,
							"manger" => TAG_DININGS,
							"ecoles" => TAG_DISTANCE_SCHOOL,
							"sejour" => TAG_SURFACE_LIVING_AREA,
							"ascenseur" => TAG_LIFT,
							"largeur_du_lot" => TAG_LOT_WIDTH,
							"mazout" => TAG_CONTENT_TANK_DOMESTIC_FUEL_OIL,
							"citerne" => TAG_WELL,
							"chauffage" => TAG_HEATING_FR,
							"electricite " => TAG_ELECTRICAL_INSPECTION_CERTIFICATE_AVAILABLE,
							"fax" => TAG_FAX,
							"tel" => TAG_CELLPHONE,
							"inondation" => TAG_FLOOD_INFORMATION_FR,
							"egouts" => TAG_CONNECTION_TO_SEWER,
							"cuisine" => TAG_KITCHEN_TYPE_FR,
							"construction_type" => TAG_CONSTRUCTION_TYPE,
							"chauffage" => TAG_HEATING_FR,
							"debarras" => TAG_STOREROOMS,
							"telephoniques" => TAG_TELEPHONE_CONNECTION,
							"dacces" => TAG_ACCESS_SEMIVALID,
							"lotissement" => TAG_SUBDIVISION_PERMIT,
							"batir" => TAG_PLANNING_PERMISSION,
							"cadastrales" => TAG_CADASTRAL_SECTION,
							"prix" => TAG_PRICE, 
							"epc" => TAG_EPC_VALUE,
							"ki" => TAG_KI,
							"mail" => TAG_EMAIL,
							"commun" => TAG_COMMON_COSTS,
							"feu" => TAG_OPEN_FIRE,
							"beaucoup_de_profondeur" => TAG_LOT_DEPTH,
							"facade_largeur" => TAG_FRONTAGE_WIDTH,
							"emission_co2" => TAG_CO2_EMISSION,
                                                     ),
				);
	
	$keys = array_keys($attributeTagsArray[$language]); // Returning Keys
	$key = clearForLowerCase($key); // Converting to lower case
	
	foreach($keys as $k){
	    
		   $check = stripos("X$key","$k");
		   if(!empty($check))
		   return $attributeTagsArray[$language][$k];
	    }
	 
	return '';	 
}

function GetExactAttrib($key,$val){
 
    $a = array();
    
    switch($key){
    case TAG_PROPERTY_TAX:
        return toNumber($val);
        break;	
    case TAG_PRICE:
        return toNumber($val);
        break;
    case TAG_CONSTRUCTION_YEAR:
        return toYear($val);
        break;
    case TAG_RENOVATION_YEAR:
        return toYear($val);
        break;
     case TAG_FREE_FROM_DATE:
        return toUnixTimestamp($val);
        break;
    case TAG_KI:
        return toNumber($val);
        break;
    case TAG_EPC_VALUE:
        return toEpc($val);
        break;
    case TAG_EPC_CERTIFICATE_NUMBER:
        return toNumber($val);
        break;
    case TAG_SURFACE_LIVING_AREA:
       return toNumber($val);
       break;
    case TAG_SURFACE_GROUND:
       return toNumber($val);
       break;
    case TAG_MOST_RECENT_DESTINATION:
       return trim($val);
       break;
    case TAG_PLANNING_PERMISSION:
       return $val;
       break;
    case TAG_SUBDIVISION_PERMIT:
       return toNumber($val); 
    break;

    case TAG_GARDEN_AVAILABLE:
       return ($val=='Ja') ? 1 : 0;
    break;
    
    case TAG_TERRACES:
       return $a[] = toNumber($val); 
    break;
    
    default:
	$val = trim($val);
	if($val=='Ja' || $val=='Nee' || $val=='Neen')
        return ($val=='Ja') ? 1 : 0;
	else{

		if(stripos($key,"permission") !== false)
	    return ($val=='Ja') ? 1 : 0;
	
	    if(stripos($key,"_nl") !== false)
	    return $val;
	    
	    if(stripos($key,"_fr") !== false)
	    return $val;
	
	    if(stripos($key,"_en") !== false)
	    return $val;
	    else
	    return toNumber($val);
	    
	}
	
    break;
     
    }
}

/// Basic checking for 
function clearForLowerCase($str = ''){ 
    $str = strtolower(str_replace(' ','_',$str)); 
    $str = trim(strip_tags($str)); 
    //$str = preg_replace('![^a-z0-9_\-\. ]!','',$str); 
    // $str = trim(preg_replace('!nbsp!','',$str)); 
    $str = trim(preg_replace('!ja,!','',$str));
    //$str = trim(preg_replace('!,!','',$str));
    //$str = trim(normalize_str($str));
    return $str ;
 
}

function toNumber($str)
{
    ///return $str;
	$value = 0;
    $str = preg_replace("/(,\d{2})$|(\.\d{2})$|\s|\+\/-/", "", $str);
    $str = preg_replace("/,(\d{3})|\.(\d{3})/",  "$1$2", $str);
    if(preg_match("/(-?\d+)/", $str, $match)) $value = intval($match[1]);
    
    if(empty($value))
    return 0;
    else
    return $value;
}

function toUnixTimestamp($str)
{
	return strtotime($str);
}

function toEpc($str){
	$epc = toNumber($str);
	if($epc > 0 && $epc <= 999) return $epc;
}

function toYear($str){
	$year = toNumber($str);
	if($year > 0 && strlen($year) == 4) return $year;
}

function normalize_str($str) {
        $invalid = array('Š' => 'S', 'š' => 's', 'Đ' => 'Dj', 'đ' => 'dj', 'Ž' => 'Z', 'ž' => 'z',
            'Č' => 'C', 'č' => 'c', 'Ć' => 'C', 'ć' => 'c', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A',
            'Ä' => 'A', 'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Ì' => 'I', 'Í' => 'I', 'Î' => 'I', 'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O',
            'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U', 'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y',
            'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a', 'å' => 'a',
            'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i',
            'î' => 'i', 'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o',
            'ö' => 'o', 'ø' => 'o', 'ù' => 'u', 'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b',
            'ÿ' => 'y', 'Ŕ' => 'R', 'ŕ' => 'r', "`" => "'", "´" => "'", "„" => ",", "`" => "'",
            "´" => "'", "“" => "\"", "”" => "\"", "´" => "'", "&acirc;€™" => "'", "{" => "",
            "~" => "", "–" => "-", "’" => "'");
        foreach($invalid as $k => $v){
            $str = str_replace($k, $v, $str); //array_values($invalid)
        }

        return $str;
    }

?>