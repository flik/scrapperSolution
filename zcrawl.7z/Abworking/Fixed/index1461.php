<?php
require_once("../../crawler_classes.php");

define('SITE_URL','http://www.stragimo.be/');
CrawlerTool::startXML();
$office[TAG_OFFICE_ID]   = "1";
$office[TAG_OFFICE_URL]  = "www.progedim.be";
$office[TAG_OFFICE_NAME] = "Progedim";
$office[TAG_STREET]      = "Avenue Slegers";
$office[TAG_NUMBER]      = "71";
$office[TAG_BOX_NUMBER]  = "";
$office[TAG_ZIP]         = "1200";
$office[TAG_CITY]        = "Bruxelles";
$office[TAG_COUNTRY]     = "Belgium";

$office[TAG_TELEPHONE]   = "+32 2 772 74 78";
$office[TAG_EMAIL]       = "info@progedim.be";

CrawlerTool::saveOffice($office);


CrawlerTool::setDefault(
    array
    (
        TAG_OFFICE_URL => "http://www.progedim.be/" 
    )
);

$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.progedim.be/en/categorie/our-properties-for-sale.html" 
    ),
);

$startPages[STATUS_FORRENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.progedim.be/en/categorie/our-properties-for-rent.html" 
    ),
);

foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {
            debugx($page);
            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
            
           
        }
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);
    $nodes = $parser->getNodes("div[@class = 'cc_title']/h3/a");
     
    $items = array();
    foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type; 
        $property[TAG_UNIQUE_URL_EN] = "http://www.progedim.be" . $parser->getAttr($node, "href"); 
        $property[TAG_UNIQUE_ID] =  CrawlerTool::generateId($property[TAG_UNIQUE_URL_EN]); 
        $property[TAG_UNIQUE_URL_FR] =  str_replace("en/", "", $property[TAG_UNIQUE_URL_EN]); 

	
        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_FR]);
    }    

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...".$item["itemUrl"];
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}
/**
 * Get a list of next pages
 */
function getPages($html)
{
    $parser = new PageParser($html);

    $pages = array();
    $nodes = $parser->getNodes("a[@class = 'Link PaginationLink']");

    if(!empty($nodes))
    {
        foreach($nodes as $node)
        {
            $pages[] = "http://www.bkgroup.be" . $parser->getAttr($node, "href");
        }
    }

    return array_unique($pages);
}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $html = str_replace("±", "", $html);
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

    if(empty($property[TAG_STATUS])) $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($parser->extract_xpath("td[contains(text(), 'Ref:')]/following-sibling::td[1]"));
    if(empty($property[TAG_STATUS])) $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($parser->extract_xpath("head/title"));
    
    $property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@class = 'cc_content']/p[1]")));
    $property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@class = 'wrapper']", RETURN_TYPE_TEXT_ALL)));
    
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'shadowbox[gal]']", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic) $picUrls[] = array(TAG_PICTURE_URL =>  $pic);

        return $picUrls;
    });

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_FR]));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_FR]));

    $address = $parser->extract_xpath("div[@id = 'content-details']/p", RETURN_TYPE_TEXT); 
		
		CrawlerTool::parseAddress(preg_replace("/,|\//", "", $address), $property);
		
		$addr = explode(' ',$address);
		$property[TAG_COUNTRY] = trim($addr[count($addr)-1]);
		$property[TAG_CITY] = str_replace(',','',trim($addr[count($addr)-2]));
		$property[TAG_ZIP] =  $parser->regex("/(\d{4})/", $address );
		
		$property[TAG_STREET] = utf8_decode(str_replace($property[TAG_CITY],'',$property[TAG_STREET]));
		$property[TAG_STREET] = str_replace($property[TAG_ZIP],'',$property[TAG_STREET]);
		
		$property[TAG_NUMBER] = str_replace($property[TAG_CITY],'',$property[TAG_NUMBER]);
		$property[TAG_NUMBER] = str_replace($property[TAG_ZIP],'',$property[TAG_NUMBER]);
		
		if(empty($property[TAG_CITY])) $property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $property[TAG_BOX_NUMBER] ));
		
		unset($property[TAG_BOX_NUMBER]);
     
    /*
    if(empty($property[TAG_CITY]))
    return;
    */
    $property[TAG_PRICE] = $parser->extract_xpath("h1[@class = 'contentTitleh1']/span", RETURN_TYPE_NUMBER);
    
    $property[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
	     {
		     $fileUrls = array();
		     foreach($files as $file)
		     {
			     if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => "http://www.hetlandgoed.be/".str_replace('../','',$file));
		     }
		     return $fileUrls;
	});

    $parser->setQueryTemplate("td[contains(text(), '" . XPATH_QUERY_TEMPLATE . "')]/following-sibling::td[1]");

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("Catégorie"));
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_FR]);
    $property[TAG_EPC_VALUE] = $parser->extract_regex("/(\d+)\skwh/i", RETURN_TYPE_EPC);
    $property[TAG_CONSTRUCTION_YEAR] = $parser->extract_xpath("Année de construction", RETURN_TYPE_YEAR);
    $property[TAG_RENOVATION_YEAR] = $parser->extract_xpath("rénovation annee", RETURN_TYPE_YEAR);
    $property[TAG_SURFACE_GROUND] = $parser->extract_xpath("Taille terrain", RETURN_TYPE_NUMBER);
    $property[TAG_SURFACE_LIVING_AREA] = $parser->extract_xpath("Surface habitable", RETURN_TYPE_NUMBER);
    $property[TAG_FRONTAGE_WIDTH] = $parser->extract_xpath("largeur façade largeur", RETURN_TYPE_NUMBER);
    $property[TAG_BEDROOMS_TOTAL] = $parser->extract_xpath("Salles de bain", RETURN_TYPE_NUMBER);
    $property[TAG_BATHROOMS_TOTAL] = $parser->extract_xpath("Nombre de salle de bain", RETURN_TYPE_NUMBER);
    $property[TAG_TOILETS_TOTAL] = $parser->extract_xpath("toilettes nombre", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Facades", RETURN_TYPE_NUMBER);
    $property[TAG_AMOUNT_OF_FLOORS] = $parser->extract_xpath("étages nombre", RETURN_TYPE_NUMBER);
    $property[TAG_GARDEN_AVAILABLE] = CrawlerTool::contains($parser->extract_xpath("Jardin"), "Oui");
    $property[TAG_GARAGES_TOTAL] = CrawlerTool::contains($parser->extract_xpath("Garage"), "Oui");
    $property[TAG_PARKINGS_TOTAL] = CrawlerTool::contains($parser->extract_xpath("Parking"), "Oui");
    $property[TAG_GAS_CONNECTION] = CrawlerTool::contains($parser->extract_xpath("gaz"), "Oui");
    $property[TAG_LIFT] = CrawlerTool::contains($parser->extract_xpath("ascenseur"), "Oui");
    $property[TAG_DOUBLE_GLAZING] = CrawlerTool::contains($parser->extract_xpath("double vitrage"), "Oui");
    $property[TAG_HEATING_FR] = $parser->extract_xpath("chauffage type");
	$property[TAG_GAS_CONNECTION] = ($parser->extract_xpath("gas") === "Ja" ? 1 : 0); 
    $property[TAG_CONNECTION_TO_WATER] = ($parser->extract_xpath("water") === "Ja" ? 1 : 0); 
    $property[TAG_TELEPHONE_CONNECTION] = ($parser->extract_xpath("telefoon") === "Ja" ? 1 : 0); 
    $property[TAG_LIFT] = ($parser->extract_xpath("lift") === "Ja" ? 1 : 0); 
    $property[TAG_FURNISHED] = ($parser->extract_xpath("Gemeubeld") === "Ja" ? 1 : 0); 
    $property[TAG_GARDEN_AVAILABLE] = ($parser->extract_xpath("Tuin") === "Ja" ? 1 : 0); 
    $property[TAG_OPEN_FIRE] = ($parser->extract_xpath("open haard aantal") ? 1 : 0); 
    $property[TAG_ALARM] = ($parser->extract_xpath("alarm") ? 1 : 0); 
    $property[TAG_PARLOPHONE] = ($parser->extract_xpath("parlofoon") ? 1 : 0); 
    $property[TAG_VIDEOPHONE] = ($parser->extract_xpath("videofoon") === "Ja" ? 1 : 0); 
	
	$property[TAG_AMOUNT_OF_FACADES] = $parser->extract_xpath("Gevels:", RETURN_TYPE_NUMBER); 
	
    $property[TAG_LOT_WIDTH] 		= $parser->extract_xpath("Perceelbreedte:", RETURN_TYPE_NUMBER); 
    $property[TAG_LOT_DEPTH] 		= $parser->extract_xpath("Perceeldiepte:", RETURN_TYPE_NUMBER); 
    $property[TAG_CONSTRUCTION_TYPE] 	= $parser->extract_xpath("Type constructie:", RETURN_TYPE_TEXT);
    $property[TAG_FRONTAGE_WIDTH] 	= $parser->extract_xpath("Gevelbreedte:", RETURN_TYPE_NUMBER); 
    $property[TAG_HEATING_NL]		= $parser->extract_xpath("Winkel:", RETURN_TYPE_NUMBER); 
    $property[TAG_SHOWERS_TOTAL]        = $parser->extract_xpath("salle de douches nombre", RETURN_TYPE_NUMBER); 
    $property[TAG_FREE_FROM]            =  $parser->extract_xpath("beschikbaar vanaf", RETURN_TYPE_TEXT); 
    $property[TAG_KITCHEN_TYPE_FR]      = $parser->extract_xpath("keuken type", RETURN_TYPE_TEXT);  

    $property[TAG_SUBDIVISION_PERMIT]   = $parser->extract_xpath("Ligging:", RETURN_TYPE_NUMBER);
    $property[TAG_PRIORITY_PURCHASE]   = $parser->extract_xpath("keuken type", RETURN_TYPE_NUMBER);
    $property[TAG_HAS_PROCEEDING]   = $parser->extract_xpath("keuken type", RETURN_TYPE_NUMBER);
    $property[TAG_FREE_FROM_DATE] = $parser->extract_xpath("Disponible de", RETURN_TYPE_UNIX_TIMESTAMP);
    if(empty($property[TAG_FREE_FROM_DATE])) $property[TAG_FREE_FROM] = $parser->extract_xpath("Disponible de");

    $bedrooms =  strtolower(str_replace(' ', '_', $property[TAG_TEXT_DESC_FR])); 
    
    if(stripos('x'.$bedrooms,"1_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 1;
	      
    if(stripos('x'.$bedrooms,"3_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 3;
	      
    if(stripos('x'.$bedrooms,"4_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 4;

    if(stripos('x'.$bedrooms,"2_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 2;

if(stripos('x'.$bedrooms,"3_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 3;
	      
    if(stripos('x'.$bedrooms,"6_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 6;

    if(stripos('x'.$bedrooms,"5_chambre") !== false)
	      $property[TAG_BEDROOMS_TOTAL] = 5;	      
	            	      
    
    getLanguageText($crawler, $property); 
    // WRITING item data to output.xml file
    
    debug($property);  
    CrawlerTool::saveProperty($property);
}

function getLanguageText($crawler, &$property)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_EN]);
    $html = str_replace("±", "", $html);
    $parser = new PageParser($html, true);

    $property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@class = 'cc_content']/p[1]", RETURN_TYPE_TEXT_ALL)));
    $property[TAG_PLAIN_TEXT_ALL_EN] = utf8_decode(CrawlerTool::encode($parser->extract_xpath("div[@class = 'wrapper']", RETURN_TYPE_TEXT_ALL)));
    
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}


