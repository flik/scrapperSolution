<?php
require_once("../crawler_classes.php");

$startPages[STATUS_TORENT] = array
(
 'http://www.cikdeurne.be/showlist.aspx?pageId=11658&goal=1' => '',
);

$startPages[STATUS_FORSELL] = array
(
"http://www.cikdeurne.be/showlist.aspx?pageId=11540&goal=0&type=1&cmMenu=2" => TYPE_HOUSE,
"http://www.cikdeurne.be/showlist.aspx?pageId=11541&goal=0&type=2&cmMenu=2" => TYPE_APARTMENT,
"http://www.cikdeurne.be/showlist.aspx?pageId=11542&goal=0&type=3&cmMenu=2" => TYPE_COMMERCIAL,
"http://www.cikdeurne.be/showlist.aspx?pageId=11543&goal=0&type=4&cmMenu=2" => TYPE_COMMERCIAL,
"http://www.cikdeurne.be/showlist.aspx?pageId=11546&goal=0&type=7&cmMenu=2" => TYPE_COMMERCIAL,
"http://www.cikdeurne.be/showlist.aspx?pageId=11544&goal=0&type=5&cmMenu=2"=> TYPE_PLOT,
"http://www.cikdeurne.be/showlist.aspx?pageId=11545&goal=0&type=6&cmMenu=2"=> TYPE_GARAGE
);


CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
	    $html = $crawler->request($page_url);
		processPage($crawler, $status, $type, $html);
		// get a list of pages to go thru from the first page
		$pageList = getPageList($html, $page_url);

		// free memory used
		unset($html);

		foreach($pageList as $nextPage) {
			//sleep(rand(15, 30));
			echo "Downloading page content..." . "<br />";
			$html = $crawler->request($nextPage);
			echo "Complete downloading page content..." . "<br />";

			// process page content
			echo "Processing page ..." . "<br />";
			processPage($crawler, $status, $type, $html);
			echo "Complete processing page ..." . "<br /><br />";

			// free memory used
			unset($html);
		}
	}
}



CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";


/**
 * Get a list of next pages
 */
function getPageList($html, $url) {
	$parser = new PageParser($html);
	$pageList = array();
	$nodes = $parser->getNodes("td[@class = 'ListPaging']/descendant::a");

	if($nodes) {
		foreach($nodes as $node) {
			$pageList[] = $url . "&cp=" . $parser->getText($node);
		}
	}

	// free memory used
	unset($dom);
	unset($xpath);

	return array_unique($pageList);
}


function processPage($crawler, $status, $type, $html)
{
	global $propertyCount;
	global $properties;
	if(empty($propertyCount)) $propertyCount = 0;
	if(empty($properties)) $properties = array();

	$parser = new PageParser($html);
	$nodes = $parser->getNodes("table[contains(@id, 'ObjectList')]/descendant::a[contains(@href, '&objectid=')][img] | table[contains(@id, 'ObjectList')]/descendant::table[contains(@onclick, '&objectid=')]");

	$items = array();
	foreach($nodes as $node)
	{
		$property = array();
		$property[TAG_STATUS] = $status;
		$property[TAG_TYPE] = $type;
		flush();
		ob_flush();
		$property[TAG_UNIQUE_URL_NL] = 'http://www.cikdeurne.be/'.$parser->getAttr($node, "href");
        $property[TAG_UNIQUE_ID] = getUniqueId($property[TAG_UNIQUE_URL_NL]);
		if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
		$properties[] = $property[TAG_UNIQUE_ID];

		$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}
	foreach($items as $item)
	{
		// keep track of number of properties processed
		$propertyCount += 1;

		//if($item["item"][TAG_UNIQUE_ID] == "16629"){
			// process item to obtain detail information
			echo "--------- Processing property #$propertyCount ...";
			echo $item["itemUrl"]."<br>";
			processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
			echo "--------- Completed<br />";
		//}
	}

	return sizeof($items);
}


function getUniqueId($url) {
	preg_match("/objectid=(\d+)/", $url, $match);
	if($match) return $match[1];
}

function processItem($crawler, $property, $html)
{
	$parser = new PageParser($html);
	$parser->deleteTags(array("script", "style"));

    $text = $parser->extract_xpath("td[contains(text(), 'Adres')]/following-sibling::td[1]");
	if($text) {
		preg_match("/(.*)[,\s]*(\d{4,})\s(.*)/", $text, $match);
		if($match) {
            echo $adres = trim(str_replace(",", "", $match[1]));
            $property[TAG_STREET]=preg_replace('/[0-9,.\/\-]/','',$adres);
            $property[TAG_NUMBER]  = trim(preg_replace("/[^0-9]/", "", $adres));
			$property[TAG_ZIP] = $match[2];
			$property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));
		}
	}
    if(empty($property[TAG_CITY])) return;
	$property[TAG_PICTURES] = $parser->extract_xpath("a[contains(@href, 'loadphotoarray')]/img[contains(@src, 'S.jpg')]/@src", RETURN_TYPE_ARRAY, function($pics)
	{
		$picUrls = array();
		foreach($pics as $pic){
		        if(stripos($pic, "no_pic.gif") !== false) continue;
		        $picUrls[] = array(TAG_PICTURE_URL => "http://www.cikdeurne.be/" . str_replace("S.jpg", "L.jpg", $pic));
     	}

		return $picUrls;
	});


	$property[TAG_PRICE] = $parser->extract_xpath("td[contains(text(), 'Prijs')]/following-sibling::td[1]", RETURN_TYPE_NUMBER);
    $text = $parser->extract_xpath("td[@class = 'content']");
    if($text) {
        preg_match("/(K.I.|KI)\s(\d+)/", $text, $match);
        if($match) {
            $KI = CrawlerTool::toNumber($match[2]);
            if($KI > 0) $property[TAG_KI]= $KI;
        }
    }

    $text = $parser->extract_xpath("td[@class = 'content']");
    if($text) {
        preg_match("/BWJ\s\D*(\d+)/", $text, $match);
        if($match) {
            $year = CrawlerTool::toNumber($match[1]);
            if($year > 0 && strlen($year) == 4) $property[TAG_CONSTRUCTION_YEAR] = $year;
        }
    }

    $property[TAG_TEXT_DESC_NL] = GetBetween($html,"d[0].content='","';");
    $property[TAG_TEXT_DESC_NL] = strip_tags($property[TAG_TEXT_DESC_NL]);
    $property[TAG_PLAIN_TEXT_ALL_NL]=$parser->extract_xpath("td[@class = 'PageBody']");
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE]               = CrawlerTool::getPropertyType(($property[TAG_PLAIN_TEXT_ALL_NL]));

    if(strtolower($property[TAG_CITY]) == "kalkan"){
    	return;
    }

	debug($property);

	// WRITING item data to output.xml file
	CrawlerTool::saveProperty($property);
}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function debug($arr){
	echo "<pre>";
	print_r($arr);
	echo "</pre>";
}

function GetBetween($content,$start,$end){
        $r = explode($start, $content);
        if (isset($r[1])){
            $r = explode($end, $r[1]);
            return $r[0];
        }
        return ''; 
}