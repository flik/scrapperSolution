<?php
require_once("./../crawler_classes.php"); 

$startPages[STATUS_FORSELL] = array
(
'http://www.immowaelkens.be/tekoop.asp?type=Woningen' => TYPE_HOUSE,
"http://www.immowaelkens.be/tekoop.asp?type=Appartementen" => TYPE_APARTMENT,
"http://www.immowaelkens.be/tekoop.asp?type=Gronden" => TYPE_PLOT

);

$startPages[STATUS_TORENT] = array
(

);




CrawlerTool::startXML();


foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
	    echo $type;
	    $html = $crawler->request($page_url);
	    processPage($crawler, $status, $type, $html,$page_url);
    }
}


CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';


function processPage($crawler, $status, $type, $html,$page_url)
{
    static $propertyCount = 0;
    static $properties = array();
    $parser = new PageParser($html);
    $property = array();
    $pattern  = "<td><table width='673'.+?<a href='(.+?)'>.+?<\/table>";
	preg_match_all ( "/" . $pattern . "/is", $html, $items_matches, PREG_SET_ORDER);

	$item = array();
    //print $html;
    foreach ($items_matches as $match) {

        $property[TAG_TYPE] = $type;
        #$property[TAG_STATUS] = $status;
        $property[TAG_STATUS] = CrawlerTool::getPropertyStatus($match[0]);
        if (stristr ($match[0], 'verkocht') or preg_replace("/\D/", "", $match[1]) == '139') {
            continue;
        }
        echo $property[TAG_UNIQUE_URL_NL]      = 'http://www.immowaelkens.be/'.str_replace('&amp;', '&', trim($match[1]));
        $property[TAG_UNIQUE_ID] = preg_replace("/\D/", "", $match[1]);
        $propertyCount += 1;
        flush();
   		ob_flush();
   		//if($property[TAG_UNIQUE_ID] == "86"){
   			// process item to obtain detail information
        	echo "--------- Processing property #$propertyCount ...";
        	processItem($crawler, $property);
        	echo "--------- Completed<br />";
   		//}

    }
}

function getUniqueId($url) {
	preg_match("/immo=(\d+)/", $url, $match);
	if($match) return $match[1];
}

function processItem($crawler, $property)
{
	//Out of Belgium
	if($property[TAG_UNIQUE_ID] == '299' || $property[TAG_UNIQUE_ID] == '282' )
	return;

    $html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
	$parser = new PageParser($html);

    $pattern = "href=\"(http:\/\/www\.immowaelkens\.be\/immofotos\/.+?)\"";
    preg_match_all("/" . $pattern . "/is", $html, $pic_url);
	foreach($pic_url[1] as $picture){
	  $pic_urls[] = array(TAG_PICTURE_URL =>(trim($picture)));
	}
	$property[TAG_PICTURES] = $pic_urls;

    $pattern = "<font size=\"3\".+?<strong>(.+?)<\/strong>";
    preg_match ( "/" . $pattern . "/is", $html, $city);
	if (isset($city[1])) {
		$property[TAG_CITY] = trim(strip_tags($city[1]));
	}

	$pattern = "<div align=\"left\"><font size=\"2\".+?>(.+?)<\/div>";
	preg_match ( "/" . $pattern . "/is", $html, $shortdescr);
	if (isset($shortdescr[1])) {
		$property[TAG_TEXT_DESC_NL] = trim (preg_replace("/(&nbsp;|\n|\r|\s+)/s", " ", html_entity_decode( strip_tags ($shortdescr[1]))));
	}

	$pattern = "VRAAGPRIJS :(.+?)<br>";
	preg_match ( "/" . $pattern . "/is", $html, $price);
	if (isset($price[1])) {
		$property[TAG_PRICE] = CrawlerTool::toNumber(strip_tags($price[1]));
	}


	if(!empty($property[TAG_PRICE]) && $property[TAG_PRICE] < 1000) {
		$property[TAG_STATUS] = "torent";
	}
	
	if(empty($property[TAG_PRICE])) 
		$property[TAG_STATUS] = "torent";

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL]);

    if(strpos($html,"VERHUURD") || strpos($html,"Verhuurd")){
        $property[TAG_STATUS] = "rented";
	return ; 
    }
    if(strpos($html,"VERKOCHT") || strpos($html,"Verkocht")){
        $property[TAG_STATUS] = "sold";
	return ; 
    }

    if($property[TAG_CITY] == "West Vlaanderen"){
    	$property[TAG_CITY] = "Kortrijk";
    }

    // Most Important 
	if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
	$property['planning_proceeding'] = 0;
	
	
	if(!isset($property['planning_permission']) || empty($property['planning_permission']))
	$property['planning_permission'] = 0;
	
	
	if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
	$property['subdivision_permit'] = 0;
	 
	if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
	$property['most_recent_destination'] = 0;
	

    debug($property);
    CrawlerTool::saveProperty($property);

}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function getvalue($parser,$start,$follow) {
    $nodes = $parser->getNodes("h1[contains(text(), $start)]/following-sibling::p/text()");
    foreach($nodes as $node) {
        $text = $parser->GetText($node);
        if(stripos($text, $follow) !== false) {
            $n = $parser->getNodes("following-sibling::strong[1]",$node);
            if($n) return $parser->GetText($n);
        }
    }
}

function debug($obj, $e = false)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
    if($e)
      exit;
    
}

?>
