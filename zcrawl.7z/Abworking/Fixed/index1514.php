<?php
require_once("../crawler_classes.php");

#$crawler->set_script_dir(realpath(dirname(__FILE__)).'/');


#$crawler->enable_delay_between_requests(5,15);
$crawler->use_cookies(true);
#$crawler->clean_cookies();
#$crawler->use_gzip(false);


$startPages[STATUS_FORSALE] = array
(
'http://www.ardennen-online.com/verkoopoverzicht_parken_nl.html'=>'',
'http://www.ardennen-online.com/verkoopoverzicht_individueel_nl.html'=>'',
'http://www.ardennen-online.com/verkoopoverzicht_kavels_nl.html'=>''
);
$startPages[STATUS_FORRENT] = array
(

);

CrawlerTool::startXML();

foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
		debugx($page_url);
		$html = $crawler->request($page_url);
		processPage($crawler, $status, $type, $html,$page_url);
	}
}


CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';


function processPage($crawler, $status, $type, $html,$page_url)
{
    static $propertyCount = 0;
    static $properties = array();
    $parser = new PageParser($html, true);
    $count=0;
    $nodes = $parser->getNodes("div[@class = 'saleshouseoverview']");
	$items = array();
	
	foreach($nodes as $node) {
		$property = array();
	    $property[TAG_STATUS] = $status;
	     
	     $para = $parser->getHTML($node);
	     
	   
		$link = str_replace(' ','_',$parser->extract_xpath("div[@class = 'blowupimg']/a/@href", RETURN_TYPE_TEXT, null, $node)); 
		
		if($link)  $property[TAG_UNIQUE_URL_NL]  = "http://www.ardennen-online.com/" . utf8_decode($link) ;
		
		$property[TAG_UNIQUE_URL_FR] = str_replace('_nl','_fr',$property[TAG_UNIQUE_URL_NL]);
		$property[TAG_UNIQUE_URL_EN] = str_replace('_nl','_uk',$property[TAG_UNIQUE_URL_NL]);
		
		//$property[TAG_UNIQUE_URL_NL] = str_replace('_uk','_nl',$property[TAG_UNIQUE_URL_EN]);
		
		$property[TAG_UNIQUE_ID]= CrawlerTool::generateId($property[TAG_UNIQUE_URL_NL]); 
		 
		if(!empty($property[TAG_UNIQUE_ID])){
			
			$n = $parser->getNode("preceding-sibling::div[@class = 'plaatsbanner']", $node);
			if($n) $property[TAG_CITY] = utf8_decode(trim(preg_replace("/\(.*\)|\d|plaats:/", "", $parser->getText($n))));
 
			$n = $parser->getNode("div[@class = 'saleshouseoverviewvanafprijs']", $node);
			if($n) {
				$text = $n->nodeValue;
				if(stripos($text, "verkocht") !== false)    $property[TAG_STATUS] = "sold";
			}
			$n = $parser->getNode("div[@class = 'saleshouseoverviewvanafprijs']", $node);
			if($n) {
				$price = CrawlerTool::toNumber($n->nodeValue);
				if($price > 0) $property[TAG_PRICE] = $price;
			}
			$n = $parser->getNode("div[@class = 'saleshouseoverviewtext']", $node);
			if($n) $property[TAG_TEXT_DESC_NL] = $parser->getText($n);
			$property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL], 999);

			if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
			$properties[] = $property[TAG_UNIQUE_ID];
			$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
		}
	}
	
	foreach($items as $item)
	{
		// keep track of number of properties processed
		$propertyCount += 1;

		// process item to obtain detail information
		echo "--------- Processing property #$propertyCount ...";
		//echo $item["itemUrl"]."<br>";
		debug($item);
		
		//processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));

		echo "--------- Completed<br />";
	}

	return sizeof($items);

}

function parentNode($node, $n = 1) {
	$parentNode = $node;
	for($i = 1; $i <= $n; $i++) $parentNode = $parentNode->parentNode;

	return $parentNode;
}

function getUniqueId($url) {
	preg_match("/\d+/", $url, $match);
	if($match) return $match[0];
}

/**
 *  Get next page
 */
function getNextPage($html,$crawler) {
    $parser = new PageParser($html);
    $nextPage="";

	$node = $parser->getNode("a[b = 'Volgende pagina']");
	if($node) $nextPage = "http://www.connexxion.biz/" . $parser->getAttr($node, "href");

	return $nextPage;
}

function processItem($crawler, $property ,$html)
{
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));
    
    $property[TAG_PLAIN_TEXT_ALL_NL]     =  utf8_decode(trim($parser->extract_xpath("div[@id = 'onderdelenvrij']", RETURN_TYPE_TEXT_ALL)));
    
    if(empty($property[TAG_TEXT_DESC_NL]))
    $property[TAG_TEXT_DESC_NL] =  utf8_decode(trim($parser->extract_xpath("div[@id = 'onderdelenvrijcontent']", RETURN_TYPE_TEXT_ALL)));
    
    
    
    $property[TAG_PICTURES] = $parser->extract_xpath("div[@class = 'smallhousedetailimages']/div/a/@href", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic)
        {
            if(!empty($pic)){
                $picUrls[] = array(TAG_PICTURE_URL => "http://www.ardennen-online.com/" . str_replace("thumb_", "", $pic));
             }
        }
        return $picUrls;
    });
    
    //Out of Belgium
    if($property[TAG_UNIQUE_ID] == '1483048256' )
    return;
		  
		  
		  $html = $crawler->request($property[TAG_UNIQUE_URL_NL]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	
	$property[TAG_PLAIN_TEXT_ALL_FR]     =  utf8_decode(trim($parser->extract_xpath("div[@id = 'onderdelenvrij']", RETURN_TYPE_TEXT_ALL)));
	$property[TAG_TEXT_DESC_FR] =  utf8_decode(trim($parser->extract_xpath("div[@id = 'onderdelenvrijcontent']", RETURN_TYPE_TEXT_ALL)));
    
	$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode($property[TAG_TEXT_DESC_FR])); 
	$property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode(CrawlerTool::encode($property[TAG_PLAIN_TEXT_ALL_FR])); 
	if(empty($property[TAG_TEXT_DESC_FR])){
		
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res); 
		$res[1] = str_replace(chr(11),'',$res[1]); 
		$property[TAG_TEXT_DESC_FR] = utf8_decode(CrawlerTool::encode(strip_tags($res[1]))); 
	}
	
	$html = $crawler->request($property[TAG_UNIQUE_URL_EN]); 
	$parser = new PageParser($html, true); 
	$parser->deleteTags(array("script", "style")); 
	
	$property[TAG_PLAIN_TEXT_ALL_EN]     =  utf8_decode(trim($parser->extract_xpath("div[@id = 'onderdelenvrij']", RETURN_TYPE_TEXT_ALL)));
	$property[TAG_TEXT_DESC_EN] =  utf8_decode(trim($parser->extract_xpath("div[@id = 'onderdelenvrijcontent']", RETURN_TYPE_TEXT_ALL)));
    
	$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode($property[TAG_TEXT_DESC_EN])); 
	$property[TAG_PLAIN_TEXT_ALL_EN] = utf8_decode(CrawlerTool::encode($property[TAG_PLAIN_TEXT_ALL_EN])); 
		
	if(empty($property[TAG_TEXT_DESC_EN])){
		preg_match('!<meta name="description" content="(.*?)"!s',$html,$res);
		$res[1] = str_replace(chr(11),'',$res[1]);
		$property[TAG_TEXT_DESC_EN] = utf8_decode(CrawlerTool::encode(strip_tags($res[1])));
	}
		  
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_DESC_NL]));
if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_NL]));

    debug($property);  
    
    $property[TAG_CITY] = str_replace('city:','',$property[TAG_CITY]);
    
    if(empty($property[TAG_CITY])) return;
    CrawlerTool::saveProperty($property);

}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function getmapinfo($text){
   preg_match('/MapView\.LonLat\((.*?)\)/',$text,$res);
   $ret=explode(",", $res[1]);
   return $ret;
}



/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}

?>