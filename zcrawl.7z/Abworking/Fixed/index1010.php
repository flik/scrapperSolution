<?php
require_once("./../crawler_classes.php");
$crawler->set_script_dir(realpath(dirname(__FILE__)).'/');

//$crawler->enable_delay_between_requests(5,15);
//$crawler->use_cookies(true);
//$crawler->clean_cookies();
//$crawler->use_gzip(false);
$startPages[STATUS_FORSELL] = array(
  'http://www.stephanegillet.be/destination/maisonsvente/' => TYPE_HOUSE,
  'http://www.stephanegillet.be/destination/terrainabatir/' => TYPE_PLOT,
  'http://www.stephanegillet.be/destination/appartementvente/' => TYPE_APARTMENT,
  'http://www.stephanegillet.be/destination/immeublesvente/' => TYPE_COMMERCIAL,
);

$startPages[STATUS_TORENT] = array(
  'http://www.stephanegillet.be/destination/appartementlocation/' => TYPE_APARTMENT,
  'http://www.stephanegillet.be/destination/maisonslocation/' => TYPE_HOUSE,
  'http://www.stephanegillet.be/destination/immeubleslocation/' => TYPE_COMMERCIAL,
  //'http://www.stephanegillet.be/destination/autreslocation/'=>TYPE_NONE,
);

CrawlerTool::startXML();

//Office Detail
$office = array();
$office[TAG_OFFICE_ID] = 1;
$office[TAG_OFFICE_NAME] = "Agence d'Andenne";
$office[TAG_OFFICE_URL] = "http://www.stephanegillet.be/";
$office[TAG_STREET] = "Place des Tilleuls";
$office[TAG_NUMBER] = "3";
$office[TAG_ZIP] = "5300";
$office[TAG_CITY] = "Andenne";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "085/71 31 76";
$office[TAG_FAX] = "085/ 71 31 78";
$office[TAG_EMAIL] = "info@stephanegillet.be";
CrawlerTool::saveOffice($office);

$office[TAG_OFFICE_ID] = 2;
$office[TAG_OFFICE_NAME] = "Agence de Ciney";
$office[TAG_OFFICE_URL] = "http://www.stephanegillet.be/";
$office[TAG_STREET] = "Rue du Centre ";
$office[TAG_NUMBER] = "15";
$office[TAG_ZIP] = "5590";
$office[TAG_CITY] = "Ciney";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "083/21 83 33";
$office[TAG_FAX] = "083/21 89 55";
$office[TAG_EMAIL] = "info@stephanegillet.be";
CrawlerTool::saveOffice($office);


$office[TAG_OFFICE_ID] = 3;
$office[TAG_OFFICE_NAME] = "Agence d’Havelange";
$office[TAG_OFFICE_URL] = "http://www.stephanegillet.be/";
$office[TAG_STREET] = "Avenue de Criel";
$office[TAG_NUMBER] = "30";
$office[TAG_ZIP] = "5370";
$office[TAG_CITY] = "Havelange";
$office[TAG_COUNTRY] = "Belgium";
$office[TAG_TELEPHONE] = "083/21 83 33";
$office[TAG_FAX] = "083/21 89 55";
$office[TAG_EMAIL] = "info@stephanegillet.be";
CrawlerTool::saveOffice($office);

foreach ($startPages as $status => $types) {
  foreach ($types as $page_url => $type) {
    $html = $crawler->request($page_url);
    processPage($crawler, $status, $type, $html);
    
    $nextPage = getNextPage($html);
    unset($html);
    
    while (strlen($nextPage) > 0) {
      echo "Downloading page content..."."<br />";
      $html = $crawler->request($nextPage);
      echo "Complete downloading page content..."."<br />";
      
      // process page content
      echo "Processing page ..."."<br />";
      processPage($crawler, $status, $type, $html);
      echo "Complete processing page ..."."<br /><br />";
      
      $nextPage = getNextPage($html);
      unset($html);
    }
  }
}

/**
 *  Get next page
 */
function getNextPage($html) {
  $nextPage = "";
  $dom = new DOMDocument();
  $dom->preserveWhiteSpace = false;
  @$dom->loadHTML($html);
  $xpath = new DOMXPath($dom);
  $parser = new PageParser($html);
  
  $node = $parser->getNode("a[contains(@class, 'nextpostslink')]");
  if ($node) {
    $nextPage = $parser->getAttr($node, "href");
  }
  
  // free memory used
  unset($dom);
  unset($xpath);
  
  return $nextPage;
}



CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';

function processPage($crawler, $status, $type, $html) {
  global $propertyCount;
  global $properties;
  if (empty($propertyCount)) {
    $propertyCount = 0;
  }
  if (empty($properties)) {
    $properties = array();
  }
  
  $parser = new PageParser($html);
  $nodes = $parser->getNodes("a[. = 'Lire la suite']");
  
  $items = array();
  foreach ($nodes as $node) {
    $property = array();
    $property[TAG_STATUS] = $status;
    $property[TAG_TYPE] = $type;
    $property[TAG_TYPE] = '';
    
    flush();
    ob_flush();
    echo $property[TAG_UNIQUE_URL_FR] = $parser->getAttr($node, "href");
    $property[TAG_UNIQUE_ID] = CrawlerTool::generateId($property[TAG_UNIQUE_URL_FR]);
    
    if (in_array($property[TAG_UNIQUE_ID], $properties)) {
      continue;
    }
    $properties[] = $property[TAG_UNIQUE_ID];
    
    $items[] = array(
      "item" => $property,
      "itemUrl" => $property[TAG_UNIQUE_URL_FR],
    );
  }
  
  preg_match_all('!OnClick="javascript:window.parent.location=\'(.*?)\'"!', $html, $res);
  foreach ($res[1] as $v) {
    $property = array();
    $property[TAG_STATUS] = $status;
    $property[TAG_TYPE] = $type;
    $property[TAG_TYPE] = '';
    flush();
    ob_flush();
    echo $property[TAG_UNIQUE_URL_FR] = urldecode(str_replace('&amp;', '&', 'http://www.stephanegillet.be/'.$v));
    $property[TAG_UNIQUE_ID] = getUniqueId($property[TAG_UNIQUE_URL_FR]);
    
    if (in_array($property[TAG_UNIQUE_ID], $properties)) {
      continue;
    }
    $properties[] = $property[TAG_UNIQUE_ID];
    
    $items[] = array(
      "item" => $property,
      "itemUrl" => $property[TAG_UNIQUE_URL_FR],
    );
  }
  

  foreach ($items as $item) {
    // keep track of number of properties processed
    $propertyCount += 1;
    
    // process item to obtain detail information
    echo "--------- Processing property #$propertyCount ...";
    echo $item["itemUrl"]."<br>";
    processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
    echo "--------- Completed<br />";
  }
  
  return sizeof($items);
}

function getUniqueId($url) {
  preg_match("/objectid=(\d+)/", $url, $match);
  if ($match) {
    return $match[1];
  }
}

function processItem($crawler, $property, $html) {
  $parser = new PageParser($html, true);
  $parser->deleteTags(array("script", "style"));
  $property[TAG_TEXT_SHORT_DESC_FR] = utf8_decode($parser->extract_xpath("div[@class = 'entry-content']/p"));
  echo $property[TAG_PRICE] = $parser->extract_xpath("span[@class = 'et-price-before']", RETURN_TYPE_NUMBER);
  $property[TAG_TEXT_TITLE_FR] = utf8_decode($parser->extract_xpath("h1[@class='title']"));
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath($property[TAG_TEXT_TITLE_FR]));
  }
  $property[TAG_CITY] = preg_match('/-(.*?)\(/', $property[TAG_TEXT_TITLE_FR], $res) ? $res[1] : '';
  $property[TAG_ZIP] = preg_match('/\((\d{4})\)/', $property[TAG_TEXT_TITLE_FR], $res) ? $res[1] : '';
  $property[TAG_PLAIN_TEXT_ALL_FR] = utf8_decode($parser->extract_xpath("article"));
  

  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
  }
  

  $property[TAG_PICTURES] = $parser->extract_xpath("div[contains(@class, 'et_slidecontent')]/img/@src", RETURN_TYPE_ARRAY,

  function($pics) {
    $picUrls = array();
    foreach ($pics as $pic) {
      if (stripos($pic, "no_pic.gif") !== false) {
        continue;
      }
      $picUrls[] = array(
        TAG_PICTURE_URL => str_replace("S.jpg",
        "L.jpg",
        $pic),
      );
    }
    
    return $picUrls;
  });
  
  if (empty($property[TAG_PICTURES])) {
    $property[TAG_PICTURES] = $parser->extract_xpath("dt[contains(@class, 'gallery-icon landscape')]/a/@href", RETURN_TYPE_ARRAY,

    function($pics) {
      $picUrls = array();
      foreach ($pics as $pic) {
        if (stripos($pic, "no_pic.gif") !== false) {
          continue;
        }
        $picUrls[] = array(
          TAG_PICTURE_URL => str_replace("S.jpg",
          "L.jpg",
          $pic),
        );
      }
      
      return $picUrls;
    });
  }
  


  if (preg_match('!GoogleX=([0-9.]+)&GoogleY=([0-9.]+)&!', $html, $res)) {
    $property[TAG_LATITUDE] = $res[1];
    $property[TAG_LONGITUDE] = $res[2];
  }
  $html1 = preg_replace('/<td align="Center" Class=".*?" width="40"><B>:<\/B><\/td>/', '', $html);
  //parse fields
  $vars = array();
  preg_match_all('!<li>([^<>]+):([^<>]+)</li>!', $html1, $res, PREG_SET_ORDER);
  foreach ($res as $arr) {
    $arr[1] = strtolower($arr[1]);
    $arr[1] = trim(strip_tags($arr[1]));
    $arr[1] = preg_replace('![^a-z0-9_\-\. ]!', '', $arr[1]);
    $arr[1] = preg_replace('!nbsp!', '', $arr[1]);
    $vars[$arr[1]] = trim(strip_tags($arr[2]));

    #echo '<br>';
  }
  
  if (isset($vars['type'])) {
    unset($vars['type']);
  }
  

  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_FR], 999);
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_TEXT_SHORT_DESC_FR]));
  }
  if (empty($property[TAG_TYPE])) {
    $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($property[TAG_PLAIN_TEXT_ALL_FR]));
  }
  
  $property[TAG_HEATING_FR] = get_var($vars, 'chauffage');
  $property[TAG_SURFACE_CONSTRUCTION] = str_replace(',', '.', get_var($vars, 'superficie totale', '!([0-9,]+)!'));
  $property[TAG_PROPERTY_TAX] = get_var($vars, 'charges', '!(\d+)!');
  $totalfloor = get_var($vars, 'nbr. tages btiment', '!(\d+)!');
  if (!empty($totalfloor)) {
    $property[TAG_AMOUNT_OF_FLOORS] = $totalfloor;
  }
  $property[TAG_SURFACE_LIVING_AREA] = get_var($vars, 'superficie construite', '!(\d+)!');
  if (empty($property[TAG_SURFACE_LIVING_AREA])) {
    $property[TAG_SURFACE_LIVING_AREA] = get_var($vars, 'superficie living', '!(\d+)!');
  }
  
  $property[TAG_KI] = get_var($vars, 'r.c', '!(\d+)!');
  $property[TAG_SURFACE_GROUND] = get_var($vars, 'superficie terrain', '!(\d+)!');
  $property[TAG_EPC_VALUE] = get_var($vars, 'peb', '!(\d+)!');
  $property[TAG_CONSTRUCTION_YEAR] = get_var($vars, 'anne de construction', '!(\d+)!');
  $property[TAG_SHOWERS_TOTAL] = get_var($vars, 'nombre de salles de douche', '!(\d+)!');
  $text = get_var($vars, 'etages', '!(\d+)!');
  if (!empty($text)) {
    $property[TAG_FLOOR] = $text;
  }
  $bedrooms = get_var($vars, 'chambres', '!(\d+)!');
  if (!empty($bedrooms)) {
    $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT] = $bedrooms;
  }
  $livings = get_var($vars, 'opp. woonkamer');
  $Garages = get_var($vars, 'garages');
  $bathrooms = get_var($vars, 'salles de bain');
  $toilets = get_var($vars, 'toilettes');
  $kitchens = get_var($vars, 'cuisine');
  $storages = get_var($vars, 'opp. berging');
  $terraces = get_var($vars, 'terrasse');
  $cellars = get_var($vars, 'opp. kelder');
  $halls = get_var($vars, 'hal', '!(\d+)!');
  $studies = get_var($vars, 'kantoor', '!(\d+)!');
  $freepossesions = get_var($vars, 'praktijkruimte');
  $attics = get_var($vars, 'opp. zolder');
  $rooms = get_var($vars, 'aantal slk.');
  if (!empty($rooms)) {
    $room = $parser->regex("/(\d)$/", $rooms);
  }
  

  if (!empty($attics)) {
    $attictotal = $parser->regex("/(\d)$/", $attics);
  }
  if (!empty($livings)) {
    $livingtotal = $parser->regex("/(\d)$/", $livings);
  }
  if (!empty($Garages)) {
    $garagetotal = $parser->regex("/(\d)$/", $Garages);
  }
  if (!empty($bathrooms)) {
    $bathroomtotal = $parser->regex("/(\d)$/", $bathrooms);
  }
  if (!empty($toilets)) {
    $toilettotal = $parser->regex("/(\d)$/", $toilets);
  }
  if (!empty($kitchens)) {
    $kitchentotal = $parser->regex("/(\d)$/", $kitchens);
  }
  if (!empty($storages)) {
    $storagetotal = $parser->regex("/(\d)$/", $storages);
  }
  if (!empty($terraces)) {
    $terracetotal = $parser->regex("/(\d)$/", $terraces);
  }
  if (!empty($cellars)) {
    $cellartotal = $parser->regex("/(\d)$/", $cellars);
  }
  if (!empty($halls)) {
    $halltotal = $parser->regex("/(\d)$/", $halls);
  }
  if (!empty($studies)) {
    $studytotal = $parser->regex("/(\d)$/", $studies);
  }
  if (!empty($freepossesions)) {
    $freepossesiontotal = $parser->regex("/(\d)$/", $freepossesions);
  }
  
  if (!empty($attics)) {
    $atticsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $attics);
  }
  if (!empty($livings)) {
    $livingsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $livings);
  }
  if (!empty($Garages)) {
    $garagesurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $Garages);
  }
  if (!empty($bathrooms)) {
    $bathroomsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $bathrooms);
  }
  if (!empty($toilets)) {
    $toiletsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $toilets);
  }
  if (!empty($kitchens)) {
    $kitchensurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $kitchens);
  }
  if (!empty($storages)) {
    $storagesurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $storages);
  }
  if (!empty($terraces)) {
    $terracesurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $terraces);
  }
  if (!empty($cellars)) {
    $cellarsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $cellars);
  }
  if (!empty($halls)) {
    $hallsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $halls);
  }
  if (!empty($studies)) {
    $studysurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $studies);
  }
  if (!empty($freepossesions)) {
    $freepossesionsurface = $parser->regex("/((\d+,\d+)|(\d+))\sm/", $freepossesions);
  }
  
  $atticdesc = $parser->regex("/([a-zA-Z_-\s]*)/", $attics);
  
  $garagedesc = $parser->regex("/([a-zA-Z_-\s]*)/", $Garages);
  $bathroomdesc = $parser->regex("/([a-zA-Z_-\s]*)/", $bathrooms);
  $toiletdesc = $parser->regex("/([a-zA-Z_-\s]*)/", $toilets);
  $kitchendesc = $parser->regex("/([a-zA-Z_-\s]*)/", $kitchens);
  $storagedesc = $parser->regex("/([a-zA-Z_-\s]*)/", $storages);
  $terracedesc = $parser->regex("/([a-zA-Z_-\s]*)/", $terraces);
  $cellardesc = $parser->regex("/([a-zA-Z_-\s]*)/", $cellars);
  $livingdesc = $parser->regex("/([a-zA-Z_-\s]*)/", $livings);
  $floorplandesc = $parser->regex("/([a-zA-Z_-\s]*)/", $parser->extract_xpath("Grondplannen"));
  $halldesc = $parser->regex("/([a-zA-Z_-\s]*)/", $halls);
  $studydesc = $parser->regex("/([a-zA-Z_-\s]*)/", $studies);
  $freepossesiondesc = $parser->regex("/([a-zA-Z_-\s]*)/", $freepossesions);
  
  $halls = array();
  $totalhalls = array();
  if (!empty($halldesc)) {
    $halls[TAG_HALL_DESC_FR] = $halldesc;
  }
  if (!empty($hallsurface)) {
    $halls[TAG_HALL_SURFACE] = $hallsurface;
  }
  if (!empty($halls)) {
    $totalhalls[] = $halls;
  }
  if (!empty($totalhalls)) {
    $property[TAG_halls] = $totalhalls;
  }
  
  $freepossesion = array();
  $totalfreepossesions = array();
  if (!empty($freepossesiondesc)) {
    $freepossesion[TAG_FREE_PROFESSION_DESC_FR] = $freepossesiondesc;
  }
  if (!empty($freepossesionsurface)) {
    $freepossesion[TAG_FREE_PROFESSION_SURFACE] = $freepossesionsurface;
  }
  if (!empty($freepossesion)) {
    $totalfreepossesions[] = $freepossesion;
  }
  if (!empty($totalfreepossesions)) {
    $property[TAG_FREE_PROFESSIONS] = $totalfreepossesions;
  }
  
  $study = array();
  $totalstudys = array();
  if (!empty($studydesc)) {
    $study[TAG_STUDY_DESC_FR] = $studydesc;
  }
  if (!empty($studysurface)) {
    $study[TAG_STUDY_SURFACE] = $studysurface;
  }
  if (!empty($study)) {
    $totalstudys[] = $study;
  }
  if (!empty($totalstudys)) {
    $property[TAG_STUDIES] = $totalstudys;
  }
  
  $attic = array();
  $totalattics = array();
  if (!empty($atticdesc)) {
    $bathroom[TAG_ATTIC_DESC_FR] = $atticdesc;
  }
  if (!empty($atticsurface)) {
    $bathroom[TAG_ATTIC_SURFACE] = $atticsurface;
  }
  if (!empty($attic)) {
    $totalattics[] = $attic;
  }
  if (!empty($totalattics)) {
    $property[TAG_ATTICS] = $totalattics;
  }
  
  $cellar = array();
  $totalcellars = array();
  if (!empty($cellardesc)) {
    $cellar[TAG_CELLAR_DESC_FR] = $cellardesc;
  }
  if (!empty($cellarsurface)) {
    $cellar[TAG_CELLAR_SURFACE] = $cellarsurface;
  }
  if (!empty($cellar)) {
    $totalcellars[] = $cellar;
  }
  if (!empty($totalcellars)) {
    $property[TAG_CELLARS] = $totalcellars;
  }
  
  $toilet = array();
  $totaltoilets = array();
  if (!empty($toiletdesc)) {
    $toilet[TAG_TOILET_DESC_FR] = $toiletdesc;
  }
  if (!empty($toiletsurface)) {
    $toilet[TAG_TOILET_SURFACE] = $toiletsurface;
  }
  if (!empty($toilet)) {
    $totaltoilets[] = $toilet;
  }
  if (!empty($totaltoilets)) {
    $property[TAG_TOILETS] = $totaltoilets;
  }
  
  $garage = array();
  $totalgarages = array();
  if (!empty($garagedesc)) {
    $garage[TAG_GARAGE_DESC_FR] = $garagedesc;
  }
  if (!empty($garagesurface)) {
    $garage[TAG_GARAGE_SURFACE] = $garagesurface;
  }
  if (!empty($garage)) {
    $totalgarages[] = $garage;
  }
  if (!empty($totalgarages)) {
    $property[TAG_GARAGES] = $totalgarages;
  }
  
  $kitchen = array();
  $totalkitchens = array();
  
  if (!empty($kitchendesc)) {
    $kitchen[TAG_KITCHEN_DESC_FR] = $kitchendesc;
  }
  if (!empty($kitchensurface)) {
    $kitchen[TAG_KITCHEN_SURFACE] = $kitchensurface;
  }
  if (!empty($kitchen)) {
    $totalkitchens[] = $kitchen;
  }
  if (!empty($totalkitchens)) {
    $property[TAG_KITCHENS] = $totalkitchens;
  }
  
  $storage = array();
  $totalstorages = array();
  if (!empty($storagedesc)) {
    $storage[TAG_STOREROOM_DESC_FR] = $storagedesc;
  }
  if (!empty($storagesurface)) {
    $storage[TAG_STOREROOM_SURFACE] = $storagesurface;
  }
  if (!empty($storage)) {
    $totalstorages[] = $storage;
  }
  if (!empty($totalstorages)) {
    $property[TAG_STOREROOMS] = $totalstorages;
  }
  
  $terrace = array();
  $totalterraces = array();
  if (!empty($terracedesc)) {
    $terrace[TAG_TERRACE_DESC_FR] = $terracedesc;
  }
  if (!empty($terracesurface)) {
    $terrace[TAG_TERRACE_SURFACE] = $terracesurface;
  }
  if (!empty($terrace)) {
    $totalterraces[] = $terrace;
  }
  if (!empty($totalterraces)) {
    $property[TAG_TERRACES] = $totalterraces;
  }
  
  $living = array();
  $totallivings = array();
  if (!empty($livingdesc)) {
    $living[TAG_LIVING_DESC_FR] = $livingdesc;
  }
  if (!empty($livingsurface)) {
    $living[TAG_LIVING_SURFACE] = $livingsurface;
  }
  if (!empty($living)) {
    $totallivings[] = $living;
  }
  if (!empty($totallivings)) {
    $property[TAG_LIVINGS] = $totallivings;
  }
  
  if (empty($bedroomtotal) && !empty($room)) {
    $bedroomtotal = $room;
  }

  # if(!empty($bedroomtotal))  $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT]=$bedroomtotal;
  if (!empty($livingtotal)) {
    $property[TAG_LIVINGS][TAG_TOTAL_AMOUNT] = $livingtotal;
  }
  if (!empty($toilettotal)) {
    $property[TAG_TOILETS][TAG_TOTAL_AMOUNT] = $toilettotal;
  }
  if (!empty($cellartotal)) {
    $property[TAG_CELLARS][TAG_TOTAL_AMOUNT] = $cellartotal;
  }
  if (!empty($kitchentotal)) {
    $property[TAG_KITCHENS][TAG_TOTAL_AMOUNT] = $kitchentotal;
  }
  
  if (!empty($garagetotal)) {
    $property[TAG_GARAGES][TAG_TOTAL_AMOUNT] = $garagetotal;
  }
  if (!empty($terracetotal)) {
    $property[TAG_TERRACES][TAG_TOTAL_AMOUNT] = $terracetotal;
  }
  if (!empty($storagetotal)) {
    $property[TAG_STOREROOMS][TAG_TOTAL_AMOUNT] = $storagetotal;
  }
  if (!empty($attictotal)) {
    $property[TAG_ATTICS][TAG_TOTAL_AMOUNT] = $attictotal;
  }
  
  if (!empty($garagetotal)) {
    $property[TAG_GARAGES][TAG_TOTAL_AMOUNT] = $garagetotal;
  }
  $parkingtotal = get_var($vars, 'parkings', '!(\d+)!');
  if (!empty($parkingtotal)) {
    $property[TAG_PARKINGS_TOTAL] = $parkingtotal;
  }
  
  // Most Important
  if (!isset($property['planning_proceeding']) || $property['planning_proceeding'] != 1) {
    $property['planning_proceeding'] = '';
  }
  

  if (!isset($property['planning_permission']) || $property['planning_permission'] != 1) {
    $property['planning_permission'] = '';
  }
  

  if (!isset($property['subdivision_permit']) || $property['subdivision_permit'] != 1) {
    $property['subdivision_permit'] = '';
  }
  
  if (!isset($property['most_recent_destination']) || $property['most_recent_destination'] != 1) {
    $property['most_recent_destination'] = '';
  }
  


  $unmatched_variables = array();
  foreach ($vars as $label => $value) {
    $unmatched_variables[] = array(
      TAG_VARIABLE_LABEL => $label,
      TAG_VARIABLE_VALUE => $value,
    );
  }
  $property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;
  

  if ($property[TAG_CITY] == '5300' || $property[TAG_CITY] == 'Andenne') {
    $property[TAG_OFFICE_ID] = 1;
  }
  
  if ($property[TAG_CITY] == '5590' || $property[TAG_CITY] == 'Ciney') {
    $property[TAG_OFFICE_ID] = 2;
  }
  

  if ($property[TAG_CITY] == '5370' || $property[TAG_CITY] == 'Havelange') {
    $property[TAG_OFFICE_ID] = 3;
  }
  
  CrawlerTool::saveProperty($property);
}

function get_var(&$vars, $field, $regex = '') {
  if (isset($vars[$field])) {
    $x = $vars[$field];
    unset($vars[$field]);
    
    if (!empty($regex)) {
      return(preg_match($regex, $x, $res)) ? $res[1] : false;
    }
    return trim($x);
  }
  
  return false;
}

function getvalue($parser, $start, $follow) {
  $nodes = $parser->getNodes("h1[contains(text(), $start)]/following-sibling::p/text()");
  foreach ($nodes as $node) {
    $text = $parser->GetText($node);
    if (stripos($text, $follow) !== false) {
      $n = $parser->getNodes("following-sibling::strong[1]", $node);
      if ($n) {
        return $parser->GetText($n);
      }
    }
  }
}

?>
