<?php

/* ============================= CONFIG ============================= */

// Crawler ID 2023

require_once("../crawler_classes.php");

$crawler->enable_delay_between_requests(5, 10);
$startPages[STATUS_FORSALE] = array
(
    TYPE_NONE        =>  array
    (
        'http://www.agenceleroy.be/de-panne/verkooplijst?filter1=&filter4=**ALL**'
    ),
);
$startPages[STATUS_TORENT] = array
(
    TYPE_NONE        =>  array
    (
        "http://www.agenceleroy.be/de-panne/jaarverhuur"
    )
    
);
/* ============================= END CONFIG ============================= */


/* ============================= TEST AREA ============================= */

/*$html = file_get_contents("p-1.htm");
processPage(new Crawler(null), "forsale", "house", $html);
exit;*/





/*$html = file_get_contents("d-1.htm");
#processItem(new Crawler(null), array(TAG_UNIQUE_ID => "", TAG_UNIQUE_URL_NL => "", TAG_UNIQUE_URL_FR => "", TAG_STATUS => "", TAG_TYPE => ""), $html);
exit;*/


/* ============================= END TEST AREA ============================= */

// START writing data to output.xml file
CrawlerTool::startXML();
foreach($startPages as $status => $types)
{
    foreach($types as $type => $pages)
    {
        foreach($pages as $page)
        {

            $html = $crawler->request($page);
            processPage($crawler, $status, $type, $html);
			echo "Complete processing page ..." . "<br /><br />";

			$nextPage = getNextPage($html);
			unset($html);

			while(strlen($nextPage) > 0) {
				echo "Downloading page content..." . "<br />";
				$html = $crawler->request($nextPage);
				echo "Complete downloading page content..." . "<br />";

				// process page content
				echo "Processing page ..." . "<br />";
				processPage($crawler, $status, $type, $html);
				echo "Complete processing page ..." . "<br /><br />";

				$nextPage = getNextPage($html);
				unset($html);
			}
		}
    }
}

// END writing data to output.xml file
CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

/**
 * Get a list of next pages
 */
function getNextPage($html) {
	$pageList = array();
    $parser = new PageParser($html);


	$node = $parser->getNode("a[contains(text(), 'volgende')]");
	if($node) $nextPage = "http://www.agenceleroy.be/".$parser->getAttr($node, "href");

	// free memory used
	unset($dom);
	unset($xpath);

	return $nextPage;
}

function getUniqueId($url) {
	preg_match("/node\/(\d+)/", $url, $match);
	if($match) return $match[1];
}


function processPage($crawler, $status, $type, $html)
{
	global $propertyCount;
	global $properties;
	if(empty($propertyCount)) $propertyCount = 0;
	if(empty($properties)) $properties = array();

	$parser = new PageParser($html);
	$nodes = $parser->getNodes("a[@class = 'meer']");
	$items = array();
	foreach($nodes as $node)
	{
		echo $property[TAG_UNIQUE_URL_NL]      = "http://www.agenceleroy.be/de-panne/".$parser->getAttr($node, "href");
		echo $property[TAG_UNIQUE_ID] = getUniqueId($property[TAG_UNIQUE_URL_NL]);
		if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
		$properties[] = $property[TAG_UNIQUE_ID];
		$n = $parser->getNode("preceding-sibling::b[1]", $node);
		if($n) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->getText($n));

		$items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_NL]);
	}

	foreach($items as $item)
	{
		// keep track of number of properties processed
		$propertyCount += 1;

		// process item to obtain detail information
		echo "--------- Processing property #$propertyCount ...";
		echo $item["itemUrl"]."<br>";
		processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
		echo "--------- Completed<br />";
	}

}

/**
 * Download and extract item detail information
 */
function processItem($crawler, $property, $html)
{
    $html = $crawler->request('http://www.agenceleroy.be/de-panne/node/13979059');
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));
    $property[TAG_STATUS] = "forsale";
    $property[TAG_TEXT_DESC_NL] = $parser->extract_xpath("h3[contains(text(), 'Beschrijving')]/following-sibling::text()[1]");
	$node = $parser->getNode("h3[contains(text(), 'Geografische ligging')]/following-sibling::text()[1]");
    
	if($node) {
        $text = $parser->getText($node);
		preg_match("/(.*)\s([0-9]+)\s(.*)/", $text, $match);
        if($match) {
            $adres = trim($match[1]);
            $property[TAG_STREET]=preg_replace('/[0-9,.]/','',$adres);
            $property[TAG_NUMBER] = preg_replace("/[^0-9]/", '',$adres);
			$property[TAG_ZIP] = $match[2];
			$property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[3]));
		}
	}
    if($property[TAG_ZIP] > 9999){
        unset($property[TAG_ZIP]);
    }

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL]);
    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("h1"));
    #$property[TAG_PLAIN_TEXT_ALL_NL] = $parser->extract_xpath("div[@class = 'pand'] | div[@class = 'detail_kenmerken'] | div[@class = 'detail_ligging']", RETURN_TYPE_TEXT_ALL);
    $property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox']/@href", RETURN_TYPE_ARRAY, function($pics)
    {
        $picUrls = array();
        foreach($pics as $pic){
            $picUrls[] = array(TAG_PICTURE_URL =>  "http://www.agenceleroy.be" .$pic);
        }
        return $picUrls;
    });
	preg_match_all('!<td><strong>([^<>]+)</strong></td>\s+<td>([^<>]+)<!',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim($arr[1]);
		$arr[1] = preg_replace('!&nbsp;!','',$arr[1]);
		echo $arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
  	    echo $vars[$arr[1]] = str_replace('&nbsp;','',$arr[2]);

		echo "<br>";
	}
    $property[TAG_PRICE]                   = CrawlerTool::toNumber(get_var($vars,'prijs'));
	$property[TAG_SURFACE_GROUND] = get_var($vars,'oppervlakte','!(\d+)!');

    $features=get_var($vars,'voorzieningen');
    $property[TAG_GAS_CONNECTION] =(preg_match('!Aardgas!',$features,$res)) ? 1 : '';
    $property[TAG_CONNECTION_TO_WATER] =(preg_match('!Stadswater!',$features,$res)) ? 1 : 0;
    $property[TAG_TELEPHONE_CONNECTION] =(preg_match('!Telefoon!',$features,$res)) ? 1 : 0;
    $property[TAG_INTERNET_CONNECTION] =(preg_match('!Internet!',$features,$res)) ? 1 : 0;
    $property[TAG_VIDEOPHONE] =(preg_match('!Videofoon!',$features,$res)) ? 1 : 0;
    $property[TAG_DISTRIBUTION] =(preg_match('!Distributie!',$features,$res)) ? 1 : 0;
    $property[TAG_CONNECTION_TO_SEWER] =(preg_match('!Riolering!',$features,$res)) ? 1 : 0;

	$property[TAG_KI] = get_var($vars,'kadastraal inkomen  bedrag','!(\d+)!');
	$property[TAG_KI_INDEX] = get_var($vars,"kad.ink. gendexeerd bedrag",'!(\d+)!');
	$property[TAG_PROPERTY_TAX] = get_var($vars,'onroerende voorheffing bedrag','!(\d+)!');
	$totalfloor = get_var($vars,'verdieping','!(\d+)!');
	if(!empty($totalfloor)) $property[TAG_FLOOR]=$totalfloor;

	$property[TAG_RENOVATION_YEAR] = get_var($vars,'renovatie jaar','!(\d{4})!');
	$property[TAG_SURFACE_LIVING_AREA] = get_var($vars,'oppervlakte bewoonbaar','!(\d+)!');
	$property[TAG_FREE_FROM_DATE] = CrawlerTool::toUnixTimestamp(get_var($vars,'beschikbaarheid'));
	if(empty($property[TAG_GARAGES_TOTAL])) $property[TAG_GARAGES_TOTAL] = get_var($vars,'garage') == 'Ja' ? 1 : '';
	$property[TAG_PARKINGS_TOTAL] = get_var($vars,'parking buiten aantal','!(\d+)!');
	if(empty($property[TAG_PARKINGS_TOTAL])) $property[TAG_PARKINGS_TOTAL]         = get_var($vars,'parking') == 'Ja' ? 1 : '';
	$property[TAG_AMOUNT_OF_FACADES] = get_var($vars,'gevels','!(\d+)!');
	$property[TAG_AMOUNT_OF_FLOORS] = get_var($vars,'verdiepingen aantal','!(\d+)!');
	$property[TAG_COMMON_COSTS] = get_var($vars,'lasten','!(\d+)!');
	$property[TAG_GAS_CONNECTION] = (get_var($vars,'gas') === "Ja" ? 1 : 0);
	$property[TAG_CONNECTION_TO_WATER] = (get_var($vars,'water') === "Ja" ? 1 : 0);
	$property[TAG_TELEPHONE_CONNECTION] = (get_var($vars,'telefoon') === "Ja" ? 1 : 0);
	$property[TAG_DOUBLE_GLAZING]=CrawlerTool::contains(get_var($vars,'dubbele beglazing') ,"Ja");
	$property[TAG_LIFT] = (get_var($vars,'lift') === "Ja" ? 1 : 0);
	$property[TAG_FURNISHED] = (get_var($vars,'gemeubeld') === "Ja" ? 1 : 0);
	$property[TAG_GARDEN_AVAILABLE] = (get_var($vars,'tuin') === "Ja" ? 1 : 0);
	$property[TAG_OPEN_FIRE] = (get_var($vars,'open haard aantal') === "Ja" ? 1 : 0);
	$property[TAG_ALARM] = (get_var($vars,'alarm') === "Ja" ? 1 : 0);
	$property[TAG_PARLOPHONE] = (get_var($vars,'parlofoon') === "Ja" ? 1 : 0);
	$property[TAG_VIDEOPHONE] = (get_var($vars,'videofoon') === "Ja" ? 1 : 0);
    $property[TAG_SUBDIVISION_PERMIT]=(get_var($vars,'verkavelingsvergunning') === "Ja" ? 1 : 0);
    $property[TAG_PRIORITY_PURCHASE]=(get_var($vars,'voorkooprecht') === "Ja" ? 1 : 0);
    $property[TAG_MOST_RECENT_DESTINATION]=(get_var($vars,'terrein bestemming') === "Ja" ? 1 : 0);
    $property[TAG_PLANNING_PERMISSION]=(get_var($vars,'bouwvergunning') === "Ja" ? 1 : 0);
    $property[TAG_FRONTAGE_WIDTH] =get_var($vars,'gevelbreedte');
    $property[TAG_SURFACE_CONSTRUCTION] = get_var($vars,'bruto oppervlakte','!(\d+)!');
    $property[TAG_HEATING_NL] = get_var($vars,'verwarming');
    $property[TAG_CONSTRUCTION_YEAR]=get_var($vars,'bouwjaar','!(\d{4})!');
    $property[TAG_HAS_PROCEEDING] =CrawlerTool::contains(get_var($vars,'dagvaarding'),'Ja');
 	preg_match_all("/slaapkamer (\d+)/s",$html,$res1);
    $count=0;
 	$set=0;
 	foreach($res1[1] as $arr)
	{
        $bedroomsurface=get_var($vars,'slaapkamer '.$arr,'!(\d+)!');

        $bedroom[TAG_BEDROOM_SURFACE]=$bedroomsurface;
        if(!empty($bedroom)) $totalbedrooms[] = $bedroom;
        if(!empty($totalbedrooms)) $property[TAG_BEDROOMS] = $totalbedrooms;

	}
    $bedrooms=get_var($vars,'slaapkamers');
    $livings=get_var($vars,'woonkamer');
    $Garages=get_var($vars,'garage');
    $bathrooms=get_var($vars,'badkamer');
    $toilets=get_var($vars,'toilet');
    $kitchens=get_var($vars,'keuken');
    $storages=get_var($vars,'berging');
    $terraces=get_var($vars,'terras');
    if(empty($terraces)) $terraces=get_var($vars,'terras 1');
    $cellars=get_var($vars,'kelder');
    $halls=get_var($vars,'inkomhal');
    $studies=get_var($vars,'kantoor','!(\d+)!');
    $freepossesions=get_var($vars,'praktijkruimte');
    $attics=get_var($vars,'zolder');
    $rooms=get_var($vars,'aantal kamers');
    if(!empty($rooms)) $room=$parser->regex("/(\d)$/", $rooms);

    if(!empty($bedrooms)) $bedroomtotal=$parser->regex("/(\d)$/", $bedrooms);
    if(!empty($attics)) $attictotal=$parser->regex("/(\d)$/", $attics);
    if(!empty($livings)) $livingtotal=$parser->regex("/(\d)$/", $livings);
    if(!empty($Garages)) $garagetotal=$parser->regex("/(\d)$/", $Garages);
    if(!empty($bathrooms)) $bathroomtotal=$parser->regex("/(\d)$/", $bathrooms);
    if(!empty($toilets)) $toilettotal=$parser->regex("/(\d)$/", $toilets);
    if(!empty($kitchens)) $kitchentotal=$parser->regex("/(\d)$/", $kitchens);
    if(!empty($storages)) $storagetotal=$parser->regex("/(\d)$/", $storages);
    if(!empty($terraces)) $terracetotal=$parser->regex("/(\d)$/", $terraces);
    if(!empty($cellars)) $cellartotal=$parser->regex("/(\d)$/", $cellars);
    if(!empty($halls)) $halltotal=$parser->regex("/(\d)$/", $halls);
    if(!empty($studies)) $studytotal=$parser->regex("/(\d)$/", $studies);
    if(!empty($freepossesions)) $freepossesiontotal=$parser->regex("/(\d)$/", $freepossesions);

    if(!empty($bedrooms)) $bedroomsurface=CrawlerTool::toNumber($bedrooms);
    if(!empty($attics)) $atticsurface=CrawlerTool::toNumber($attics);
    if(!empty($livings)) $livingsurface=CrawlerTool::toNumber($livings);
    if(!empty($Garages)) $garagesurface=CrawlerTool::toNumber($Garages);
    if(!empty($bathrooms)) $bathroomsurface=CrawlerTool::toNumber($bathrooms);
    if(!empty($toilets)) $toiletsurface=CrawlerTool::toNumber($toilets);
    if(!empty($kitchens)) $kitchensurface=CrawlerTool::toNumber($kitchens);
    if(!empty($storages)) $storagesurface=CrawlerTool::toNumber($storages);
    if(!empty($terraces)) $terracesurface=CrawlerTool::toNumber($terraces);
    if(!empty($cellars)) $cellarsurface=CrawlerTool::toNumber($cellars);
    if(!empty($halls))  $hallsurface=CrawlerTool::toNumber($halls);
    if(!empty($studies)) $studysurface=CrawlerTool::toNumber($studies);
    if(!empty($freepossesions)) $freepossesionsurface=CrawlerTool::toNumber($freepossesions);

  #  if(empty($terracesurface)) $terracesurface=$parser->extract_xpath("Terras opervlakte",RETURN_TYPE_NUMBER);
  #  if(empty($cellarsurface)) $cellarsurface=$parser->extract_xpath("Kelder opp",RETURN_TYPE_NUMBER);

    $atticdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $attics);

    $garagedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $Garages);
    $bathroomdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $bathrooms);
    $toiletdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $toilets);
    $kitchendesc=$parser->regex("/([a-zA-Z_-\s]*)/", $kitchens);
    $storagedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $storages);
    $terracedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $terraces);
    $cellardesc=$parser->regex("/([a-zA-Z_-\s]*)/", $cellars);
    $livingdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $livings);
    $floorplandesc=$parser->regex("/([a-zA-Z_-\s]*)/", $parser->extract_xpath("Grondplannen"));
    $halldesc=$parser->regex("/([a-zA-Z_-\s]*)/", $halls);
    $studydesc=$parser->regex("/([a-zA-Z_-\s]*)/", $studies);
    $freepossesiondesc=$parser->regex("/([a-zA-Z_-\s]*)/", $freepossesions);

	$parser->extract_xpath("dt[contains(text(), 'Slaapkamer')]/following-sibling::dd[1]", RETURN_TYPE_ARRAY, function($arr) use(&$property)
	{
		$bedrooms = array();
		foreach($arr as $count=>$surface)
		{
			$surface = CrawlerTool::toNumber($surface);
			$bedroom = array(TAG_BEDROOM_SURFACE => $surface, TAG_BEDROOM_DESC_NL => "slaapkamer " . ($count + 1) . " oppervlakte (m²)");
			$bedrooms[] = $bedroom;
		}

		if(!empty($bedrooms)) $property[TAG_BEDROOMS] = $bedrooms;
	});


 	preg_match_all("/Slaapkamer (\d+)/s",$html,$res1);
    $count=0;
 	$set=0;
 	foreach($res1[1] as $arr)
	{
        $bedroomsurface=get_var($vars,'slaapkamer '.$arr,'!(\d+)!');

        $bedroom[TAG_BEDROOM_SURFACE]=$bedroomsurface;
        if(!empty($bedroom)) $totalbedrooms[] = $bedroom;
        if(!empty($totalbedrooms)) $property[TAG_BEDROOMS] = $totalbedrooms;

	}

 	preg_match_all("/Badkamer (\d+)/s",$html,$res1);
    $count=0;
 	$set=0;
 	foreach($res1[1] as $arr)
	{
        $bathroomsurface=get_var($vars,'badkamer '.$arr,'!(\d+)!');

        $bathroom[TAG_BATHROOM_SURFACE]=$bathroomsurface;
        if(!empty($bathroom)) $totalbathrooms[] = $bathroom;
        if(!empty($totalbathrooms)) $property[TAG_BATHROOMS] = $totalbathrooms;

	}

    $halls = array();
    $totalhalls = array();
    if(!empty($halldesc)) 		 $halls[TAG_HALL_DESC_NL]=$halldesc;
    if(!empty($hallsurface)) 		 $halls[TAG_HALL_SURFACE]=$hallsurface;
    if(!empty($halls)) $totalhalls[] = $halls;
    if(!empty($totalhalls)) $property[TAG_HALLS] = $totalhalls;

    $freepossesion = array();
    $totalfreepossesions = array();
    if(!empty($freepossesiondesc)) 		 $freepossesion[TAG_FREE_PROFESSION_DESC_NL]=$freepossesiondesc;
    if(!empty($freepossesionsurface)) 		 $freepossesion[TAG_FREE_PROFESSION_SURFACE]=$freepossesionsurface;
    if(!empty($freepossesion)) $totalfreepossesions[] = $freepossesion;
    if(!empty($totalfreepossesions)) $property[TAG_FREE_PROFESSIONS] = $totalfreepossesions;

    $study = array();
    $totalstudys = array();
    if(!empty($studydesc)) 		 $study[TAG_STUDY_DESC_NL]=$studydesc;
    if(!empty($studysurface)) 		 $study[TAG_STUDY_SURFACE]=$studysurface;
    if(!empty($study)) $totalstudys[] = $study;
    if(!empty($totalstudys)) $property[TAG_STUDIES] = $totalstudys;

    $attic = array();
    $totalattics = array();
    if(!empty($atticdesc)) 		 $bathroom[TAG_ATTIC_DESC_NL]=$atticdesc;
    if(!empty($atticsurface)) 		 $bathroom[TAG_ATTIC_SURFACE]=$atticsurface;
    if(!empty($attic)) $totalattics[] = $attic;
    if(!empty($totalattics)) $property[TAG_ATTICS] = $totalattics;

    $cellar = array();
    $totalcellars = array();
    if(!empty($cellardesc)) 		 $cellar[TAG_CELLAR_DESC_NL]=$cellardesc;
    if(!empty($cellarsurface)) 		 $cellar[TAG_CELLAR_SURFACE]=$cellarsurface;
    if(!empty($cellar)) $totalcellars[] = $cellar;
    if(!empty($totalcellars)) $property[TAG_CELLARS] = $totalcellars;

    $toilet = array();
    $totaltoilets = array();
    if(!empty($toiletdesc)) 		 $toilet[TAG_TOILET_DESC_NL]=$toiletdesc;
    if(!empty($toiletsurface)) 		 $toilet[TAG_TOILET_SURFACE]=$toiletsurface;
    if(!empty($toilet)) $totaltoilets[] = $toilet;
    if(!empty($totaltoilets)) $property[TAG_TOILETS] = $totaltoilets;

    $garage = array();
    $totalgarages = array();
    if(!empty($garagedesc)) 		 $garage[TAG_GARAGE_DESC_NL]=$garagedesc;
    if(!empty($garagesurface)) 		 $garage[TAG_GARAGE_SURFACE]=$garagesurface;
    if(!empty($garage)) $totalgarages[] = $garage;
    if(!empty($totalgarages)) $property[TAG_GARAGES] = $totalgarages;

    $kitchen = array();
    $totalkitchens = array();

    if(!empty($kitchendesc)) 		 $kitchen[TAG_KITCHEN_DESC_NL]=$kitchendesc;
    if(!empty($kitchensurface)) 		 $kitchen[TAG_KITCHEN_SURFACE]=$kitchensurface;
    if(!empty($kitchen)) $totalkitchens[] = $kitchen;
    if(!empty($totalkitchens)) $property[TAG_KITCHENS] = $totalkitchens;

    $storage = array();
    $totalstorages = array();
    if(!empty($storagedesc)) 		 $storage[TAG_STOREROOM_DESC_NL]=$storagedesc;
    if(!empty($storagesurface)) 		 $storage[TAG_STOREROOM_SURFACE]=$storagesurface;
    if(!empty($storage)) $totalstorages[] = $storage;
    if(!empty($totalstorages)) $property[TAG_STOREROOMS] = $totalstorages;

    $terrace = array();
    $totalterraces = array();
    if(!empty($terracedesc)) 		 $terrace[TAG_TERRACE_DESC_NL]=$terracedesc;
    if(!empty($terracesurface)) 		 $terrace[TAG_TERRACE_SURFACE]=$terracesurface;
    if(!empty($terrace)) $totalterraces[] = $terrace;
    if(!empty($totalterraces)) $property[TAG_TERRACES] = $totalterraces;

    $living = array();
    $totallivings = array();
    if(!empty($livingdesc)) 		 $living[TAG_LIVING_DESC_NL]=$livingdesc;
    if(!empty($livingsurface)) 		 $living[TAG_LIVING_SURFACE]=$livingsurface;
    if(!empty($living)) $totallivings[] = $living;
    if(!empty($totallivings)) $property[TAG_LIVINGS] = $totallivings;

    if(empty($bedroomtotal) && !empty($room))  $bedroomtotal=$room;
    if(!empty($bedroomtotal))  $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT]=$bedroomtotal;

    if(!empty($livingtotal))  $property[TAG_LIVINGS][TAG_TOTAL_AMOUNT]=$livingtotal;
    if(!empty($toilettotal)) $property[TAG_TOILETS][TAG_TOTAL_AMOUNT]=$toilettotal;
    if(!empty($cellartotal)) $property[TAG_CELLARS][TAG_TOTAL_AMOUNT]=$cellartotal;
    if(!empty($kitchentotal)) $property[TAG_KITCHENS][TAG_TOTAL_AMOUNT]=$kitchentotal;

    if(!empty($garagetotal)) $property[TAG_GARAGES][TAG_TOTAL_AMOUNT]=$garagetotal;
    if(!empty($terracetotal)) $property[TAG_TERRACES][TAG_TOTAL_AMOUNT]=$terracetotal;
    if(!empty($storagetotal)) $property[TAG_STOREROOMS][TAG_TOTAL_AMOUNT]=$storagetotal;
    if(!empty($attictotal)) $property[TAG_ATTICS][TAG_TOTAL_AMOUNT]=$attictotal;

    if(!empty($garagetotal)) $property[TAG_GARAGES][TAG_TOTAL_AMOUNT]=$garagetotal;
    $property[TAG_GARDEN_AVAILABLE] =get_var($vars,'tuin') == 'Ja' ? 1 : '';
    $parkingtotal=get_var($vars,'parkeerplaatsen','!(\d+)!');
    if(!empty($parkingtotal))  $property[TAG_PARKINGS_TOTAL]=$parkingtotal;


    $property[TAG_FILES] = $parser->extract_xpath("a[contains(@href, 'pdf')]", RETURN_TYPE_ARRAY, function($files)
	 {
		 $fileUrls = array();
		 foreach($files as $file)
		 {
			 if(!empty($file)) $fileUrls[] = array(TAG_FILE_URL_NL => "http://www.hetlandgoed.be/".str_replace('../','',$file));
		 }
		 return $fileUrls;
    });


	$unmatched_variables = array();
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	}
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;

    // Most Important 
    if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
    $property['planning_proceeding'] = 0;
    
    
    if(!isset($property['planning_permission']) || empty($property['planning_permission']))
    $property['planning_permission'] = 0;
    
    
    if(!isset($property['subdivision_permit']) || empty($property['subdivision_permit']))
    $property['subdivision_permit'] = 0;
    
    
    if(!isset($property['planning_proceeding']) || empty($property['planning_proceeding']))
    $property['planning_proceeding'] = 0;
    
    
    if(!isset($property['most_recent_destination']) || empty($property['most_recent_destination']))
    $property['most_recent_destination'] = 0;

    if(empty($property[TAG_CITY]))
        return;

    debug($property);

	// WRITING item data to output.xml file
	CrawlerTool::saveProperty($property);
}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function debug($obj, $e = false)
{
    echo "<pre>";
    print_r($obj);
    echo "</pre>";
    if($e)
      exit;
    
}