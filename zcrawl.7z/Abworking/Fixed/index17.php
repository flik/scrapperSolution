<?php
require_once("../crawler_classes.php");
$crawler->set_script_dir(realpath(dirname(__FILE__)).'/');


//$crawler->enable_delay_between_requests(5,15);
//$crawler->use_cookies(true);
//$crawler->clean_cookies();
//$crawler->use_gzip(false);


$startPages[STATUS_FORSELL] = array
(
'http://www.promimo.be/ShowList.aspx?goal=0&type=1%2c2%2c7%2c4%2c5%2c6%2c9&language=2&from=search&cp=2' => TYPE_NONE,
);

$startPages[STATUS_TORENT] = array
(
'http://www.promimo.be/ShowList.aspx?Goal=1&Type=1,2,7,4,5,6,9&Language=2&from=search' =>TYPE_NONE,
);

CrawlerTool::startXML();


foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
	    $html = $crawler->request($page_url);
		processPage($crawler, $status, $type, $html);
		$cp = 2;
		while(true) {
            if(!preg_match("/&cp=$cp/",$html,$res)) break;
			echo "Downloading page content..." . "<br />";
			$html = $crawler->request($page_url . "&cp=". $cp);
			echo "Complete downloading page content..." . "<br />";

			// process page content
			echo "Processing page ..." . "<br />";
			$numOfItem = processPage($crawler, $status, $type, $html);
			echo "Complete processing page ..." . "<br /><br />";
			$cp += 1;
		}
	}
}


CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';

function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $properties = array();

    $parser = new PageParser($html);

    $nodes = $parser->extract_regex("/objectid=(\d+)/", RETURN_TYPE_ARRAY);

    $items = array();
	foreach($nodes as $node)
    {
        $property = array();
        $property[TAG_STATUS] = $status;
        $property[TAG_TYPE] = $type;
        $property[TAG_UNIQUE_URL_FR] = "http://www.promimo.be/showobject.aspx?objectid=" . $node;
        $property[TAG_UNIQUE_ID] =  $node;

        if(in_array($property[TAG_UNIQUE_ID], $properties)) continue;
        $properties[] = $property[TAG_UNIQUE_ID];

        $items[] = array("item"=>$property, "itemUrl" => $property[TAG_UNIQUE_URL_FR]);
	}

    foreach($items as $item)
    {
        // keep track of number of properties processed
        $propertyCount += 1;

        // process item to obtain detail information
        echo "--------- Processing property #$propertyCount ...";
        processItem($crawler, $item["item"], $crawler->request($item["itemUrl"]));
        echo "--------- Completed<br />";
    }

    return sizeof($items);
}


function getUniqueId($url) {
	preg_match("/objectid=(\d+)/", $url, $match);
	if($match) return $match[1];
}

/**
 * Download and extract item detail information
 */

function processItem($crawler, $property ,$type)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_FR]);
    $parser = new PageParser($html, true);
    $parser->deleteTags(array("script", "style"));

	$node = $parser->getNode("table[@cellspacing = '5']/tr/td[@class = 'DetailTitle']");
	if($node) {
        $text = $parser->getText($node);
		preg_match("/(\d{4,})\s(.*)/", $text, $match);
		if($match) {
			$property[TAG_ZIP] = $match[1];
			$property[TAG_CITY] = trim(preg_replace("/\(.*\)|\d/", "", $match[2]));
		}
	}
	
	$property[TAG_PLAIN_TEXT_ALL_FR] = $parser->extract_xpath("table[contains(@id, 'ExistObject')]");
	$property[TAG_PRICE] = $parser->extract_xpath("td[b[contains(text(), 'Prix')]]/following-sibling::td[2]",RETURN_TYPE_NUMBER);

	$property[TAG_PICTURES] = $parser->extract_xpath("a[@rel = 'lightbox[pand_detail]']/@href", RETURN_TYPE_ARRAY, function($pics)
	{
		$picUrls = array();
		foreach($pics as $pic){
		        if(stripos($pic, "no_pic.gif") !== false) continue;
		        $picUrls[] = array(TAG_PICTURE_URL => "http://www.promimo.be/" . str_replace("S.jpg", "L.jpg", $pic));
     	}

		return $picUrls;
	});


    $property[TAG_TEXT_DESC_FR]=preg_match('/"NoneField">Description.*?<body>(.*?)<\/body>/si',$html,$res) ? html_entity_decode( strip_tags ($res[1])) : '';
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($parser->extract_xpath("head/title"));
	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType(strtoupper($parser->extract_xpath("h1")));
	#$property[TAG_TEXT_DESC_FR] = trim(substr (trim (preg_replace("/&nbsp;|\n|\r|\s+|TE KOOP:/is", " ", html_entity_decode( strip_tags ($shortdescr[1])))), 0, 255));


	if (preg_match('!GoogleX=([0-9.]+)&GoogleY=([0-9.]+)&!',$html,$res))
	{
		$property[TAG_LATITUDE] = $res[1];
		$property[TAG_LONGITUDE] = $res[2];
	}

    $html1=str_replace('<td width="5%" align="Center" Class="DetailFieldLabel"><B>:</B></td>','',$html);
 	//parse fields
	$vars = array();
	preg_match_all('!<td width="30%" Class="DetailFieldLabel"><B>([^<>]+)</B></td>\s+<td align="Left" width="65%" Class="DetailFieldValue">([^<>]+)<!',$html1,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim(strip_tags($arr[1]));
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$arr[1] = preg_replace('!nbsp!','',$arr[1]);
		$vars[$arr[1]] = trim(strip_tags($arr[2]));
		#echo '<br>';
	}
	preg_match_all('!<td width="35%" align="left" nowrap="">([^<>]+)</td>\s+<td width="65%" align="Left">\s+<b>([^<>]+)<!',$html,$res,PREG_SET_ORDER);

	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim(strip_tags($arr[1]));
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$arr[1] = preg_replace('!nbsp!','',$arr[1]);
		$vars[$arr[1]] = trim(strip_tags($arr[2]));
		#echo '<br>';
	}
	preg_match_all('!<td width="30%" align="left" nowrap="">([^<>]+)</td>\s+<td align="left"><strong>([^<>]+)<!',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim(strip_tags($arr[1]));
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$arr[1] = preg_replace('!nbsp!','',$arr[1]);
		$vars[$arr[1]] = trim(strip_tags($arr[2]));
		#echo '<br>';
	}
	preg_match_all('!<td width="35%" align="left" nowrap="">([^<>]+)</td><td width="65%" align="left"><strong>([^<>]+)<!',$html,$res,PREG_SET_ORDER);
	foreach ($res as $arr)
	{
		$arr[1] = strtolower($arr[1]);
		$arr[1] = trim(strip_tags($arr[1]));
		$arr[1] = preg_replace('![^a-z0-9_\-\. ]!','',$arr[1]);
		$arr[1] = preg_replace('!nbsp!','',$arr[1]);
		$vars[$arr[1]] = trim(strip_tags($arr[2]));
		#echo '<br>';
	}
	if (isset($vars['prix'])) {unset($vars['prix']);}
	if (isset($vars['commune'])) {unset($vars['commune']);}
	if (isset($vars['id bien'])) {unset($vars['id bien']);}

	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_FR], 999);

	if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_PLAIN_TEXT_ALL_FR], 999);

    $property[TAG_HEATING_FR] = get_var($vars,'chauffage');
    $property[TAG_SURFACE_CONSTRUCTION]          = str_replace(',','.',get_var($vars,'superficie totale','!([0-9,]+)!'));
    $property[TAG_PROPERTY_TAX]=get_var($vars,'charges','!(\d+)!');
    $totalfloor = get_var($vars,'nbr. tages btiment','!(\d+)!');
    if(!empty($totalfloor)) $property[TAG_AMOUNT_OF_FLOORS]=$totalfloor;
    $property[TAG_SURFACE_LIVING_AREA] = get_var($vars,'superficie construite','!(\d+)!');
    if(empty($property[TAG_SURFACE_LIVING_AREA])) $property[TAG_SURFACE_LIVING_AREA] = get_var($vars,'superficie habitable','!(\d+)!');
    if(empty($property[TAG_SURFACE_LIVING_AREA])) $property[TAG_SURFACE_LIVING_AREA] = get_var($vars,'superficie living','!(\d+)!');

    $property[TAG_KI] = get_var($vars,'myki','!(\d+)!');
    $property[TAG_SURFACE_GROUND] = get_var($vars,'superficie terrain','!(\d+)!');
    $property[TAG_EPC_VALUE]=get_var($vars,'peb','!(\d+)!');
    $property[TAG_CONSTRUCTION_YEAR]      = get_var($vars,'anne de construction2','!(\d+)!');
    $property[TAG_SHOWERS_TOTAL]=	get_var($vars,'nombre de salles de douche','!(\d+)!');
    $text=get_var($vars,'etagetotal');
    if(preg_match('/(\d+)\/(\d+)/',$text,$res)){
        $property[TAG_FLOOR]= $res[1];
        $property[TAG_AMOUNT_OF_FLOORS]=$res[2];
    }
    $property[TAG_GARDEN_AVAILABLE]=get_var($vars,'jardin') === 'Oui' ? 1 : '';
    $bedrooms=get_var($vars,'nombre de chambres','!(\d+)!');
    if(!empty($bedrooms)) $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT]=$bedrooms;
    $livings=get_var($vars,'opp. woonkamer');
    $Garages=get_var($vars,'nombre de garages');
    if(empty($Garages)) $Garages=get_var($vars,'garage');


    $bathrooms=get_var($vars,'nombre de salles de bain');
    $toilets=get_var($vars,'toilet');
    $kitchens=get_var($vars,'cuisine');
    $storages=get_var($vars,'opp. berging');
    $terraces=get_var($vars,'terrasse');
    $cellars=get_var($vars,'opp. kelder');
    $halls=get_var($vars,'hal','!(\d+)!');
    $studies=get_var($vars,'kantoor','!(\d+)!');
    $freepossesions=get_var($vars,'praktijkruimte');
    $attics=get_var($vars,'opp. zolder');
    $rooms=get_var($vars,'aantal slk.');
    if(!empty($rooms)) $room=$parser->regex("/(\d)$/", $rooms);


    if(!empty($attics)) $attictotal=$parser->regex("/(\d)$/", $attics);
    if(!empty($livings)) $livingtotal=$parser->regex("/(\d)$/", $livings);
    if(!empty($Garages)) $garagetotal=$parser->regex("/(\d)$/", $Garages);
    if(!empty($bathrooms)) $bathroomtotal=$parser->regex("/(\d)$/", $bathrooms);
    if(!empty($toilets)) $toilettotal=$parser->regex("/(\d)$/", $toilets);
    if(!empty($kitchens)) $kitchentotal=$parser->regex("/(\d)$/", $kitchens);
    if(!empty($storages)) $storagetotal=$parser->regex("/(\d)$/", $storages);
    if(!empty($terraces)) $terracetotal=$parser->regex("/(\d)$/", $terraces);
    if(!empty($cellars)) $cellartotal=$parser->regex("/(\d)$/", $cellars);
    if(!empty($halls)) $halltotal=$parser->regex("/(\d)$/", $halls);
    if(!empty($studies)) $studytotal=$parser->regex("/(\d)$/", $studies);
    if(!empty($freepossesions)) $freepossesiontotal=$parser->regex("/(\d)$/", $freepossesions);

    if(!empty($attics)) $atticsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $attics);
    if(!empty($livings)) $livingsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $livings);
    if(!empty($Garages)) $garagesurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $Garages);
    if(!empty($bathrooms)) $bathroomsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $bathrooms);
    if(!empty($toilets)) $toiletsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $toilets);
    if(!empty($kitchens)) $kitchensurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $kitchens);
    if(!empty($storages)) $storagesurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $storages);
    if(!empty($terraces)) $terracesurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $terraces);
    if(!empty($cellars)) $cellarsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $cellars);
    if(!empty($halls)) $hallsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $halls);
    if(!empty($studies)) $studysurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $studies);
    if(!empty($freepossesions)) $freepossesionsurface=$parser->regex("/((\d+,\d+)|(\d+))\sm/", $freepossesions);

    $atticdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $attics);

    $garagedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $Garages);
    $bathroomdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $bathrooms);
    $toiletdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $toilets);
    $kitchendesc=$parser->regex("/([a-zA-Z_-\s]*)/", $kitchens);
    $storagedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $storages);
    $terracedesc=$parser->regex("/([a-zA-Z_-\s]*)/", $terraces);
    $cellardesc=$parser->regex("/([a-zA-Z_-\s]*)/", $cellars);
    $livingdesc=$parser->regex("/([a-zA-Z_-\s]*)/", $livings);
    $floorplandesc=$parser->regex("/([a-zA-Z_-\s]*)/", $parser->extract_xpath("Grondplannen"));
    $halldesc=$parser->regex("/([a-zA-Z_-\s]*)/", $halls);
    $studydesc=$parser->regex("/([a-zA-Z_-\s]*)/", $studies);
    $freepossesiondesc=$parser->regex("/([a-zA-Z_-\s]*)/", $freepossesions);

    $halls = array();
    $totalhalls = array();
    if(!empty($halldesc)) 		 $halls[TAG_HALL_DESC_FR]=$halldesc;
    if(!empty($hallsurface)) 		 $halls[TAG_HALL_SURFACE]=$hallsurface;
    if(!empty($halls)) $totalhalls[] = $halls;
    if(!empty($totalhalls)) $property[TAG_halls] = $totalhalls;

    $freepossesion = array();
    $totalfreepossesions = array();
    if(!empty($freepossesiondesc)) 		 $freepossesion[TAG_FREE_PROFESSION_DESC_FR]=$freepossesiondesc;
    if(!empty($freepossesionsurface)) 		 $freepossesion[TAG_FREE_PROFESSION_SURFACE]=$freepossesionsurface;
    if(!empty($freepossesion)) $totalfreepossesions[] = $freepossesion;
    if(!empty($totalfreepossesions)) $property[TAG_FREE_PROFESSIONS] = $totalfreepossesions;

    $study = array();
    $totalstudys = array();
    if(!empty($studydesc)) 		 $study[TAG_STUDY_DESC_FR]=$studydesc;
    if(!empty($studysurface)) 		 $study[TAG_STUDY_SURFACE]=$studysurface;
    if(!empty($study)) $totalstudys[] = $study;
    if(!empty($totalstudys)) $property[TAG_STUDIES] = $totalstudys;

    $attic = array();
    $totalattics = array();
    if(!empty($atticdesc)) 		 $bathroom[TAG_ATTIC_DESC_FR]=$atticdesc;
    if(!empty($atticsurface)) 		 $bathroom[TAG_ATTIC_SURFACE]=$atticsurface;
    if(!empty($attic)) $totalattics[] = $attic;
    if(!empty($totalattics)) $property[TAG_ATTICS] = $totalattics;

    $cellar = array();
    $totalcellars = array();
    if(!empty($cellardesc)) 		 $cellar[TAG_CELLAR_DESC_FR]=$cellardesc;
    if(!empty($cellarsurface)) 		 $cellar[TAG_CELLAR_SURFACE]=$cellarsurface;
    if(!empty($cellar)) $totalcellars[] = $cellar;
    if(!empty($totalcellars)) $property[TAG_CELLARS] = $totalcellars;

    $toilet = array();
    $totaltoilets = array();
    if(!empty($toiletdesc)) 		 $toilet[TAG_TOILET_DESC_FR]=$toiletdesc;
    if(!empty($toiletsurface)) 		 $toilet[TAG_TOILET_SURFACE]=$toiletsurface;
    if(!empty($toilet)) $totaltoilets[] = $toilet;
    if(!empty($totaltoilets)) $property[TAG_TOILETS] = $totaltoilets;

    $garage = array();
    $totalgarages = array();
    if(!empty($garagedesc)) 		 $garage[TAG_GARAGE_DESC_FR]=$garagedesc;
    if(!empty($garagesurface)) 		 $garage[TAG_GARAGE_SURFACE]=$garagesurface;
    if(!empty($garage)) $totalgarages[] = $garage;
    if(!empty($totalgarages)) $property[TAG_GARAGES] = $totalgarages;

    $kitchen = array();
    $totalkitchens = array();

    if(!empty($kitchendesc)) 		 $kitchen[TAG_KITCHEN_DESC_FR]=$kitchendesc;
    if(!empty($kitchensurface)) 		 $kitchen[TAG_KITCHEN_SURFACE]=$kitchensurface;
    if(!empty($kitchen)) $totalkitchens[] = $kitchen;
    if(!empty($totalkitchens)) $property[TAG_KITCHENS] = $totalkitchens;

    $storage = array();
    $totalstorages = array();
    if(!empty($storagedesc)) 		 $storage[TAG_STOREROOM_DESC_FR]=$storagedesc;
    if(!empty($storagesurface)) 		 $storage[TAG_STOREROOM_SURFACE]=$storagesurface;
    if(!empty($storage)) $totalstorages[] = $storage;
    if(!empty($totalstorages)) $property[TAG_STOREROOMS] = $totalstorages;

    $terrace = array();
    $totalterraces = array();
    if(!empty($terracedesc)) 		 $terrace[TAG_TERRACE_DESC_FR]=$terracedesc;
    if(!empty($terracesurface)) 		 $terrace[TAG_TERRACE_SURFACE]=$terracesurface;
    if(!empty($terrace)) $totalterraces[] = $terrace;
    if(!empty($totalterraces)) $property[TAG_TERRACES] = $totalterraces;

    $living = array();
    $totallivings = array();
    if(!empty($livingdesc)) 		 $living[TAG_LIVING_DESC_FR]=$livingdesc;
    if(!empty($livingsurface)) 		 $living[TAG_LIVING_SURFACE]=$livingsurface;
    if(!empty($living)) $totallivings[] = $living;
    if(!empty($totallivings)) $property[TAG_LIVINGS] = $totallivings;

    if(empty($bedroomtotal) && !empty($room))  $bedroomtotal=$room;
   # if(!empty($bedroomtotal))  $property[TAG_BEDROOMS][TAG_TOTAL_AMOUNT]=$bedroomtotal;

    if(!empty($livingtotal))  $property[TAG_LIVINGS][TAG_TOTAL_AMOUNT]=$livingtotal;
    if(!empty($toilettotal)) $property[TAG_TOILETS][TAG_TOTAL_AMOUNT]=$toilettotal;
    if(!empty($cellartotal)) $property[TAG_CELLARS][TAG_TOTAL_AMOUNT]=$cellartotal;
    if(!empty($kitchentotal)) $property[TAG_KITCHENS][TAG_TOTAL_AMOUNT]=$kitchentotal;

    if(!empty($garagetotal)) $property[TAG_GARAGES][TAG_TOTAL_AMOUNT]=$garagetotal;
    if(!empty($terracetotal)) $property[TAG_TERRACES][TAG_TOTAL_AMOUNT]=$terracetotal;
    if(!empty($storagetotal)) $property[TAG_STOREROOMS][TAG_TOTAL_AMOUNT]=$storagetotal;
    if(!empty($attictotal)) $property[TAG_ATTICS][TAG_TOTAL_AMOUNT]=$attictotal;

    if(!empty($garagetotal)) $property[TAG_GARAGES][TAG_TOTAL_AMOUNT]=$garagetotal;
    $parkingtotal=get_var($vars,'parking') == 'Oui' ? 1 : '';
    if(!empty($parkingtotal))  $property[TAG_PARKINGS_TOTAL]=$parkingtotal;


	$unmatched_variables = array();
	foreach ($vars as $label => $value)
	{
		$unmatched_variables[] = array(TAG_VARIABLE_LABEL => $label, TAG_VARIABLE_VALUE => $value);
	}
	$property[TAG_UNMATCHED_VARIABLES] = $unmatched_variables;


    CrawlerTool::saveProperty($property);

}


function get_var(&$vars,$field,$regex = '')
{
	if (isset($vars[$field]))
	{
		$x = $vars[$field];
		unset($vars[$field]);

		if (!empty($regex))
		{
				return (preg_match($regex,$x,$res)) ? $res[1] : false;
		}
		return trim($x);
	}

	return false;
}

function getvalue($parser,$start,$follow) {
    $nodes = $parser->getNodes("h1[contains(text(), $start)]/following-sibling::p/text()");
    foreach($nodes as $node) {
        $text = $parser->GetText($node);
        if(stripos($text, $follow) !== false) {
            $n = $parser->getNodes("following-sibling::strong[1]",$node);
            if($n) return $parser->GetText($n);
        }
    }
}

?>
