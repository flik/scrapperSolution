


<?php



$html = '<a href="viewEstates.action?estate.status=FOR_SALE&estate.status=OPTION_FOR_SALE&estate.status=SOLD&locale=nl_BE&orderBy=e.websiteStats.latestPublication.creationDate+desc&startRow=7">URL</a>';
$html .= ' <a href="viewEstates.action?estate.status=FOR_SALE&estate.status=OPTION_FOR_SALE&estate.status=SOLD&locale=nl_BE&orderBy=e.websiteStats.latestPublication.creationDate+desc&startRow=13">URLx</a>';

$url = preg_match_all('/(viewEstates\.action\?estate\.status\=)(.+)/', $html, $match);

$info = parse_url($match[1]);

debug($match); 
debug($info);

echo $info['scheme'].'://'.$info['host'];

/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for print array
function debug($obj, $e = false)
{
	echo "<pre>";
	print_r($obj);
	echo "</pre>";
	if($e)
	  exit;
	
}
 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//function for echo array
function debugx($obj, $e = false)
{
	echo "<br />************************<br/>";
	echo $obj;
	echo "<br/>************************<br/>";
	if($e)
	  exit;
	
}



?>


