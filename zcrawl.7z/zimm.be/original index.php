<?php
require_once("../crawler_classes.php");
$crawler->set_script_dir(realpath(dirname(__FILE__)).'/');

//$crawler->enable_delay_between_requests(5,15);
//$crawler->use_cookies(true);
//$crawler->clean_cookies();
//$crawler->use_gzip(false);




$startPages[STATUS_TORENT] = array
(
'http://www.zimm.be/projects.php?typeID=2&l=nl' => '',

);

$startPages[STATUS_FORSELL] = array
(
'http://www.zimm.be/projects.php?typeID=3&l=nl' => '',
);

CrawlerTool::startXML();


foreach($startPages as $status => $types)
{
	foreach($types as $page_url => $type)
	{
	    $html = $crawler->request($page_url);
		processPage($crawler, $status, $type, $html);

	}
}


CrawlerTool::endXML();

echo "<br /><b>Completed!!</b>";

echo '<br><a href="output.xml">Click here to view ouput</a>';


function processPage($crawler, $status, $type, $html)
{
    static $propertyCount = 0;
    static $projectCount = 0;

    static $properties = array();
    static $project = array();
    $count=0;
    $parser = new PageParser($html);


	preg_match_all("!<td class='thumbimg'>.*?<a href='project\.php\?projectID=(\d+)&l=nl'>.*?<div class='thumbtitle'>(.*?)</div>!s",$html,$res);
	foreach ($res[1] as $v)
	{
	    $property[TAG_STATUS]             = $status;
		echo $property[TAG_UNIQUE_URL_NL]   = 'http://www.zimm.be/project.php?projectID='.$v.'&l=nl';
		if(!empty($res[2][$count])){
		    $property[TAG_TYPE] = CrawlerTool::getPropertyType($res[2][$count]);
		    if(strpos($res[2][$count],"SOLD")) $property[TAG_STATUS]="sold";
		}
        $count=$count+1;
		$property[TAG_UNIQUE_ID]    = $v;
		echo $propertyCount += 1;
		flush();
		ob_flush();
		// process item to obtain detail information
		echo "--------- Processing property #$propertyCount ...";
		processItem($crawler,$property,$type,$status);
		echo "--------- Completed<br />";
	}

}

function getUniqueId($url) {
	preg_match("/bien=(\d+)/", $url, $match);
	if($match) return $match[1];
}


function processItem($crawler, $property ,$type)
{
    $html = $crawler->request($property[TAG_UNIQUE_URL_NL]);
    $parser = new PageParser($html);
    $parser->deleteTags(array("script", "style"));

	preg_match('!name="photos" width="" height="" border="0" hspace="\d+"></a>(.*?)<div id="googlemap">!s',$html,$res);
	$property[TAG_TEXT_DESC_NL]  =  trim(strip_tags($res[1]));

	if (preg_match('!xmlfile=(http://www.zimm.be/xml\.php\?projectID=\d+)!',$html,$res))
	{
		$r = $crawler->request($res[1]);
		if (preg_match('!<album id="gallerie" title="gallerie" lgPath="_images/" tnPath="_thumbs/" tn="[^<>]*" description="[^<>]*">(.*?)</album>!s',$r,$res))
		{
			$pic_urls = array();
			preg_match_all('!<img src="([^<>]+)" caption="[^<>]*" client="[^<>]*" thetitle="[^<>]*" />!',$r,$res1);
			foreach ($res1[1] as $v) {$pic_urls[] = array(TAG_PICTURE_URL=>'http://www.zimm.be/_images/'.$v);}
			$property[TAG_PICTURES]       = $pic_urls;


		}
	}

	if (preg_match('!src="http://maps.google.be/maps\?f=q&source=s_q&hl=nl&geocode=&q=([^&]+)&!',$html,$res))
	{
		$res[1] = urldecode($res[1]);

		$tmp = explode(',',$res[1]);

		if (isset($tmp[1]))
		{
			$property[TAG_CITY]         = trim($tmp[1]);
			$adres= trim($tmp[0]);
		}
		else
		{
			preg_match('!(.*)\s+(.+)!',$tmp[0],$res);
			$property[TAG_CITY]         = trim($res[2]);
			$adres = trim($res[1]);
		}
	}

    if(!empty($adres)){
		 $property[TAG_NUMBER] = trim(preg_replace("/[a-zA-Z\/\>\- ]/", "", $adres));
		 $property[TAG_STREET] = trim(preg_replace("/\(.*\)|\<br\s\/|\d|\/\>/", "", $adres));
    }


	if (empty($property[TAG_CITY]))
	{
		preg_match('!>([^<>]+)</div>\s*<div id="rightcolumn">!',$html,$res);
		if (stripos($res[1],'ZANDHOVEN')!==false)
		{
			$property[TAG_CITY] = 'ZANDHOVEN';
		}
		elseif (stripos($res[1],'KONTICH')!==false)
		{
			$property[TAG_CITY] = 'KONTICH';
		}
		elseif (stripos($res[1],'AARTSELAAR')!==false)
		{
			$property[TAG_CITY] = 'AARTSELAAR';
		}
		elseif (stripos($res[1],'MECHELEN')!==false)
		{
			$property[TAG_CITY] = 'MECHELEN';
		}
	}

    if(empty($property[TAG_TYPE])) $property[TAG_TYPE] = CrawlerTool::getPropertyType($property[TAG_TEXT_DESC_NL], 999);


    CrawlerTool::saveProperty($property);

}

?>